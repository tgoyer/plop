export * from '@/components';
import './styles/atlas.scss';
