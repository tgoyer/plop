import { getColors } from '@/utilities/colors';

const Colors = () => {
    const colors = getColors();

    return (
        <div>
            {getStatuses(colors).map((key) => (
                <ColorGroup colors={colors} id={key} />
            ))}
            <hr />
            {getPrimary(colors).map((key) => (
                <ColorGroup colors={colors} id={key} />
            ))}
            <hr />
            {getPalette(colors).map((key) => (
                <ColorGroup colors={colors} id={key} />
            ))}
        </div>
    );
};

export default Colors;

const ColorGroup = ({ colors, id }: any) => {
    const color = colors[id];
    return (
        <div className="atlas-flex atlas-flex-col atlas-gap-2 atlas-py-4">
            <div className="atlas-text-xs atlas-font-semibold atlas-uppercase">{id}</div>
            <div className="atlas-flex atlas-flex-row atlas-gap-4">
                {typeof color === 'string' ? (
                    <ColorCard hex={color} name={id} />
                ) : (
                    Object.keys(color).map((c, i) => {
                        const hex = color[c];
                        return <ColorCard key={i} hex={hex} name={c} />;
                    })
                )}
            </div>
        </div>
    );
};

const ColorCard = ({ name, hex }: any) => {
    return (
        <div className="atlas-flex atlas-flex-col atlas-items-start atlas-justify-center atlas-overflow-hidden atlas-text-xs">
            <div className={`atlas-w-full atlas-h-12 atlas-rounded-md ${name === 'white' ? 'atlas-border' : ''}`} style={{ backgroundColor: hex }}></div>
            <div className="atlas-p-2 atlas-min-w-20">
                <div className="atlas-lowercase">{String(name).toLowerCase() === 'default' ? `(${name})` : name}</div>
                <div className="atlas-font-light">{hex}</div>
            </div>
        </div>
    );
};

const getPalette = (colors: any) =>
    Object.keys(colors)
        .filter((c) => c !== 'current' && c !== 'transparent' && c !== 'black' && c !== 'white')
        .filter((c) => !['alert', 'information', 'primary', 'success', 'warning'].includes(c))
        .sort();
const getPrimary = (colors: any) =>
    Object.keys(colors)
        .filter((c) => c === 'black' || c === 'white')
        .sort();
const getStatuses = (colors: any) =>
    Object.keys(colors)
        .filter((c) => c !== 'current' && c !== 'transparent' && c !== 'black' && c !== 'white')
        .filter((c) => ['alert', 'information', 'primary', 'success', 'warning'].includes(c))
        .sort();
