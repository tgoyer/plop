import { Button, LinkButton, FormInput, FormCombobox, mapComboboxOptions } from '@/components';

const people = [
    { id: 1, name: 'Wade Cooper' },
    { id: 2, name: 'Arlene Mccoy' },
    { id: 3, name: 'Devon Webb' },
    { id: 4, name: 'Tom Cook' },
];
const peopleOptions = mapComboboxOptions(people, 'id', 'name');

const states = [
    { id: 'TN', name: 'Tennessee' },
    { id: 'FL', name: 'Florida' },
    { id: 'CA', name: 'California' },
    { id: 'NY', name: 'New York' },
];
const stateOptions = mapComboboxOptions(states, 'id', 'name');

const Form = () => {
    return (
        <div className="atlas-flex atlas-flex-col atlas-gap-4 atlas-bg-primary-bg atlas-p-8">
            <div className="atlas-flex atlas-flex-col lg:atlas-flex-row atlas-gap-4">
                <FormInput label="First Name" />
                <FormInput label="Second Name" />
            </div>
            <div className="atlas-flex atlas-flex-col lg:atlas-flex-row atlas-gap-4">
                <FormInput label="Address 1" />
                <FormInput label="Address 2" />
            </div>
            <div className="atlas-flex atlas-flex-col lg:atlas-flex-row atlas-gap-4">
                <div className="atlas-w-full atlas-flex atlas-flex-row atlas-gap-4">
                    <div className="atlas-w-full">
                        <FormInput label="City" />
                    </div>
                    <div className="atlas-w-1/4">
                        <FormCombobox label="State" mode="alert" message="Must choose a state." options={stateOptions} />
                    </div>
                    <div className="atlas-w-1/4">
                        <FormInput label="Zip" />
                    </div>
                </div>
            </div>
            <div className="atlas-flex atlas-flex-col lg:atlas-flex-row atlas-gap-4">
                <FormCombobox mode="warning" label="Some People" className="lg:w-60" options={peopleOptions} />
                <FormInput label="My Second Field" />
            </div>
            <div className="atlas-flex atlas-flex-col lg:atlas-flex-row atlas-gap-4">
                <FormInput label="My First Field" className="lg:w-40" />
                <FormInput mode="success" label="My Second Field" message="This value passed validation" />
            </div>
            <div className="atlas-flex atlas-flex-row atlas-justify-between">
                <div>
                    <LinkButton href="http://google.com">Go to Google.com</LinkButton>
                </div>
                <div className="atlas-flex atlas-flex-row atlas-gap-2">
                    <Button variation="none">Cancel</Button>
                    <Button>Submit</Button>
                </div>
            </div>
        </div>
    );
};

export default Form;
