import type { Meta, StoryObj } from '@storybook/react';

import Colors from '@/stories/Colors';

type Story = StoryObj<typeof Colors>;
const meta: Meta<typeof Colors> = {
    title: 'Utilities/Colors',
    component: Colors,
};

export default meta;

export const Scale: Story = {};
