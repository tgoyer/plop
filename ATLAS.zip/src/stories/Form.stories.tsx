import type { Meta, StoryObj } from '@storybook/react';

import Form from '@/stories/Form';

type Story = StoryObj<typeof Form>;
const meta: Meta<typeof Form> = {
    title: 'Examples/Form',
    component: Form,
};

export default meta;

export const Demo: Story = {};
