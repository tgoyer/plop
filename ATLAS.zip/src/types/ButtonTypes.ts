export type ButtonVariations = 'primary' | 'outline' | 'none';
export type ButtonSizes = 'sm' | 'md' | 'lg' | 'xl';
