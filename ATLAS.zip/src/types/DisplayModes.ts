export type DisplayModes = 'default' | 'alert' | 'information' | 'success' | 'warning';
