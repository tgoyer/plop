import { ButtonSizes, ButtonVariations } from '@/types/ButtonTypes';
import { DisplayModes } from '@/types/DisplayModes';

interface ButtonStyles {
    disabled?: boolean;
    full?: boolean;
    mode?: DisplayModes;
    rounded?: boolean;
    size?: ButtonSizes;
    variation?: ButtonVariations;
}

export const getStyles = ({ disabled = false, full = false, mode = 'default', rounded = true, size = 'md', variation = 'primary' }: ButtonStyles) => {
    return `${getDefault(disabled, rounded, size, full)} ${getSize(size)} ${getModeVariation(variation, mode)}`;
};

const getDefault = (disabled: boolean, rounded: boolean, size: ButtonSizes, full: boolean) => {
    const disabledCss = disabled ? 'atlas-opacity-30 atlas-cursor-not-allowed' : '';
    const roundedSize = size === 'sm' ? 'atlas-rounded' : size === 'md' ? 'atlas-rounded-md' : size === 'lg' ? 'atlas-rounded-lg' : size === 'xl' ? 'atlas-rounded-xl' : '';
    const roundedCss = rounded ? roundedSize : '';
    const fullCss = full ? 'atlas-w-full atlas-justify-center' : 'atlas-w-full atlas-justify-center sm:atlas-w-fit';
    return `atlas-flex atlas-flex-row atlas-items-center ${roundedCss} ${disabledCss} ${fullCss}`;
};

const getSize = (size: ButtonSizes): string => {
    switch (size) {
        case 'sm':
            return 'atlas-px-1 atlas-py-0 atlas-text-sm';
        case 'md':
            return 'atlas-px-2 atlas-py-1 atlas-text-sm';
        case 'lg':
            return 'atlas-px-4 atlas-py-2 atlas-text-base';
        case 'xl':
            return 'atlas-px-6 atlas-py-3 atlas-text-lg';
        default: {
            return '';
        }
    }
};

const getModeVariation = (variation: ButtonVariations, mode: DisplayModes) => {
    let rules: string[] = [];
    rules.push('atlas-border active:atlas-shadow-focus focus-visible:atlas-shadow-focus');
    if (variation === 'primary') {
        if (mode === 'alert') rules.push('atlas-bg-alert atlas-border-alert atlas-text-white hover:atlas-bg-alert-light');
        if (mode === 'default') rules.push('atlas-bg-primary atlas-border-primary atlas-text-white hover:atlas-bg-primary-light');
        if (mode === 'information') rules.push('atlas-bg-information atlas-border-information atlas-text-white hover:atlas-bg-information-light');
        if (mode === 'success') rules.push('atlas-bg-success atlas-border-success atlas-text-white hover:atlas-bg-success-light');
        if (mode === 'warning') rules.push('atlas-bg-warning atlas-border-warning atlas-text-white hover:atlas-bg-warning-light');
    } else if (variation === 'outline') {
        if (mode === 'alert') rules.push('atlas-border-alert atlas-text-alert active:atlas-bg-red-100 hover:atlas-bg-red-100');
        if (mode === 'default') rules.push('atlas-border-primary atlas-text-primary active:atlas-bg-gray-100 hover:atlas-bg-gray-100');
        if (mode === 'information') rules.push('atlas-border-information atlas-text-information active:atlas-bg-blue-100 hover:atlas-bg-blue-100');
        if (mode === 'success') rules.push('atlas-border-success atlas-text-success active:atlas-bg-green-100 hover:atlas-bg-green-100');
        if (mode === 'warning') rules.push('atlas-border-warning atlas-text-warning active:atlas-bg-yellow-100 hover:atlas-bg-yellow-100');
    } else if (variation === 'none') {
        rules.push('atlas-bg-transparent atlas-border-transparent active:atlas-border-transparent');
        if (mode === 'alert') rules.push('atlas-text-alert hover:atlas-bg-red-100');
        if (mode === 'default') rules.push('atlas-text-primary hover:atlas-bg-gray-100');
        if (mode === 'information') rules.push('atlas-text-information hover:atlas-bg-blue-100');
        if (mode === 'success') rules.push('atlas-text-success hover:atlas-bg-green-100');
        if (mode === 'warning') rules.push('atlas-text-warning hover:atlas-bg-yellow-100');
    }
    return rules.join(' ');
};
