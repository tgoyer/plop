import { AnchorHTMLAttributes, PropsWithChildren } from 'react';

import { getStyles } from '@/components/Button/styles';
import { ButtonSizes, DisplayModes } from '@/types';

interface LinkButtonProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
    className?: string;
    disabled?: boolean;
    mode?: DisplayModes;
    size?: ButtonSizes;
}

const LinkButton = ({ className = '', disabled = false, href, mode = 'default', size = 'md', ...rest }: PropsWithChildren<LinkButtonProps>) => {
    return (
        <a
            href={href ?? ''}
            className={`${getStyles({
                disabled,
                size,
                mode,
                full: false,
                rounded: true,
                variation: 'none',
            })} ${className}`}
            {...rest}
        />
    );
};

export default LinkButton;
