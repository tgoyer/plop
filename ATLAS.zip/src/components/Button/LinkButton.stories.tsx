import type { Meta, StoryObj } from '@storybook/react';
import { LinkButton } from '@/components';

type Story = StoryObj<typeof LinkButton>;
const meta: Meta<typeof LinkButton> = {
    title: 'Atoms/LinkButton',
    component: LinkButton,
    tags: ['autodocs'],
};

export default meta;

export const Demo: Story = {
    args: {
        children: 'Link Button',
        className: '',
        disabled: false,
        size: 'md',
        mode: 'default',
    },
};
