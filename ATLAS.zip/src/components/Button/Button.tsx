import { ButtonHTMLAttributes, PropsWithChildren, forwardRef } from 'react';

import { getStyles } from '@/components/Button/styles';
import { ButtonSizes, ButtonVariations, DisplayModes } from '@/types';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    mode?: DisplayModes;
    rounded?: boolean;
    size?: ButtonSizes;
    variation?: ButtonVariations;
    full?: boolean;
}

const Button = forwardRef<HTMLButtonElement, PropsWithChildren<ButtonProps>>((props, ref) => {
    const { children, className = '', disabled = false, full = false, mode = 'default', rounded = true, size = 'md', variation = 'primary', ...rest } = props;
    return (
        <button ref={ref} disabled={disabled} className={`${getStyles({ disabled, full, mode, rounded, size, variation })} ${className}`} {...rest}>
            {children}
        </button>
    );
});

Button.displayName = 'Button';

export default Button;
