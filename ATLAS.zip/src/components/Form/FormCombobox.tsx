import { PropsWithChildren } from 'react';

import { default as Combobox, ComboboxProps } from '../Combobox/Combobox';
import { default as FormField, FormFieldProps } from './FormField';

interface FormComboboxProps extends FormFieldProps, ComboboxProps {}

const FormCombobox = ({ label, message, mode, className, ...props }: PropsWithChildren<FormComboboxProps>) => {
    return (
        <FormField label={label} message={message} mode={mode} className={className}>
            <Combobox {...props}></Combobox>
        </FormField>
    );
};

export default FormCombobox;
