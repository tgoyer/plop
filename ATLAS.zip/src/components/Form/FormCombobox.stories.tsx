import { Meta, StoryObj } from '@storybook/react';
import { FormCombobox, mapComboboxOptions, ComboboxOption } from '@/components';

type Story = StoryObj<typeof FormCombobox>;
const meta: Meta<typeof FormCombobox> = {
    title: 'Forms/FormCombobox',
    component: FormCombobox,
    tags: ['autodocs'],
};

export default meta;

export const Demo = () => {
    //import { Combobox, mapComboboxOptions, ComboboxOption } from '@/components';

    // Sample data
    const people = [
        { id: 1, name: 'Wade Cooper' },
        { id: 2, name: 'Arlene Mccoy' },
        { id: 3, name: 'Devon Webb' },
        { id: 4, name: 'Tom Cook' },
        { id: 5, name: 'Tanya Fox' },
        { id: 6, name: 'Hellen Schmidt' },
    ];

    const options = mapComboboxOptions(people, 'id', 'name');

    const args = {
        label: 'Field Name',
        message: 'There is an error in the field',
        mode: 'default',
        className: 'atlas-bg-gray-200 atlas-p-4',
        options,
        defaultOption: options[0],
        onSelect: (item: ComboboxOption) => item,
    };
    return <FormCombobox {...args} />;
};
