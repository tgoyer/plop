import { PropsWithChildren } from 'react';
import { DisplayModes } from '@/types';

export interface FormFieldProps {
    className?: string | undefined;
    label?: string;
    message?: string;
    helpText?: string;
    mode?: DisplayModes;
}

const FormField = ({ label, message, mode = 'default', helpText, className, children }: PropsWithChildren<FormFieldProps>) => {
    const textClass = getTextClass(mode);

    return (
        <div className={`atlas-flex atlas-flex-col atlas-w-full ${className}`}>
            <label className="atlas-flex atlas-flex-col atlas-gap-2 atlas-truncate atlas-text-ellipsis" title={label}>
                <span className={`${textClass} atlas-text-sm atlas-font-semibold atlas-uppercase`}>{label}</span>
                {children}
            </label>
            {helpText != null && (
                <div>
                    <p className={`atlas-text-xs atlas-font-light atlas-py-2`}>{helpText}</p>
                </div>
            )}
            {message != null && (
                <div>
                    <p className={`${textClass} atlas-text-xs atlas-font-normal atlas-py-2 atlas-truncate atlas-text-ellipsis`} title={message}>
                        {message}
                    </p>
                </div>
            )}
        </div>
    );
};

export default FormField;

const getTextClass = (mode: DisplayModes) => {
    switch (mode) {
        case 'alert':
            return 'atlas-text-alert';
        case 'information':
            return 'atlas-text-information';
        case 'success':
            return 'atlas-text-success';
        case 'warning':
            return 'atlas-text-warning';
        default:
            return 'atlas-default';
    }
};
