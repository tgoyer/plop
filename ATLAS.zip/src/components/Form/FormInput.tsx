import { InputHTMLAttributes, PropsWithChildren } from 'react';

import { default as Input } from '../Input/Input';
import { default as FormField, FormFieldProps } from './FormField';

interface FormInputProps extends FormFieldProps, InputHTMLAttributes<HTMLInputElement> {}

const FormInput = ({ label, message, mode, className, ...props }: PropsWithChildren<FormInputProps>) => {
    return (
        <FormField label={label} message={message} mode={mode} className={className}>
            <Input {...props}></Input>
        </FormField>
    );
};

export default FormInput;
