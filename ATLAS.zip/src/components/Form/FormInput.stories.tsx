import { Meta, StoryObj } from '@storybook/react';
import { FormInput } from '@/components';

type Story = StoryObj<typeof FormInput>;
const meta: Meta<typeof FormInput> = {
    title: 'Forms/FormInput',
    component: FormInput,
    tags: ['autodocs'],
};

export default meta;

export const Demo: Story = {
    args: {
        label: 'Field Name',
        message: 'There is an error in the field',
        mode: 'default',
        className: 'atlas-bg-gray-200 atlas-p-4',
    },
};
