import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Button, Dialog } from '@/components';

type Story = StoryObj<typeof Dialog>;
const meta: Meta<typeof Dialog> = {
    title: 'Molecules/Dialog',
    component: Dialog,
    tags: ['autodocs'],
};

export default meta;

export const Demo = () => {
    const [open, setOpen] = useState<boolean>(false);

    return (
        <>
            <Button onClick={() => setOpen(true)}>Show Dialog</Button>
            <Dialog show={open} title="Show an alert?" onClose={() => setOpen(false)}>
                <div className="flex flex-col items-center justify-center gap-8">
                    <div className="flex flex-row items-center justify-end w-full gap-4 p-2">
                        <Button variation="none" onClick={() => setOpen(false)}>
                            Cancel
                        </Button>
                        <Button variation="primary" onClick={() => alert('Yay!')}>
                            Ok
                        </Button>
                    </div>
                </div>
            </Dialog>
        </>
    );
};
