import { Dialog as HLDialog, Transition as HLTransition } from '@headlessui/react';
import { Fragment, PropsWithChildren } from 'react';

interface DialogProps {
    show: boolean;
    title: string;
    onClose?: () => void;
}

const Dialog = ({ children, show = false, title, onClose }: PropsWithChildren<DialogProps>) => {
    const handleClose = () => {
        if (onClose != null) {
            onClose();
        }
    };

    return (
        <HLTransition show={show} as={Fragment}>
            <HLDialog as="div" className="atlas-relative atlas-z-10" onClose={handleClose}>
                <HLTransition.Child
                    as={Fragment}
                    enter="atlas-ease-out atlas-duration-300"
                    enterFrom="atlas-opacity-0"
                    enterTo="atlas-opacity-100"
                    leave="atlas-ease-in atlas-duration-200"
                    leaveFrom="atlas-opacity-100"
                    leaveTo="atlas-opacity-0"
                >
                    <div className="atlas-fixed atlas-inset-0 atlas-bg-black atlas-bg-opacity-25" />
                </HLTransition.Child>

                <div className="atlas-fixed atlas-inset-0 atlas-overflow-y-auto">
                    <div className="atlas-flex atlas-min-h-full atlas-items-center atlas-justify-center atlas-p-4 atlas-text-center">
                        <HLTransition.Child
                            as={Fragment}
                            enter="atlas-ease-out atlas-duration-300"
                            enterFrom="atlas-opacity-0 atlas-scale-95"
                            enterTo="atlas-opacity-100 atlas-scale-100"
                            leave="atlas-ease-in atlas-duration-200"
                            leaveFrom="atlas-opacity-100 atlas-scale-100"
                            leaveTo="atlas-opacity-0 atlas-scale-95"
                        >
                            <HLDialog.Panel className="atlas-w-full atlas-max-w-md atlas-transform atlas-overflow-hidden atlas-rounded-2xl atlas-bg-white atlas-p-6 atlas-text-left atlas-align-middle atlas-shadow-xl atlas-transition-all">
                                <HLDialog.Title as="h3" className="atlas-text-lg atlas-font-medium atlas-leading-6 atlas-text-gray-900">
                                    {title}
                                </HLDialog.Title>
                                {children}
                            </HLDialog.Panel>
                        </HLTransition.Child>
                    </div>
                </div>
            </HLDialog>
        </HLTransition>
    );
};

export default Dialog;
