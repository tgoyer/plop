import { Tab } from '@headlessui/react';
import { Children, PropsWithChildren, ReactNode, useMemo } from 'react';

function classNames(...classes: string[]) {
    return classes.filter(Boolean).join(' ');
}

const Tabs = ({ children }: PropsWithChildren<{}>) => {
    const titles = useMemo(() => {
        return Children.map(children, (child: any) => (child?.props != null ? child.props.title : null)).filter((c: any) => c != null);
    }, [children]);
    const panels = useMemo(() => {
        return Children.map(children, (child: any) => (child?.props != null ? child.props.children : null)).filter((c: any) => c != null);
    }, [children]);

    return (
        <div className="atlas-w-full">
            <Tab.Group>
                <Tab.List className="atlas-flex atlas-w-full atlas-space-x-1 atlas-rounded atlas-bg-white/50 atlas-p-1">
                    {titles.map((title: string, idx: number) => (
                        <Tab
                            key={idx}
                            className={({ selected }) =>
                                classNames(
                                    'atlas-w-full atlas-rounded-sm atlas-py-2.5 atlas-text-sm atlas-font-medium atlas-leading-5',
                                    'atlas-ring-white atlas-ring-opacity-60 atlas-ring-offset-2 atlas-ring-offset-blue-400 focus:atlas-outline-none focus:atlas-ring-2',
                                    selected ? 'atlas-bg-white atlas-text-information shadow' : 'atlas-text-primary-dark hover:atlas-bg-information/50 hover:atlas-text-white'
                                )
                            }
                        >
                            {title}
                        </Tab>
                    ))}
                </Tab.List>
                <Tab.Panels className="atlas-mt-2 atlas-w-full">
                    {panels.map((panel: ReactNode, idx: number) => (
                        <Tab.Panel
                            key={idx}
                            className={classNames('atlas-inset-0 atlas-rounded-md', 'atlas-ring-blue-400 focus:atlas-z-10 focus:atlas-outline-none focus:atlas-ring-2')}
                        >
                            {panel}
                        </Tab.Panel>
                    ))}
                </Tab.Panels>
            </Tab.Group>
        </div>
    );
};

export default Tabs;
