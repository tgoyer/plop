import type { Meta, StoryObj } from '@storybook/react';
import { Button, FormInput, LinkButton, Tabs, Tab } from '@/components';

type Story = StoryObj<typeof Tabs>;
const meta: Meta<typeof Tabs> = {
    title: 'Molecules/Tabs',
    component: Tabs,
    tags: ['autodocs'],
};

export default meta;

export const Demo = () => (
    <Tabs>
        <Tab title="Recent">
            <ul className="atlas-rounded-md atlas-bg-gray-100">
                <li className="atlas-p-3">
                    <h3>Recent</h3>
                    <h3 className="atlas-text-sm atlas-font-medium atlas-leading-5">Does drinking coffee make you smarter?</h3>
                </li>
                <li className="atlas-p-3">
                    <div className="atlas-flex atlas-flex-col lg:atlas-flex-row atlas-gap-4">
                        <FormInput label="My First Field" className="lg:w-40" />
                        <FormInput label="My Second Field" />
                    </div>
                    <div className="atlas-flex atlas-flex-row atlas-justify-between">
                        <div>
                            <LinkButton href="http://google.com">Go to Google.com</LinkButton>
                        </div>
                        <div className="atlas-flex atlas-flex-row atlas-gap-2">
                            <Button variation="none">Cancel</Button>
                            <Button>Submit</Button>
                        </div>
                    </div>
                </li>
            </ul>
        </Tab>
        <Tab title="Popular">
            <ul className="atlas-rounded-md atlas-bg-gray-100">
                <li className="atlas-p-3">
                    <h3>Popular</h3>
                    <h3 className="atlas-text-sm atlas-font-medium atlas-leading-5">Does drinking coffee make you smarter?</h3>
                </li>
                <li className="atlas-p-3">
                    <h3 className="atlas-text-sm atlas-font-medium atlas-leading-5">So you've bought coffee... now what?</h3>
                </li>
            </ul>
        </Tab>
        <Tab title="Trending">
            <ul className="atlas-rounded-md atlas-bg-gray-100">
                <li className="atlas-p-3">
                    <h3>Trending</h3>
                    <h3 className="atlas-text-sm atlas-font-medium atlas-leading-5">Does drinking coffee make you smarter?</h3>
                </li>
                <li className="atlas-p-3">
                    <h3 className="atlas-text-sm atlas-font-medium atlas-leading-5">So you've bought coffee... now what?</h3>
                </li>
            </ul>
        </Tab>
    </Tabs>
);
