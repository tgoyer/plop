import { PropsWithChildren, ReactNode } from 'react';

export interface TabProps {
    title: string;
}

const Tab = ({ title }: PropsWithChildren<TabProps>) => null;

export default Tab;
