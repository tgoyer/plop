import { ChangeEvent, Fragment, useMemo, useState } from 'react';
import { Combobox as HUICombobox, Transition as HUITransition } from '@headlessui/react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAnglesDown, faCheck } from '@fortawesome/free-solid-svg-icons';

import Input from '../Input/Input';

export interface ComboboxOption {
    key: string | number;
    value: string;
}

export interface ComboboxProps {
    options?: ComboboxOption[];
    disabled?: boolean;
    defaultOption?: ComboboxOption | null;
    onSelect?: (item: ComboboxOption) => void;
    onChange?: (value: string) => void;
}

const Combobox = ({ options = [], disabled = false, defaultOption = null, onChange, onSelect }: ComboboxProps) => {
    const [query, setQuery] = useState('');
    const [selectedItem, setSelectedItem] = useState(defaultOption);

    const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value;
        setQuery(value);
        if (onChange != null) {
            onChange(value);
        }
    };
    const handleSelect = (item: ComboboxOption) => {
        setSelectedItem(item);
        if (onSelect != null) {
            onSelect(item);
        }
    };

    const filteredItems = useMemo<ComboboxOption[]>(() => {
        return query === '' ? options : options.filter((item) => item.value.toLowerCase().replace(/\s+/g, '').includes(query.toLowerCase().replace(/\s+/g, '')));
    }, [options, query]);

    return (
        <div className="atlas-w-full">
            <HUICombobox value={selectedItem} onChange={handleSelect} disabled={disabled}>
                <div>
                    <div className="atlas-flex atlas-flex-row atlas-items-center atlas-justify-between atlas-w-full atlas-gap-2 atlas-overflow-hidden atlas-bg-white atlas-rounded atlas-cursor-default focus:atlas-outline-none focus-visible:atlas-ring-2 focus-visible:atlas-ring-white focus-visible:atlas-ring-opacity-75 focus-visible:atlas-ring-offset-2 focus-visible:atlas-ring-offset-blue-300">
                        <HUICombobox.Input
                            as={Input}
                            className="atlas-w-full atlas-px-4 atlas-py-2 atlas-text-sm atlas-leading-5 atlas-text-gray-900 atlas-border-none focus:atlas-ring-0"
                            displayValue={(item: ComboboxOption) => (item != null ? item.value : '')}
                            onChange={handleChange}
                        />
                        <HUICombobox.Button className="atlas-flex atlas-items-center atlas-px-4 atlas-py-2 atlas-text-gray-500 atlas-border-l atlas-border-gray-300">
                            <FontAwesomeIcon icon={faAnglesDown} />
                        </HUICombobox.Button>
                    </div>
                    <HUITransition
                        as={Fragment}
                        leave="atlas-transition atlas-ease-in atlas-duration-100"
                        leaveFrom="atlas-opacity-100"
                        leaveTo="atlas-opacity-0"
                        afterLeave={() => setQuery('')}
                    >
                        <HUICombobox.Options className="atlas-absolute atlas-z-10 atlas-w-fit atlas-py-1 atlas-mt-1 atlas-overflow-auto atlas-text-sm atlas-bg-white atlas-rounded atlas-shadow-lg atlas-max-h-60 atlas-ring-1 atlas-ring-black atlas-ring-opacity-5 focus:atlas-outline-none">
                            {filteredItems.length === 0 && query !== '' ? (
                                <div className="atlas-relative atlas-px-4 atlas-py-2 atlas-text-gray-500 atlas-cursor-default atlas-select-none">Nothing found.</div>
                            ) : (
                                filteredItems.map((item) => (
                                    <HUICombobox.Option
                                        key={item.key}
                                        className={({ active }) =>
                                            `atlas-relative atlas-select-none atlas-py-3 atlas-px-4 ${active ? 'atlas-bg-blue-600 atlas-text-white' : 'atlas-text-gray-900'}`
                                        }
                                        value={item}
                                    >
                                        {(props) => {
                                            const { selected, active } = props;
                                            return (
                                                <div className="atlas-flex atlas-flex-row atlas-items-center atlas-justify-start">
                                                    <span className={`atlas-pr-3 ${active ? 'atlas-text-white' : 'atlas-text-blue-600'}`}>
                                                        <FontAwesomeIcon icon={faCheck} className={!selected ? 'atlas-text-transparent' : ''} />
                                                    </span>
                                                    <span className={`atlas-block atlas-truncate ${selected ? 'atlas-font-medium' : 'atlas-font-normal'}`}>{item.value}</span>
                                                </div>
                                            );
                                        }}
                                    </HUICombobox.Option>
                                ))
                            )}
                        </HUICombobox.Options>
                    </HUITransition>
                </div>
            </HUICombobox>
        </div>
    );
};

export default Combobox;

export const mapComboboxOptions = (data: any[], keyField: string, valueField: string): ComboboxOption[] => {
    return data.map((item) => ({ key: item[keyField], value: item[valueField] }));
};
