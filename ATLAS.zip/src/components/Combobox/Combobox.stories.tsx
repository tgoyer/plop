import type { Meta, StoryObj } from '@storybook/react';

import { Combobox, mapComboboxOptions, ComboboxOption } from '@/components';

type Story = StoryObj<typeof Combobox>;
const meta: Meta<typeof Combobox> = {
    title: 'Atoms/Combobox',
    component: Combobox,
    tags: ['autodocs'],
};

export default meta;

export const Demo = () => {
    //import { Combobox, mapComboboxOptions, ComboboxOption } from '@/components';

    // Sample data
    const people = [
        { id: 1, name: 'Wade Cooper' },
        { id: 2, name: 'Arlene Mccoy' },
        { id: 3, name: 'Devon Webb' },
        { id: 4, name: 'Tom Cook' },
        { id: 5, name: 'Tanya Fox' },
        { id: 6, name: 'Hellen Schmidt' },
    ];

    const options = mapComboboxOptions(people, 'id', 'name');
    const handleSelected = (item: ComboboxOption) => console.log(item);

    return (
        <div className="atlas-h-full atlas-w-full atlas-bg-gray-400 atlas-px-10 atlas-py-16">
            <Combobox options={options} defaultOption={options[0]} onSelect={handleSelected} />
        </div>
    );
};
