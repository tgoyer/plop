import { Meta, StoryObj } from '@storybook/react';
import { Input } from '@/components';

type Story = StoryObj<typeof Input>;
const meta: Meta<typeof Input> = {
    title: 'Atoms/Input',
    component: Input,
    tags: ['autodocs'],
};

export default meta;

export const Demo: Story = {
    args: {
        label: 'Field Name',
        message: 'There is an error in the field',
        mode: 'default',
        className: 'border focus-visible:shadow-focus',
    },
};
