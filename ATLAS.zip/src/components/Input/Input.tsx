import { InputHTMLAttributes, PropsWithChildren, forwardRef } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {}

const Input = forwardRef<HTMLInputElement, PropsWithChildren<InputProps>>(({ className, type = 'text', ...props }, ref) => {
    return <input ref={ref} className={`atlas-px-2 atlas-py-2 atlas-text-sm atlas-bg-white atlas-w-full atlas-rounded ${className}`} type={type} {...props}></input>;
});

export default Input;
