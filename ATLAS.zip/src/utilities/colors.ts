import twColors from 'tailwindcss/colors';

export const getColors = () => {
    const colors = {
        transparent: 'transparent',
        current: 'currentColor',
        black: twColors.black,
        white: twColors.white,

        blue: twColors.sky,
        gray: twColors.neutral,
        green: twColors.emerald,
        red: twColors.rose,
        yellow: twColors.amber,
    };

    return {
        ...colors,
        primary: {
            dark: colors.gray[800],
            DEFAULT: colors.gray[700],
            light: colors.gray[500],
            bg: colors.gray[200],
        },
        alert: {
            dark: colors.red[700],
            DEFAULT: colors.red[600],
            light: colors.red[500],
        },
        information: {
            dark: colors.blue[700],
            DEFAULT: colors.blue[600],
            light: colors.blue[500],
        },
        success: {
            dark: colors.green[700],
            DEFAULT: colors.green[600],
            light: colors.green[500],
        },
        warning: {
            dark: colors.yellow[700],
            DEFAULT: colors.yellow[600],
            light: colors.yellow[500],
        },
    };
};
