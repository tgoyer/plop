#Atlas Design System

A set of fully accessible React components, designed to standardize user interface implementation at AB EIMT.

---

## Documentation

### Installing the latest version

1. In the root of your React application, create an new empty file named `.npmrc`. Add the these lines to the file:

    ```
    @ab-eimt:registry=https://pkgs.dev.azure.com/AB-EIMT/Research/_packaging/atlas-components/npm/registry/

    always-auth=true
    ```

1. Once that is complete, you can install the latest version by using:
   `npm install @ab-eimt/atlas-components`

Once the library is installed, you can use the components as you would from any other library.

```
import * as React from "react";
import { Button } from "@ab-eimt/atlas-components";

export const MyApp = () => (
  <div>
    <Button variation="outline">
      Send
    </Button>
  </div>
);
```

To view the component list, clone this repository and run the Story Book.

```
npm install
npm run sb
```

This will compile the library and open a web-browser where you will be able to browse all the available components.
