import { useState, useEffect, useCallback } from 'react';

export default function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [token, setToken] = useState(null);
    const [user, setUser] = useState(null);
    const [profile, setProfile] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    // Form states
    const [username, setUsername] = useState('demo');
    const [password, setPassword] = useState('password123');

    const API_URL = 'http://localhost:3001/api';

    const verifyToken = useCallback(async (tkn) => {
        try {
            const response = await fetch(`${API_URL}/users/verify`, {
                headers: {
                    Authorization: `Bearer ${tkn}`,
                },
            });

            if (response.ok) {
                const data = await response.json();
                setIsAuthenticated(true);
                setUser(data.user);
            } else {
                logout();
            }
        } catch (err) {
            console.error('Token verification failed:', err);
            logout();
        }
    }, []);

    const handleLogin = async () => {
        setError('');
        setLoading(true);

        try {
            const response = await fetch(`${API_URL}/users/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (response.ok) {
                sessionStorage.setItem('token', data.token);
                setToken(data.token);
                setUser(data.user);
                setIsAuthenticated(true);
            } else {
                setError(data.error || 'Login failed');
            }
        } catch (err) {
            setError('Network error. Make sure the BFF server is running on port 3001.');
        } finally {
            setLoading(false);
        }
    };

    const fetchProfile = async () => {
        setError('');
        setLoading(true);

        try {
            const response = await fetch(`${API_URL}/users/profile`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            const data = await response.json();

            if (response.ok) {
                setProfile(data);
            } else {
                setError(data.error || 'Failed to fetch profile');
            }
        } catch (err) {
            setError('Failed to fetch profile');
        } finally {
            setLoading(false);
        }
    };

    const logout = () => {
        sessionStorage.removeItem('token');
        setToken(null);
        setIsAuthenticated(false);
        setUser(null);
        setProfile(null);
        setError('');
    };

    useEffect(() => {
        const storedToken = sessionStorage.getItem('token');
        if (storedToken) {
            setToken(storedToken);
            verifyToken(storedToken);
        }
    }, [verifyToken]);

    if (!isAuthenticated) {
        return (
            <form style={styles.container}>
                <div style={styles.loginCard}>
                    <h1 style={styles.title}>JWT Authentication</h1>

                    <div style={styles.demoBox}>
                        <p style={styles.demoTitle}>Demo Credentials:</p>
                        <p style={styles.demoText}>Username: demo</p>
                        <p style={styles.demoText}>Password: password123</p>
                    </div>

                    <div style={styles.formGroup}>
                        <label style={styles.label}>Username</label>
                        <input
                            autoComplete="username"
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            style={styles.input}
                        />
                    </div>

                    <div style={styles.formGroup}>
                        <label style={styles.label}>Password</label>
                        <input
                            autoComplete="current-password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                            style={styles.input}
                        />
                    </div>

                    {error && (
                        <div style={styles.errorBox}>
                            <p style={styles.errorText}>{error}</p>
                        </div>
                    )}

                    <button
                        onClick={handleLogin}
                        disabled={loading}
                        style={{ ...styles.button, ...(loading ? styles.buttonDisabled : {}) }}
                    >
                        {loading ? 'Logging in...' : 'Login'}
                    </button>
                </div>
            </form>
        );
    }

    return (
        <div style={styles.dashboardContainer}>
            <div style={styles.dashboardContent}>
                <div style={styles.card}>
                    <div style={styles.header}>
                        <h1 style={styles.welcomeTitle}>Welcome, {user?.username}!</h1>
                        <button onClick={logout} style={styles.logoutButton}>
                            Logout
                        </button>
                    </div>

                    <div style={styles.successBox}>
                        <p style={styles.successTitle}>✓ Authenticated with JWT</p>
                        <p style={styles.successText}>Token contains AES-encrypted UserID</p>
                    </div>

                    <div style={styles.section}>
                        <h2 style={styles.sectionTitle}>User Information</h2>
                        <div style={styles.infoBox}>
                            <p style={styles.infoText}>
                                <span style={styles.bold}>Username:</span> {user?.username}
                            </p>
                            <p style={styles.infoText}>
                                <span style={styles.bold}>Email:</span> {user?.email}
                            </p>
                        </div>
                    </div>

                    <button
                        onClick={fetchProfile}
                        disabled={loading}
                        style={{ ...styles.primaryButton, ...(loading ? styles.buttonDisabled : {}) }}
                    >
                        {loading ? 'Loading...' : 'Fetch Profile (Protected Route)'}
                    </button>

                    {error && (
                        <div style={{ ...styles.errorBox, marginTop: '16px' }}>
                            <p style={styles.errorText}>{error}</p>
                        </div>
                    )}

                    {profile && (
                        <div style={styles.profileBox}>
                            <h3 style={styles.profileTitle}>Protected Profile Data</h3>
                            <div style={styles.profileContent}>
                                <p style={styles.profileText}>
                                    <span style={styles.bold}>User ID (decrypted):</span> {profile.id}
                                </p>
                                <p style={styles.profileText}>
                                    <span style={styles.bold}>Username:</span> {profile.username}
                                </p>
                                <p style={styles.profileText}>
                                    <span style={styles.bold}>Email:</span> {profile.email}
                                </p>
                                <p style={styles.profileMessage}>{profile.message}</p>
                            </div>
                        </div>
                    )}
                </div>

                <div style={{ ...styles.card, marginTop: '24px' }}>
                    <h2 style={styles.sectionTitle}>Architecture Notes</h2>
                    <ul style={styles.list}>
                        <li style={styles.listItem}>• JWT tokens contain AES-256-CBC encrypted UserID</li>
                        <li style={styles.listItem}>• Rijndael cipher (AES) protects sensitive user identifiers</li>
                        <li style={styles.listItem}>• BFF validates and decrypts tokens on protected routes</li>
                        <li style={styles.listItem}>• Token stored in sessionStorage for persistence</li>
                        <li style={styles.listItem}>• 24-hour token expiration</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

const styles = {
    container: {
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '16px',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        width: '100%',
    },
    loginCard: {
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
        padding: '32px',
        width: '100%',
    },
    title: {
        fontSize: '28px',
        fontWeight: 'bold',
        color: '#1a202c',
        marginBottom: '24px',
        textAlign: 'center',
        margin: '0 0 24px 0',
    },
    demoBox: {
        backgroundColor: '#ebf8ff',
        padding: '16px',
        borderRadius: '8px',
        border: '1px solid #90cdf4',
        marginBottom: '24px',
    },
    demoTitle: {
        fontSize: '14px',
        color: '#2c5282',
        fontWeight: '600',
        margin: '0 0 8px 0',
    },
    demoText: {
        fontSize: '14px',
        color: '#2b6cb0',
        margin: '4px 0',
    },
    formGroup: {
        marginBottom: '16px',
    },
    label: {
        display: 'block',
        color: '#4a5568',
        fontSize: '14px',
        fontWeight: '500',
        marginBottom: '8px',
    },
    input: {
        width: '100%',
        padding: '10px 16px',
        border: '1px solid #d1d5db',
        borderRadius: '8px',
        fontSize: '14px',
        boxSizing: 'border-box',
        outline: 'none',
        transition: 'border-color 0.2s',
    },
    button: {
        width: '100%',
        backgroundColor: '#3b82f6',
        color: 'white',
        padding: '10px 16px',
        borderRadius: '8px',
        border: 'none',
        fontSize: '14px',
        fontWeight: '500',
        cursor: 'pointer',
        transition: 'background-color 0.2s',
    },
    buttonDisabled: {
        backgroundColor: '#9ca3af',
        cursor: 'not-allowed',
    },
    errorBox: {
        backgroundColor: '#fef2f2',
        padding: '12px',
        borderRadius: '8px',
        border: '1px solid #fecaca',
        marginBottom: '16px',
    },
    errorText: {
        color: '#dc2626',
        fontSize: '14px',
        margin: 0,
    },
    dashboardContainer: {
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        padding: '32px',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        width: '100%',
    },
    dashboardContent: {
        margin: '0 auto',
    },
    card: {
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
        padding: '32px',
    },
    header: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '24px',
    },
    welcomeTitle: {
        fontSize: '28px',
        fontWeight: 'bold',
        color: '#1a202c',
        margin: 0,
    },
    logoutButton: {
        backgroundColor: '#dc2626',
        color: 'white',
        padding: '10px 24px',
        borderRadius: '8px',
        border: 'none',
        fontSize: '14px',
        fontWeight: '500',
        cursor: 'pointer',
        transition: 'background-color 0.2s',
    },
    successBox: {
        backgroundColor: '#f0fdf4',
        padding: '16px',
        borderRadius: '8px',
        border: '1px solid #86efac',
        marginBottom: '24px',
    },
    successTitle: {
        color: '#166534',
        fontWeight: '500',
        margin: '0 0 4px 0',
    },
    successText: {
        fontSize: '14px',
        color: '#16a34a',
        margin: 0,
    },
    section: {
        marginBottom: '24px',
    },
    sectionTitle: {
        fontSize: '20px',
        fontWeight: '600',
        color: '#374151',
        marginBottom: '12px',
        margin: '0 0 12px 0',
    },
    infoBox: {
        backgroundColor: '#f9fafb',
        padding: '16px',
        borderRadius: '8px',
    },
    infoText: {
        color: '#374151',
        margin: '8px 0',
        fontSize: '15px',
    },
    bold: {
        fontWeight: '500',
    },
    primaryButton: {
        backgroundColor: '#3b82f6',
        color: 'white',
        padding: '10px 24px',
        borderRadius: '8px',
        border: 'none',
        fontSize: '14px',
        fontWeight: '500',
        cursor: 'pointer',
        transition: 'background-color 0.2s',
    },
    profileBox: {
        backgroundColor: '#eef2ff',
        padding: '24px',
        borderRadius: '8px',
        border: '1px solid #c7d2fe',
        marginTop: '24px',
    },
    profileTitle: {
        fontSize: '18px',
        fontWeight: '600',
        color: '#312e81',
        marginBottom: '12px',
        margin: '0 0 12px 0',
    },
    profileContent: {
        display: 'flex',
        flexDirection: 'column',
        gap: '8px',
    },
    profileText: {
        color: '#3730a3',
        margin: 0,
        fontSize: '15px',
    },
    profileMessage: {
        color: '#4338ca',
        fontSize: '14px',
        fontStyle: 'italic',
        marginTop: '12px',
        margin: '12px 0 0 0',
    },
    list: {
        listStyle: 'none',
        padding: 0,
        margin: 0,
    },
    listItem: {
        color: '#374151',
        fontSize: '14px',
        marginBottom: '8px',
    },
};
