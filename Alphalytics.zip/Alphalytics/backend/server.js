const express = require('express');
const cors = require('cors');

const config = require('./appsettings.json');

// Configuration
// // // // // // // // // // // //
// Generate a JWT_Secret via cmd line:
//    node -e "console.log(require('crypto').randomBytes(32).toString('hex'));"
// // // // // // // // // // // //
const CORS = config.server.cors ?? true;
const PORT = config.server.port ?? 3001;

const app = express();
app.use(express.json());
app.use(cors(CORS));

app.use('/api/users', require('./controllers/users'));

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log('Test credentials: username=demo, password=password123');
});
