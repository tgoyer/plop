const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const config = require('../appsettings.json');

const { authenticateToken, encryptUserId } = require('../services/securityService');
const JWT_SECRET = config.jwt.secret;

// // // // // // // // // // // //
// Mock user database
// // // // // // // // // // // //
const users = [{ id: 'IA000001225', username: 'demo', password: 'password123', email: 'demo@example.com' }];
// // // // // // // // // // // //

// Login endpoint
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find((u) => u.username === username && u.password === password);

    if (user == null) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Encrypt the userId using AES
    const encryptedUserId = encryptUserId(user.id);

    // Create JWT with encrypted userId
    const token = jwt.sign(
        {
            encryptedUserId,
            username: user.username,
            email: user.email,
        },
        JWT_SECRET,
        {
            expiresIn: config.jwt.expiresIn || '1h',
        }
    );

    res.json({
        token,
        user: {
            username: user.username,
            email: user.email,
        },
    });
});

// Protected endpoint example
router.get('/profile', authenticateToken, (req, res) => {
    const user = users.find((u) => u.id === req.userId);
    if (user == null) {
        return res.status(404).json({ error: 'User not found' });
    }

    console.log('Encrypted userId from token:', req.encryptedUserId);

    res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        message: `Your encrypted userId is ${req.encryptedUserId} (retrieved from token)`,
    });
});

// Verify token endpoint
router.get('/verify', authenticateToken, (req, res) => {
    res.json({
        valid: true,
        userId: req.userId,
        user: req.user,
    });
});

module.exports = router;
