import crypto from 'crypto';
import jwt from 'jsonwebtoken';

import config from '../appsettings.json' with { type: 'json' };

const JWT_SECRET = config.jwt.secret;

// Configuration
// // // // // // // // // // // //
// Generate a JWT_Secret via cmd line:
//    node -e "console.log(require('crypto').randomBytes(32).toString('hex'));"
// // // // // // // // // // // //
const AES_KEY = crypto.scryptSync(config.aes.password, config.aes.salt, 32);
const AES_IV = crypto.randomBytes(16);
const ALGORITHM = 'aes-256-cbc';

// AES Decryption
export function decryptUserId(encryptedUserId) {
    const decipher = crypto.createDecipheriv(ALGORITHM, AES_KEY, AES_IV);
    let decrypted = decipher.update(encryptedUserId, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

// AES Encryption (Rijndael)
export function encryptUserId(userId) {
    const cipher = crypto.createCipheriv(ALGORITHM, AES_KEY, AES_IV);
    let encrypted = cipher.update(userId.toString(), 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

// Middleware to verify JWT
export function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }

        // Decrypt the userId from the token
        try {
            req.encryptedUserId = decoded.encryptedUserId;
            req.userId = decryptUserId(decoded.encryptedUserId);
            req.user = decoded;
            next();
        } catch (error) {
            return res.status(403).json({ error: 'Invalid token payload' });
        }
    });
}
