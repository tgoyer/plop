import { defineConfig, splitVendorChunkPlugin, transformWithEsbuild } from 'vite';
import react from '@vitejs/plugin-react';
import eslint from 'vite-plugin-eslint';
import viteTsconfigPaths from 'vite-tsconfig-paths';

import fs from 'fs';
import path from 'path';

function getFile(filepath) {
    var __path = path.resolve(__dirname, filepath);
    try {
        return fs.readFileSync(__path);
    } catch (err) {
        console.log('File Access Error: ', `${__path} not found.`);
        return null;
    }
}

export default defineConfig(({ command }) => {
    return {
        esbuild: {
            loader: 'jsx',
        },
        optimizeDeps: {
            esbuildOptions: {
                loader: {
                    '.js': 'jsx',
                },
            },
        },
        resolve: {
            alias: {
                '@': path.resolve(__dirname, './src'),
            },
        },
        plugins: [
            {
                name: 'treat-js-files-as-jsx',
                async transform(code, id) {
                    if (!id.match(/src\/.*\.js$/)) return null;

                    // Use the exposed transform from vite, instead of directly
                    // transforming with esbuild
                    return transformWithEsbuild(code, id, {
                        loader: 'jsx',
                        jsx: 'automatic',
                    });
                },
            },
            react(),
            eslint(),
            viteTsconfigPaths(),
            splitVendorChunkPlugin(),
        ],
        server:
            command === 'build'
                ? {}
                : {
                      open: true,
                      port: 3001,
                      https: {
                          key: getFile('./certs/localhost-key.pem'),
                          cert: getFile('./certs/localhost.pem'),
                      },
                  },
        build: {
            sourcemap: true,
            rollupOptions: {
                output: {
                    dir: 'build',
                    manualChunks(id) {
                        if (id.includes('node_modules')) {
                            return id.toString().split('node_modules/')[1].split('/')[0].toString();
                        }
                    },
                },
            },
        },
    };
});
