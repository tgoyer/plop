import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { saveFeedback } from '../store/FeedbackModule';
import FeedbackComponent from '../Applications/Feedback';

const mapStateToProps = (state) => {
    return {
        UserInfo: state.UserReducer.UserInfo.Data,
        FeedbackInfo: state.FeedbackReducer.FeedbackInfo,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        saveFeedbackDispatcher: (feedback) => dispatch(saveFeedback(feedback)),
    };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(FeedbackComponent));
