import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { setViewStatus, setLocalSetting } from '../store/AppSettingsModule';
import { selectCompanyByID } from '../store/CompanyModule';
import { getPortfolioProducts, getPublishers, getTeamRatings, getUserTeams } from '../store/DimensionModule';
import { deleteFile } from '../store/FileModule';
import { deleteNote, generateNotePdf, getMSCIRating, getNote, getNoteKeyIssues, saveNote } from '../store/NoteModule';

import { toOptionsList, toSingleOption } from '../Utils/selectHelper';

import ResearchInput from '../Applications/ResearchInput';

const toTeamRatingsObject = (list) => {
    let teamRatings = [
        { label: 'N/A', value: 'N/A', colorCode: null, pillar: 'Environment', ratingType: null },
        { label: 'N/A', value: 'N/A', colorCode: null, pillar: 'Social', ratingType: null },
        { label: 'N/A', value: 'N/A', colorCode: null, pillar: 'Governance', ratingType: null },
    ];

    return [
        ...teamRatings,
        ...(list != null
            ? list.map((value) => ({ label: value.Value, value: value.Value, colorCode: value.ColorCode, pillar: value.Pillar, ratingType: value.Name }))
            : []),
    ];
};

const mapStateToProps = (state) => {
    return {
        Analysts: toOptionsList(state.DimensionReducer.Analysts, 'FullName', 'UserID'),
        Attachments: state.FileReducer.NoteAttachments,
        Selected: state.CompanyReducer.Selected.Data,
        Consensus: toOptionsList(state.DimensionReducer.Consensus, 'Text', 'Value'),
        DefaultTeam: toSingleOption(state.DimensionReducer.DefaultTeam, 'TeamName', 'TeamID'),
        Effects: toOptionsList(state.DimensionReducer.Effects, 'Name', 'EffectID'),
        Fetching: state.ApiReducer.Fetching,
        MSCIPinned: state.AppSettingsReducer.LocalSettings.ResearchInput.msciPinned,
        MSCIRating: state.NoteReducer.MSCIRating,
        NoteData: state.NoteReducer.NoteData,
        NoteKeyIssues: state.NoteReducer.NoteKeyIssues,
        PortfolioActions: toOptionsList(state.DimensionReducer.PortfolioActions, 'Name', 'PortfolioActionID'),
        PortfolioProducts: toOptionsList(state.DimensionReducer.PortfolioProducts, 'ProductName', 'ProductID'),
        TeamRatings: toTeamRatingsObject(state.DimensionReducer.TeamRatings),
        UserTeams: toOptionsList(state.DimensionReducer.UserTeams, 'TeamName', 'TeamID'),
        UserDetails: state.UserReducer.UserInfo.Data,
        IsDirty: state.AppSettingsReducer.ViewStatus.mustConfirmNavigation,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        deleteFileDispatcher: (noteID, fileID) => dispatch(deleteFile(fileID, noteID)),
        deleteNoteDataDispatcher: (noteID) => dispatch(deleteNote(noteID)),
        fetchAnalystTeamsDispatcher: (userID, noteID) => dispatch(getUserTeams(userID, noteID || 0)),
        fetchAndSelectCompanyDispatcher: (companyID) => dispatch(selectCompanyByID(companyID)),
        fetchPortfolioProductsDispatcher: (teamID) => dispatch(getPortfolioProducts(teamID)),
        fetchTeamRatingsDispatcher: (teamID) => dispatch(getTeamRatings(teamID)),
        generateNotePdfDispatcher: (noteID) => dispatch(generateNotePdf(noteID)),
        getPublisherDispatcher: () => dispatch(getPublishers(true)),
        setDirtyFlagDispatcher: (isDirty) => dispatch(setViewStatus({ mustConfirmNavigation: isDirty })),
        setLocalSettingDispatcher: (value) => dispatch(setLocalSetting('ResearchInput', value)),
        saveNoteDispatcher: (data) => dispatch(saveNote(data)),

        fetchResearchInputDispatcher: (companyID, noteID) =>
            Promise.all([dispatch(getNote(noteID)), dispatch(getNoteKeyIssues(companyID, noteID)), dispatch(getMSCIRating(companyID))]),
    };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ResearchInput));
