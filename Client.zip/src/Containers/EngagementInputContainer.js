import { connect } from 'react-redux';

import { setViewStatus, setLocalSetting } from '../store/AppSettingsModule';
import { getCompanyMeetings, selectCompanyByID } from '../store/CompanyModule';
import { getAnalysts, getConsensus, getEffects, getPortfolioActions, getPortfolioProducts, getPublishers, getUserTeams } from '../store/DimensionModule';
import { getUserWatchlistData } from '../store/UserModule';
import { deleteFile } from '../store/FileModule';
import { deleteNote, generateNotePdf, getAttendees, getMSCIRating, getNote, getNoteKeyIssues, saveNote } from '../store/NoteModule';

import { toOptionsList, toSingleOption } from '../Utils/selectHelper';

import EngagementInput from '../Applications/EngagementInput';

const mapStateToProps = (state) => {
    return {
        Analysts: toOptionsList(state.DimensionReducer.Analysts, 'FullName', 'UserID'),
        Attachments: state.FileReducer.NoteAttachments,
        Selected: state.CompanyReducer.Selected.Data,
        Consensus: toOptionsList(state.DimensionReducer.Consensus, 'Text', 'Value'),
        DefaultTeam: toSingleOption(state.DimensionReducer.DefaultTeam, 'TeamName', 'TeamID'),
        Effects: toOptionsList(state.DimensionReducer.Effects, 'Name', 'EffectID',["N/A"])
                .map(option=>{ 
                   return option.isDisabled ? {...option, label: `${option.label} (disabled)`} : option
                }),
        Fetching: state.ApiReducer.Fetching,
        MSCIPinned: state.AppSettingsReducer.LocalSettings.EngagementInput.msciPinned,
        MSCIRating: state.NoteReducer.MSCIRating,
        NoteData: state.NoteReducer.NoteData,
        NoteKeyIssues: state.NoteReducer.NoteKeyIssues,
        PortfolioActions: toOptionsList(state.DimensionReducer.PortfolioActions, 'Name', 'PortfolioActionID'),
        PortfolioProducts: toOptionsList(state.DimensionReducer.PortfolioProducts, 'ProductName', 'ProductID'),
        Ratings: toOptionsList(state.DimensionReducer.Ratings, 'Text', 'Value'),
        UserTeams: toOptionsList(state.DimensionReducer.UserTeams, 'TeamName', 'TeamID'),
        UserDetails: state.UserReducer.UserInfo.Data,
        IsDirty: state.AppSettingsReducer.ViewStatus.mustConfirmNavigation,
        WatchlistData: state.UserReducer.UserWatchlistData,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        deleteFileDispatcher: (noteID, fileID) => dispatch(deleteFile(fileID, noteID)),
        deleteNoteDataDispatcher: (noteID) => dispatch(deleteNote(noteID)),
        fetchAnalystTeamsDispatcher: (userID, noteID) => dispatch(getUserTeams(userID, noteID)),
        fetchAndSelectCompanyDispatcher: (companyID) => dispatch(selectCompanyByID(companyID)),
        fetchPortfolioProductsDispatcher: (teamID) => dispatch(getPortfolioProducts(teamID)),
        fetchAttendeesDispatcher: (noteID) => dispatch(getAttendees(noteID)),
        generateNotePdfDispatcher: (noteID) => dispatch(generateNotePdf(noteID)),
        getPublisherDispatcher: () => dispatch(getPublishers(true)),
        getWatchlistDataDispatcher: (userID) => dispatch(getUserWatchlistData(userID)),
        setDirtyFlagDispatcher: (isDirty) => dispatch(setViewStatus({ mustConfirmNavigation: isDirty })),
        setLocalSettingDispatcher: (value) => dispatch(setLocalSetting('EngagementInput', value)),
        saveNoteDispatcher: (data) => dispatch(saveNote(data)),
        getMeetingsDispatcher: (companyID, userID) => dispatch(getCompanyMeetings(companyID, userID)),

        fetchEngagementInputDispatcher: (companyID, noteID) =>
            Promise.all([
                dispatch(getAnalysts()),
                dispatch(getNote(noteID)),
                dispatch(getNoteKeyIssues(companyID, noteID)),
                dispatch(getPortfolioActions()),
                dispatch(getConsensus()),
                dispatch(getEffects()),
                dispatch(getMSCIRating(companyID)),
            ]),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(EngagementInput);
