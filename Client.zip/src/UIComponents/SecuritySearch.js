import React, { Component, createRef } from 'react';
import Downshift from 'downshift';

import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { pxToRem } from '../Utils/layoutHelper';
import { getCompanySearch } from '../store/CompanyModule';
import { hasEntries } from 'Utils/arrayHelpers';

class SecuritySearch extends Component {
    constructor(props) {
        super(props);
        this.inputRef = createRef();
    }

    handleInputOnChange = (event) => {
        this.props.searchAction(event.target.value);
    };

    handleOnChange = (selectedCompany) => {
        this.props.clickAction(selectedCompany);
    };

    componentDidMount() {
        if (this.props.autoFocus) {
            const input = this.inputRef.current;
            input.focus();
            input.select();
        }
    }

    render() {
        const { CompanyList } = this.props;

        return (
            <Downshift onChange={this.handleOnChange} defaultHighlightedIndex={0} selectedItem={this.props.selectedItem} itemToString={(item) => (item ? item.Ticker : '')}>
                {({ getInputProps, getItemProps, highlightedIndex, inputValue, isOpen, selectedItem }) => (
                    <div style={{ width: '100%' }}>
                        <input
                            {...getInputProps({
                                value: inputValue == null ? '' : inputValue,
                                placeholder: 'Enter ticker or company name',
                                onChange: this.handleInputOnChange,
                            })}
                            style={{ width: '100%', padding: 8, fontSize: 14 }}
                            ref={this.inputRef}
                        />
                        {isOpen ? (
                            <div
                                style={{
                                    backgroundColor: '#ffffff',
                                    border: '1px solid rgba(34,36,38,.15)',
                                    width: 380,
                                    maxHeight: 400,
                                    overflowY: 'auto',
                                    overflowX: 'hidden',
                                    position: 'absolute',
                                    zIndex: 1000,
                                }}
                            >
                                {!!CompanyList.isLoading && (
                                    <div className="dropdown-item" style={{ marginLeft: 20, padding: 5 }}>
                                        <i className="fas fa-circle-notch fa-spin"></i>
                                        <span style={{ paddingLeft: 10 }}>Searching for security...</span>
                                    </div>
                                )}
                                {!CompanyList.isLoading && !hasEntries(CompanyList?.Data) && (
                                    <div className="dropdown-item" style={{ marginLeft: 20, padding: 5 }}>
                                        No security information found.
                                    </div>
                                )}
                                {!CompanyList.isLoading &&
                                    hasEntries(CompanyList?.Data) &&
                                    CompanyList.Data.map((item, index) => {
                                        return (
                                            <div
                                                className="dropdown-item row"
                                                key={item.SecurityID}
                                                style={{
                                                    margin: 0,
                                                    backgroundColor: highlightedIndex === index ? '#cfcfcf' : 'white',
                                                    fontWeight: selectedItem === item ? 'bold' : 'normal',
                                                }}
                                                {...getItemProps({ index, item })}
                                            >
                                                <div className="col-xs-3" style={{ fontWeight: 'bold', fontColor: '#002463' }}>
                                                    {item.Ticker}
                                                </div>
                                                <div className="col-xs-9" style={{ fontSize: pxToRem(12) }}>
                                                    {item.CompanyName}
                                                </div>
                                            </div>
                                        );
                                    })}
                            </div>
                        ) : null}
                    </div>
                )}
            </Downshift>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        CompanyList: state.CompanyReducer.CompanyList,
    };
};

const mapDispatchToProps = (dispatch) => ({
    searchAction: (criteria) => dispatch(getCompanySearch(criteria)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(SecuritySearch));
