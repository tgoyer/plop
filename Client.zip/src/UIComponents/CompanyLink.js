import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { selectCompanyByID } from '../store/CompanyModule';

export class CompanyLink extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            fetching: false,
        };
    }

    handleClick = (event) => {
        const { history, to } = this.props;

        event.stopPropagation();
        event.preventDefault();

        history.push(to);
    };

    render() {
        const { children, to } = this.props;
        return this.state.fetching ? (
            <React.Fragment>{children}</React.Fragment>
        ) : (
            <a href={to} onClick={this.handleClick}>
                {children}
            </a>
        );
    }
}

CompanyLink.propTypes = {
    companyID: PropTypes.number.isRequired,
};

const mapStateToProps = (state) => ({
    CompanyList: state.CompanyReducer.CompanyList,
});

const mapDispatchToProps = (dispatch) => ({
    selectCompanyDispatcher: (companyID) => dispatch(selectCompanyByID(companyID)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CompanyLink));
