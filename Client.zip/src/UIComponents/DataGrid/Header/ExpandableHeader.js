import React from 'react';
import Button from '@material-ui/core/Button';

import { withStyles } from '@material-ui/core/styles';

import { ColumnHeader } from './ColumnHeader';
import { pxToRem } from '../../../Utils/layoutHelper';

const styles = theme => ({
    expandoButton: { 
        cursor: 'pointer',
        margin: '0 4px 0 0', 
        fontSize: pxToRem(14), 
        fontWeight: 700,
        padding: '0 5px',
        textTransform: 'none',
        width: '100%',
    },
});

const BaseExpandableHeader = (props) => {
    const { canExpand, children, classes, onClick, style, expanded } = props;
    const expandedIcon = expanded === true 
        ? 'fas fa-angle-left'
        : 'fas fa-angle-right'

    const handleClick = (evt) => {
        if (canExpand && onClick != null) {
            onClick(evt);
        }
    }
    
    return (
        <ColumnHeader style={{...style}}>
            <Button color="primary" className={classes.expandoButton} onClick={handleClick}>
                { canExpand && <i className={expandedIcon} style={{ padding: '3px 0', color: '#000' }} /> }
                <span style={{ color: '#000', textAlign: 'left', padding: '0 15px 0 5px', }}>{children}</span>
            </Button>
        </ColumnHeader>
    );
};

export const ExpandableHeader = withStyles(styles, { withTheme: true })(BaseExpandableHeader);
