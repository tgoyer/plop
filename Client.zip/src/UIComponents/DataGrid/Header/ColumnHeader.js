import React from 'react';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    gridHeader: { 
        paddingLeft: 2,
        textAlign: 'left',
        '& button': {
            textAlign: 'left',
        },
        '& button > span': {
            alignItems: 'normal',
            justifyContent: 'normal',
            textAlign: 'left',
        },
        '& button > span > span': {
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
        }
    },
});

const BaseColumnHeader = (props) => {
    const { classes, children, style } = props;

    return (
        <div className={classes.gridHeader} style={{...style}}>{children}</div>
    );
}

export const ColumnHeader = withStyles(styles, { withTheme: true })(BaseColumnHeader);
