import ReactTable from 'react-table';
import withFixedColumns from 'react-table-hoc-fixed-columns';

import 'react-table/react-table.css';
import 'react-table-hoc-fixed-columns/lib/styles.css';
import './react-table-overrides.css';

export default withFixedColumns(ReactTable);
