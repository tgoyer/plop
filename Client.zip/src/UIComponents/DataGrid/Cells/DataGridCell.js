import React from 'react';

import { default as BaseDataGridCell } from './BaseDataGridCell';

export const Component = (props) => {
    const style = { 
        ...{}, 
        ...props.style 
    }
    return <div style={style}>{props.children}</div>
};

export default {
    Component,
    getHeaderProps: BaseDataGridCell.getHeaderProps,
    getProps: BaseDataGridCell.getProps,
}