import React from 'react';

import { default as BaseDataGridCell } from './BaseDataGridCell';
import { formatDate, toDateTime } from '../../../Utils/dateHelper';

export const Component = ({ value }) => {
    return value != null 
        ? <div>{ formatDate(toDateTime(value)) }</div>
        : <div></div>;
};

export const getHeaderProps = (row, field) => {
    const base = BaseDataGridCell.getHeaderProps(row, field);
    return {
        style: {
            ...base.style,
            textAlign: 'center',
        }
    }
}

export default {
    Component,
    getHeaderProps,
    getProps: BaseDataGridCell.getProps,
}