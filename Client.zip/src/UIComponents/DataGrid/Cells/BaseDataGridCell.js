export const Component = ({ value }) => value != null ? value : null;
export const getProps = (row, field) => ({})

export const getHeaderProps = (row, field) => {
    return {
        style: {
            overflow: 'visible',
        }
    }
}

export default {
    Component,
    getHeaderProps,
    getProps
}