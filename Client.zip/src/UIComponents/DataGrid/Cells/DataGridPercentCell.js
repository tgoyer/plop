import React from 'react';

import BaseDataGridCell from './BaseDataGridCell';
import DataGridNullDashCell from './DataGridNullDashCell';

import { toSignedPercent } from '../../../Utils/numberHelper';

// eslint-disable-next-line
export default {
    Component: ({ value, precision }) => {
        return value == null || isNaN(value) ? (
            <DataGridNullDashCell.Component value={value} />
        ) : (
            <span>{toSignedPercent(Number(value) / 100, precision)}</span>
        );
    },
    getHeaderProps: BaseDataGridCell.getHeaderProps,
    getProps: (row, field) => {
        const base = BaseDataGridCell.getProps(row, field);
        return {
            ...base,
            style: {
                ...base.style,
                textAlign: 'right',
            },
        };
    },
};
