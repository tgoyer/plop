import React from 'react';

import { default as BaseDataGridCell } from './BaseDataGridCell';

export const Component = ({ value }) => {
    return value == null 
        ? <span>&mdash;&mdash;</span>
        : Boolean(value)
            ? <span>Yes</span>
            : <span>No</span>
    ;
}

export const getHeaderProps = (row, field) => {
    const base = BaseDataGridCell.getHeaderProps(row, field);
    return {
        style: {
            ...base.style,
            textAlign: 'center',
        }
    }
}

export const getProps = (row, field) => {
    return {
        style: {
            textAlign: 'center',
        }
    }
}

export default {
    Component,
    getHeaderProps,
    getProps
}