import React from 'react';

import Tooltip from '../../../componentlibrary/tooltip/Tooltip';

import { default as BaseDataGridCell } from './BaseDataGridCell';
import { generateId } from '../../../Utils/layoutHelper';

const defaultStyle = {
    cursor: 'default',
    position: 'relative',
    whiteSpace: 'nowrap',
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    width: '100%',
};

class Component extends React.Component {
    displayRef = React.createRef();
    id = generateId();
    state = {
        showTooltip: false,
    };

    testOverflow = () => {
        const div = this.displayRef.current;
        let result = false;

        if (div != null) {
            var test = document.createElement('div');
            test.style.left = '-99in';
            test.style.position = 'absolute';
            test.style.whiteSpace = 'nowrap';
            test.style.font = div.style.font;
            test.style.margin = div.style.margin;
            test.style.padding = div.style.padding;
            test.innerHTML = div.innerHTML;

            document.body.appendChild(test);
            result = test.clientWidth > div.clientWidth;
            document.body.removeChild(test);
        }

        return result;
    };

    onToggleOverlay = (show) => (evt) => {
        const showTooltip = !!show && this.testOverflow();
        this.setState({ showTooltip });
    };

    render() {
        return (
            <Tooltip
                show="top"
                open={this.state.showTooltip}
                trigger={
                    <div ref={this.displayRef} style={{ ...defaultStyle, ...this.props.style }} onMouseEnter={this.onToggleOverlay(true)} onMouseLeave={this.onToggleOverlay(false)}>
                        <span>{this.props.children}</span>
                    </div>
                }
            >
                {this.props.children}
            </Tooltip>
        );
    }
}

export default {
    Component,
    getHeaderProps: BaseDataGridCell.getHeaderProps,
    getProps: BaseDataGridCell.getProps,
};
