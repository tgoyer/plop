import React from 'react';
import { default as BaseDataGridCell } from './BaseDataGridCell';

export default {
    Component: ({ value }) => value == null || value === '' 
        ? <span>&mdash;&mdash;</span>
        : value,
    getHeaderProps: BaseDataGridCell.getHeaderProps,
    getProps: BaseDataGridCell.getProps
}