import React from 'react';
import cn from 'classnames';
import _debounce from 'lodash/debounce';

import Button from '@material-ui/core/Button';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core/styles';

import { FilterPanel } from './FilterPanel';

const styles = theme => ({
    button: {
        height: 40,
        padding: 0,
        width: 'calc(50% - 8px)',
        margin: 4
    },
    buttons: {},
    default: {
        backgroundColor: '#f8f8f8',
        color: '#666666',
        padding: '4px 8px 4px 30px',
        '&:hover': {
            backgroundColor: 'rgba(221, 221, 221, 0.5)',
        }
    },
    selectCheck: {
        color: theme.palette.primary.main,
        padding: '0 6px 0 2px',
    },
    selected: {
        paddingLeft: 6,
    },
});

const initialState = {
    'yes': true,
    'no': true,
    'blank': true,
}

class Filter extends React.Component {
    componentRef = React.createRef();
    state = { 
        showPanel: false,
        values: { ...initialState }
    };

    componentDidUpdate = (prevProps) => {
        if (prevProps.filter != null && this.props.filter == null) {
            this.handleClear();
        }
    }

    handleButtonClick = () => {
        this.setState({ showPanel: !this.state.showPanel })
    }

    triggerChange = _debounce((value, clearFilter) => this.props.onChange(value), 150);
    handleChange = (fieldName) => () => {
        const list = { ...this.state.values };

        list[fieldName] = !list[fieldName];

        this.setState({ values: list });
    }

    handleClear = (hideMenu) => () => {
        this.setState({ values: { ...initialState } }, () => {
            this.triggerChange({ ...this.state.values, clearFilter: true });
            hideMenu();
        });
    };

    handleSubmit = (hideMenu) => () => {
        const { yes, no, blank } = this.state.values;
        this.triggerChange({ ...this.state.values }, (yes === false && no === false && blank === false));
        hideMenu();
    }

    render () {
        const { classes, filter, id } = this.props;

        const blankSelected = this.state.values['blank'] === true;
        const noSelected = this.state.values['no'] === true;
        const yesSelected = this.state.values['yes'] === true;

        return (
            <FilterPanel icon="fas fa-filter" id={id} isActive={filter != null}>
            {(hideMenu) => [
                <MenuItem key="yesFilter" className={cn(classes.default, { [classes.selected]: yesSelected })} onClick={this.handleChange('yes')}>
                    {yesSelected && <i className={cn("fas", "fa-check", "fa-inverse", classes.selectCheck)} />}
                    Yes
                </MenuItem>,
                <MenuItem key="noFilter" className={cn(classes.default, { [classes.selected]: noSelected })} onClick={this.handleChange('no')}>
                    {noSelected && <i className={cn("fas", "fa-check", "fa-inverse", classes.selectCheck)} />}
                    No
                </MenuItem>,
                <MenuItem key="blankFilter" className={cn(classes.default, { [classes.selected]: blankSelected })} onClick={this.handleChange('blank')}>
                    {blankSelected && <i className={cn("fas", "fa-check", "fa-inverse", classes.selectCheck)} />}
                    <span>&mdash;&mdash; Blank &mdash;&mdash;</span>
                </MenuItem>,
                <div key={id+'_buttonpanel'} className={classes.buttons}>
                    <Button variant="contained" color="primary" className={classes.button} onClick={this.handleSubmit(hideMenu)}>Ok</Button>
                    <Button variant="outlined" color="primary" className={classes.button} onClick={this.handleClear(hideMenu)}>Clear</Button>
                </div>
            ]}
            </FilterPanel>
        );
    }
}

const filterMethod = (filter, row) => {
    const id = filter.pivotId || filter.id;
    const data = (row[id] == null || row[id] === '') ? null : Boolean(row[id]);
    const yes = filter.value.yes === true;
    const no = filter.value.no === true;
    const blank = filter.value.blank === true;
    
    return (yes === false && no === false && blank === false)
        || (yes && (data === true))
        || (no && (data === false))
        || (blank && (data == null));
}

const sortMethod = (a, b, desc) => {
    a = a == null ? -Infinity : Boolean(a);
    b = b == null ? -Infinity : Boolean(b);
    
    if (a > b) {
        return -1;
    } else if (a < b) {
        return 1;
    } else {
        return 0;
    }
};

const StyledFilter = withStyles(styles, { withTheme: true })(Filter);
export default {
    Filter: (data, id) => (props) => <StyledFilter data={data} id={id} {...props} />,
    filterMethod,
    sortMethod,
}