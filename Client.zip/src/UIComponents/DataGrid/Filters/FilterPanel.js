import React from 'react';
import cn from 'classnames';

import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import { withStyles } from '@material-ui/core/styles';

import { pxToRem } from '../../../Utils/layoutHelper';

const styles = theme => ({
    container: {
        height: '100%',
        width: '100%',
        '& > button': {
            overflow: 'hidden',
            textOverflow: 'ellipsis',
        }
    },
    header: {
        backgroundColor: theme.palette.primary.main,
        color: '#ffffff',
        fontSize: pxToRem(14),
        textAlign: 'left',
        padding: '4px 8px',
        '& > div': {
            cursor: 'pointer',
        },
        '& i': {
            paddingRight: 8,
        }
    },
    iconClear: {},
    label: {
        paddingLeft: 8,
    },
    paper: {
        minWidth: 150,
        '& > ul': {
            padding: '0 !important'
        }
    },
    activeButton: {
        backgroundColor: theme.palette.primary.main,
        color: '#fff',
    },
    subheader: {
        backgroundColor: 'rgba(105, 135, 185, 0.08)',
        color: theme.palette.primary.main,
        fontWeight: 400,
        fontSize: pxToRem(12),
        padding: '8px 14px 8px 14px',
    },
    subHeaderButton: {
        fontWeight: 700,
        padding: '6px 6px 6px 10px',
        minHeight: 32,
        '& i': {
           paddingRight: 8, 
        }
    },
});

class Panel extends React.Component {
    componentRef = React.createRef();
    state = { showMenu: false }
        
    handleButtonClick = () => {
        this.setState({ showMenu: !this.state.showMenu })
    }

    handleClear = () => {
        this.handleButtonClick();
        if (this.props.onClear != null) {
            this.props.onClear();
        }
    }

    render() {
        const { children, classes, icon, label, show, subheader, onClear } = this.props;

        if (typeof(children) !== "function") throw new Error("children must be a function.");

        return (
            <div className={classes.container}>
                <Button 
                    buttonRef={this.componentRef}
                    color="primary" 
                    className={cn(classes.subHeaderButton, {[classes.activeButton]: this.props.isActive})} 
                    onClick={this.handleButtonClick}
                >
                    {icon != null && <i className={icon}></i>}{label != null && <span className={classes.label}>{label}</span>} 
                </Button>
                { (show == null || show === true) && (
                    <Menu 
                        id="filterPanelMenu"
                        anchorEl={this.componentRef && this.componentRef.current}
                        classes={{ paper: classes.paper }}
                        open={this.state.showMenu}
                        onClose={this.handleButtonClick}
                        MenuListProps={{
                            dense: true,
                            disablePadding: true,
                        }}
                    >
                        <div className={classes.header}>
                            { onClear != null 
                                ? <div onClick={this.handleClear}><i className="far fa-trash-alt"></i> Clear All Filters</div>
                                : <div><i className="fas fa-filter" />Filters</div>
                            }
                        </div>
                        { subheader != null && (
                            <div className={classes.subheader}>{subheader}</div>
                        )}
                        {children(this.handleButtonClick)}
                    </Menu>
                )}
            </div>
        );
    }
}

export const FilterPanel = withStyles(styles, { withTheme: true })(Panel);
