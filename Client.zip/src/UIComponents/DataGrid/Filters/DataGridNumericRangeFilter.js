import React from 'react';

import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import { withStyles } from '@material-ui/core/styles';

import { FilterPanel } from './FilterPanel';
import { RangeSlider } from '../../RangeSlider';
import { toPercent, formatCurrency, formatNumber } from '../../../Utils/numberHelper';
import { sort } from '../../../Utils/listHelper';

const styles = theme => ({
    body: {
        '& select': {
            border: '1px solid rgba(0, 0, 0, 0.1)',
            borderRadius: 4,
            margin: '0 2px',
            padding: '5px 10px !important',
        }
    },
    button: {
        height: 40,
        padding: 0,
        width: 'calc(50% - 8px)',
        margin: 4
    },
    buttons: {},
    container: {
        padding: '8px',
    },
    dataControlLabel: {
        display: 'inline-block',
        width: 75,
    },
});

const initialState = {
    max: null,
    min: null,
    start: null,
    end: null,
    showNull: true,
}

const TYPES = {
    Currency: "currency",
    Number: "number",
    Percent: "percent",
}

class Filter extends React.Component {
    state = { ...initialState, };
    
    componentDidMount = () => {
        const values = this.getValuesFromProps();
        
        this.setState({
            max: values.end,
            min: values.start,
            start: values.start,
            end: values.end,
        });
    }

    componentDidUpdate = (prevProps) => {
        if (prevProps.filter != null && this.props.filter == null) {
            this.handleClear();
        }
    }

    formatValue = (value) => {
        const { type, precision } = this.props;

        switch (type) {
            case TYPES.Currency:
                return formatCurrency(value);
            case TYPES.Percent:
                return parseFloat(toPercent(value, 2 + precision).toFixed(precision));
            case TYPES.Number:
            default:
                return formatNumber(value, this.props.precision);
        }
    }

    getValuesFromProps = () => {
        const data = (this.props.data != null && this.props.data.length > 0)
            ? this.props.data
                .filter(item => item[this.props.id] != null)
                .sort(sort(this.props.id))
            : null;

        const start = data != null && data.length > 0
            ? data[0][this.props.id]
            : null;

        const end = data != null && data.length > 0
            ? data.reverse()[0][this.props.id]
            : null;

        return { start, end }
    }

    handleCheckboxClick = (fieldName) => () => {
        const value = !this.state[fieldName];

        this.setState({ [fieldName]: value })
    }

    handleChange = (values) => {
        this.setState({ 
            start: values[0],
            end: values[1],
        });
    }

    handleClear = (hideMenu) => () => {
        const values = this.getValuesFromProps();
        
        this.setState({
            start: values.start,
            end: values.end,
        }, () => {
            this.props.onChange({
                ...this.getValuesFromProps(),
                clearFilter: true,
            });
            hideMenu();
        });
    };

    handleSubmit = (hideMenu) => () => {
        const { end, start, showNull } = this.state;
        this.props.onChange({ start, end, showNull });
        hideMenu();
    }

    render () {
        const { classes, filter, id } = this.props;
        return (
            <FilterPanel icon="fas fa-filter" id={id} isActive={filter != null}>
            {(hideMenu) => (
                <div className={classes.container}>
                    <div className={classes.body}>
                        <RangeSlider 
                            limits={[this.state.min, this.state.max]} 
                            values={[this.state.start, this.state.end]} 
                            formatValue={this.formatValue} 
                            onChange={this.handleChange} 
                            rangeColor={'#6987b9'}
                        />
                    </div>
                    <div className={classes.body} style={{ textAlign: 'right' }}>
                        Include Blank Values:
                        <Checkbox
                            color="primary"
                            checked={this.state.showNull}
                            onChange={this.handleCheckboxClick('showNull')}
                            style={{ textAlign: 'right', padding: 4 }}
                        />
                    </div>
                    <div className={classes.buttons}>
                        <Button variant="contained" color="primary" className={classes.button} onClick={this.handleSubmit(hideMenu)}>Ok</Button>
                        <Button variant="outlined" color="primary" className={classes.button} onClick={this.handleClear(hideMenu)}>Clear</Button>
                    </div>
                </div>
            )}
            </FilterPanel>
        );
    }
}

const filterMethod = (filter, row) => {
    const id = filter.pivotId || filter.id;
    const { end, start, showNull } = filter.value;
    const data = (row[id] != null) ? row[id] : null;

    return (data == null) 
        ? showNull
        : data >= start && data <= end;
}

const StyledFilter = withStyles(styles, { withTheme: true })(Filter);

export default {
    Filter: (data, id, precision = 0, type = TYPES.Number) => (props) => <StyledFilter data={data} id={id} precision={precision} type={type} {...props} />,
    Types: TYPES,
    filterMethod,
}


