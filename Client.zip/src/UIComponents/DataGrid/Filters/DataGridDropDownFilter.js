import React from 'react';

import BaseDropDownFilter from './BaseDropDownFilter';

const Filter = (data, id, exact) => (props) => {
    const { filter, onChange } = props;

    const uniqueValues = data == null 
        ? [] 
        : data.reduce((acc, item) => {
            const data = item[id];
            const value = data == null || data === '' 
                ? null
                : (isNaN(data))
                    ? `${data.toString().trim()}` 
                    : Number(data);

            if (acc.indexOf(value) < 0) {
                acc.push(value);
            }
            return acc;
        }, []);

    uniqueValues.sort();

    return <BaseDropDownFilter.Filter id={id} exact={exact} onChange={onChange} options={uniqueValues} filter={filter} />
}

export default {
    Filter,
    filterMethod: BaseDropDownFilter.filterMethod
}