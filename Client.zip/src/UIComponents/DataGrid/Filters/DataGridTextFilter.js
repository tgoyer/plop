import React from 'react';
import _debounce from 'lodash/debounce';

import { isMobileBrowser } from '../../../Utils/layoutHelper';

class Filter extends React.Component {
    state = { isNumeric: false, value: '' }
    isMobile = isMobileBrowser();

    componentDidMount = () => {
        const { filter, id, data} = this.props;
        const hasNaNValue = data == null || data.find(d => isNaN( d[id] ));
        this.setState({ 
            isNumeric: !hasNaNValue,
            value: (filter != null && filter.value != null) ? filter.value : ''
        })
    }

    componentDidUpdate = (prevProps) => {
        if (prevProps.filter != null && this.props.filter == null) {
            this.setState({ value: '' }, () => this.props.onChange(''))
        }
    }

    triggerChange = _debounce((value) => this.props.onChange(value), 250);
    
    handleChange = (event) => {
        const value = event.currentTarget.value;
        this.setState({ value }, () => this.triggerChange(value));
    }

    render () {
        const style = { width: '100%', height: '100%' };
        return this.state.isNumeric && this.isMobile
            ? <input style={style} type="number" pattern="/d*" onChange={this.handleChange} value={this.state.value}></input>
            : <input style={style} type="text" onChange={this.handleChange} value={this.state.value} />
    }
}

const filterMethod = (filter, row) => {
    const id = filter.pivotId || filter.id;
    const filterValue = filter.value != null 
        ? filter.value.toUpperCase() 
        : null;
    const rowValue = row[id] != null 
        ? String(row[id]).toUpperCase()
        : null;

    return filterValue == null
        ? true
        : rowValue != null
            ? rowValue.indexOf(filterValue) >= 0
            : false;
}


export default {
    Filter: (data, id) => (props) => <Filter data={data} id={id} {...props} />,
    filterMethod
}