import React from 'react';

import BaseDropDownFilter from './BaseDropDownFilter';

const Filter = (data, id, delimiter, exact = false) => (props, a, b, c) => {
    const { filter, onChange } = props;

    const uniqueValues = data == null 
        ? [] 
        : data.reduce((acc, item) => {
            const issues = item[id] == null 
                ? [null] 
                : item[id].split(delimiter);
                
            issues.forEach(issue => {
                issue = issue == null ? null : issue.trim();
                if (acc.indexOf(issue) < 0) acc.push(issue);
            });

            return acc;
        }, []).sort();

    return <BaseDropDownFilter.Filter id={id} exact={exact} onChange={onChange} options={uniqueValues} filter={filter} />
}

export default {
    Filter,
    filterMethod: BaseDropDownFilter.filterMethod,
}