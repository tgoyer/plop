import React from 'react';
import cn from 'classnames';
import _debounce from 'lodash/debounce';

import Button from '@material-ui/core/Button';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core/styles';

import { FilterPanel } from './FilterPanel';
import { findIndex } from '../../../Utils/listHelper';

const styles = theme => ({
    button: {
        height: 40,
        padding: 0,
        width: 'calc(50% - 8px)',
        margin: 4
    },
    buttons: {},
    default: {
        backgroundColor: '#f8f8f8',
        color: '#666666',
        padding: '4px 8px 4px 30px',
        '&:hover': {
            backgroundColor: 'rgba(221, 221, 221, 0.5)',
        }
    },
    selectCheck: {
        color: theme.palette.primary.main,
        padding: '0 6px 0 2px',
    },
    selected: {
        paddingLeft: 6,
    },
});

class Filter extends React.Component {
    state = { 
        options: [],
        selectedOptions: []
    };
    
    componentDidMount = () => {
        const { filter, options } = this.props;
        const data = options.map((opt, idx) => ({
            key: idx, value: opt
        }));

        this.setState({
            options: data,
            selectedOptions: filter != null && filter.value != null && filter.value.values != null
                ? filter.value.values
                : [],
        });
    }

    componentDidUpdate = (prevProps) => {
        if (prevProps.filter != null && this.props.filter == null) {
            this.setState({ selectedOptions: []})
        }
    }

    triggerChange = _debounce((values, clearFilter) => this.props.onChange({ 
        exact: this.props.exact === true, 
        clearFilter, 
        values 
    }), 150);
    
    handleChange = (key) => () => {
        const options = this.state.options;
        const list = [ ...this.state.selectedOptions ];
        
        const index = findIndex(list, (item) => item.key === key);

        if (index >= 0) {
            list.splice(index, 1);
        } else {
            list.push(options[key])
        }

        this.setState({ selectedOptions: list });
    }

    handleSubmit = (hideMenu) => () => {
        const { selectedOptions } = this.state;
        this.triggerChange(selectedOptions, selectedOptions.length === 0);
        hideMenu();
    }

    handleClear = (hideMenu) => () => {
        this.setState({ selectedOptions: [] }, () => {
            this.triggerChange([], true);
            hideMenu();
        });
    };

    render () {
        const { classes, filter, id } = this.props;
        const { options, selectedOptions } = this.state;

        return (
            <FilterPanel icon="fas fa-filter" id={id} isActive={filter != null}>
            {(hideMenu) => (options == null || options.length === 0)
                ? <MenuItem className={classes.default}>No options</MenuItem>
                : [
                    ...options.map(opt => {
                        const isSelected = findIndex(selectedOptions, selectedOpt => opt.key === selectedOpt.key) >= 0;
                        const value = opt.value == null ? '-- Blank --' : opt.value;
                        return (
                            <MenuItem 
                                className={cn(classes.default, { [classes.selected]: isSelected })}
                                key={opt.key} 
                                onClick={this.handleChange(opt.key)}
                            >
                                {isSelected && <i className={cn("fas", "fa-check", "fa-inverse", classes.selectCheck)} />}
                                {value}
                            </MenuItem>
                        )
                    }),
                    <div key={id+'_buttonpanel'} className={classes.buttons}>
                        <Button variant="contained" color="primary" className={classes.button} onClick={this.handleSubmit(hideMenu)}>Ok</Button>
                        <Button variant="outlined" color="primary" className={classes.button} onClick={this.handleClear(hideMenu)}>Clear</Button>
                    </div>
                ]
            }
            </FilterPanel>  
        );
    }
}

const checkData = (input, filterValues, exact) => {
    const data = (input == null || input === '')
        ? null 
        : String(input);
    
    return filterValues == null
        ? true
        : filterValues.reduce((acc, filter) => {
            if (acc === true) return acc;

            return (exact === true)
                ? data === filter.value || data === String(filter.value) 
                : String(data).indexOf(filter.value) >= 0;
        }, false);
}

const filterMethod = (filter, row) => {
    const { id } = filter;
    const { exact, values } = filter.value;
    const data = row[id];
    const value = data != null && typeof(data) === 'string'
        ? String(data).trim()
        : data;

    const ret = values.length === 0
        ? true
        : checkData(value, values, exact);
    return ret;
}

export default {
    Filter: withStyles(styles, { withTheme: true })(Filter),
    filterMethod: filterMethod
}