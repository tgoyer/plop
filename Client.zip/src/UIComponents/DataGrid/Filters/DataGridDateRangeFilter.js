import React from 'react';

import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import { withStyles } from '@material-ui/core/styles';

import { FilterPanel } from './FilterPanel';
import { getMonthsList, toDateTime } from '../../../Utils/dateHelper';
import { sort } from '../../../Utils/listHelper';

const styles = (theme) => ({
    body: {
        '& select': {
            border: '1px solid rgba(0, 0, 0, 0.1)',
            borderRadius: 4,
            margin: '0 2px',
            padding: '5px 10px !important',
        },
    },
    button: {
        height: 40,
        padding: 0,
        width: 'calc(50% - 8px)',
        margin: 4,
    },
    buttons: {},
    container: {
        padding: '8px',
    },
    dataControlLabel: {
        display: 'inline-block',
        width: 75,
    },
});

const initialState = {
    start: null,
    end: null,
    startMonth: null,
    startYear: null,
    endMonth: null,
    endYear: null,
    showNull: true,
};

class Filter extends React.Component {
    state = { ...initialState };
    months = getMonthsList('short');
    years = [];

    componentDidMount = () => {
        const dates = this.getDatesFromProps();
        const startYear = Number(dates.start.toFormat('yyyy'));
        const endYear = Number(dates.end.toFormat('yyyy'));

        this.years.push(startYear);

        if (startYear < endYear) {
            for (var i = 1; i <= endYear - startYear; i++) {
                this.years.push(startYear + i);
            }
        }

        this.setState({
            endMonth: Number(dates.end.toFormat('MM')),
            endYear: Number(dates.end.toFormat('yyyy')),
            startMonth: Number(dates.start.toFormat('MM')),
            startYear: Number(dates.start.toFormat('yyyy')),
        });
    };

    componentDidUpdate = (prevProps) => {
        if (prevProps.filter != null && this.props.filter == null) {
            this.handleClear();
        }
    };

    getDatesFromProps = () => {
        const data =
            this.props.data != null && this.props.data.length > 0
                ? this.props.data
                      .filter((item) => item[this.props.id] != null)
                      .map((item) =>
                          item.toDate == null
                              ? {
                                    ...item,
                                    [this.props.id]: toDateTime(item[this.props.id]),
                                }
                              : item
                      )
                      .sort(sort(this.props.id))
                : null;

        const revData = data != null ? [...data].reverse() : [];

        const start = data != null && data.length > 0 && data[0] != null && data[0][this.props.id] != null ? data[0][this.props.id] : toDateTime(new Date());

        const end = revData.length > 0 && revData[0] != null && revData[0][this.props.id] != null ? revData[0][this.props.id] : toDateTime(new Date());

        return { start, end };
    };

    getDatesFromState = () => {
        const { endMonth, endYear, startMonth, startYear } = this.state;

        const sMonth = startMonth !== '' ? startMonth : 1;
        const eMonth = endMonth !== '' ? endMonth : 12;

        const sYear = startYear !== '' ? startYear : this.years[0];
        const eYear = endYear !== '' ? endYear : this.years[this.years.length - 1];

        const start = toDateTime(new Date(`${sMonth}/01/${sYear}`));
        const end = toDateTime(new Date(`${eMonth}/01/${eYear}`)).plus({ month: 1 });

        return { end, start };
    };

    handleCheckboxClick = (fieldName) => () => {
        const value = !this.state[fieldName];

        this.setState({ [fieldName]: value });
    };

    handleChange = (fieldName) => (event) => {
        const value = event.currentTarget.value;
        this.setState({
            [fieldName]: value != null && value !== '' ? Number(value) : '',
        });
    };

    handleClear = (hideMenu) => () => {
        const dates = this.getDatesFromProps();

        this.setState(
            {
                endMonth: Number(dates.end.toFormat('MM')),
                endYear: Number(dates.end.toFormat('yyyy')),
                startMonth: Number(dates.start.toFormat('MM')),
                startYear: Number(dates.start.toFormat('yyyy')),
            },
            () => {
                this.props.onChange({
                    ...this.getDatesFromState(),
                    clearFilter: true,
                });
                hideMenu();
            }
        );
    };

    handleSubmit = (hideMenu) => () => {
        this.props.onChange({
            ...this.getDatesFromState(),
            showNull: this.state.showNull,
        });
        hideMenu();
    };

    render() {
        const { classes, filter, id } = this.props;
        const { endMonth, endYear, startMonth, startYear } = this.state;
        return (
            <FilterPanel icon="fas fa-filter" id={id} isActive={filter != null}>
                {(hideMenu) => (
                    <div className={classes.container}>
                        <div className={classes.body}>
                            <span className={classes.dataControlLabel}>Start Date:</span>
                            <select onChange={this.handleChange('startMonth')} value={startMonth}>
                                {this.months.map((value, idx) => (
                                    <option key={idx} value={idx + 1}>
                                        {value}
                                    </option>
                                ))}
                            </select>
                            <select onChange={this.handleChange('startYear')} value={startYear}>
                                {this.years.map((value, idx) => (
                                    <option key={value} value={value}>
                                        {value}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className={classes.body}>
                            <span className={classes.dataControlLabel}>End Date:</span>
                            <select onChange={this.handleChange('endMonth')} value={endMonth}>
                                {this.months.map((value, idx) => (
                                    <option key={idx} value={idx + 1}>
                                        {value}
                                    </option>
                                ))}
                            </select>
                            <select onChange={this.handleChange('endYear')} value={endYear}>
                                {this.years.map((value, idx) => (
                                    <option key={value} value={value}>
                                        {value}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className={classes.body} style={{ textAlign: 'right' }}>
                            Include Blank Dates:
                            <Checkbox
                                color="primary"
                                checked={this.state.showNull}
                                onChange={this.handleCheckboxClick('showNull')}
                                style={{ textAlign: 'right', padding: 4 }}
                            />
                        </div>
                        <div className={classes.buttons}>
                            <Button variant="contained" color="primary" className={classes.button} onClick={this.handleSubmit(hideMenu)}>
                                Ok
                            </Button>
                            <Button variant="outlined" color="primary" className={classes.button} onClick={this.handleClear(hideMenu)}>
                                Clear
                            </Button>
                        </div>
                    </div>
                )}
            </FilterPanel>
        );
    }
}

const filterMethod = (filter, row) => {
    const id = filter.pivotId || filter.id;
    const { end, start, showNull } = filter.value;
    const data = row[id] != null ? toDateTime(row[id]) : null;

    return data == null ? showNull : data >= start && data < end;
};

const StyledFilter = withStyles(styles, { withTheme: true })(Filter);
export default {
    Filter: (data, id) => (props) => <StyledFilter data={data} id={id} {...props} />,
    filterMethod,
};
