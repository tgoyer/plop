import React from 'react';
import Downshift from 'downshift';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import Tooltip from './Tooltip';

import { searchAccounts } from '../store/PortfolioModule';

const PortfolioSearch = (props) => {
    const inputRef = React.createRef();
    const { Account, Search, isFavorite, onFavoriteClick, onSearch, searchAccountsDispatcher, disabled } = props;
    const handleInputOnChange = (event) => searchAccountsDispatcher(event.target.value);

    const handleOnChange = (item) => {
        if (onSearch != null) {
            onSearch(item);
        }
    };

    const onFocus = () => {
        const { current } = inputRef;
        if (current != null) {
            current.focus();
            current.select();
        }
    };

    return (
        !disabled && (
            <Downshift onChange={handleOnChange} defaultHighlightedIndex={0} selectedItem={Account} itemToString={(item) => (item != null ? item.AccountName : '')}>
                {({ getInputProps, getItemProps, highlightedIndex, isOpen, selectedItem }) => (
                    <div style={{ display: 'inline-block', width: 'calc(100% - 35px)' }}>
                        <input
                            ref={inputRef}
                            onFocus={onFocus}
                            style={{ display: 'inline-block', width: '100%', paddingLeft: '4px' }}
                            {...getInputProps({
                                placeholder: 'Enter account name or number',
                                onChange: handleInputOnChange,
                            })}
                        />
                        {onFavoriteClick != null && (
                            <React.Fragment>
                                <span data-tip data-for="favoriteStar_TT" onClick={onFavoriteClick} style={{ position: 'relative', cursor: 'pointer', padding: 0, margin: 0 }}>
                                    {Account == null ? null : isFavorite === true ? (
                                        <React.Fragment>
                                            <i className="fas fa-star fa-stack-1x" style={{ padding: 4, marginLeft: 8, color: '#f08f50' }} />
                                            <i className="far fa-star fa-stack-1x" style={{ padding: 4, marginLeft: 8, color: '#a43a04' }} />
                                        </React.Fragment>
                                    ) : (
                                        <i className="far fa-star fa-stack-1x" style={{ padding: 4, marginLeft: 8 }} />
                                    )}
                                </span>
                                <Tooltip id="favoriteStar_TT" place="top">
                                    Mark this account as a favorite. It will be listed in the "Saved Items" section of the "Adv Options" pane.
                                </Tooltip>
                            </React.Fragment>
                        )}

                        {isOpen ? (
                            <div
                                style={{
                                    backgroundColor: '#ffffff',
                                    border: '1px solid rgba(34,36,38,.15)',
                                    width: 600,
                                    maxHeight: 400,
                                    overflowY: 'auto',
                                    overflowX: 'hidden',
                                    position: 'absolute',
                                    zIndex: 1000,
                                }}
                            >
                                {!!Search.isLoading && (
                                    <div className="dropdown-item" style={{ marginLeft: 20, padding: 5 }}>
                                        <i className="fas fa-circle-notch fa-spin"></i>
                                        <span style={{ paddingLeft: 10 }}>Searching for account...</span>
                                    </div>
                                )}
                                {!Search.isLoading && (Search.Data == null || Search.Data.length === 0) && (
                                    <div className="dropdown-item" style={{ marginLeft: 20, padding: 5 }}>
                                        No account information found.
                                    </div>
                                )}
                                {!Search.isLoading &&
                                    Array.isArray(Search.Data) &&
                                    Search.Data.map((item, index) => (
                                        <div
                                            className="dropdown-item row"
                                            key={item.AccountID}
                                            style={{
                                                margin: 0,
                                                backgroundColor: highlightedIndex === index ? '#cfcfcf' : 'white',
                                                fontWeight: selectedItem === item ? 'bold' : 'normal',
                                            }}
                                            {...getItemProps({ index, item })}
                                        >
                                            <div className="col-xs-2" style={{ padding: 0, margin: 0, fontWeight: 700, fontColor: '#002463' }}>
                                                <div style={{ padding: '0 15px', margin: 0 }}>{item.AccountNumber}</div>
                                            </div>
                                            <div className="col-xs-8" style={{ padding: 0, margin: 0 }}>
                                                <div
                                                    style={{
                                                        margin: 0,
                                                        overflow: 'hidden',
                                                        padding: '0 10px',
                                                        textOverflow: 'ellipsis',
                                                        whiteSpace: 'nowrap',
                                                    }}
                                                >
                                                    <span>{item.AccountName}</span>
                                                </div>
                                            </div>
                                            <div className="col-xs-2" style={{ padding: 0, margin: 0, fontWeight: 700, fontColor: '#002463' }}>
                                                <div style={{ padding: '0 15px', margin: 0, fontStyle: 'italic' }}>{item.Subaccount}</div>
                                            </div>
                                        </div>
                                    ))}
                            </div>
                        ) : null}
                    </div>
                )}
            </Downshift>
        )
    );
};

const mapStateToProps = (state) => {
    return {
        Search: state.PortfolioReducer.Search,
    };
};

const mapDispatchToProps = (dispatch) => ({
    searchAccountsDispatcher: (criteria) => dispatch(searchAccounts(criteria)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(PortfolioSearch));
