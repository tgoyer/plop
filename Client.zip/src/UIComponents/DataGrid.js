import React from 'react';

import ReactTable from 'react-table';
import withFixedColumns from "react-table-hoc-fixed-columns";

import 'react-table/react-table.css';

export default withFixedColumns(ReactTable);