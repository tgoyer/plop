import React from 'react';
import PropTypes from 'prop-types';
import dragula from 'dragula';

import { generateId } from '../../Utils/layoutHelper';

class DraggableContainer extends React.Component {
    dragHandleID = 'dragHandleID';
    containerRef = React.createRef();
    drake = null;
    dragging = false;
    state = {
        data: []
    }

    constructor(props) {
        super(props);

        const drakeOpts = { 
            direction: 'vertical',
            revertOnSpill: true,
            moves: (el, container, handle) => handle.classList.contains(this.dragHandleID),
        };
        this.drake = dragula(drakeOpts)
            .on('drag', () => this.dragging = true)
            .on('dragend', () => this.dragging = false)
            .on('drop', this.onDrop);
    }

    static getDerivedStateFromProps = (props) => {
        return {
            data: props.data.reduce((acc, item) => {
                acc[generateId()] = item;
                return acc;
            }, {})
        }
    }
    componentDidMount = () => {
        this.drake.containers.push(this.containerRef.current);
        this.containerRef.current.addEventListener('ontouchmove', this.freezeScrollOnMobile);
    }
    componentWillUnmount = () => {
        this.drake.destroy();
        this.containerRef.current.removeEventListener('ontouchmove', this.freezeScrollOnMobile);
    }
    freezeScrollOnMobile = (e) => {
        if (this.dragging) e.preventDefault();
    }
    onDrop = (element, target) => {
        const items = [...target.childNodes].map(el => {
            return this.state.data[el.dataset['key']];
        });

        if (this.onDrop != null) {
            this.props.onDrop(element, items);
        }
    }
    render = () => {
        const { children } = this.props;
        const data = this.state.data;

        return (
            <div ref={this.containerRef}>
                { Object.keys(data)
                    .map(key => React.cloneElement(
                        children({ 
                            ...data[key], 
                            className: this.dragHandleID 
                        }), { 'data-key': key }
                    ))
                }
            </div>
        );
    }
}

DraggableContainer.propTypes = {
    children: PropTypes.func.isRequired
};

export default DraggableContainer;