import React from 'react';

import LoadingSpinner from 'componentlibrary/spinners/Loading';

const LoadingPanel = ({ children }) => <LoadingSpinner>{children}</LoadingSpinner>;

export default LoadingPanel;
