import React from 'react';
import ReactTooltip from 'react-tooltip';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

const gray = '#6e86a0 !important';

const styles = (theme) => ({
    commentBoxToolTip: {
        borderRadius: '10px !important',
        backgroundColor: gray,
        color: 'white !important',
        '&.show': {
            opacity: 1,
        },
        '&.place-bottom:after': {
            borderBottomColor: gray,
        },
        '&.place-left:after': {
            borderLeftColor: gray,
        },
        '&.place-right:after': {
            borderRightColor: gray,
        },
        '&.place-top:after': {
            borderTopColor: gray,
        },
    },
    commentBoxContent: {
        fontWeight: 400,
        lineHeight: 'normal',
        maxWidth: 640,
        textAlign: 'left',
        whiteSpace: 'normal',
        '& a': {
            color: 'white !important',
        },
    },
});

const Tooltip = ({ id, children, className = null, classes, place = 'top' }) => (
    <ReactTooltip
        id={id}
        delayShow={750}
        effect="solid"
        multiline={true}
        place={place}
        className={cn(classes.commentBoxToolTip, className)}
        overridePosition={(coords, currentEvent, currentTarget, node) => {
            const { left, top } = coords;
            const d = document.documentElement;

            const minLeft = Math.min(d.clientWidth - node.clientWidth, left);
            const minTop = Math.min(d.clientHeight - node.clientHeight, top);

            return {
                left: Math.max(0, minLeft),
                top: Math.max(0, minTop),
            };
        }}
    >
        <div className={classes.commentBoxContent}>{children}</div>
    </ReactTooltip>
);

export default withStyles(styles)(Tooltip);
