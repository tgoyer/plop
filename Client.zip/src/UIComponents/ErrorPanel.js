import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import LoadingPanel from './LoadingPanel';
import { pxToRem } from '../Utils/layoutHelper';

const styles = (theme) => ({
    container: {
        fontSize: pxToRem(18),
        fontWeight: 700,
        textAlign: 'left',
        display: 'inline-block',
        verticalAlign: 'middle',
        width: 'calc(100% - 73px)',
    },
    icon: {
        fontSize: pxToRem(24),
        paddingRight: 16,
        display: 'inline-block',
        verticalAlign: 'middle',
    },
});

const ErrorPanel = ({ classes, message }) => {
    return (
        <LoadingPanel>
            <i className={cn('fas fa-times-circle', classes.icon)}></i>
            <div className={classes.container}>{message}</div>
        </LoadingPanel>
    );
};

export default withStyles(styles)(ErrorPanel);
