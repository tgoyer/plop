import React from 'react';

import mime from 'mime-types';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({});

const FileViewer = ({ classes, path, fileName }) => {
    const mimeLookup = mime.lookup(fileName);
    const type = mimeLookup !== false
        ? mimeLookup
        : null;

    return (
        <object type={type} data={path} width="100%" height="100%">
            Your browser cannot embed this file.  <a href={path}>Click to download.</a>
        </object>
    );
}

export default withStyles(styles)(FileViewer);