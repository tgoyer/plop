import React, { useState } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import { FileViewer } from './';

const styles = theme => ({
    asLink: {
        background: 'none',
        border: 0,
        color: theme.palette.primary.main,
        cursor: 'pointer',
        margin: 0,
        padding: 0,
    }
});

const FileLink = ({ children, classes, className, onClick, onClose, show, path, type="application/pdf", ...buttonProps }) => {
    const [_show, setShow] = useState(show === true);

    const handleClick = (e) => {
        setShow(true);

        if (onClick != null) {
            onClick(e);
        }
    }

    const handleClose = (e) => {
        setShow(false);

        if (onClose != null) {
            onClose(e);
        }
    }

    return (
        <React.Fragment>
            <button className={cn(classes.asLink, className)} onClick={handleClick} {...buttonProps}>{children}</button>
            <FileViewer onClose={handleClose} show={_show} path={path} />
        </React.Fragment>
    )
};

FileLink.propTypes = {
    classes: PropTypes.object,
    className: PropTypes.oneOfType([ PropTypes.string, PropTypes.object ]),
    children: PropTypes.any,
    onClick: PropTypes.func,
    onClose: PropTypes.func,
    path: PropTypes.string.isRequired,
    show: PropTypes.bool,
    title: PropTypes.string,
    type: PropTypes.string,
}

export default withStyles(styles)(FileLink);