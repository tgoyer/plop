import React from 'react';
import { connect } from 'react-redux';

import { resetLocalSettings } from '../store/AppSettingsModule';

class ErrorBoundary extends React.Component {
    state = {
        showStackTrace: false,
        error: null,
        errorInfo: null,
    };

    // Wijmo's "React" grid is dumb and updates the DOM outside
    // the virtual DOM.  Since it adds random elements to the DOM,
    // the virtual DOM gets out of sync and React can't unmount the grid.
    // This will keep out-of-sync unmount errors from blowing up the app.
    static getDerivedStateFromError(error) {
        return error != null && error.name !== 'NotFoundError'
            ? { error }
            : {
                  showStackTrace: false,
                  error: null,
                  errorInfo: null,
              };
    }

    // At some point, might want to hook up a clientside error reporter into this lifecycle event.
    componentDidCatch = (error, errorInfo) =>
        this.setState({
            errorInfo: error != null && error.name !== 'NotFoundError' ? errorInfo : null,
        });

    handleResetClick = async () => {
        await this.props.resetLocalSettingDispatcher();
        window.location.reload(true);
    };

    handleShowTechDetailsClick = () => this.setState({ showStackTrace: !this.state.showStackTrace });

    render() {
        const { showStackTrace, error, errorInfo } = this.state;
        return error == null ? (
            this.props.children
        ) : (
            <div>
                <p>
                    <strong>Oops! An error occurred!</strong>
                </p>
                <p>
                    <em>
                        An error has occurred. Press <code>CTRL + F5</code> to try again.
                    </em>
                </p>
                <p>If this continues to occur, please contact EIMT - Application Support.</p>
                <p>
                    In addition, you can{' '}
                    <span style={{ textDecoration: 'underline' }} onClick={this.handleResetClick}>
                        reset your saved preferences
                    </span>{' '}
                    and try again.
                </p>
                <span style={{ textDecoration: 'underline' }} onClick={this.handleShowTechDetailsClick}>
                    Show Technical Details
                </span>
                {showStackTrace && (
                    <div style={{ marginTop: 10, padding: 20 }}>
                        <p>
                            <strong>Error:</strong> <em>{error.message.toString()}</em>
                        </p>
                        <strong>Component Stack:</strong>
                        <br />
                        <pre>
                            <code>{errorInfo.componentStack.trim()}</code>
                        </pre>
                        <br />
                        <strong>Stack Trace:</strong>
                        <br />
                        <pre>
                            <code>{error.stack}</code>
                        </pre>
                        <br />
                    </div>
                )}
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    LocalSettings: state.AppSettingsReducer.LocalSettings.Portfolio,
});

const mapDispatchToProps = (dispatch) => ({
    resetLocalSettingDispatcher: () => dispatch(resetLocalSettings()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ErrorBoundary);
