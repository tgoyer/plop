import React from 'react';

const LoadingOverlay = () => {
    return (
        <div>
            <div className="loading-background"></div>
            <div className="loading-fading-circle">
                <div className="loading-circle1 loading-circle"></div>
                <div className="loading-circle2 loading-circle"></div>
                <div className="loading-circle3 loading-circle"></div>
                <div className="loading-circle4 loading-circle"></div>
                <div className="loading-circle5 loading-circle"></div>
                <div className="loading-circle6 loading-circle"></div>
                <div className="loading-circle7 loading-circle"></div>
                <div className="loading-circle8 loading-circle"></div>
                <div className="loading-circle9 loading-circle"></div>
                <div className="loading-circle10 loading-circle"></div>
                <div className="loading-circle11 loading-circle"></div>
                <div className="loading-circle12 loading-circle"></div>
            </div>
        </div>
    );
};

export default LoadingOverlay;
