import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { Dialog, DialogActions, DialogTitle, DialogContent } from '@material-ui/core';

import Button from 'componentlibrary/buttons/Button';

const styles = (theme) => ({
    contentContainer: {
        padding: '15px',
        minWidth: '350px',
        borderRadius: '4px 4px 0 0',
    },
    headerContainer: {
        background: theme.palette.primary.main,
        color: 'white !important',
        padding: '6px 6px 6px 12px',
        textShadow: '1px 1px rgba(65, 92, 139, 1)',
    },
    dialogActionContainer: {
        paddingRight: '10px',
        marginTop: '-10px',
        paddingBottom: '10px',
    },
});

const CommonDialog = ({ classes, title, canConfirm = true, onClose, onConfirm, children, showActions, isInformation, open }) => {
    return (
        <Dialog aria-describedby="dialog-title" aria-labelledby="dialog-title" open={open}>
            <DialogTitle id="dialog-title" className={classes.headerContainer} disableTypography={true}>
                <h2>{title}</h2>
            </DialogTitle>
            <DialogContent>
                <div id="alert-dialog-slide-description" className={classes.contentContainer}>
                    {children}
                </div>
            </DialogContent>
            {showActions && (
                <DialogActions className={classes.dialogActionContainer}>
                    <Button onClick={onClose} className={!isInformation && 'secondary'}>
                        {isInformation ? 'OK' : 'Cancel'}
                    </Button>
                    {onConfirm != null && (
                        <Button disabled={!canConfirm} onClick={onConfirm}>
                            Confirm
                        </Button>
                    )}
                </DialogActions>
            )}
        </Dialog>
    );
};

export default React.memo(withStyles(styles)(CommonDialog));
