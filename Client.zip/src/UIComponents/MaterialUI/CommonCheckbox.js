import React from 'react';
import PropTypes from 'prop-types';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import cn from 'classnames';
import green from '@material-ui/core/colors/green';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from '../Tooltip';
import { pxToRem } from '../../Utils/layoutHelper';

const styles = {
    root: {
        color: green[600],
        '&$checked': {
            color: green[500],
        },
        height: 23,
    },
    checked: {},
    toolTip: {
        '& table': {
            border: 0,
            maxWidth: 400,
        },
    },
    size: {
        height: 40,
    },
    sizeIcon: {
        fontSize: pxToRem(20),
    },
};

class CheckboxLabels extends React.Component {
    getIndex(value, arr, prop) {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i][prop] === value) {
                return i;
            }
        }
        return -1; //to handle the case where the value doesn't exist
    }

    handleOnChange = (item) => (event) => {
        event.stopPropagation();

        const { IdField } = this.props;
        const checked = !!event.target.checked;
        const items = [...this.props.Items];
        const selectedItem = items.find((i) => i[IdField] === item[IdField]);

        if (selectedItem != null) {
            selectedItem.IsSelected = checked;
        }

        //sending current components state values to main components
        this.props.onChange(items, this.props.Name);
    };

    render() {
        const { classes, CheckedField, IdField, isDisabled } = this.props;

        const checkboxColor =
            this.props.ThemeOverride != null && this.props.ThemeOverride.CheckboxColor != null ? this.props.ThemeOverride.CheckboxColor : styles.root.color;

        return (
            <FormGroup>
                {this.props.Items != null &&
                    this.props.Items.length > 0 &&
                    this.props.Items.map((item) => (
                        <React.Fragment key={item[IdField]}>
                            <FormControlLabel
                                data-tip
                                data-for={`KeyIssueTooltip-${item[IdField]}`}
                                key={item[IdField]}
                                control={
                                    <Checkbox
                                        disabled={isDisabled}
                                        checked={!!item[CheckedField]}
                                        classes={{
                                            root: classes.root,
                                            checked: classes.checked,
                                        }}
                                        style={{
                                            color: checkboxColor,
                                            '&$checked': checkboxColor,
                                        }}
                                        onChange={this.handleOnChange(item)}
                                        value={item[IdField].toString()}
                                    />
                                }
                                label={item.KeyIssueName}
                            />
                            {item.Definition && (
                                <Tooltip id={`KeyIssueTooltip-${item[IdField]}`} className={cn(classes.toolTip)} place="left">
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td>{item.Definition}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </Tooltip>
                            )}
                        </React.Fragment>
                    ))}
            </FormGroup>
        );
    }
}

CheckboxLabels.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(CheckboxLabels);
