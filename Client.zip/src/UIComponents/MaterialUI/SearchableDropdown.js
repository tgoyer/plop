/* eslint-disable react/prop-types, react/jsx-handler-names */

import React from 'react';
import PropTypes from 'prop-types';
import Select from 'react-select';

import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core/styles';

import { convertRgbaToCss, convertCssRgbToRgb, calculateContrastColorRgb, pxToRem } from '../../Utils/layoutHelper';

const baseSize = pxToRem(14);
const styles = (theme) => ({
    input: {
        display: 'flex',
        fontSize: baseSize,
        height: 'inherit',
        padding: 0,
    },
    valueContainer: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        width: '100%',
    },
    singleValue: {
        fontSize: baseSize,
        overflow: 'hidden',
        paddingLeft: 10,
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        width: 'calc(100% - 16px)',
    },
});

function ClearIndicator(props) {
    return null;
}

function inputComponent({ inputRef, ...props }) {
    return <div ref={inputRef} {...props} />;
}

function Control(props) {
    return (
        <TextField
            fullWidth
            InputProps={{
                inputComponent,
                inputProps: {
                    className: props.selectProps.classes.input,
                    inputRef: props.innerRef,
                    children: props.children,
                    ...props.innerProps,
                },
            }}
            {...props.selectProps.textFieldProps}
        />
    );
}

function Option(props) {
    const rgbValues = convertCssRgbToRgb(props.data.colorCode);
    const style = {
        backgroundColor: props.data.colorCode,
        color: rgbValues != null ? convertRgbaToCss(calculateContrastColorRgb(rgbValues.r, rgbValues.g, rgbValues.b)) : 'black',
        fontWeight: props.isSelected ? 700 : 400,
        fontSize: pxToRem(14),
        padding: 10,
    };

    return (
        <MenuItem buttonRef={props.innerRef} selected={props.isFocused} component="div" style={style} {...props.innerProps}>
            {props.children}
        </MenuItem>
    );
}

function SingleValue(props) {
    const rgbValues = convertCssRgbToRgb(props.data.colorCode);
    const style = {
        backgroundColor: props.data.colorCode,
        color: rgbValues != null ? convertRgbaToCss(calculateContrastColorRgb(rgbValues.r, rgbValues.g, rgbValues.b)) : 'inherit',
    };

    return (
        <div className={props.selectProps.classes.singleValue} style={style} {...props.innerProps}>
            {props.children}
        </div>
    );
}

function ValueContainer(props) {
    return <div className={props.selectProps.classes.valueContainer}>{props.children}</div>;
}

const components = {
    ClearIndicator,
    Control,
    Option,
    SingleValue,
    ValueContainer,
};

class SearchableDropdown extends React.Component {
    render() {
        const { classes, isClearable = true, isDisabled, dropdownName, dropdownItems, defaultValue, onClick, onChange, placeholder, selectStyles } = this.props;
        const customStyles = {
            valueContainer: (base) => ({
                ...base,
                ...selectStyles,
            }),
        };

        return (
            <div onClick={onClick} style={{ width: '100%' }}>
                <Select
                    classes={classes}
                    styles={customStyles}
                    textFieldProps={{
                        label: dropdownName,
                        InputLabelProps: {
                            ...this.props.InputLabelProps,
                            shrink: true,
                        },
                    }}
                    options={dropdownItems}
                    components={components}
                    value={defaultValue}
                    onChange={onChange}
                    placeholder={placeholder}
                    isDisabled={isDisabled}
                    backspaceRemovesValue={true}
                    isClearable={isClearable}
                />
            </div>
        );
    }
}

SearchableDropdown.propTypes = {
    classes: PropTypes.object.isRequired,
    theme: PropTypes.object.isRequired,
};

export default withStyles(styles, { withTheme: true })(SearchableDropdown);
