import React from 'react';
import { withStyles } from '@material-ui/core/styles';

import Button from '@material-ui/core/Button';

import { Popover, DialogSizes } from '../../components/Dialogs';

const styles = {
    headerText: {
        color: 'black',
    },
    messageContainer: {
        maxHeight: 300,
        overflowX: 'auto',
    },
    messageList: {
        margin: '10px 0 0 -20px',
        '& li': {
            background: '#fee',
            borderLeft: '3px solid #900',
            color: '#000',
            listStyleType: 'none',
            margin: '8px 0 0 -16px',
            padding: '4px 2px 4px 8px',
        },
    },
};

const CommonErrorDialog = (props) => {
    const { classes, title, messages, onClose } = props;
    const isVisible = Array.isArray(messages) && messages.length > 0;
    const dialogTitle = title || "Oops!  Something's not right...";
    return (
        <Popover
            onClose={onClose}
            show={isVisible}
            title={dialogTitle}
            size={DialogSizes.SMALL}
            lockHeight={true}
            actions={
                <React.Fragment>
                    <Button onClick={onClose} variant="contained" color="primary" style={{ paddingTop: '10px', margin: '2px' }}>
                        Close
                    </Button>
                </React.Fragment>
            }
        >
            <div className={classes.headerText}>Please review these errors and try again.</div>
            <div className={classes.messageContainer}>
                <ul className={classes.messageList}>{messages && messages.map((msg, i) => <li key={i}>{msg}</li>)}</ul>
            </div>
        </Popover>
    );
};

export default withStyles(styles)(CommonErrorDialog);
