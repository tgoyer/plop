import React from 'react';
import Snackbar from '@material-ui/core/Snackbar';
import { withStyles } from '@material-ui/core/styles';

import NotificationBarContent from './NotificationBarContent';

const styles = (theme) => ({
    margin: theme.spacing(2),
});

class NotificationBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            open: props.open || false,
        };
    }

    handleClose = (event, reason) => {
        this.setState({ open: false }, () => {
            if (this.props.onClose) {
                this.props.onClose();
            }
        });
    };

    render() {
        const { classes, variant, children } = this.props;

        return (
            <React.Fragment>
                <Snackbar
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                    open={this.state.open}
                    // autoHideDuration={60000}
                    onClose={this.handleClose}
                >
                    <NotificationBarContent className={classes.margin} onClose={this.handleClose} variant={variant == null ? 'info' : variant}>
                        {children}
                    </NotificationBarContent>
                </Snackbar>
            </React.Fragment>
        );
    }
}

export default withStyles(styles)(NotificationBar);
