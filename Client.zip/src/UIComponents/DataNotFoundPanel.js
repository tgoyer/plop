import React from 'react';
import LoadingPanel from './LoadingPanel';

import { pxToRem } from '../Utils/layoutHelper';

const containerStyle = {
    fontSize: pxToRem(18),
    fontWeight: 700,
    textAlign: 'left',
    display: 'inline-block',
    verticalAlign: 'middle',
    width: 'calc(100% - 73px)',
};
const iconStyle = {
    fontSize: pxToRem(24),
    paddingRight: 16,
    display: 'inline-block',
    verticalAlign: 'middle',
};

const DataNotFoundPanel = ({ message }) => (
    <LoadingPanel>
        <i className="fas fa-times-circle" style={iconStyle}></i>
        <div style={containerStyle}>{message}</div>
    </LoadingPanel>
);

export default DataNotFoundPanel;
