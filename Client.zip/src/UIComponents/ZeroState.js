import React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';

import SecuritySearch from '../UIComponents/SecuritySearch';
import { pxToRem } from '../Utils/layoutHelper';

import { selectCompanyByID } from '../store/CompanyModule';

const styles = (theme) => ({
    root: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',

        height: '50%',
        width: '100%',
    },
    actionContent: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16,

        padding: 24,
        backgroundColor: '#ffffff',
        border: '1px solid #cccccc',
        borderRadius: 8,
        maxWidth: 550,
        minWidth: 350,
        width: '50%',
    },
    actionIcon: {
        fontSize: pxToRem(35),
    },
    actionLabel: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 24,
        padding: '0 16px',
        fontSize: pxToRem(16),
    },
});

const ZeroState = (props) => {
    const { classes, Selected } = props;

    const handler = (selectedCompany) => {
        const { history, match } = props;
        history.push(`${match.url}/${selectedCompany.CompanyID}`);
    };

    return (
        <div className={classes.root}>
            <div className={classes.actionContent}>
                <div className={classes.actionLabel}>
                    <i className={cn('fa', 'fa-search', classes.actionIcon)} aria-hidden="true"></i>
                    <span>You must select a security before using this feature. To start, search for a company by name or security ticker.</span>
                </div>
                <SecuritySearch autoFocus={true} clickAction={handler} selectedItem={Selected} />
            </div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        Selected: state.CompanyReducer.Selected.Data,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchAndSelectCompanyByID: (company) => dispatch(selectCompanyByID(company)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withStyles(styles)(ZeroState)));
