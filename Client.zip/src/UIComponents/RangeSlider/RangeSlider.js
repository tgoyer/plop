import React from "react";

import styles from "./styles.module.css";

class RangeSlider extends React.Component {
    constructor(props) {
        super(props);
        this.state = this.getStateFromProps(props);
    }

    componentWillReceiveProps(nextProps) {
        this.setState(this.getStateFromProps(nextProps));
    }

    getStateFromProps(props) {
        let limits = props.limits.slice().sort(this.sortValues);
        let values = props.values.slice().sort(this.sortValues);
        let size = Math.abs(limits[1] - limits[0]);

        values[0] = values[0] < limits[0] 
            ? limits[0] 
            : values[0] > limits[1] 
                ? limits[1] 
                : values[0];

        values[1] = values[1] > limits[1] 
            ? limits[1] 
            : values[1] < limits[0] 
                ? limits[0] 
                : values[1];

        return {
            limits,
            size,
            values,
            isSelDown: false,
            indexSelDown: 0,
            moveStartValue: 0,
            moveCurrentValue: 0,
            moveStartX: 0,
            moveCurrentX: 0,
            boxWidth: 0, 
        }
    }

    /**
     * getDisplayLimits
     * return limits well formated
     */
    getDisplayLimits() {
        const limits = this.getLimits();

        if (this.props.reverse) {
            limits.reverse();
        }
        
        return [
            this.props.formatValue(limits[0]), 
            this.props.formatValue(limits[1])
        ];
    }

    /**
     * getValues
     * return current values, including when sliding, formatted for display.
     */
    getDisplayValues() {
        const values = this.getValues().sort(this.sortValues);
        
        if (this.props.reverse) {
            values.reverse();
        }

        return [
            this.props.formatValue(values[0]), 
            this.props.formatValue(values[1])
        ];
    }

    /**
     * getLeftPositions
     * return left position as a proportion
     */
    getLeftPositions() {
        const values = this.getValues();
        const limits = this.getLimits();
        const size = this.state.size;
        const left = [values[0] - limits[0], values[1] - limits[0]];
        const leftPos = [left[0] / size * 100, left[1] / size * 100];

        if (this.props.reverse) {
            return [100 - leftPos[0], 100 - leftPos[1]];
        }

        return leftPos;
    }

    /**
     * getLimits
     * return limits
     */
    getLimits() {
        return [...this.state.limits];
    }

    /**
     * getMoveCurrentValue
     * return the moving current value
     */
    getMoveCurrentValue (moveCurrentX) {
        let moveBoxProportion = (moveCurrentX-this.state.moveStartX) / this.state.boxWidth;
        if (this.props.reverse) {
            moveBoxProportion = moveBoxProportion * -1;
        }

        const moveIntoLimit = this.state.size * moveBoxProportion;

        let moveCurrentValue = this.state.moveStartValue+moveIntoLimit;
        moveCurrentValue = moveCurrentValue < this.state.limits[0] 
            ? this.state.limits[0]
            : moveCurrentValue;
        moveCurrentValue = moveCurrentValue > this.state.limits[1] 
            ? this.state.limits[1]
            : moveCurrentValue;

        return moveCurrentValue;
    }

    /**
     * getValues
     * return current values, including when sliding
     */
    getValues() {
        const values = [...this.state.values];

        if (this.state.isSelDown) {
            values[this.state.indexSelDown] = this.state.moveCurrentValue;
        }
        
        return values;
    }
  
    move(event) {
        if (this.state.isSelDown) {
            const clientX = event.touches && event.touches.length > 0 
                ? event.touches[0].clientX 
                : event.clientX;
            
            this.setState({
                moveCurrentX: clientX,
                moveCurrentValue: this.getMoveCurrentValue(clientX)
            });
        }
    }

    onChange() {
        this.props.onChange(this.getValues().sort(this.sortValues));
    }

    onMouseDownMax(event) {
        this.startToMove(event, 1);
    }

    onMouseDownMin(event) {
        this.startToMove(event, 0);
    }
    
    onMouseLeave(event) {
        this.stopToMove(event);
    }

    onMouseMove(event) {
        this.move(event);
    }

    onMouseUp(event) {
        this.stopToMove(event);
    }

    onTouchEnd(event) {
        this.stopToMove(event);
    }
    
    onTouchMove(event) {
        this.move(event);
    }

    onTouchStartMax(event) {
        this.startToMove(event, 1);
    }

    onTouchStartMin(event) {
        this.startToMove(event, 0);
    }

    /**
     * startToMove
     * event triggered when the user starts to move
     */
    startToMove(event, index) {
        const clientX = event.touches && event.touches.length > 0 
            ? event.touches[0].clientX 
            : event.clientX;

        event.stopPropagation();
        this.setState({
            isSelDown:true,
            indexSelDown: index,
            moveStartValue: Number(this.state.values[index]),
            moveCurrentValue: Number(this.state.values[index]),
            moveStartX: Number(clientX),
            moveCurrentX: Number(clientX),
            boxWidth:event.currentTarget.parentElement.offsetWidth
        });
    }

    /**
     * stopToMove
     * event triggered when the user stop to move
     */
    stopToMove(event) {
        if(this.state.isSelDown) {
            const values = this.getValues().map(i => Number(i));
            this.setState({
                values: values,
                isSelDown: false
            });
            this.onChange();
        }
        event.stopPropagation();
    }

    /**
     * sortValues
     * ascending sort method for arrays
     */
    sortValues(a, b) { return a-b; }

    /**
     * render
     * component rendering method 
     */
    render() {
        const displayValues = this.getDisplayValues();
        //const displayLimits = this.getDisplayLimits();
        const leftPos = this.getLeftPositions();

        let crossLinePos = leftPos.slice();
        crossLinePos.sort(this.sortValues);
        crossLinePos[1] = 100 - crossLinePos[1];

        const styleCrossline = {
            left: crossLinePos[0] + '%',
            right: crossLinePos[1] + '%',
            backgroundColor: this.props.rangeColor,
        };

        const styleSelector0 = {
            left: leftPos[0] + '%',
            display: this.props.lock[0] === false ? 'block' : 'none',
        };

        const styleSelector1 = {
            left: leftPos[1] + '%',
            display: this.props.lock[1] === false ? 'block' : 'none',
        };

        return (
            <div className={styles.component} 
                data-name='component'
                onMouseMove={this.onMouseMove.bind(this)}
                onMouseLeave={this.onMouseLeave.bind(this)}
                onMouseUp={this.onMouseUp.bind(this)}
                onTouchMove={this.onTouchMove.bind(this)}
                onTouchEnd={this.onTouchEnd.bind(this)}
            >
                <div className={styles.sliders}>
                    <div className={styles.line}><div className={styles.crossLine} style={styleCrossline}></div></div>
                    <div 
                        className={[styles.selector, styles.selector0].join(' ')} 
                        style={styleSelector0}
                        onMouseDown={this.onMouseDownMin.bind(this)}
                        onTouchStart={this.onTouchStartMin.bind(this)}
                        >
                        <div></div>
                    </div>
                    <div
                        className={[styles.selector, styles.selector1].join(' ')} 
                        style={styleSelector1}
                        onMouseDown={this.onMouseDownMax.bind(this)}
                        onTouchStart={this.onTouchStartMax.bind(this)}
                        >
                        <div></div>
                    </div>
                </div>
                
                <div className={styles.values}>
                    { /* <div className={styles.limit}>{displayLimits[0]}</div> */ }
                    <div className={styles.value}>{displayValues[0]}</div>
                    { /* <div className={styles.valueRange} style={styleValueRange}></div> */ }
                    <div className={styles.value}>{displayValues[1]}</div>
                    { /* <div className={styles.limit}>{displayLimits[1]}</div> */ }
                </div>
            </div>
        );
    }
}

RangeSlider.displayName = "RangeSlider";

RangeSlider.defaultProps = {
    limits: [0, 100],
    values: [0, 100],
    lock: [false, false],
    reverse: false,
    formatValue: function(value) {
        return value;
    },
    onChange: function() {},
    rangeColor:'#999'
};

export default RangeSlider;