import React from 'react';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    badges: {
        listStyle: 'none',
        margin: 0,
        padding: '0 10px',
        width: '100%',
    }
});
  
const BadgeList = (props) => {
    const { classes, children } = props;
    const style = (props.style != null) ? props.style : {};

    return (
        <ul className={classes.badges} style={{...style}}>{children}</ul>
    );
}
  
export default withStyles(styles)(BadgeList);