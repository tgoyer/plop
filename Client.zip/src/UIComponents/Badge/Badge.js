import React from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

const createBgColors = (color) => ({
    backgroundColor: color || '#eee',
    '&::after': {
        borderLeft: `10px solid ${ color || '#eee' }`,
    },
    '&::before': {
        borderRight: `10px solid ${ color || '#eee' }`,
    }
})

const styles = theme => ({
    root: {
        background: '#eee',
        color: '#fff',
        display: 'inline-block',
        fontWeight: 700,
        padding: 0,
        position: 'relative',
        margin: 0,
        textAlign: 'center',
        textDecoration: 'none',
        textShadow: '1px 1px rgba(65, 92, 139, 1)',
        width: '100%',
        '&::after': {
            backgroundColor: theme.palette.primary.main,
            content: '""',
            position: 'absolute',
        },
        '&::before': {
            backgroundColor: theme.palette.primary.main,
            content: '""',
            position: 'absolute',
        },
    },
    defaultBadge: {
        borderRadius: '3px 0 0 3px',
        padding: '0 0 0 6px',
        '&::after': {
            borderBottom: '13px solid transparent',
            borderLeft: '10px solid #eee',
            borderTop: '13px solid transparent',
            right: 0,
            top: 0,
        },
        '&::before': {
            borderRadius: 10,
            boxShadow: 'inset 0 1px rgba(0, 0, 0, 0.6)',
            height: 6,
            left: 10,
            top: 10,
            width: 6,
        },
    },
    arrowBadge: {
        borderRadius: 0,
        '&::after': {
            borderBottom: '13px solid transparent',
            borderLeft: '10px solid #eee',
            borderTop: '13px solid transparent',
            right: 0,
            top: 0,
        },
        '&::before': {
            borderBottom: '13px solid transparent',
            borderRight: '10px solid #eee',
            borderTop: '13px solid transparent',
            left: 0,
            top: 0,
        },
    },
    roundBadge: {
        borderRadius: 50,
    },
    stripeBadge: {
        borderRadius: 0,
    },
    colorBlue: createBgColors('#1e98d7'),
    colorCornflower: createBgColors(theme.palette.primary.main),
    colorGreen: createBgColors('#60ba53'),
    colorNavy: createBgColors('#3f51b5'),
    colorOrange: createBgColors('#f08f50'),
});

class Badge extends React.Component {
    static Colors = {
        Blue: 0,
        Cornflower: 1,
        Green: 2,
        Navy: 3,
        Orange: 4,
    }

    static Types = {
        Default: 'default',
        Arrow: 'arrow',
        Rounded: 'round',
        Stripe: 'stripe',
    }

    render() {
        const { children, classes, color, type, fontSize } = this.props;
        const classNames = cn(classes.root, {
            [classes.defaultBadge]: type === Badge.Types.Default,
            [classes.arrowBadge]: type === Badge.Types.Arrow,
            [classes.roundBadge]: type === Badge.Types.Rounded,
            [classes.stripeBadge]: type === Badge.Types.Stripe,
            
            [classes.colorBlue]: color === Badge.Colors.Blue,
            [classes.colorCornflower]: color === Badge.Colors.Cornflower,
            [classes.colorGreen]: color === Badge.Colors.Green,
            [classes.colorNavy]: color === Badge.Colors.Navy,
            [classes.colorOrange]: color === Badge.Colors.Orange,
        });
        const style = {
            fontSize: (fontSize != null) ? fontSize : 18
        }

        return <li style={style} className={classNames}>{ children }</li>;
    }
}


export default withStyles(styles)(Badge);