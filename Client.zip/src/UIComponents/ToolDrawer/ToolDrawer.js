import React from 'react';
import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    drawerTools: {
        display: 'flex',
        flexDirection: 'column',
        height: 'calc(100vh - 166px)',
        margin: 12,
        '& > div + div': {
            marginTop: 10,
            overflowY: 'auto',
        },
    },
});

const ToolDrawer = (props) => {
    const { children, classes } = props;
    const [expandedIdx, setExpandedIdx] = React.useState(0);

    const handleHeaderClick = (idx) => () => setExpandedIdx(idx);

    return (
        <div className={classes.drawerTools} data-test="tool-drawer">
            {React.Children.map(children, (child, idx) => {
                return React.cloneElement(child, {
                    onHeaderClick: handleHeaderClick(idx),
                    expanded: idx === expandedIdx,
                });
            })}
        </div>
    );
};

export default withStyles(styles, { withTheme: true })(ToolDrawer);
