import React from 'react';
import cn from 'classnames';
import { DateTime } from 'luxon';
import { useSelector } from 'react-redux';

import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import DatePicker from 'components/Form/DatePicker';
import SearchableDropdown from 'UIComponents/MaterialUI/SearchableDropdown';
import DrawerSection from './DrawerSection';
import { toOptionsList } from 'Utils/selectHelper';
import { pxToRem } from 'Utils/layoutHelper';

const styles = (theme) => ({
    activeButton: {},
    checkbox: {
        fontSize: 12,
        padding: '0 8px 0 0',
    },
    clearLink: {
        color: '#6987B9',
        float: 'right',
        fontSize: pxToRem(11),
        fontWeight: 400,
        textDecoration: 'underline',
    },
    filter: {
        display: 'inline-block',
        verticalAlign: 'middle',
        width: '100%',
        '& button': {
            marginTop: 8,
        },
        '& button + button': {
            marginLeft: 8,
        },
    },
    filterGroup: {
        display: 'inline',
    },
    filterDateButton: {
        width: '35%',
    },
    filterDateControl: {
        margin: '5px 10px',
        width: 300,
        '& button': {
            padding: 6,
        },
    },
    iconGlobal: {
        color: theme.palette.primary.main,
        transform: 'rotate(23deg)',
    },
    linkButton: {
        background: 'none',
        color: theme.palette.primary.main,
        cursor: 'pointer',
        fontSize: pxToRem(12),
        margin: 0,
        padding: 0,
        minWidth: 40,
    },
    primaryButton: {
        backgroundColor: theme.palette.primary.main,
        color: '#eee',
        '&:hover': {
            backgroundColor: '#495e81',
            color: '#fff',
        },
    },
    sectionBlock: {
        marginBottom: 20,
    },
    sectionFilter: {
        margin: '0 0 0 50px',
        paddingBottom: 10,
        '& div + div': {
            paddingBottom: 0,
        },
    },
    sectionGlobalFilters: {},
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: pxToRem(14),
        margin: '5px 0px 5px 20px',
        padding: 5,
    },
    sectionHeaderLabel: {
        cursor: 'pointer',
    },
    selectDropDown: {
        fontSize: pxToRem(12),
    },
    subHeaderButton: {
        fontWeight: 700,
        padding: '0 12px',
    },
});

const entryTypes = Object.freeze({
    RESEARCH: 1,
    ENGAGEMENT: 2,
});

const filterTypes = Object.freeze({
    DATE: 'date',
    ENTRY: 'entry',
    TEAM: 'team',
});

const dateDaysAgo = (days) => DateTime.now().minus({ days }).toJSDate();

const GlobalFiltersDrawerSection = ({
    classes,
    expanded,
    filterEntryType,
    filterDate,
    filterTeam,
    onHeaderClick,
    onSave,
    showTeamSelection = false,
    showDateSelection = false,
    showEntryTypeSelection = false,
}) => {
    const teams = useSelector((state) => state.DimensionReducer.Teams);

    const [dateEnabled, toggleDateFilter] = React.useState(false);
    const [teamEnabled, toggleTeamFilter] = React.useState(false);
    const [entryType, setEntryType] = React.useState(null);
    const teamOptions = React.useMemo(() => toOptionsList(teams, 'TeamName', 'TeamID'), [teams]);

    const showTeam = showTeamSelection === 1 || showTeamSelection === true;
    const showDate = showDateSelection === 1 || showDateSelection === true;
    const showEntryTypes = showEntryTypeSelection === 1 || showEntryTypeSelection === true;
    const showSection = showTeam || showDate || showEntryTypes;

    React.useEffect(() => {
        toggleDateFilter(dateEnabled || (filterDate != null && (filterDate.End != null || filterDate.Start != null)));
        toggleTeamFilter(teamEnabled || filterTeam != null);
    }, [dateEnabled, teamEnabled, filterDate, filterTeam]);

    React.useEffect(() => {
        setEntryType(filterEntryType);
    }, [filterEntryType]);

    const clearFieldClear = (type) => () => {
        onSave([
            {
                name: type,
                value: type === filterTypes.DATE ? { Start: null, End: null } : null,
            },
        ]);
    };

    const handleDateButtonClick = (type) => () => {
        const date = {
            Start: dateDaysAgo(type === 'week' ? 7 : 30),
            End: dateDaysAgo(0),
        };
        toggleDateFilter(true);
        onSave([{ name: filterTypes.DATE, value: date }]);
    };

    const handleDateInputChange = (dateType) => (value) => {
        const dateValue = value != null ? value.toJSDate() : value;

        const date = {
            Start: dateType === 'Start' ? dateValue : filterDate.Start,
            End: dateType === 'End' ? dateValue : filterDate.End,
        };
        onSave([{ name: filterTypes.DATE, value: date }]);
    };

    const handleDatePickerClick = () => toggleDateFilter(true);
    const handleEntryTypeClick = (type) => () => onSave([{ name: filterTypes.ENTRY, value: type === entryType ? null : type }]);
    const handleTeamChange = (team) => onSave([{ name: filterTypes.TEAM, value: team }]);

    return (
        showSection && (
            <DrawerSection label="Filters" classExpanded={classes.sectionGlobalFilters} expanded={expanded} onHeaderClick={onHeaderClick}>
                {showTeam && (
                    <div className={classes.sectionBlock}>
                        <div className={classes.sectionHeader}>
                            <span className={classes.sectionHeaderLabel}>
                                Global Team Filter
                                <span className={classes.clearLink} onClick={clearFieldClear(filterTypes.TEAM)}>
                                    clear
                                </span>
                            </span>
                        </div>
                        <div className={classes.sectionFilter}>
                            <div className={classes.filter}>
                                <SearchableDropdown id="Teams" dropdownItems={teamOptions} defaultValue={filterTeam} onChange={handleTeamChange} />
                            </div>
                        </div>
                    </div>
                )}
                {showDate && (
                    <div className={classes.sectionBlock}>
                        <div className={classes.sectionHeader}>
                            <span className={classes.sectionHeaderLabel}>
                                Date Range Filter
                                <span className={classes.clearLink} onClick={clearFieldClear(filterTypes.DATE)}>
                                    clear
                                </span>
                            </span>
                        </div>
                        <div className={classes.sectionFilter}>
                            <div className={classes.filterGroup}>
                                <div className={cn(classes.filter, classes.filterDateControl)}>
                                    <DatePicker
                                        label="Start Date"
                                        value={filterDate != null ? filterDate.Start : undefined}
                                        maxDate={filterDate != null && filterDate.End != null ? filterDate.End : undefined}
                                        onChange={handleDateInputChange('Start')}
                                        animateYearScrolling={false}
                                        disableFuture={false}
                                        InputProps={{ style: { fontSize: 12 }, disabled: true, onClick: handleDatePickerClick }}
                                        InputLabelProps={{ shrink: true }}
                                        maxDateMessage="Date should not be after End date"
                                    />
                                </div>
                                <div className={cn(classes.filter, classes.filterDateControl)}>
                                    <DatePicker
                                        label="End Date"
                                        value={filterDate != null ? filterDate.End : undefined}
                                        minDate={filterDate != null && filterDate.Start != null ? filterDate.Start : undefined}
                                        onChange={handleDateInputChange('End')}
                                        animateYearScrolling={false}
                                        disableFuture={false}
                                        InputProps={{ style: { fontSize: 12 }, disabled: true, onClick: handleDatePickerClick }}
                                        InputLabelProps={{ shrink: true }}
                                        minDateMessage="Date should not be before Start date"
                                    />
                                </div>
                            </div>
                            <div className={classes.filterGroup}>
                                <div className={cn(classes.filter, classes.filterDateButton)}>
                                    <Button color="primary" className={cn(classes.linkButton, classes.subHeaderButton)} onClick={handleDateButtonClick('week')}>
                                        Last 7 days
                                    </Button>
                                </div>
                                <div className={cn(classes.filter, classes.filterDateButton)}>
                                    <Button
                                        color="primary"
                                        className={cn(classes.linkButton, classes.subHeaderButton)}
                                        onClick={handleDateButtonClick('month')}
                                    >
                                        Last 30 days
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                {showEntryTypes && (
                    <div className={classes.sectionBlock}>
                        <div className={classes.sectionHeader}>
                            <span className={classes.sectionHeaderLabel}>
                                Entry Type Filter
                                <span className={classes.clearLink} onClick={clearFieldClear(filterTypes.ENTRY)}>
                                    clear
                                </span>
                            </span>
                        </div>
                        <div className={classes.sectionFilter}>
                            <div className={classes.filter}>
                                <Button
                                    className={cn({
                                        [classes.linkButton]: entryType !== entryTypes.ENGAGEMENT,
                                        [classes.subHeaderButton]: entryType !== entryTypes.ENGAGEMENT,
                                    })}
                                    color="primary"
                                    onClick={handleEntryTypeClick(entryTypes.ENGAGEMENT)}
                                    variant={entryType === entryTypes.ENGAGEMENT ? 'contained' : 'text'}
                                >
                                    Engagement
                                </Button>
                                <Button
                                    className={cn({
                                        [classes.linkButton]: entryType !== entryTypes.RESEARCH,
                                        [classes.subHeaderButton]: entryType !== entryTypes.RESEARCH,
                                    })}
                                    color="primary"
                                    onClick={handleEntryTypeClick(entryTypes.RESEARCH)}
                                    variant={entryType === entryTypes.RESEARCH ? 'contained' : 'text'}
                                >
                                    Research
                                </Button>
                            </div>
                        </div>
                    </div>
                )}
            </DrawerSection>
        )
    );
};

export default withStyles(styles, { withTheme: true })(GlobalFiltersDrawerSection);
