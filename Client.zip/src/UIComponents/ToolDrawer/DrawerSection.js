import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import { pxToRem } from '../../Utils/layoutHelper';

const styles = (theme) => ({
    actionsContainer: {
        display: 'inline-block',
        float: 'right',
        '& > button': {
            minHeight: '32px !important',
        },
    },
    collapsed: {
        display: 'flex',
        flexDirection: 'column',
        flexGrow: 0.0001,
    },
    expanded: {
        display: 'flex',
        flexDirection: 'column',
        flexGrow: 1,
        flexBasis: '35px',
    },
    sectionBody: {
        fontSize: pxToRem(12),
        margin: 0,
        height: 'calc(100% - 36px)',
        '& > div + div': {
            marginTop: 12,
        },
    },
    sectionContainer: {
        transition: 'all 150ms',
    },
    sectionHeading: {
        backgroundColor: '#eee',
        color: theme.palette.primary.main,
        cursor: 'pointer',
        fontSize: pxToRem(13),
        fontWeight: 'bold',
        margin: 0,
        userSelect: 'none',
        '& > *': {
            display: 'inline-block',
        },
        '& > i': {
            padding: '10px 10px 10px 15px',
        },
    },
    sectionHeadingIcon: {
        transform: 'rotate(0deg)',
    },
    sectionHeadingIconRotate: {
        transform: 'rotate(90deg)',
    },
    sectionHeadingLabel: {},
    sectionHidden: {
        height: 0,
        display: 'none',
        '& > i': {
            padding: '10px 15px 15px 15px',
        },
    },
});

const DrawerSection = (props) => {
    const { actions, children, classExpanded, classCollapsed, classes, expanded, label, onHeaderClick, ...rest } = props;

    return (
        <div
            className={cn(classes.sectionContainer, {
                [classes.expanded]: expanded === true,
                [classExpanded]: expanded === true,
                [classes.collapsed]: expanded === false,
                [classCollapsed]: expanded === false,
            })}
        >
            <div className={classes.sectionHeading} onClick={onHeaderClick}>
                <i className={cn('fas', classes.sectionHeadingIcon, { 'fa-arrow-right': !expanded, 'fa-arrow-down': expanded })}></i>
                <span className={classes.sectionHeadingLabel}>{label}</span>
                {actions != null && <div className={classes.actionsContainer}>{actions({ active: expanded })}</div>}
            </div>
            {expanded && (
                <div className={cn(classes.sectionBody, { [classes.sectionHidden]: !expanded })}>
                    {React.Children.map(children, (child) => {
                        return child != null && child !== false ? React.cloneElement(child, { ...rest }) : null;
                    })}
                </div>
            )}
        </div>
    );
};

export default withStyles(styles, { withTheme: true })(DrawerSection);
