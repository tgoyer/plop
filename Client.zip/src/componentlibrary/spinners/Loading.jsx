import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import { pxToRem } from 'Utils/layoutHelper';

const styles = (theme) => ({
    panel: {
        padding: 16,
        fontSize: pxToRem(16),
        width: '100%',
        margin: '0 auto',
        textAlign: 'center',
        opacity: 0.75,
    },
    spin: {
        fontSize: pxToRem(24),
        margin: '10px 25px',
        display: 'inline-block',
        verticalAlign: 'middle',
        color: '#bfbfbf',
    },
});

const Loading = ({ classes, children }) => <div className={classes.panel}>{children != null ? children : <i className={cn(classes.spin, 'fas fa-circle-notch fa-spin')}></i>}</div>;

export default withStyles(styles)(Loading);
