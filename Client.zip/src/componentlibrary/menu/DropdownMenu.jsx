import { Root, Arrow, CheckboxItem, Content, Item, Portal, Sub, SubTrigger, SubContent, Separator, Trigger, ItemIndicator } from '@radix-ui/react-dropdown-menu';
import { withStyles } from '@material-ui/core/styles';
import cn from 'classnames';

const styles = () => ({
    arrow: {
        fill: '#bfbfbf',
    },
    content: {
        minWidth: 220,
        backgroundColor: '#ffffff',
        border: '2px solid #bfbfbf',
        borderRadius: 4,
        boxShadow: '#0e121659 0px 10px 38px -10px, #0e121633 0px 10px 20px -15px',
        overflow: 'hidden',
    },
    indicator: {
        position: 'absolute',
        left: 0,
        width: 25,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    item: {
        display: 'flex',
        alignItems: 'center',
        backgroundColor: '#fff',
        color: '#333',
        cursor: 'pointer',
        outline: 'none',
        padding: 6,
        paddingLeft: 25,
        position: 'relative',
        userSelect: 'none',
        '&[data-disabled]': {
            color: '#999',
            pointerEvents: 'none',
        },
        '&[data-highlighted]': {
            backgroundColor: '#f2f2f2',
            fontWeight: 700,
        },
    },
    subMenu: {
        fontWeight: 700,
        paddingLeft: 8,
    },
    title: {
        display: 'flex',
        justifyContent: 'center',

        backgroundColor: '#1279c611',
        borderBottom: '1px solid #1279c633',
        padding: '6px 8px',
        textTransform: 'uppercase',
        fontWeight: 700,
    },
    trigger: {
        '&[data-disabled]': {
            backgroundColor: '#eee',
            color: '#999',
            pointerEvents: 'none',
        },
        "&[data-highlighted], &[data-state='open']": {
            backgroundColor: '#f2f2f2',
            fontWeight: 700,
        },
    },
});

const Menu = ({ children, classes, open, title, trigger, ...props }) => {
    return (
        <Root open={open}>
            <Trigger className={cn(classes.trigger)} asChild>
                {trigger}
            </Trigger>
            <Portal>
                <Content className={cn(classes.content)} {...props}>
                    {title != null && <div className={classes.title}>{title}</div>}
                    {children}
                    <Arrow className={classes.arrow} />
                </Content>
            </Portal>
        </Root>
    );
};
const SubMenu = ({ children, classes, trigger }) => {
    return (
        <Sub>
            <SubTrigger className={cn(classes.trigger, classes.item, classes.subMenu)}>{trigger}</SubTrigger>
            <Portal>
                <SubContent className={cn(classes.content)}>{children}</SubContent>
            </Portal>
        </Sub>
    );
};
const CheckMenuItem = ({ classes, children, ...props }) => {
    return (
        <CheckboxItem className={classes.item} {...props}>
            <ItemIndicator className={classes.indicator}>
                <i className="fas fa-check"></i>
            </ItemIndicator>
            {children}
        </CheckboxItem>
    );
};
const MenuItem = ({ classes, children, ...props }) => {
    return (
        <Item className={classes.item} {...props}>
            {children}
        </Item>
    );
};

const StyledDropdownMenu = withStyles(styles)(Menu);
const StyledDropdownSubMenu = withStyles(styles)(SubMenu);
const StyledDropdownItem = withStyles(styles)(MenuItem);
const StyledDropdownCheckboxItem = withStyles(styles)(CheckMenuItem);

export {
    StyledDropdownMenu as DropdownMenu,
    StyledDropdownSubMenu as DropdownSubMenu,
    StyledDropdownItem as DropdownItem,
    StyledDropdownCheckboxItem as DropdownCheckboxItem,
    Separator as DropdownSeparator,
};
