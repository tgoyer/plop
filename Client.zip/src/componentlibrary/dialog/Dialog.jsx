import { Close, Content, Description, Overlay, Portal, Root, Title, Trigger } from '@radix-ui/react-dialog';
import cn from 'classnames';
import { withStyles } from '@material-ui/core';

const styles = () => ({
    actions: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingTop: 20,
        gap: 12,
    },
    overlay: {
        backgroundColor: '#00000099',
        position: 'fixed',
        inset: 0,
    },
    children: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        overflow: 'hidden',
        overflowY: 'auto',
    },
    content: {
        display: 'flex',
        flexDirection: 'column',
        gap: 4,

        backgroundColor: '#fff',
        borderRadius: 6,
        boxShadow: 'hsl(206 22% 7% / 35%) 0px 10px 38px -10px, hsl(206 22% 7% / 20%) 0px 10px 20px -15px',
        padding: 25,
        position: 'fixed',
        maxHeight: '85vh',
        overflow: 'auto',
        maxWidth: '90vw',
        width: 'fit-content',

        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',

        '&:focus': {
            outline: 'none',
        },
    },
    title: {
        margin: 0,
        fontWeight: 700,
        color: '#333',
        fontSize: 17,
    },
    description: {
        color: '#333',
        fontSize: 14,
        margin: 0,
        paddingBottom: 12,
    },
    closeButton: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',

        background: 'transparent',
        border: 'transparent',
        borderRadius: 9999,
        color: '#333',
        height: 35,
        width: 35,

        position: 'absolute',
        top: 10,
        right: 10,

        '&:hover': {
            background: '#00000011',
        },
    },
});

const Dialog = ({ classes, className, actions, open, trigger, title, description, children, onOpenChange }) => {
    const handleOpenClose = (open) => {
        if (onOpenChange != null) onOpenChange(open);
    };

    return (
        <Root open={open} onOpenChange={handleOpenClose}>
            <Trigger asChild>{trigger}</Trigger>
            <Portal>
                <Overlay className={classes.overlay} />
                <Content className={cn(classes.content, className)}>
                    <Title className={classes.title}>{title}</Title>
                    <Description className={classes.description}>{description}</Description>
                    <div className={classes.children}>{children}</div>
                    {actions != null && <div className={classes.actions}>{actions}</div>}
                    <Close asChild>
                        <button className={classes.closeButton} onClick={() => handleOpenClose(false)} aria-label="Close">
                            <i className="fas fa-times"></i>
                        </button>
                    </Close>
                </Content>
            </Portal>
        </Root>
    );
};

export default withStyles(styles)(Dialog);
