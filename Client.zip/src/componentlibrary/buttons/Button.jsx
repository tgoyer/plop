import { forwardRef } from 'react';
import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    button: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,

        border: 0,
        borderRadius: 4,
        padding: '0 15px',
        fontSize: '1rem',
        lineHeight: 1,
        fontWeight: 700,
        height: 35,
        outline: 'none',
        width: 'fit-content',

        background: '#1279c6',
        color: '#fff',
        '&:hover': {
            background: '#1279c699',
        },

        '&:focus-visible': {
            boxShadow: '#1279c6 0px 0px 1px 0px, inset #1279c6 0px 0px 0px 1px',
        },
        '&:disabled, &:disabled:hover': {
            background: '#00000033 !important',
            color: '#00000099 !important',
            cursor: 'not-allowed',
        },
        '&.chip': {
            borderRadius: 9999,
        },
        '&.full': {
            width: '100%',
        },
        '&.alert': {
            background: 'transparent',
            color: '#aa1111',
            '&:hover': {
                background: '#c6121211',
            },
        },
        '&.secondary': {
            background: 'transparent',
            color: '#1279c6',
            '&:hover': {
                background: '#1279c611',
            },
        },
    },
});

const Button = forwardRef(({ as = 'button', classes, className, children, ...props }, ref) => {
    const Component = as;

    return (
        <Component ref={ref} className={cn(classes.button, className)} {...props}>
            {children}
        </Component>
    );
});

export default withStyles(styles)(Button);

/*
const icons = {
    default: () => null,
    add: () => <i className={`ab-primary ab-${getStyles(buttonStyle)}-icon fas fa-plus-circle`}></i>,
    chevronDown: () => <i className={`ab-primary ab-${getStyles(buttonStyle)}-icon fas fa-chevron-down`}></i>,
    chevronUp: () => <i className={`ab-primary ab-${getStyles(buttonStyle)}-icon fas fa-chevron-up`}></i>,
    close: () => <i className={`ab-primary ab-${getStyles(buttonStyle)}-icon fas fa-times-circle`}></i>,
    delete: () => <i className={`ab-primary ab-${getStyles(buttonStyle)}-icon fas fa-trash-alt`}></i>,
    custom: () => renderCustomIcon()
};
*/
