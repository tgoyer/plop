import { forwardRef } from 'react';
import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    buttonBar: {
        display: 'flex',
        flexDirection: 'row',
        borderRadius: 4,
        overflow: 'hidden',
        '& > button': {
            borderRadius: 0,
        },
        '& > button.secondary': {
            background: '#1279c611',
            '&:hover': {
                background: '#1279c633',
            },
        },
    },
});

const ButtonBar = forwardRef(({ classes, className, children, ...props }, ref) => {
    return (
        <div ref={ref} className={cn(classes.buttonBar, className)} {...props}>
            {children}
        </div>
    );
});

export default withStyles(styles)(ButtonBar);
