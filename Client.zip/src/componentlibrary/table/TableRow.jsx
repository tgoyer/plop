import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    scrollSnapAlign: 'start',
});

const TableRow = ({ children, classes, className, ...props }) => (
    <tr className={cn(className)} {...props}>
        {children}
    </tr>
);

export default withStyles(styles)(TableRow);
