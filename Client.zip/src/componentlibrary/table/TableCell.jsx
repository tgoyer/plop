import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    cell: {
        padding: '6px 10px',
    },
    header: {
        backgroundColor: '#ebf1fa',
        color: '#4d4d4d',
        minWidth: 24,
        verticalAlign: 'middle',
        padding: '8px 12px',
    },
});

const TableCell = ({ as = 'td', children, classes, className, ...props }) => {
    const Component = as;

    return (
        <Component className={cn(classes.cell, { [classes.header]: as === 'th' }, className)} {...props}>
            {children}
        </Component>
    );
};
export default withStyles(styles)(TableCell);
