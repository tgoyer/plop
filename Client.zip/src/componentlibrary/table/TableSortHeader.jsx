import cn from 'classnames';
import { withStyles } from '@material-ui/core';
import { TableCell } from 'componentlibrary/table';

const styles = () => ({
    header: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 24,
        cursor: 'pointer',
        width: '100%',
    },
    children: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    icons: {
        display: 'flex',
        flexDirection: 'column',
        color: '#cccccc',
        '& i': {
            padding: 2,
            margin: '-3px 0',
        },
    },
    active: {
        color: '#000000',
    },
});

const getDirection = (direction) => {
    switch (direction) {
        case 'ASC':
            return 'DESC';
        case 'DESC':
            return null;
        default:
            return 'ASC';
    }
};

const TableSortHeader = ({ classes, children, field, sort, onClick }) => {
    const handleClick = () => {
        if (onClick != null) {
            onClick({ field, direction: getDirection(sort?.direction) });
        }
    };

    return (
        <TableCell as="th">
            <div className={classes.header} onClick={handleClick}>
                <div className={classes.children}>{children}</div>
                <div className={classes.icons}>
                    <i className={cn('fas fa-caret-up', { [classes.active]: field === sort?.field && sort?.direction === 'ASC' })}></i>
                    <i className={cn('fas fa-caret-down', { [classes.active]: field === sort?.field && sort?.direction === 'DESC' })}></i>
                </div>
            </div>
        </TableCell>
    );
};

export default withStyles(styles)(TableSortHeader);
