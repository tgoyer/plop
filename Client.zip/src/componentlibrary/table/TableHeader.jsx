import { withStyles } from '@material-ui/core';
import cn from 'classnames';
import { TableCell, TableRow } from 'componentlibrary/table';

const styles = () => ({
    head: {
        position: 'sticky',
        top: 0,

        '& th.titlehead': {
            backgroundColor: '#d9e3f2',
            fontWeight: 700,
        },
        '& div.title': {
            display: 'flex',
            flexDirection: 'row',
            gap: 8,
            alignItems: 'center',
            justifyContent: 'center',
        },
    },
});

const TableHeader = ({ children, classes, className, title, ...props }) => (
    <thead className={cn(classes.head, className)} {...props}>
        {title != null && (
            <TableRow>
                <TableCell as="th" colSpan={999} className="titlehead">
                    <div className="title">{title}</div>
                </TableCell>
            </TableRow>
        )}
        {children}
    </thead>
);

export default withStyles(styles)(TableHeader);
