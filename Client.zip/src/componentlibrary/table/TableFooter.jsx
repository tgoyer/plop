import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    foot: {
        '& td': {
            border: '2px solid #fff',
            color: '#333',
            verticalAlign: 'middle',
            minWidth: 'fit-content',
        },
    },
});

const TableFooter = ({ children, classes, className, ...props }) => (
    <tfoot className={cn(classes.foot, className)} {...props}>
        {children}
    </tfoot>
);

export default withStyles(styles)(TableFooter);
