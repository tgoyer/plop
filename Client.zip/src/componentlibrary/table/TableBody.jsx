import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    body: {
        '& tr': {
            scrollSnapAlign: 'start',
        },
        '& tr:hover': {
            backgroundColor: '#eee',
        },
        '& td': {
            border: '2px solid #fff',
            color: '#333',
            verticalAlign: 'middle',
            minWidth: 'fit-content',
        },
    },
});

const TableBody = ({ children, classes, className, ...props }) => (
    <tbody className={cn(classes.body, className)} {...props}>
        {children}
    </tbody>
);

export default withStyles(styles)(TableBody);
