import { withStyles } from '@material-ui/core';
import cn from 'classnames';

const styles = () => ({
    table: {
        backgroundColor: '#fff',
        border: 0,
        borderCollapse: 'collapse',
        width: '100%',
        '& tr': {
            scrollSnapAlign: 'start',
        },
    },
    scrollable: {
        maxWidth: '100%',
        overflowY: 'auto',
        scrollSnapType: 'y mandatory',
    },
});

const Table = ({ children, classes, className, ...props }) => {
    return (
        <div className={classes.scrollable}>
            <table className={cn(classes.table, className)} {...props}>
                {children}
            </table>
        </div>
    );
};

export default withStyles(styles)(Table);
