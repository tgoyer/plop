import React, { useState } from "react";

import "./Tabs.css";

const Tabs = ({ className, tabs }) => {
    const [tab, setTab] = useState(tabs[0]);

    const Tab = () => <tab.component />;

    return (
        <div className={`${className} ab-tabs`}>
            <div className="ab-tabs-menu">
                {tabs.map(t => <div key={t.label} className="ab-tab-item" onClick={() => setTab(t)}>
                    <div className="tab-label">{t.label}</div>
                    <div className={t.label === tab.label ? 'ab-selected-tab' : 'indicator'}></div>
                </div>)}
            </div>
            <Tab />
        </div>
    );
};

export default Tabs;