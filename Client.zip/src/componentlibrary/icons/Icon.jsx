import React from 'react';

import Button from '../buttons/Button';
import { getExtension } from 'Utils/layoutHelper.js';

import './Icon.css';

// By default we use FontAwesome V5 Icon class names
// https://fontawesome.com/v5/search?o=r&m=free
export const FA_ICONS_LIST = Object.freeze({
    DEFAULT: 'fa-plus-circle',
    CLOSE: 'fa-times-circle',
    ARROW_UP: 'fa-arrow-up',
    ARROW_DOWN: 'fa-arrow-down',
    ARROW_LEFT: 'fa-arrow-left',
    ARROW_RIGHT: 'fa-arrow-right',
    CARET_DOWN: 'fa-caret-down',
    DOWN_ARROW_CIRCLE: 'fa-arrow-circle-down',
    EYE: 'fa-eye',
    ELLIPSIS: 'fa-ellipsis-h',
    EDIT: 'fa-edit',
    FILE: 'fa-file',
    FILE_ALT: 'fa-file-alt',
    FILE_DOWNLOAD: 'fa-file-download',
    FILE_EXCEL: 'fa-file-excel',
    FILE_IMAGE: 'fa-file-image',
    FILE_POWERPOINT: 'fa-file-powerpoint',
    FILE_PDF: 'fa-file-pdf',
    FILE_WORD: 'fa-file-word',
    FILTER: 'fa-filter',
    INFO: 'fa-info-circle',
    LINK: 'fa-link',
    PAPERCLIP: 'fa-paperclip',
    PLUS: 'fa-plus',
    SAVE: 'fa-save',
    SEARCH: 'fa-search',
    TRASH: 'fa-trash-alt',
    WARNING: 'fa-exclamation-circle',
});

export const FA_ICON_SIZES = Object.freeze({
    DEFAULT: '',
    XSMALL: 'fa-xs',
    SMALL: 'fa-sm',
    LARGE: 'fa-lg',
});

// Configurable Icon Component (Compatible with FontAwesome V5)
// https://fontawesome.com/v5/search?o=r&m=free
//
const Icon = ({ classNames = '', iconName = 'DEFAULT', onClick, size = 'DEFAULT', iconType = 'DEFAULT', label }) => {
    const icon = FA_ICONS_LIST[iconName];
    const iconSize = FA_ICON_SIZES[size];
    const RenderIcon = () => <i className={`fas ${icon} ${iconSize} icon-component ${classNames}`} onClick={onClick}></i>;

    return iconType === 'chip' ? (
        <Button className="chip">
            <span>{label}</span>
            <RenderIcon />
        </Button>
    ) : (
        <RenderIcon />
    );
};

// Optionally Add an Attachment/File Icon from the default collection (FontAwesome V5) that matches one of the common file extensions (PDF,Excel,etc.)
export const getFileExtensionIcon = (fileName) => {
    const fileTypes = {
        WORD: { label: 'Word', extension: 'docx', icon: 'FILE_WORD' },
        POWERPOINT: { label: 'Powerpoint', extension: 'pptx', icon: 'FILE_POWERPOINT' },
        PDF: { label: 'PDF', extension: 'pdf', icon: 'FILE_PDF' },
        EXCEL_XLSX: { label: 'Excel_xlsx', extension: 'xlsx', icon: 'FILE_EXCEL' },
        EXCEL_XLS: { label: 'Excel_xls', extension: 'xls', icon: 'FILE_EXCEL' },
    };

    return fileTypes[Object.keys(fileTypes).find((fileType) => fileTypes[fileType].extension === String(getExtension(fileName)).toLowerCase())]?.matchingIconKey || 'FILE_DOWNLOAD';
};

export default Icon;
