import React, { useState } from 'react';

import './DropdownInput.css';

const DropdownInput = ({
    label,
    optionsPlaceholder,
    options = [],
    isOptionSelected = () => {},
    value,
    dropdownIcon,
    hasOptionsFooter,
    handleChange,
    handleInputChange,
    ActionButtons = () => null,
    InputValueActions = () => null,
    OptionsFooter = () => null,
}) => {
    const [showingOptions, setShowingOptions] = useState(false);

    // Currently using FontAwesome icons. Default to chevron
    const getDefaultDropdownIconClasses = () => (dropdownIcon ? dropdownIcon : showingOptions ? 'fa-chevron-up' : 'fa-chevron-down');
    const getOptionClasses = (identifier) => (isOptionSelected(identifier) ? 'selected-option' : '');

    const DropdownTrigger = ({ handleTriggerClick }) => {
        return <i onClick={handleTriggerClick} className={`ab-dropdowninput-btn-icon fas ${getDefaultDropdownIconClasses()}`} aria-hidden="true"></i>;
    };

    return (
        <div className="ab-dropdowninput-wrapper">
            <div>
                <div className="ab-dropdowninput">
                    <input value={value ? value : ''} onChange={handleInputChange} placeholder={label} />
                    <div className="input-value-actions">
                        <InputValueActions />
                    </div>
                    <DropdownTrigger handleTriggerClick={() => setShowingOptions(!showingOptions)} />
                </div>
                {showingOptions && (
                    <div id="ab-dropdowninput-content" className="ab-dropdowninput-content">
                        {
                            <div className="ab-dropdowninput-top">
                                <span>{optionsPlaceholder}</span>
                                <div className="actions-btns">
                                    <ActionButtons />
                                </div>
                            </div>
                        }
                        {options.map(({ label, identifier }) => {
                            return (
                                <div
                                    className={`ab-dropdowninput-option ${getOptionClasses(identifier)}`}
                                    key={identifier}
                                    onClick={() => {
                                        handleChange(identifier);
                                    }}
                                >
                                    {label}
                                </div>
                            );
                        })}
                        {hasOptionsFooter && (
                            <OptionsFooter callback={() => setShowingOptions(false)}>
                                <span onClick={() => setShowingOptions(false)}>Close</span>
                            </OptionsFooter>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default DropdownInput;
