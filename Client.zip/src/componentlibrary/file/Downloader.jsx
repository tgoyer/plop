import { forwardRef, useState } from 'react';
import axios from 'axios';
import { withStyles } from '@material-ui/core';
import cn from 'classnames';

import { getResourceUrl } from 'Utils/layoutHelper';
import { hasEntries } from 'Utils/arrayHelpers';
import Tooltip from 'componentlibrary/tooltip/Tooltip';

const styles = {
    container: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    button: {
        background: 'none',
        border: 0,
        color: '#4183c4',
        cursor: 'pointer',
        fontFamily: "'Inter', Helvetica, Arial, 'Lucida Grande', sans-serif !important",
        fontWeight: 'inherit',
        padding: 0,
        margin: 0,
        textAlign: 'inherit',
        wordBreak: 'break-all',
    },
    icons: {
        padding: '0 4px',
    },
    red: {
        color: '#991111',
    },
};

const getFileName = (url) => {
    var parts = url.pathname.split('/');
    return hasEntries(parts) ? parts[parts.length - 1] : null;
};

const Downloader = forwardRef(({ classes, className, fileName = null, useApiResource = false, uri, onClick, children, ...props }, ref) => {
    const [active, setActive] = useState(false);
    const [error, setError] = useState(null);

    const handleClick = async (evt) => {
        evt.stopPropagation();
        evt.preventDefault();

        setError(null);
        setActive(true);

        const urlObj = new URL(useApiResource ? getResourceUrl(uri) : uri, window.location.origin);
        try {
            const response = await axios.get(urlObj.href, { responseType: 'blob' });
            if (response == null || response?.status === 404) throw new Error('File not found.');

            const blob = URL.createObjectURL(response?.data);

            // Get file name from response headers
            const contentDisposition = response.headers['content-disposition'];
            const fileNameMatch = contentDisposition?.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
            const headerFileName = hasEntries(fileNameMatch) ? fileNameMatch[1] : null;
            const downloadName = fileName ?? headerFileName ?? getFileName(urlObj) ?? 'unknown';

            // create "a" HTML element with href to file & click
            const nonAlphaChars = /^([^a-zA-Z0-9])|([^a-zA-Z0-9])$/g;
            const link = document.createElement('a');
            document.body.appendChild(link);
            link.href = blob;
            link.setAttribute('download', downloadName?.replace(nonAlphaChars, '').trim());
            link.click();

            // clean up "a" element & remove ObjectURL
            document.body.removeChild(link);
            URL.revokeObjectURL(blob);

            if (onClick != null) onClick(evt);
        } catch (err) {
            setError(err);
        } finally {
            setActive(false);
        }
    };

    return (
        <div className={cn(classes.container, className)}>
            <button ref={ref} {...props} className={cn(classes.button)} onClick={handleClick}>
                {children}
            </button>
            {(active === true || error != null) && (
                <div className={classes.icons}>
                    {active === true && <i className="fas fa-circle-notch fa-spin"></i>}
                    {error != null && (
                        <Tooltip trigger={<i className={cn(classes.red, 'fas fa-exclamation')}></i>}>
                            <p>There was an error downloading the selected file.</p>
                            <p>
                                <strong>Message: </strong>
                                {error.message}
                            </p>
                        </Tooltip>
                    )}
                </div>
            )}
        </div>
    );
});

export default withStyles(styles)(Downloader);
