import { forwardRef } from 'react';
import { withStyles } from '@material-ui/core';
import cn from 'classnames';
import { useDebug } from '@spiffdog/spiffy-hooks';

const styles = () => ({
    switch: {
        position: 'relative',
        display: 'inline-block',
        width: 50,
        height: 14,

        '& input': {
            opacity: 0,
            width: 0,
            height: 0,

            '&:checked + .slider': {
                backgroundColor: '#1279c6',
            },
            '&:focus + .slider': {
                boxShadow: '0 0 1px #1279c6',
            },
            '&:checked + .slider:before': {
                transform: 'translateX(36px)',
                boxShadow: '0px 0px 4px 0px #1279c6',
            },
        },

        '& .slider': {
            display: 'inline-block',
            position: 'absolute',
            cursor: 'pointer',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: '#ccc',
            transition: '250ms',
            borderRadius: 14,

            '&:before ': {
                display: 'block',
                position: 'absolute',
                boxShadow: '0px 0px 4px 0px #9c9c9c',
                content: '""',
                height: 17,
                width: 17,
                left: -2,
                bottom: -2,
                borderRadius: '50%',
                backgroundColor: '#fff',
                transition: '250ms',
            },
        },
    },
});

const Toggle = forwardRef(({ classes, className, ...props }, ref) => (
    <label ref={ref} className={cn(classes.switch, className)}>
        <input type="checkbox" {...props} />
        <span className="slider"></span>
    </label>
));

export default withStyles(styles)(Toggle);
