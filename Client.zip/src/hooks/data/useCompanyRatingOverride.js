import { useCallback } from 'react';
import axios from 'axios';

import { useData } from '@spiffdog/spiffy-hooks';
import { isNullOrEmpty } from 'Utils/stringHelper';

export const dataSchema = {
    companyID: 0,
    overrideBy: null,
    overrideByName: null,
    overrideDate: null,
    rating: null,
    ratingScheme: null,
    rationale: null,
    reAffirm: false,
};

const getURL = (props) => `/companies/${props.companyID}/abvOverride`;
const getPostBody = (data) => ({
    ...dataSchema,
    ...data,
});

const mapResponse = (data) =>
    isNullOrEmpty(data)
        ? null
        : {
              companyID: data.CompanyID,
              overrideBy: data.OverrideByID,
              overrideDate: data.OverrideDate,
              overrideByName: data.OverrideByName,
              overrideRating: data.Rating,
              overrideRatingScheme: data.RatingScheme,
              overrideRationale: data.Rationale,
              reAffirm: data.ReAffirm,
          };

export const useCompanyRatingOverride = () => {
    const [response, requestor] = useData();

    const getterFn = useCallback(
        async (props) =>
            requestor(async (config) => {
                const res = await axios.get(getURL(props), config);
                return {
                    ...res,
                    data: mapResponse(res?.data),
                };
            }),
        [requestor]
    );

    const setterFn = useCallback(
        async (props) =>
            requestor(async (config) => {
                const res = await axios.post(getURL(props), getPostBody(props), config);
                return {
                    ...res,
                    data: mapResponse(res?.data),
                };
            }, true),
        [requestor]
    );

    return [response, getterFn, setterFn];
};
