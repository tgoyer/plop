import { useCallback, useEffect, useState } from 'react';
import axios from 'axios';
import { useData } from '@spiffdog/spiffy-hooks';

const url = '/featureflags';
const settingsUri = `${url}/settings`;
const userUri = `${url}/users`;
const teamUri = `${url}/teams`;

const useFeatureFlags = () => {
    const [response, requestor] = useData();
    const [flags, setFlags] = useState([]);
    const [users, setUserFlags] = useState([]);
    const [teams, setTeamFlags] = useState([]);

    const load = useCallback(async () => {
        requestor(async () => await axios.get(settingsUri));
    }, [requestor]);

    const deleteTeam = useCallback(
        async ({ id }) => {
            requestor(async () => await axios.delete(`${teamUri}/${id}`));
        },
        [requestor]
    );
    const deleteUser = useCallback(
        async ({ id }) => {
            requestor(async () => await axios.delete(`${userUri}/${id}`));
        },
        [requestor]
    );

    const saveFlag = useCallback(
        async (flag) => {
            requestor(async () => await axios.post(url, flag));
        },
        [requestor]
    );
    const saveTeams = useCallback(
        async (teams) => {
            requestor(async () => await axios.post(teamUri, teams));
        },
        [requestor]
    );
    const saveUsers = useCallback(
        async (users) => {
            requestor(async () => await axios.post(userUri, users));
        },
        [requestor]
    );

    useEffect(() => {
        load();
    }, [load]);

    useEffect(() => {
        const { data } = response;
        setFlags(data?.Flags);
        setTeamFlags(data?.Teams);
        setUserFlags(data?.Users);
    }, [response]);

    return { response, flags, users, teams, deleteTeam, deleteUser, saveFlag, saveTeams, saveUsers };
};

export default useFeatureFlags;
