import { useCallback, useEffect, useState } from 'react';
import axios from 'axios';

import { hasEntries } from 'Utils/arrayHelpers';

const useFeatureFlags = () => {
    const [flags, setFlags] = useState([]);

    const hasFlag = useCallback(
        (flag, enabled = true) => {
            if (hasEntries(flags)) {
                const found = flags.find((f) => f?.FlagName === flag);
                return found?.IsEnabled ?? enabled;
            }
            return enabled;
        },
        [flags]
    );

    useEffect(() => {
        const load = async () => {
            const res = await axios.get('/featureflags/me');
            setFlags(res?.data);
        };
        load();
    }, []);

    return { flags, hasFlag };
};

export default useFeatureFlags;
