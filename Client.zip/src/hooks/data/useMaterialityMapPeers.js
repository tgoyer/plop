import { useCallback } from 'react';
import axios from 'axios';

import { useData } from '@spiffdog/spiffy-hooks';

const getURL = ({ companyID, factorID, name }) => `/companies/${companyID}/materialitymaps/${name}/peers/${factorID}`;

export const useMaterialityMapPeers = () => {
    const [response, requestor] = useData();

    const getterFn = useCallback(
        async (props) => {
            requestor(async (config) => await axios.get(getURL(props), config));
        },
        [requestor]
    );

    return [response, getterFn];
};
