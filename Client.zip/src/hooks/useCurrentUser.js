import { useSelector } from "react-redux";

const useCurrentUser = () => {
    const { Data : userInfo, loading } = useSelector((state) => state.UserReducer.UserInfo); 
    const permissions = userInfo.Permissions;
    return { userInfo, permissions,loading }
};

export default useCurrentUser;
