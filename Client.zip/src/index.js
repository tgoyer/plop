import React, { useEffect } from 'react';
import reactDom from 'react-dom';
import CssBaseline from '@material-ui/core/CssBaseline';
import LuxonUtils from '@date-io/luxon';
import axios from 'axios';
import * as wijmo from '@grapecity/wijmo';
import { BrowserRouter as Router } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Provider as ReduxProvider } from 'react-redux';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import { MuiThemeProvider, createTheme } from '@material-ui/core/styles';
import { AuthProvider, hasAuthParams, useAuth } from 'react-oidc-context';

import store from 'store';
import { getAppSettings, setOnlineStatus } from 'store/AppSettingsModule';
import { getContacts } from 'store/ContactsModule';
import { getContent, getTabs } from 'store/ContentModule';
import {
    getAnalysts,
    getConsensus,
    getCountries,
    getDocumentSources,
    getEffects,
    getEscalationPaths,
    getGICSSectors,
    getKeyIssues,
    getOtherDocumentTypes,
    getPortfolioActions,
    getPublishers,
    getRegions,
    getTeams,
    getActionTypes,
} from 'store/DimensionModule';
import { getMsciRatingChanges } from 'store/GridDataModule';
import { getUserInfo } from 'store/UserModule';

import { getResourceUrl } from 'Utils/layoutHelper';
import { configureOidcSettings, handleRenewError, handleTokenExpiration, oidcAxiosRequestHandler, oidcAxiosResponseErrorHandler, setOidcRedirectPath } from 'Utils/oidcHelper';

import { Main } from 'Layout';

import 'semantic-ui-css/semantic.min.css';
import '@grapecity/wijmo.styles/wijmo.css';

const theme = createTheme({
    palette: {
        primary: {
            main: '#6987B9',
            contrastText: '#ffffff',
        },
        secondary: {
            main: '#6987B9',
            contrastText: '#6987B9',
        },
        text: {
            disabled: 'rbga(0,0,0,1)',
        },
    },
    typography: {
        fontFamily: ['Inter', 'Helvetica', 'Arial', 'Lucida Grande', 'sans-serif'].join(','),
        fontSize: 12,
        htmlFontSize: 12,
    },
});

configureApp();
initializeData();

const App = () => {
    const auth = useAuth();
    auth.clearStaleState();

    const isLoggingIn = auth.isLoading && !auth.isAuthenticated;
    const hasLoginError = !auth.isLoading && !auth.isAuthenticated;

    useEffect(() => {
        const processAuth = async (auth) => {
            auth.clearStaleState();

            const userData = store.getState().UserReducer?.UserInfo?.Data;
            const noAuthParams = !hasAuthParams();
            const notAuthed = noAuthParams && !auth.isAuthenticated && !auth.isLoading;
            const isAuthed = auth.isAuthenticated;

            if (notAuthed) {
                auth.signinRedirect();
            } else if (isAuthed && userData == null) {
                await dispatchDataLoaders();
            }
        };

        processAuth(auth);
    }, [auth]);

    useEffect(() => {
        return handleRenewError(auth);
    }, [auth]);

    useEffect(() => {
        return handleTokenExpiration(auth);
    }, [auth]);

    return (
        <ReduxProvider store={store}>
            <MuiPickersUtilsProvider utils={LuxonUtils}>
                <HelmetProvider>
                    <Router>
                        <MuiThemeProvider theme={theme}>
                            <CssBaseline />
                            <Main isLoggingIn={isLoggingIn} hasLoginError={hasLoginError} />
                        </MuiThemeProvider>
                    </Router>
                </HelmetProvider>
            </MuiPickersUtilsProvider>
        </ReduxProvider>
    );
};

const Offline = () => {
    return (
        <ReduxProvider store={store}>
            <MuiPickersUtilsProvider utils={LuxonUtils}>
                <HelmetProvider>
                    <Router>
                        <MuiThemeProvider theme={theme}>
                            <CssBaseline />
                            <Main isLoggingIn={false} hasLoginError={false} offline={true} />
                        </MuiThemeProvider>
                    </Router>
                </HelmetProvider>
            </MuiPickersUtilsProvider>
        </ReduxProvider>
    );
};

function configureApp() {
    window.addEventListener('online', handleConnectionChange);
    window.addEventListener('offline', handleConnectionChange);

    /// ---- CONFIGURE AXIOS ---- ///
    axios.defaults.baseURL = getResourceUrl();
    axios.defaults.headers = {
        Pragma: 'no-cache',
        'Cache-Control': 'no-cache',
        Expires: -1,
    };
    axios.defaults.withCredentials = true;

    axios.interceptors.response.use(
        (response) => response,
        (error) => {
            const oAuthSettings = store.getState().AppSettingsReducer.ServerSettings.OAuth;
            oidcAxiosResponseErrorHandler(oAuthSettings, error, axios);
        }
    );

    axios.interceptors.request.use(
        (config) => oidcAxiosRequestHandler(config),
        (error) => Promise.reject(error)
    );
}

function handleConnectionChange(event) {
    store.dispatch(setOnlineStatus(event.type === 'online'));
}

async function dispatchDataLoaders() {
    return await Promise.all([
        await store.dispatch(getUserInfo()),
        await store.dispatch(getAnalysts()),
        await store.dispatch(getConsensus()),
        await store.dispatch(getContacts()),
        await store.dispatch(getContent()),
        await store.dispatch(getCountries()),
        await store.dispatch(getDocumentSources()),
        await store.dispatch(getEffects()),
        await store.dispatch(getEscalationPaths()),
        await store.dispatch(getActionTypes()),
        await store.dispatch(getGICSSectors()),
        await store.dispatch(getKeyIssues()),
        await store.dispatch(getMsciRatingChanges(180)),
        await store.dispatch(getOtherDocumentTypes()),
        await store.dispatch(getPortfolioActions()),
        await store.dispatch(getPublishers()),
        await store.dispatch(getRegions()),
        await store.dispatch(getTabs()),
        await store.dispatch(getTeams()),
    ]);
}

async function initializeData() {
    const ele = document.getElementById('root');
    try {
        setOidcRedirectPath();

        await store.dispatch(getAppSettings());
        const { OAuth, Keys } = store.getState().AppSettingsReducer.ServerSettings;
        const oidcConfig = configureOidcSettings(OAuth);
        wijmo.setLicenseKey(Keys.Wijmo);

        reactDom.render(
            <AuthProvider {...oidcConfig}>
                <App />
            </AuthProvider>,
            ele
        );
    } catch (error) {
        reactDom.render(<Offline />, ele);
    }
}
