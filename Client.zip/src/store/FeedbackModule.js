import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = createState({
    FeedbackInfo: {
        submitted: false,
    },
});

//====> FSA ACTION CREATORS <====//
const save = createAction('FEEDBACK::SAVE');

//====> ACTIONS <====//
export const saveFeedback = (feedback) => (dispatch) => {
    return axios
        .post('/feedback', feedback)
        .then(() => dispatch(save.action()))
        .catch((err) => dispatch(save.catch(err)));
};

//====> REDUCERS <====//
const saveReducer = handleAction(
    save,
    (state, action) => {
        return {
            ...state,
            FeedbackInfo: {
                submitted: action.payload,
                error: action.error,
            },
        };
    },
    initialState
);

export default reduceReducers(saveReducer);
