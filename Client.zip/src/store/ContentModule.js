import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';
import { getAnnouncements, deleteGeneratedAnnouncements } from './AnnouncementsModule';

const initialState = createState({
    Content: {
        isUploading: false,
        Tabs: [],
        Active: {
            Data: [],
        },
    },
});

//====> FSA ACTION CREATORS <====//
const setUploadingAction = createAction('CONTENT::UPLOADING');

const getContentAction = createAction('CONTENT-ALL::GETALL');
const createContentAction = createAction('CONTENT::CREATE');
const updateContentAction = createAction('CONTENT::UPDATE');
const deleteContentAction = createAction('CONTENT::DELETE');

const getTabsAction = createAction('CONTENT-TABS::GETALL');

//====> ACTIONS <====//
export const setUploading = (isUploading) => (dispatch) => {
    dispatch(setUploadingAction.begin());
    dispatch(getContentAction.resolve(isUploading));
};

export const getContent = () => (dispatch) => {
    dispatch(getContentAction.begin());
    axios
        .get('/content')
        .then((response) => dispatch(getContentAction.resolve(response.data)))
        .catch((err) => dispatch(getContentAction.catch(err)));
};

export const getTabs = () => (dispatch) => {
    dispatch(getTabsAction.begin());
    axios
        .get('/content/tabs')
        .then((response) => dispatch(getTabsAction.resolve(response.data)))
        .catch((err) => dispatch(getTabsAction.catch(err)));
};

export const createContent = (content) => (dispatch) => {
    dispatch(createContentAction.begin());
    axios
        .post('/content', content)
        .then((response) => {
            dispatch(createContentAction.resolve(response.data));
            dispatch(getAnnouncements());
        })
        .catch((err) => dispatch(createContentAction.catch(err)));
};

export const updateContent = (content) => (dispatch) => {
    dispatch(updateContentAction.begin());
    axios
        .put('/content', content)
        .then((response) => {
            dispatch(updateContentAction.resolve(response.data));
            dispatch(getAnnouncements());
        })
        .catch((err) => dispatch(updateContentAction.catch(err)));
};

export const deleteContent = (contentID) => (dispatch) => {
    dispatch(deleteContentAction.begin());
    axios
        .delete(`/content/${contentID}`)
        .then((response) => {
            dispatch(deleteGeneratedAnnouncements(contentID)); // Cleanup announcements in state that referenced it
            dispatch(deleteContentAction.resolve(response.data));
        })
        .catch((err) => dispatch(deleteContentAction.catch(err)));
};

//====> REDUCERS <====//
const contentReducer = handleAction(
    getContentAction,
    (state, action) => {
        return {
            ...state,
            Content: {
                ...state.Content,
                Active: {
                    ...state.Content.Active,
                    Data: action.payload,
                },
            },
        };
    },
    initialState
);

const tabsReducer = handleAction(
    getTabsAction,
    (state, action) => {
        return {
            ...state,
            Content: {
                ...state.Content,
                Tabs: action.payload,
            },
        };
    },
    initialState
);

//====> REDUCERS <====//
const createContentReducer = handleAction(
    createContentAction,
    (state, action) => {
        return {
            ...state,
            Content: {
                ...state.Content,
                Active: {
                    ...state.Content.Active,
                    Data: [...[action.payload], ...state.Content.Active.Data],
                },
            },
        };
    },
    initialState
);

const updateContentReducer = handleAction(
    updateContentAction,
    (state, action) => {
        return {
            ...state,
            Content: {
                ...state.Content,
                Active: {
                    ...state.Content.Active,
                    Data: state.Content.Active.Data.map((content) => (content.ContentID === action.payload.ContentID ? action.payload : content)),
                },
            },
        };
    },
    initialState
);

const deleteContentReducer = handleAction(
    deleteContentAction,
    (state, action) => {
        return {
            ...state,
            Content: {
                ...state.Content,
                Active: {
                    ...state.Content.Active,
                    Data: state.Content.Active.Data.filter((c) => c.ContentID !== action.payload),
                },
            },
        };
    },
    initialState
);

export default reduceReducers(contentReducer, createContentReducer, updateContentReducer, deleteContentReducer, tabsReducer);
