import _get from 'lodash/get';

import axios from 'axios';

import { getLocalData, setLocalData } from '../Utils/localStorageHelper';
import { createAction, handleAction, reduceReducers } from './utilities';

const initialState = {
    Fetching: false,
    Errors: {},
    Count: 0,
};

//====> FSA ACTION CREATORS <====//
const errorActionCreator = createAction('API::ERROR');
const clearErrorActionCreator = createAction('API::CLEAR-ERROR');

//====> ACTIONS <====//
export const handleRequestError = (error, message) => (dispatch) => {
    dispatch(errorActionCreator.resolve({ error, message }));
};
export const clearError = (url) => (dispatch) => {
    dispatch(clearErrorActionCreator.resolve(url));
};

//====> REDUCERS <====//
const errorReducer = handleAction(
    errorActionCreator,
    (state, action) => {
        const count = state.Count - 1;
        const error = action.payload.error;
        const message = action.payload.message ?? (action.payload.error?.response?.status === 403 ? 'Not authorized to access requested resource' : undefined);
        const url = error != null && error.config != null ? error.config.url : '';
        return {
            ...state,
            Fetching: count > 0,
            Count: count,
            Errors: {
                ...state.Errors,
                [url]: {
                    error: error,
                    message: message,
                },
            },
        };
    },
    initialState
);
const clearErrorReducer = handleAction(
    clearErrorActionCreator,
    (state, action) => {
        const errors = Object.keys(state.Errors).reduce((acc, key) => {
            if (key !== action.payload) {
                acc[key] = state.Errors[key];
            }
            return acc;
        }, {});

        return {
            ...state,
            Errors: { ...errors },
        };
    },
    initialState
);

export default reduceReducers(clearErrorReducer, errorReducer);

// HELPERS
export const getCachedData =
    (action, cacheName, cacheKey, apiUrl, params = null, invalidateCache = false) =>
    (dispatch, getState) => {
        dispatch(action.begin());
        const localData = getLocalData(cacheName, cacheKey);
        const stateData = localData != null ? localData : params == null ? _get(getState(), cacheName, null) : null;

        const promise =
            !invalidateCache && _get(stateData, 'length', 0) > 0
                ? Promise.resolve(stateData).then((data) => setLocalData(cacheName, cacheKey, data))
                : axios.get(apiUrl, { params }).then((response) => setLocalData(cacheName, cacheKey, response.data));

        return promise.then((data) => dispatch(action.resolve(data))).catch((err) => dispatch(action.catch(err)));
    };
