import _get from 'lodash/get';

import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = {
    UserInfo: createState({ Data: null }),
    UserWatchlistData: {},
    UserWatchlistCompanyInfo: {},
    UserGeneralFollowUpInfo: {},
    Surveys: createState({ Data: [] }),
};

//====> FSA ACTION CREATORS <====//
const getUserInfoAction = createAction('USER::GET', 'UserInfo');
const getUserWatchlistDataAction = createAction('USER-WATCHLIST::FETCH');
const deleteUserWatchlistItemAction = createAction('USER-WATCHLIST-ITEM::DELETE');
const saveWatchlistAction = createAction('USER-WATCHLIST::SAVE');
const getUserWatchlistCompanyInfoAction = createAction('USER-WATCHLIST-COMPANY-INFO::FETCH');
const saveUserGeneralFollowUpInfoAction = createAction('USER-GENERAL-FOLLOWUP::SAVE');
const deleteUserGeneralFollowUpInfoAction = createAction('USER-GENERAL-FOLLOWUP::DELETE');
const addOrRemoveWatchlistCompanyAction = createAction('USER-WATCHLIST-COMPANY::ADD-REMOVE');
const getUserGeneralFollowUpAction = createAction('USER-GENERAL-FOLLOWUP::FETCH');
const getUserSurveysAction = createAction('USER-SURVEYS::FETCH', 'Surveys');

//====> ACTIONS <====//
export const getUserInfo = () => async (dispatch) => {
    dispatch(getUserInfoAction.begin());

    try {
        const resp = await axios.get('/users/me');
        dispatch(getUserInfoAction.resolve(resp?.data));
        return resp?.data;
    } catch (err) {
        dispatch(getUserInfoAction.catch(err));
    }
};

export const getUserWatchlistData = (userID) => async (dispatch) => {
    dispatch(getUserWatchlistDataAction.begin());

    try {
        const { data } = await axios.get(`/users/${userID}/watchlist`);
        dispatch(getUserWatchlistDataAction.resolve(data));
        return data;
    } catch (err) {
        dispatch(getUserWatchlistDataAction.catch(err));
    }
};

export const deleteUserWatchlistItem = (userID, watchlistDetailID) => async (dispatch) => {
    dispatch(deleteUserWatchlistItemAction.begin());

    try {
        const { data } = await axios.delete(`/users/${userID}/watchlist/items/${watchlistDetailID}`);
        dispatch(deleteUserWatchlistItemAction.resolve(data));
        return data;
    } catch (err) {
        dispatch(deleteUserWatchlistItemAction.catch(err));
    }
};

export const saveWatchlist = (userID, watchlistData) => (dispatch) => {
    dispatch(saveWatchlistAction.begin());
    const promise = axios.post(`/users/${userID}/watchlist`, watchlistData);
    return promise.then((response) => dispatch(saveWatchlistAction.resolve(response.data))).catch((err) => dispatch(saveWatchlistAction.catch(err)));
};

export const getUserWatchlistCompanyInfo = (userID, companyID) => (dispatch) => {
    dispatch(getUserWatchlistCompanyInfoAction.begin());

    return axios
        .get(`/users/${userID}/watchlist/companies/${companyID}`)
        .then((response) => {
            dispatch(getUserWatchlistCompanyInfoAction.resolve(response.data));
            return response.data;
        })
        .catch((err) => dispatch(getUserWatchlistCompanyInfoAction.catch(err)));
};

export const saveUserGeneralFollowUpInfo = (userId, generalFollowUpInfo) => (dispatch) => {
    dispatch(saveUserGeneralFollowUpInfoAction.begin());
    const promise = axios.post(`/users/${userId}/watchlist/generalfollowupinfo`, generalFollowUpInfo);

    return promise
        .then((response) => {
            return dispatch(saveUserGeneralFollowUpInfoAction.resolve(response.data));
        })
        .catch((err) => dispatch(saveUserGeneralFollowUpInfoAction.catch(err)));
};

export const deleteUserGeneralFollowUpInfo = (userID, companyID) => (dispatch) => {
    dispatch(deleteUserGeneralFollowUpInfoAction.begin());
    const promise = axios.delete(`/users/${userID}/watchlist/generalfollowupinfo/${companyID}`);

    return promise
        .then((response) => {
            return dispatch(deleteUserGeneralFollowUpInfoAction.resolve(response.data));
        })
        .catch((err) => dispatch(deleteUserGeneralFollowUpInfoAction.catch(err)));
};

export const addWatchlistCompany = (userID, companyID) => (dispatch) => {
    dispatch(addOrRemoveWatchlistCompanyAction.begin());
    const promise = axios.post(`/users/${userID}/watchlist/companies/${companyID}`, { UserID: userID, CompanyID: companyID });

    return promise.then((response) => dispatch(addOrRemoveWatchlistCompanyAction.resolve(response.data))).catch((err) => dispatch(addOrRemoveWatchlistCompanyAction.catch(err)));
};

export const removeWatchlistCompany = (userID, companyID) => (dispatch) => {
    dispatch(addOrRemoveWatchlistCompanyAction.begin());
    const promise = axios.delete(`/users/${userID}/watchlist/companies/${companyID}`, { UserID: userID, CompanyID: companyID });

    return promise.then((response) => dispatch(addOrRemoveWatchlistCompanyAction.resolve(response.data))).catch((err) => dispatch(addOrRemoveWatchlistCompanyAction.catch(err)));
};

export const getUserGeneralFollowUpInfo = (userID) => (dispatch) => {
    dispatch(getUserGeneralFollowUpAction.begin());

    return axios
        .get(`/users/${userID}/watchlist/usergeneralfollowup`, {
            params: { userID: userID },
        })
        .then((response) => dispatch(getUserGeneralFollowUpAction.resolve(response.data)))
        .catch((err) => dispatch(getUserGeneralFollowUpAction.catch(err)));
};

export const getUserSurveys = (userID) => (dispatch) => {
    dispatch(getUserSurveysAction.begin());

    return axios
        .get(`/users/${userID}/surveys`)
        .then((response) => dispatch(getUserSurveysAction.resolve(response.data)))
        .catch((err) => dispatch(getUserSurveysAction.catch(err)));
};

//====> REDUCERS <====//
const getUserInfoReducer = handleAction(
    getUserInfoAction,
    (state, action) => {
        const permissions = _get(action, 'payload.Permissions', []).map((p) => p.Value);

        return {
            ...state,
            UserInfo: {
                ...state.UserInfo,
                Data: {
                    ...state.UserInfo.Data,
                    ...action.payload,
                    Permissions: {
                        Claims: [...action.payload.Permissions],
                        CanAdmin: permissions.indexOf('ESG.Admin') >= 0,
                        CanRead: permissions.indexOf('ESG.Read') >= 0,
                        CanWrite: permissions.indexOf('ESG.Write') >= 0,
                    },
                },
            },
        };
    },
    initialState
);

const userWatchlistDataReducer = handleAction(
    getUserWatchlistDataAction,
    (state, action) => {
        return {
            ...state,
            UserWatchlistData: action.payload,
        };
    },
    initialState
);

const addOrRemoveWatchlistCompanyReducer = handleAction(addOrRemoveWatchlistCompanyAction, (state, action) => state, initialState);
const saveWatchlistReducer = handleAction(saveWatchlistAction, (state, action) => state, initialState);
const saveUserGeneralFollowUpInfoReducer = handleAction(saveUserGeneralFollowUpInfoAction, (state, action) => state, initialState);
const deleteUserGeneralFollowUpInfoReducer = handleAction(deleteUserGeneralFollowUpInfoAction, (state, action) => state, initialState);
const deleteWatchlistItemReducer = handleAction(deleteUserWatchlistItemAction, (state, action) => state, initialState);

const userWatchlistCompanyInfoDataReducer = handleAction(
    getUserWatchlistCompanyInfoAction,
    (state, action) => {
        return {
            ...state,
            UserWatchlistCompanyInfo: action.payload,
        };
    },
    initialState
);

const userGeneralFollowUpInfoDataReducer = handleAction(
    getUserWatchlistCompanyInfoAction,
    (state, action) => {
        return {
            ...state,
            UserGeneralFollowUpInfo: action.payload,
        };
    },
    initialState
);
const getUserSurveyReducer = handleAction(
    getUserSurveysAction,
    (state, { payload }) => ({
        ...state,
        Surveys: {
            ...state.Surveys,
            Data: payload,
        },
    }),
    initialState
);

export default reduceReducers(
    userWatchlistDataReducer,
    saveWatchlistReducer,
    deleteWatchlistItemReducer,
    userWatchlistCompanyInfoDataReducer,
    saveUserGeneralFollowUpInfoReducer,
    deleteUserGeneralFollowUpInfoReducer,
    addOrRemoveWatchlistCompanyReducer,
    userGeneralFollowUpInfoDataReducer,
    getUserInfoReducer,
    getUserSurveyReducer
);
