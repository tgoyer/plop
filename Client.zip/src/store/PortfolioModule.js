import _debounce from 'lodash/debounce';

import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = createState({
    Account: createState({
        Data: {},
    }),
    Portfolio: createState({
        Data: [],
        Stats: [],
    }),
    Search: createState({
        Data: [],
    }),
});

let abortPortfolioController;
const portfolioSearch = (criteria, accountId, callback) => {
    if (abortPortfolioController != null) {
        abortPortfolioController.abort();
    }
    abortPortfolioController = new AbortController();
    const url = criteria != null && criteria.length > 0 ? `/accounts/search?query=${criteria}` : accountId != null && String(accountId).length > 0 ? `/accounts/${accountId}` : null;

    const promise =
        url == null
            ? Promise.resolve().then(() => [])
            : axios
                  .get(url, {
                      signal: abortPortfolioController.signal,
                  })
                  .then((response) => response?.data);

    callback(promise);
};
const debouncedSearch = _debounce(portfolioSearch, 250);

//====> FSA ACTION CREATORS <====//
const searchAccountAction = createAction('PORTFOLIO::SEARCH-ACCOUNTS', 'Search');
const selectAccountAction = createAction('PORTFOLIO::SELECT-ACCOUNT', 'Account');
const selectAccountByIdAction = createAction('PORTFOLIO::SELECT-ACCOUNT-BY-ID', 'Account');
const getAccountPortfolioAction = createAction('PORTFOLIO::FETCH-PORTFOLIO', 'Portfolio');

//====> ACTIONS <====//
export const searchAccounts = (criteria) => (dispatch) => {
    dispatch(searchAccountAction.begin());
    return debouncedSearch(criteria, null, (promise) =>
        promise
            .then((data) => dispatch(searchAccountAction.resolve(data)))
            .catch((err) => {
                dispatch(searchAccountAction.resolve(initialState.Search));
                dispatch(searchAccountAction.catch(err));
            })
    );
};

export const selectAccount = (account) => (dispatch) => {
    dispatch(selectAccountAction.begin());
    return dispatch(selectAccountAction.resolve(account));
};

export const selectAccountById = (accountId) => (dispatch) => {
    dispatch(selectAccountByIdAction.action(null));
    dispatch(selectAccountByIdAction.begin());
    return debouncedSearch(null, accountId, (promise) => promise.then((data) => dispatch(selectAccountByIdAction.resolve(data))));
};

export const selectPortfolioByAccount = (accountId, teamId, startDate, endDate) => async (dispatch) => {
    dispatch(getAccountPortfolioAction.begin());
    try {
        if (accountId == null) return null;
        const response = await axios.get(`/portfolios/${accountId}`, {
            params: { teamId, startDate, endDate },
        });
        dispatch(getAccountPortfolioAction.resolve(response?.data));
    } catch (error) {
        dispatch(getAccountPortfolioAction.resolve(initialState.Portfolio));
        dispatch(getAccountPortfolioAction.catch(error));
    }
};

//====> REDUCERS <====//
const searchAccountReducer = handleAction(
    searchAccountAction,
    (state, { payload }) => ({
        ...state,
        Search: {
            ...state.Search,
            Data: payload,
        },
    }),
    initialState
);

const selectAccountReducer = handleAction(
    [selectAccountAction, selectAccountByIdAction],
    (state, { payload }) => {
        return {
            ...state,
            Account: {
                ...state.Account,
                Data: payload != null ? payload : null,
            },
        };
    },
    initialState
);

const selectPortfolioReducer = handleAction(
    getAccountPortfolioAction,
    (state, { payload }) => ({
        ...state,
        Portfolio: {
            ...state.Portfolio,
            Data: payload?.Data ?? [],
            Stats: payload?.Stats ?? [],
        },
    }),
    initialState
);

export default reduceReducers(searchAccountReducer, selectAccountReducer, selectPortfolioReducer);
