import { applyMiddleware, combineReducers, compose, createStore } from 'redux';
import thunk from 'redux-thunk';

import ApiReducer from './ApiModule';
import AnnouncementsReducer from './AnnouncementsModule';
import AppSettingsReducer from './AppSettingsModule';
import CompanyReducer from './CompanyModule';
import ContentReducer from './ContentModule';
import ContactsReducer from './ContactsModule';
import DimensionReducer from './DimensionModule';
import FeedbackReducer from './FeedbackModule';
import FileReducer from './FileModule';
import GridDataReducer from './GridDataModule';
import LayoutReducer from './LayoutModule';
import NoteReducer from './NoteModule';
import PortfolioReducer from './PortfolioModule';
import UserReducer from './UserModule';

import { getEnvironment } from 'Utils/layoutHelper';

export const rootReducer = combineReducers({
    ApiReducer,
    AnnouncementsReducer,
    AppSettingsReducer,
    CompanyReducer,
    ContentReducer,
    ContactsReducer,
    DimensionReducer,
    FeedbackReducer,
    FileReducer,
    GridDataReducer,
    LayoutReducer,
    NoteReducer,
    PortfolioReducer,
    UserReducer,
});

const env = getEnvironment();
const isProduction = env === 'PRODUCTION';
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

export default isProduction ? createStore(rootReducer, applyMiddleware(thunk)) : createStore(rootReducer, composeEnhancers(applyMiddleware(thunk)));
