import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';
import { alphaNumericSort } from '../Utils/listHelper';

import { isNullOrEmpty } from '../Utils/stringHelper';
import { validateWeights } from 'Applications/Grids/Msci/utils';

const initialState = {
    ControversyInfo: createState({
        Data: null,
    }),
    ClimateTransitionAlignmentFrameworkScore: createState({
        Data: null,
    }),
    ModernSlaveryRiskExposureRating: createState({
        Data: null,
    }),
    MSCIInfo: createState({
        Data: null,
    }),
    MSCIRecentRatingsInfo: createState({
        Data: null,
    }),
    PortfolioActionsInfo: createState({
        Data: null,
    }),
    ProxyInfo: createState({
        Data: null,
    }),
    GridValidation: {
        modalIsOpen: false,
        errors: [],
    },
    Cache: {
        MSCIInfoByCompany: {},
    },
};

//====> FSA ACTION CREATORS <====//
const cache = createAction('GRID-DATA::CACHE');

const fetchControversy = createAction('GRID-DATA::CONTROVERSY', 'ControversyInfo');
const fetchMSCI = createAction('GRID-DATA::MSCI', 'MSCIInfo');
const fetchClimateTransitionAlignmentFrameworkScore = createAction('GRID-DATA::CLIMATE_TRANSITION_ALIGNMENT_FRAMEWORK_SCORE', 'ClimateTransitionAlignmentFrameworkScore');
const fetchModernSlaveryRiskExposureRating = createAction('GRID-DATA::MODERN_SLAVERY_RISK_EXPOSURE_RATING', 'ModernSlaveryRiskExposureRating');
const fetchMsciRatingChanges = createAction('GRID-DATA::MSCI_RATING_CHANGES', 'MSCIRecentRatingsInfo');
const fetchPortfolioActionsInfo = createAction('GRID-DATA::PORTFOLIO_ACTIONS_INFO', 'PortfolioActionsInfo');
const fetchProxy = createAction('GRID-DATA::PROXY', 'ProxyInfo');
const saveAbOverride = createAction('COMPANY::SAVE-AB_OVERRIDE');
const saveClimateTransitionAlignmentFrameworkScore = createAction('GRID-DATA:CLIMATE_TRANSITION_ALIGNMENT_FRAMEWORK_SCORE');
const saveModernSlaveryRiskExposureRatingAction = createAction('GRID-DATA::SAVE-MODERN_SLAVERY_RISK_EXPOSURE_RATING');
const toggleGridValidationErrorsModalAction = createAction('GRID-DATA::VALIDATION_ERROR');

//====> ACTIONS <====//

export const getControversy = (companyID) => (dispatch) => {
    dispatch(fetchControversy.begin());
    return axios
        .get(`/companies/${companyID}/controversies`)
        .then((response) => dispatch(fetchControversy.resolve(response.data)))
        .catch((err) => {
            dispatch(fetchControversy.resolve(initialState.ControversyInfo));
            dispatch(fetchControversy.catch(err));
        });
};

export const getClimateTransitionAlignmentFrameworkScore = (companyID) => (dispatch) => {
    dispatch(fetchClimateTransitionAlignmentFrameworkScore.begin());

    return axios
        .get(`/companies/${companyID}/ratings/ctaf_score`)
        .then((response) => dispatch(fetchClimateTransitionAlignmentFrameworkScore.resolve(response.data)))
        .catch((err) => {
            dispatch(fetchClimateTransitionAlignmentFrameworkScore.resolve(initialState.ClimateTransitionAlignmentFrameworkScore.Data));
            dispatch(fetchClimateTransitionAlignmentFrameworkScore.catch(err));
        });
};

export const getModernSlaveryRiskExposureRating = (companyID) => (dispatch) => {
    dispatch(fetchModernSlaveryRiskExposureRating.begin());

    return axios
        .get(`/companies/${companyID}/ratings/modern_slavery_risk`)
        .then((response) => dispatch(fetchModernSlaveryRiskExposureRating.resolve(response.data)))
        .catch((err) => {
            dispatch(fetchModernSlaveryRiskExposureRating.resolve(initialState.ModernSlaveryRiskExposureRating.Data));
            dispatch(fetchModernSlaveryRiskExposureRating.catch(err));
        });
};
export const getMsci = (companyID) => (dispatch) => {
    dispatch(fetchMSCI.begin());

    return axios
        .get(`/companies/${companyID}/materialitymaps/msci`)
        .then((response) => response.data)
        .then((data) => dispatch(fetchMSCI.resolve(data)))
        .catch((err) => {
            dispatch(fetchMSCI.resolve(initialState.MSCIInfo.Data));
            dispatch(fetchMSCI.catch(err));
        });
};
export const getMsciRatingChanges = (pastDays) => (dispatch) => {
    dispatch(fetchMsciRatingChanges.begin());
    return axios
        .get('/companies/materialitymaps/msci', {
            params: { pastDays: pastDays },
        })
        .then((response) => dispatch(fetchMsciRatingChanges.resolve(response.data)))
        .catch((err) => {
            dispatch(fetchMsciRatingChanges.resolve(initialState.MSCIRecentRatingsInfo));
            dispatch(fetchMsciRatingChanges.catch(err));
        });
};
export const getPortfolioActions = (pastDays) => (dispatch) => {
    dispatch(fetchPortfolioActionsInfo.begin());
    return axios
        .get('/portfolios/actions', {
            params: { pastDays: pastDays },
        })
        .then((response) => dispatch(fetchPortfolioActionsInfo.resolve(response.data)))
        .catch((err) => {
            dispatch(fetchPortfolioActionsInfo.resolve(initialState.PortfolioActionsInfo));
            dispatch(fetchPortfolioActionsInfo.catch(err));
        });
};
export const getProxy = (companyID) => (dispatch) => {
    dispatch(fetchProxy.begin());
    return axios
        .get(`/companies/${companyID}/proxy`)
        .then((response) => dispatch(fetchProxy.resolve(response.data)))
        .catch((err) => {
            dispatch(fetchProxy.resolve(initialState.ProxyInfo));
            dispatch(fetchProxy.catch(err));
        });
};
export const resetCompanyGrids = () => (dispatch) => {
    dispatch(fetchMSCI.action(initialState.MSCIInfo.Data));
    dispatch(fetchControversy.action(initialState.ControversyInfo.Data));
    dispatch(fetchProxy.action(initialState.ProxyInfo.Data));
};

export const toggleGridValidationErrorsModal = (isShowing, errors) => (dispatch) => {
    dispatch(toggleGridValidationErrorsModalAction.action({ isShowing, errors }));
};

export const saveModernSlaveryRiskExposureRating = (companyID, rating) => (dispatch) => {
    dispatch(saveModernSlaveryRiskExposureRatingAction.begin());

    var promise = rating.RatingID < 1 ? axios.post(`/companies/${companyID}/ratings/modern_slavery_risk`, rating) : axios.put(`/companies/${companyID}/ratings/modern_slavery_risk`, rating);

    return promise.then((res) => dispatch(saveModernSlaveryRiskExposureRatingAction.resolve(res.data))).catch((err) => dispatch(saveModernSlaveryRiskExposureRatingAction.catch(err)));
};

export const saveMsciOverride =
    (overrideId, companyId, keyIssueId, type = null, value = null, msciData) =>
    (dispatch) => {
        dispatch(saveAbOverride.begin());

        // Normalize passed in values.
        overrideId = isNullOrEmpty(overrideId) ? null : overrideId;
        type = isNullOrEmpty(type) ? null : type;
        value = isNullOrEmpty(value) ? null : value;

        // Weight Validation not required for Governance or Scores
        if (type === 'Weight') {
            // validate
            const { isValid, errors } = validateWeights(msciData, { keyIssueId, type, value });

            if (!isValid) {
                dispatch(toggleGridValidationErrorsModal(true, errors));
                dispatch(getMsci(companyId));
                return;
            }
        }

        var promise =
            value == null
                ? axios.delete(`/companies/${companyId}/materialitymaps/msci/${keyIssueId}/${type}`)
                : overrideId == null
                ? axios.post(`/companies/${companyId}/materialitymaps/msci/${keyIssueId}`, { type, value })
                : axios.put(`/companies/${companyId}/materialitymaps/msci/${keyIssueId}`, { type, value });

        return promise.then((res) => dispatch(saveAbOverride.resolve(res.data))).catch((err) => dispatch(saveAbOverride.catch(err)));
    };

//====> REDUCERS <====//
const cacheReducer = handleAction(
    cache,
    (state, action) => {
        const { dataPoint, key, data } = action.payload;

        return {
            ...state,
            Cache: {
                ...state.Cache,
                [dataPoint]: {
                    ...state.Cache[dataPoint],
                    [key]: data,
                },
            },
        };
    },
    initialState
);

const controversyReducer = handleAction(
    fetchControversy,
    (state, action) => {
        return {
            ...state,
            ControversyInfo: {
                ...state.ControversyInfo,
                Data: action.payload,
            },
        };
    },
    initialState
);

const climateTransitionAlignmentFrameworkScore = handleAction(
    fetchClimateTransitionAlignmentFrameworkScore,
    (state, action) => {
        return {
            ...state,
            ClimateTransitionAlignmentFrameworkScore: {
                ...state.ClimateTransitionAlignmentFrameworkScore,
                Data: action.payload,
            },
        };
    },
    initialState
);

const modernSlaveryRiskExposureRatingReducer = handleAction(
    fetchModernSlaveryRiskExposureRating,
    (state, action) => {
        return {
            ...state,
            ModernSlaveryRiskExposureRating: {
                ...state.ModernSlaveryRiskExposureRating,
                Data: action.payload,
            },
        };
    },
    initialState
);

const saveModernSlaveryRiskExposureRatingReducer = handleAction(
    saveModernSlaveryRiskExposureRatingAction,
    (state, action) => {
        return {
            ...state,
            ModernSlaveryRiskExposureRating: {
                ...state.ModernSlaveryRiskExposureRating,
                Data: action.payload,
            },
        };
    },
    initialState
);

const msciReducer = handleAction(
    fetchMSCI,
    (state, action) => {
        return {
            ...state,
            MSCIInfo: {
                ...state.MSCIInfo,
                Data: action.payload,
            },
        };
    },
    initialState
);

const msciRatingChangesReducer = handleAction(
    fetchMsciRatingChanges,
    (state, action) => {
        return {
            ...state,
            MSCIRecentRatingsInfo: {
                ...state.MSCIRecentRatingsInfo,
                Data: action.payload,
            },
        };
    },
    initialState
);
const msciOverrideReducer = handleAction(
    saveAbOverride,
    (state, action) => {
        return {
            ...state,
            MSCIInfo: {
                ...state.MSCIInfo,
                Data: action.payload,
            },
        };
    },
    initialState
);

const portfolioActionsReducer = handleAction(
    fetchPortfolioActionsInfo,
    (state, action) => {
        return {
            ...state,
            PortfolioActionsInfo: {
                ...state.PortfolioActionsInfo,
                Data: action.payload,
            },
        };
    },
    initialState
);

const proxyReducer = handleAction(
    fetchProxy,
    (state, action) => {
        return {
            ...state,
            ProxyInfo: {
                ...state.ProxyInfo,
                Data: {
                    ...state.ProxyInfo.Data,
                    SummaryData: action.payload != null && action.payload.SummaryData != null ? action.payload.SummaryData : [],
                    DetailsData: action.payload != null && action.payload.DetailsData != null ? action.payload.DetailsData.sort(alphaNumericSort('ProposalNumber', false)) : [],
                },
            },
        };
    },
    initialState
);

const gridValidationReducer = handleAction(
    toggleGridValidationErrorsModalAction,
    (state, action) => {
        return {
            ...state,
            GridValidation: {
                modalIsOpen: action.payload.isShowing,
                errors: action.payload.errors,
            },
        };
    },
    initialState
);

export default reduceReducers(
    cacheReducer,
    controversyReducer,
    climateTransitionAlignmentFrameworkScore,
    modernSlaveryRiskExposureRatingReducer,
    saveModernSlaveryRiskExposureRatingReducer,
    msciReducer,
    msciOverrideReducer,
    msciRatingChangesReducer,
    gridValidationReducer,
    portfolioActionsReducer,
    proxyReducer
);
