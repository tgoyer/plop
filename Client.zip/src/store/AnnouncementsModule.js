import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = {
    Active: createState({
        Data: [],
    }),
    All: createState({
        Data: [],
    }),
};
//====> FSA ACTION CREATORS <====//
const getAnnouncementsAction = createAction('ANNOUNCEMENTS::GET');
const getAllAnnouncementsAction = createAction('ANNOUNCEMENTS-ALL::GET');
const createAnnouncementAction = createAction('ANNOUNCEMENTS::CREATE');
const updateAnnouncementAction = createAction('ANNOUNCEMENTS::UPDATE');
const deleteAnnouncementAction = createAction('ANNOUNCEMENTS::DELETE');
const deleteGeneratedAnnouncementsAction = createAction('ANNOUNCEMENTS-GENERATED::DELETE');

//====> ACTIONS <====//
export const getAnnouncements = () => (dispatch) => {
    dispatch(getAnnouncementsAction.begin());
    axios
        .get('/announcements')
        .then((response) => dispatch(getAnnouncementsAction.resolve(response?.data)))
        .catch((err) => dispatch(getAnnouncementsAction.catch(err)));
};

export const getAllAnnouncements = () => (dispatch) => {
    dispatch(getAllAnnouncementsAction.begin());
    axios
        .get('/announcements/all')
        .then((response) => dispatch(getAllAnnouncementsAction.resolve(response?.data)))
        .catch((err) => dispatch(getAllAnnouncementsAction.catch(err)));
};

export const updateAnnouncement = (announcement) => (dispatch) => {
    dispatch(updateAnnouncementAction.begin());
    axios
        .put(`/announcements`, announcement)
        .then((response) => dispatch(updateAnnouncementAction.resolve(response?.data)))
        .catch((err) => dispatch(updateAnnouncementAction.catch(err)));
};

export const createAnnouncement = (announcement) => (dispatch) => {
    dispatch(createAnnouncementAction.begin());
    axios
        .post('/announcements', announcement)
        .then((response) => dispatch(createAnnouncementAction.resolve(response?.data)))
        .catch((err) => dispatch(createAnnouncementAction.catch(err)));
};

export const deleteAnnouncement = (id) => (dispatch) => {
    dispatch(deleteAnnouncementAction.begin());
    axios
        .delete(`/announcements/${id}`)
        .then((response) => dispatch(deleteAnnouncementAction.resolve(response?.data)))
        .catch((err) => dispatch(deleteAnnouncementAction.catch(err)));
};

// Cleans up any auto-generated announcements from the UI when the related contentID entity
// they referenced is deleted
export const deleteGeneratedAnnouncements = (contentID) => (dispatch) => {
    dispatch(deleteGeneratedAnnouncementsAction.begin());
    dispatch(deleteGeneratedAnnouncementsAction.resolve(contentID));
};

//====> REDUCERS <====//
const createAnnouncementReducer = handleAction(
    createAnnouncementAction,
    (state, action) => {
        return {
            ...state,
            Active: {
                ...state.Active,
                Data: [...[action.payload], ...state.Active.Data],
            },
        };
    },
    initialState
);
const updateAnnouncementReducer = handleAction(
    updateAnnouncementAction,
    (state, action) => {
        return {
            ...state,
            Active: {
                ...state.Active,
                Data: state.Active.Data.map((a) => (a.AnnouncementID === action.payload.AnnouncementID ? action.payload : a)),
            },
        };
    },
    initialState
);
const getAnnouncementsReducer = handleAction(
    getAnnouncementsAction,
    (state, action) => {
        return {
            ...state,
            Active: {
                ...state.Active,
                Data: action.payload,
            },
        };
    },
    initialState
);
const getAllAnnouncementsReducer = handleAction(
    getAllAnnouncementsAction,
    (state, action) => {
        return {
            ...state,
            All: {
                ...state.All,
                Data: action.payload,
            },
        };
    },
    initialState
);

const deleteAnnouncementReducer = handleAction(
    deleteAnnouncementAction,
    (state, action) => {
        return {
            ...state,
            Active: {
                ...state.Active,
                Data: state.Active.Data.filter((a) => a.AnnouncementID !== action.payload.DeletedID),
            },
        };
    },
    initialState
);

const deleteGeneratedAnnouncementsReducer = handleAction(
    deleteGeneratedAnnouncementsAction,
    (state, action) => {
        return {
            ...state,
            Active: {
                ...state.Active,
                Data: state.Active.Data.filter((a) => a.ContentID !== action.payload),
            },
        };
    },
    initialState
);

export default reduceReducers(
    createAnnouncementReducer,
    getAnnouncementsReducer,
    getAllAnnouncementsReducer,
    updateAnnouncementReducer,
    deleteAnnouncementReducer,
    deleteGeneratedAnnouncementsReducer
);
