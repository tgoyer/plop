import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

import { getNoteAttachments } from './FileModule';

import { getLocalData, setLocalData } from '../Utils/localStorageHelper';

const initialState = createState({
    NoteData: null,
    NoteHistory: {},
    NoteKeyIssues: [],
    NoteList: {
        PortfolioActions: [],
        Boxes: [],
        pageNumber: 0,
        canLoadMore: true,
        ActionKeyIssues: [],
    },
    MSCIRating: {},
    DeletedNote: '',
    Cache: {
        CompanyRating: null,
    },
    TrackingActions: [],
    SearchActions: [],
});

//====> FSA ACTION CREATORS <====//
const cacheAction = createAction('NOTE::CACHE');
const clearNoteAction = createAction('NOTE::CLEAR');
const deleteNoteAction = createAction('NOTE::DELETE');
const getAttendeesAction = createAction('NOTE::ATTENDEES');
const getKeyIssuesAction = createAction('NOTE::KEYISSUES');
const getNoteAction = createAction('NOTE::FETCH');
const getNoteHistoryAction = createAction('NOTE::FETCH-HISTORY');
const getNotesAction = createAction('NOTE::FETCH-ALL-NOTES');
const getRatingAction = createAction('NOTE::RATING');
const regenNotePdfAction = createAction('NOTE::REGENERATE-PDF');
const saveNoteAction = createAction('NOTE::SAVE');

//====> ACTIONS <====//
export const clearNote = () => (dispatch) => {
    dispatch(clearNoteAction.begin());
    dispatch(clearNoteAction.resolve());
};

export const deleteNote = (noteID) => (dispatch) => {
    dispatch(deleteNoteAction.begin());
    return axios
        .delete(`/notes/${noteID}`)
        .then((response) => dispatch(deleteNoteAction.resolve(response.data)))
        .catch((err) => dispatch(deleteNoteAction.catch(err)));
};

export const generateNotePdf = (noteId) => (dispatch) => {
    dispatch(regenNotePdfAction.begin());

    // This PUT action doesn't return any data.
    // It does not have a reducer as there is no data to reduce.
    return axios
        .put(`/notes/${noteId}/generatePDF`)
        .then(() => dispatch(regenNotePdfAction.resolve()))
        .catch((err) => dispatch(regenNotePdfAction.catch(err)));
};

export const getAttendees = (noteID) => (dispatch) => {
    dispatch(getAttendeesAction.begin());
    return axios
        .get(`/notes/${noteID}/attendees`, {
            params: { noteID },
        })
        .then((response) => dispatch(getAttendeesAction.resolve(response.data)))
        .catch((err) => dispatch(getAttendeesAction.catch(err)));
};

export const getMSCIRating = (companyID) => async (dispatch) => {
    dispatch(getRatingAction.begin());
    try {
        const { data } = await axios.get(`/companies/${companyID}/rating`);
        dispatch(getRatingAction.resolve(data));
    } catch (err) {
        dispatch(getRatingAction.catch(err));
    }
};

export const getNote = (noteID) => (dispatch) => {
    dispatch(getNoteAction.begin());
    dispatch(clearNote());

    const promise = noteID == null ? Promise.resolve(null) : axios.get(`/notes/${noteID}`).then((response) => response.data);

    return promise
        .then((data) => {
            const noteIds = data != null && data.NoteID != null ? [data.NoteID] : [0];
            dispatch(getNoteAttachments(noteIds));
            dispatch(getNoteAction.resolve(data));
        })
        .catch((err) => dispatch(getNoteAction.catch(err)));
};

export const getNoteHistory = (noteID, keyIssueID) => (dispatch) => {
    dispatch(getNoteHistoryAction.begin());

    return axios
        .get(`/notes/${noteID}/key_issue_action/history`)
        .then((response) => response.data)
        .then((data) => dispatch(getNoteHistoryAction.resolve(data)))
        .catch((err) => dispatch(getNoteHistoryAction.catch(err)));
};

export const getNotes = (companyID, startDate, endDate, noteTypeID, query, noteID, pageNumber, teamID) => async (dispatch) => {
    dispatch(getNotesAction.begin());

    if (pageNumber === 1) {
        dispatch(
            getNotesAction.resolve({
                pageNumber,
                Comments: [],
                PortfolioActions: [],
                ActionKeyIssues: [],
            })
        );
    }

    try {
        const { data } = await axios.get(`/notes`, {
            params: { companyID, startDate, endDate, noteTypeID, query, noteID, pageNumber, teamID },
        });

        dispatch(getNoteAttachments(data?.Comments != null ? data?.Comments.map((comment) => comment.NoteID) : []));
        dispatch(getNotesAction.resolve({ pageNumber, ...data }));
    } catch (err) {
        dispatch(getNotesAction.catch(err));
    }
};

export const getNoteKeyIssues = (companyID, noteID) => (dispatch, getState) => {
    dispatch(getKeyIssuesAction.begin());

    const url = companyID != null && noteID != null ? `/companies/${companyID}/notes/${noteID}/key_issues` : companyID != null ? `/companies/${companyID}/key_issues` : null;

    const promise = url == null ? Promise.resolve([]) : axios.get(url).then((response) => response.data);

    return promise.then((data) => dispatch(getKeyIssuesAction.resolve(data))).catch((err) => dispatch(getKeyIssuesAction.catch(err)));
};

export const saveNote = (note) => (dispatch) => {
    dispatch(saveNoteAction.begin());

    const promise = note.NoteID == null ? axios.post('/notes', note) : axios.put(`/notes/${note.NoteID}`, note);

    return promise
        .then((response) => {
            dispatch(saveNoteAction.resolve(response.data));
            return response.data;
        })
        .catch((err) => dispatch(saveNoteAction.catch(err)));
};

//====> REDUCERS <====//
const cacheReducer = handleAction(
    cacheAction,
    (state, action) => {
        const { dataPoint, key, data } = action.payload;

        return {
            ...state,
            Cache: {
                ...state.Cache,
                [dataPoint]: {
                    ...state.Cache[dataPoint],
                    [key]: data,
                },
            },
        };
    },
    initialState
);
const clearNoteReducer = handleAction(
    clearNoteAction,
    (state, action) => {
        return {
            ...state,
            NoteData: null,
        };
    },
    initialState
);

const deleteNoteReducer = handleAction(
    deleteNoteAction,
    (state, action) => {
        return {
            ...state,
            DeletedNote: action.payload,
        };
    },
    initialState
);
const getAttendeesReducer = handleAction(
    getAttendeesAction,
    (state, action) => {
        const foundExternalAttendees = action.payload.filter((data) => data.AttendeesUserID === -1);
        let externalAttendees = '';

        if (foundExternalAttendees != null && foundExternalAttendees.length > 0 && foundExternalAttendees[0].AttendeesName != null) {
            externalAttendees = foundExternalAttendees[0].AttendeesName.split('|').join('; ');
        }

        const internalAttendees = action.payload.filter((data) => data.AttendeesUserID > 0);
        return {
            ...state,
            NoteData: {
                ...state.NoteData,
                ExternalAttendees: externalAttendees,
                InternalAttendees: internalAttendees,
            },
        };
    },
    initialState
);
const getMSCIRatingReducer = handleAction(
    getRatingAction,
    (state, action) => {
        return {
            ...state,
            MSCIRating: action.payload,
        };
    },
    initialState
);
const getNoteReducer = handleAction(
    getNoteAction,
    (state, action) => {
        return {
            ...state,
            NoteData: action.payload,
        };
    },
    initialState
);
const getNoteHistoryReducer = handleAction(
    getNoteHistoryAction,
    (state, action) => {
        return {
            ...state,
            NoteHistory: action.payload,
        };
    },
    initialState
);
const getNotesReducer = handleAction(
    getNotesAction,
    (state, action) => {
        const {
            payload: { pageNumber, Comments, PortfolioActions, ActionKeyIssues },
        } = action;
        const portfolioActions = pageNumber <= 1 ? PortfolioActions : [...state.NoteList.PortfolioActions, PortfolioActions];
        const comments = pageNumber <= 1 ? Comments : [...state.NoteList.Boxes, ...Comments];
        const canLoadMore = Comments.length > 0;
        const actionKeyIssues = pageNumber <= 1 ? ActionKeyIssues : [...state.NoteList.ActionKeyIssues, ...ActionKeyIssues];

        return {
            ...state,
            NoteList: {
                Boxes: comments,
                PortfolioActions: portfolioActions,
                ActionKeyIssues: actionKeyIssues,
                pageNumber: pageNumber,
                canLoadMore: canLoadMore,
            },
        };
    },
    initialState
);
const getNoteKeyIssuesReducer = handleAction(
    getKeyIssuesAction,
    (state, action) => {
        return {
            ...state,
            NoteKeyIssues: action.payload,
        };
    },
    initialState
);
const saveNoteReducer = handleAction(
    saveNoteAction,
    (state, action) => {
        return {
            ...state,
            NoteData: action.payload,
        };
    },
    initialState
);

export default reduceReducers(
    cacheReducer,
    clearNoteReducer,
    deleteNoteReducer,
    getAttendeesReducer,
    getMSCIRatingReducer,
    getNoteReducer,
    getNoteHistoryReducer,
    getNotesReducer,
    getNoteKeyIssuesReducer,
    saveNoteReducer
);
