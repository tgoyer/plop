import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = createState({
    Contacts: createState({
        Data: null,
    }),
});

//====> FSA ACTION CREATORS <====//
const getContactsAction = createAction('CONTACTS::FETCH');

//====> ACTIONS <====//
export const getContacts = () => (dispatch) => {
    dispatch(getContactsAction.begin());
    return Promise.resolve(contacts)
        .then((data) => dispatch(getContactsAction.resolve(data)))
        .catch((err) => dispatch(getContactsAction.catch(err)));
};

//====> REDUCERS <====//
const getContactsReducer = handleAction(
    getContactsAction,
    (state, { payload }) => {
        return {
            ...state,
            Contacts: {
                ...state.Contacts,
                Data: payload,
            },
        };
    },
    initialState
);

export default reduceReducers(getContactsReducer);

const contacts = [
    { team: 'Emerging Markets Growth', contacts: [{ user: 'Kate Huang', email: 'Kate.Huang@alliancebernstein.com' }] },
    { team: 'Concentrated Global Growth', contacts: [{ user: 'Ton Wijsman', email: 'Ton.Wijsman@alliancebernstein.com' }] },
    { team: 'Concentrated US GROWTH', contacts: [{ user: 'Dave Tsoupros', email: 'David.Tsoupros@alliancebernstein.com' }] },
    { team: 'FSOF', contacts: [{ user: 'Stephen Kapsky', email: 'Stephen.Kapsky@alliancebernstein.com' }] },
    { team: 'Global Core Equity', contacts: [{ user: 'Thomas Christensen', email: 'Thomas.Christensen@alliancebernstein.com' }] },
    { team: 'GRI', contacts: [{ user: 'Tawhid Ali', email: 'tawhid.ali@alliancebernstein.com' }] },
    { team: 'Strategic Core - International (EAFE)', contacts: [{ user: 'Anu Venkataraman', email: 'anu.venkataraman@alliancebernstein.com' }] },
    { team: 'Strategic Core EM', contacts: [{ user: 'Vivian Lubrano', email: 'Vivian.Lubrano@alliancebernstein.com' }] },
    { team: 'Strategic Core US', contacts: [{ user: 'Ian McNaugher', email: 'Ian.McNaugher@alliancebernstein.com' }] },
    {
        team: 'Sustainable Global Thematic',
        contacts: [
            { user: 'Amy Yang', email: 'Amy.Yang@bernstein.com' },
            { user: 'David Wheeler', email: 'David.Wheeler@alliancebernstein.com' },
        ],
    },
    { team: 'US Large Cap Growth', contacts: [{ user: 'Ryan Oden', email: 'Ryan.Oden@alliancebernstein.com' }] },
    { team: 'US Select Equities', contacts: [{ user: 'Anthony Nappo', email: 'Anthony.Nappo@alliancebernstein.com' }] },
    { team: 'Value - Asia ex Japan', contacts: [{ user: 'Stuart Rae', email: 'stuart.rae@alliancebernstein.com' }] },
    { team: 'Value - Australia - Managed Vol', contacts: [{ user: 'Roy Maslen', email: 'roy.maslen@alliancebernstein.com' }] },
    { team: 'Value - Australia - Managed Vol - Global', contacts: [{ user: 'Roy Maslen', email: 'roy.maslen@alliancebernstein.com' }] },
    { team: 'Value - Australian Value', contacts: [{ user: 'Roy Maslen', email: 'roy.maslen@alliancebernstein.com' }] },
    { team: 'Value - Australian Value Concentrated', contacts: [{ user: 'Roy Maslen', email: 'roy.maslen@alliancebernstein.com' }] },
    { team: 'Value - Emerging Markets Value', contacts: [{ user: "Henry D'Auria", email: 'henry.dauria@alliancebernstein.com' }] },
    { team: 'Value - European Value', contacts: [{ user: 'Tawhid Ali', email: 'tawhid.ali@alliancebernstein.com' }] },
    { team: 'Value - Global Value', contacts: [{ user: 'Tawhid Ali', email: 'tawhid.ali@alliancebernstein.com' }] },
    { team: 'Value - International Value', contacts: [{ user: 'Tawhid Ali', email: 'tawhid.ali@alliancebernstein.com' }] },
    { team: 'Value - Japan Strategic Value', contacts: [{ user: 'Atsushi Horikawa', email: 'Atsushi.Horikawa@alliancebernstein.com' }] },
    { team: 'Value - Japan Value', contacts: [{ user: 'Atsushi Horikawa', email: 'Atsushi.Horikawa@alliancebernstein.com' }] },
    { team: 'Value - Real Estate', contacts: [{ user: 'Ajit Ketkar', email: 'ajit.ketkar@alliancebernstein.com' }] },
    { team: 'Value - US Small Cap Value', contacts: [{ user: 'James MacGregor', email: 'james.macgregor@alliancebernstein.com' }] },
    { team: 'Value - US SMID Value', contacts: [{ user: 'James MacGregor', email: 'james.macgregor@alliancebernstein.com' }] },
    { team: 'Value - US Strategic Value', contacts: [{ user: 'Shri Singhvi', email: 'Shri.Singhvi@alliancebernstein.com' }] },
    { team: 'Value - Large Cap', contacts: [{ user: 'Cem Inal', email: 'Cem.Inal@alliancebernstein.com' }] },
    { team: 'US Small Cap Growth', contacts: [{ user: 'Esteban Gomez', email: 'esteban.gomez@alliancebernstein.com' }] },
    { team: 'US Strategic Equities', contacts: [{ user: 'Shri Singhvi', email: 'Shri.Singhvi@alliancebernstein.com' }] },
    {
        team: 'Fixed Income - PRISM',
        contacts: [
            { user: 'Rob Hopper', email: 'Robert.Hopper@alliancebernstein.com' },
            { user: 'Susan Hutman', email: 'susan.hutman@alliancebernstein.com' },
        ],
    },
    { team: 'N50', contacts: [{ user: 'Vlad Byalik', email: 'vlad.byalik@alliancebernstein.com' }] },
    { team: 'Global Improvers', contacts: [{ user: 'Michelle Dunstan', email: 'michelle.dunstan@alliancebernstein.com' }] },
    { team: 'REUSE', contacts: [{ user: 'Valerie Grant', email: 'valerie.grant@alliancebernstein.com' }] },
];
