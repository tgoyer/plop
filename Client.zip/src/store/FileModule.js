import _get from 'lodash/get';

import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = {
    FavoriteFiles: createState({ Data: [] }),
    Files: createState({ Data: {} }),
    NoteAttachments: createState({ Data: {} }),
    PopularFiles: createState({ Data: [] }),
    RecentFiles: createState({ Data: [] }),
    SearchFiles: createState({ Data: [], Count: 0 }),
    SearchMetrics: createState({ Data: [] }),
    Sustainalytics: createState({ Blob: null }),
    UploadedFiles: createState({ Data: [] }),
    SearchFilesByName: createState({ Count: 0, Hits: [] }),
};

//====> FSA ACTION CREATORS <====//
const clearSearchFilesByNameAction = createAction('FILE::CLEAR-SEARCH-FILESBY-NAME', 'SearchFilesByName');
const clearSearchFilesAction = createAction('FILE::CLEAR-DOC-REPOSITORY', 'SearchFiles');
const deleteFavoriteFilesAction = createAction('USER::DELETE-FAVORITE-FILE', 'FavoriteFiles');
const deleteFileAction = createAction('FILE::DELETE', 'Files');
const getFavoriteFilesAction = createAction('USER::GET-FAVORITE-FILES', 'FavoriteFiles');
const getNoteAttachmentsAction = createAction('NOTE::GET-NOTE-ATTACHMENTS', 'NoteAttachments');
const getPopularFilesAction = createAction('FILE::GET-POPULAR', 'PopularFiles');
const getRecentFilesAction = createAction('FILE::GET-RECENT', 'RecentFiles');
const getSearchMetricsAction = createAction('FILE::GET-SEARCH-METRICS', 'SearchMetrics');
const getUploadedFilesAction = createAction('USER::GET-UPLOADED-FILES', 'UploadedFiles');
const saveFavoriteFileAction = createAction('USER::SAVE-FAVORITE-FILE', 'FavoriteFiles');
const saveFileAction = createAction('USER::SAVE-FILE', 'Files');
const searchFilesAction = createAction('FILE::SEARCH-DOC-REPOSITORY', 'SearchFiles');
const sustainalyticsAction = createAction('FILE::GET-SUSTAINALYTICS', 'Sustainalytics');
const searchFilesByNameAction = createAction('FILE::SEARCH-FILESBY-NAME', 'SearchFilesByName');

//====> ACTIONS <====//
export const clearSearchFilesByName = () => (dispatch) => {
    dispatch(clearSearchFilesByNameAction.begin());
    dispatch(clearSearchFilesByNameAction.action());
    return Promise.resolve();
};

export const clearSearchFiles = () => (dispatch) => {
    dispatch(clearSearchFilesAction.begin());
    dispatch(clearSearchFilesAction.action());
    return Promise.resolve();
};

export const deleteFavoriteFile = (fileId) => (dispatch) => {
    dispatch(deleteFavoriteFilesAction.begin());
    return axios
        .delete(`/users/me/favorites/${fileId}`)
        .then(() => dispatch(deleteFavoriteFilesAction.resolve(fileId)))
        .catch((err) => dispatch(deleteFavoriteFilesAction.catch(err)));
};

export const deleteFile = (fileId) => (dispatch) => {
    dispatch(deleteFileAction.begin());
    return axios({
        url: '/files/' + fileId,
        method: 'DELETE',
    })
        .then(() => dispatch(deleteFileAction.resolve(fileId)))
        .catch((err) => dispatch(deleteFileAction.catch(err)));
};

export const downloadSustainalyticsReport = (companyID, fileType) => (dispatch) => {
    dispatch(sustainalyticsAction.begin());
    return axios({
        url: `/companies/${companyID}/reports/sustainalytics`,
        params: { sustainalyticsCompanyID: companyID },
        method: 'GET',
        responseType: 'arraybuffer',
    })
        .then((response) => dispatch(sustainalyticsAction.resolve({ data: response.data, type: fileType })))
        .catch((err) => dispatch(sustainalyticsAction.catch(err)));
};

export const getFavoriteFiles = () => (dispatch) => {
    dispatch(getFavoriteFilesAction.begin());

    return axios
        .get(`/users/me/favorites`)
        .then((response) => dispatch(getFavoriteFilesAction.resolve(response.data)))
        .catch((err) => dispatch(getFavoriteFilesAction.catch(err)));
};

export const getNoteAttachments = (ids) => (dispatch) => {
    dispatch(getNoteAttachmentsAction.begin());
    const params = { ids, subdomain: 'Note::Attachments' };
    return axios
        .get(`/files/notes`, {
            params,
            paramsSerializer: (d) => new URLSearchParams(d).toString(),
        })
        .then((response) => dispatch(getNoteAttachmentsAction.resolve(response.data)))
        .catch((err) => dispatch(getNoteAttachmentsAction.catch(err)));
};

export const getPopularFiles = () => (dispatch) => {
    dispatch(getPopularFilesAction.begin());

    return axios
        .get(`/files/popular`)
        .then((response) => dispatch(getPopularFilesAction.resolve(response.data)))
        .catch((err) => dispatch(getPopularFilesAction.catch(err)));
};

export const getRecentFiles = () => (dispatch) => {
    dispatch(getRecentFilesAction.begin());

    return axios
        .get(`/files/recent`)
        .then((response) => dispatch(getRecentFilesAction.resolve(response.data)))
        .catch((err) => dispatch(getRecentFilesAction.catch(err)));
};

export const getSearchMetrics = () => (dispatch) => {
    dispatch(getSearchMetricsAction.begin());

    return axios
        .get(`/files/search/metrics`)
        .then((response) => dispatch(getSearchMetricsAction.resolve(response.data)))
        .catch((err) => dispatch(getSearchMetricsAction.catch(err)));
};

export const getUploadedFiles = () => (dispatch) => {
    dispatch(getUploadedFilesAction.begin());

    return axios
        .get(`/users/me/uploads`)
        .then((response) => dispatch(getUploadedFilesAction.resolve(response.data)))
        .catch((err) => dispatch(getUploadedFilesAction.catch(err)));
};

export const saveFavoriteFile = (fileId) => (dispatch) => {
    dispatch(saveFavoriteFileAction.begin());

    return axios
        .post(`/users/me/favorites/${fileId}`)
        .then((response) => dispatch(saveFavoriteFileAction.resolve(response.data)))
        .catch((err) => dispatch(saveFavoriteFileAction.catch(err)));
};

export const saveFileData = (file) => (dispatch, getState) => {
    dispatch(saveFileAction.begin());

    return axios
        .put(`/files/${file.id}`, file)
        .then((response) => dispatch(saveFileAction.resolve(response.data)))
        .catch((err) => dispatch(saveFileAction.catch(err)));
};

export const searchDocumentRepository = (data) => (dispatch) => {
    dispatch(searchFilesAction.begin());

    return axios
        .post('/files/search', data)
        .then((response) => dispatch(searchFilesAction.resolve(response.data)))
        .catch((err) => dispatch(searchFilesAction.catch(err)));
};

export const searchFilesByName = (fileNames) => (dispatch) => {
    dispatch(searchFilesByNameAction.begin());
    return axios
        .post('/files/search/name', fileNames)
        .then((response) => dispatch(searchFilesByNameAction.resolve(response.data)))
        .catch((err) => dispatch(searchFilesByNameAction.catch(err)));
};

export const updateFileRefs = (noteIds) => (dispatch) => {
    dispatch(getFavoriteFiles());
    dispatch(getPopularFiles());
    dispatch(getRecentFiles());
    dispatch(getUploadedFiles());
    dispatch(getNoteAttachments(Array.isArray(noteIds) ? noteIds : [0]));
};

//====> REDUCERS <====//
const clearSearchFilesByNameReducer = handleAction(
    clearSearchFilesByNameAction,
    (state, action) => {
        return {
            ...state,
            SearchFilesByName: {
                ...state.SearchFilesByName,
                ...initialState.SearchFilesByName,
            },
        };
    },
    initialState
);

const clearSearchFilesReducer = handleAction(
    clearSearchFilesAction,
    (state, action) => {
        return {
            ...state,
            SearchFiles: {
                ...state.SearchFiles,
                isLoading: false,
                isLoaded: false,
                Data: [],
            },
        };
    },
    initialState
);

const deleteFavoriteReducer = handleAction(
    deleteFavoriteFilesAction,
    (state, action) => {
        return {
            ...state,
            FavoriteFiles: {
                ...state.FavoriteFiles,
                Data: state.FavoriteFiles.Data.filter((id) => id !== action.payload),
            },
        };
    },
    initialState
);

const deleteFileReducer = handleAction(
    deleteFileAction,
    (state, action) => {
        const fileId = action.payload;
        const files = { ...state.Files.Data };
        delete files[fileId];

        return {
            ...state,
            Files: {
                ...state.Files,
                Data: files,
            },
        };
    },
    initialState
);

const getNoteAttachmentsReducer = handleAction(
    getNoteAttachmentsAction,
    (state, action) => {
        const [ids, files] = extractFileStateData(action, state);

        const data = Object.keys(files.Data).reduce((acc, key) => {
            const file = files.Data[key];
            if (Array.isArray(ids) && ids.indexOf(file.Id) >= 0) {
                const noteId = _get(file, 'External.NoteId');
                acc[noteId] = [...(acc[noteId] || []), file.Id];
            }
            return acc;
        }, {});

        return {
            ...state,
            Files: files,
            NoteAttachments: {
                ...state.NoteAttachments,
                Data: {
                    ...state.NoteAttachments.Data,
                    ...data,
                },
            },
        };
    },
    initialState
);

const getFavoriteFilesReducer = handleAction(
    getFavoriteFilesAction,
    (state, action) => {
        const [ids, files] = extractFileStateData(action, state);

        return {
            ...state,
            Files: files,
            FavoriteFiles: {
                ...state.FavoriteFiles,
                Data: ids,
            },
        };
    },
    initialState
);

const getPopularFilesReducer = handleAction(
    getPopularFilesAction,
    (state, action) => {
        const [ids, files] = extractFileStateData(action, state);

        return {
            ...state,
            Files: files,
            PopularFiles: {
                ...state.PopularFiles,
                Data: ids,
            },
        };
    },
    initialState
);

const getRecentFilesReducer = handleAction(
    getRecentFilesAction,
    (state, action) => {
        const [ids, files] = extractFileStateData(action, state);

        return {
            ...state,
            Files: files,
            RecentFiles: {
                ...state.RecentFiles,
                Data: ids,
            },
        };
    },
    initialState
);

const getSearchMetricsReducer = handleAction(
    getSearchMetricsAction,
    (state, action) => {
        return {
            ...state,
            SearchMetrics: {
                ...state.SearchMetrics,
                Data: _get(action, 'payload', {
                    Tags: [],
                    Terms: [],
                }),
            },
        };
    },
    initialState
);

const getUploadedFilesReducer = handleAction(
    getUploadedFilesAction,
    (state, action) => {
        const [ids, files] = extractFileStateData(action, state);

        return {
            ...state,
            Files: files,
            UploadedFiles: {
                ...state.UploadedFiles,
                Data: ids,
            },
        };
    },
    initialState
);

const saveFavoriteFileReducer = handleAction(
    saveFavoriteFileAction,
    (state, action) => {
        const [ids] = extractFileStateData(action, state);

        return {
            ...state,
            FavoriteFiles: {
                ...state.FavoriteFiles,
                Data: ids,
            },
        };
    },
    initialState
);

const saveFileReducer = handleAction(
    saveFileAction,
    (state, action) => {
        const hits = _get(action, 'payload.Hits', []);
        const files = { ...state.Files.Data };

        hits.forEach((h) => (files[h.Id] = h));

        return {
            ...state,
            Files: {
                ...state.Files,
                Data: files,
            },
        };
    },
    initialState
);

const searchFilesByNameReducer = handleAction(
    searchFilesByNameAction,
    (state, action) => {
        return {
            ...state,
            SearchFilesByName: {
                ...state.SearchFilesByName,
                ...action.payload,
            },
        };
    },
    initialState
);

const searchFilesReducer = handleAction(
    searchFilesAction,
    (state, action) => {
        const [ids, files] = extractFileStateData(action, state);

        return {
            ...state,
            Files: files,
            SearchFiles: {
                Data: ids,
                Count: action.payload.Count,
            },
        };
    },
    initialState
);

const sustainalyticsFetchReducer = handleAction(
    sustainalyticsAction,
    (state, action) => {
        return {
            ...state,
            Sustainalytics: {
                ...state.Sustainalytics,
                Blob: createFileBlob(action),
            },
        };
    },
    initialState
);

export default reduceReducers(
    clearSearchFilesByNameReducer,
    clearSearchFilesReducer,
    deleteFavoriteReducer,
    deleteFileReducer,
    getFavoriteFilesReducer,
    getNoteAttachmentsReducer,
    getRecentFilesReducer,
    getPopularFilesReducer,
    getSearchMetricsReducer,
    getUploadedFilesReducer,
    saveFavoriteFileReducer,
    saveFileReducer,
    searchFilesReducer,
    sustainalyticsFetchReducer,
    searchFilesByNameReducer
);

export const getFileDefinitions = (ids, files) => {
    return Array.isArray(ids) && files != null
        ? ids.reduce((acc, id) => {
              const file = files[id];
              if (file != null) acc.push(file);
              return acc;
          }, [])
        : [];
};

const createFileBlob = (action) => {
    return action.payload == null ? null : action.payload.type != null ? new Blob([action.payload.data], { type: action.payload.type }) : new Blob([action.payload.data]);
};

const extractFileStateData = (action, state) => {
    const hits = _get(action, 'payload.Hits', []);
    const ids = hits == null ? [] : hits.map((h) => h.Id);
    const files =
        hits == null
            ? {}
            : hits.reduce((acc, h) => {
                  acc[h.Id] = h;
                  return acc;
              }, {});

    return [
        ids,
        {
            ...state.Files,
            Data: {
                ...state.Files.Data,
                ...files,
            },
        },
    ];
};
