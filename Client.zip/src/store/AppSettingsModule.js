// TODO: Move user-preference LOCALSETTINGS server-side at some point as this is getting more complicated than anticipated the expanded grid settings.
// TODO: Move user-preference LOCALSETTINGS server-side at some point as this is getting more complicated than anticipated the expanded grid settings.
// TODO: Move user-preference LOCALSETTINGS server-side at some point as this is getting more complicated than anticipated the expanded grid settings.

import _get from 'lodash/get';
import _set from 'lodash/set';

import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';
import { getLocalData, setLocalData } from '../Utils/localStorageHelper';

const localSettingsSchemaVersion = {
    Filters: 1.0,
    ResearchInput: 1.0,
    EngagementInput: 1.0,
    Portfolio: 1.5,
};
const initialState = createState({
    KnowledgeCenter: {
        Query: {
            query: '',
            categories: {},
        },
    },
    LocalSettings: {
        EngagementInput: {
            msciPinned: false,
        },
        Filters: {
            IsActive: false,
            Team: null,
            Date: {
                End: null,
                Start: null,
            },
        },
        Portfolio: {
            accountId: null,
            favoritePortfolios: {},
            gridConfigurations: {},
            gridFiltered: [],
            gridResized: [],
            gridSort: [],
            gridSettings: [],
        },
        ResearchInput: {
            msciPinned: false,
        },
    },
    Messages: [],
    OnlineStatus: true,
    ServerSettings: {},
    ViewStatus: {
        mustConfirmNavigation: false,
    },
});

//====> FSA ACTION CREATORS <====//
const getLocalSettingsAction = createAction('LOCAL-SETTINGS::FETCH');
const setLocalSettingsAction = createAction('LOCAL-SETTINGS::SET');
const setKnowledgeCenterSettingsAction = createAction('KC-SETTINGS::SET');
const setOnlineStatusAction = createAction('ONLINE-STATUS::SET');
const viewStatusAction = createAction('VIEW-STATUS::SET');
const serverSettingsAction = createAction('SERVER-APP-SETTINGS::FETCH');

//====> ACTIONS <====//
export const getAppSettings = () => async (dispatch) => {
    return await Promise.all([dispatch(getServerSettings()), dispatch(getLocalSettings())]);
};

export const setKnowledgeCenterSettings = (settings) => (dispatch) => {
    dispatch(setKnowledgeCenterSettingsAction.begin());
    return dispatch(setKnowledgeCenterSettingsAction.resolve(settings));
};

export const getLocalSettings = () => (dispatch) => {
    dispatch(getLocalSettingsAction.begin());
    const cacheName = 'LocalSettings';
    const data = getLocalData(cacheName, null) || initialState.LocalSettings;

    if (data != null) {
        for (let key in data) {
            if (data[key] == null || data[key]._v !== localSettingsSchemaVersion[key]) {
                data[key] = {
                    ...initialState.LocalSettings[key],
                    _v: localSettingsSchemaVersion[key],
                };
            }
        }
    }

    setLocalData(cacheName, null, data);

    return Promise.resolve(dispatch(getLocalSettingsAction.resolve(data)));
};

export const resetLocalSettings = () => (dispatch) => {
    return Promise.all(
        Object.keys(initialState.LocalSettings).map((setting) => {
            return dispatch(setLocalSetting(setting, initialState.LocalSettings[setting]));
        })
    );
};

export const setOnlineStatus = (isOnline) => (dispatch) => {
    dispatch(setOnlineStatusAction.action(isOnline));
    return Promise.resolve();
};

export const setLocalSetting = (key, value) => (dispatch) => {
    dispatch(setLocalSettingsAction.action({ key, value }));
    return Promise.resolve();
};

export const setViewStatus = (status) => (dispatch) => {
    dispatch(viewStatusAction.action(status));
    return Promise.resolve();
};

export const getServerSettings = () => async (dispatch) => {
    dispatch(serverSettingsAction.begin());
    try {
        const { data } = await axios.get('/common/app_settings');
        dispatch(serverSettingsAction.resolve(data));
        return data;
    } catch (err) {
        dispatch(serverSettingsAction.catch(err));
    }
};

//====> REDUCERS <====//
const getLocalSettingsReducer = handleAction(
    getLocalSettingsAction,
    (state, action) => {
        return {
            ...state,
            LocalSettings: {
                ...initialState.LocalSettings,
                ...state.LocalSettings,
                ...action.payload,
            },
        };
    },
    initialState
);

const setKnowledgeCenterSettingsReducer = handleAction(
    setKnowledgeCenterSettingsAction,
    (state, action) => {
        const settings = action.payload;
        return {
            ...state,
            KnowledgeCenter: settings != null ? { ...state.KnowledgeCenter, ...settings } : { ...initialState.KnowledgeCenter },
        };
    },
    initialState
);

const setLocalSettingsReducer = handleAction(
    setLocalSettingsAction,
    (state, action) => {
        const { key, value } = action.payload;
        const localSettings = { ...state.LocalSettings };

        const localSettingsState = _set(localSettings, key, {
            ..._get(localSettings, key),
            ...value,
        });

        const newState = {
            ...state,
            LocalSettings: {
                ...state.LocalSettings,
                ...localSettingsState,
            },
        };

        setLocalData('LocalSettings', null, localSettingsState);

        return newState;
    },
    initialState
);

const setOnlineStatusReducer = handleAction(
    setOnlineStatusAction,
    (state, action) => {
        return {
            ...state,
            OnlineStatus: action.payload,
        };
    },
    initialState
);

const serverAppSettingReducer = handleAction(
    serverSettingsAction,
    (state, action) => {
        return {
            ...state,
            ServerSettings: {
                ...state.ServerSettings,
                ...action.payload,
            },
        };
    },
    initialState
);

const viewStatusReducer = handleAction(
    viewStatusAction,
    (state, action) => {
        return {
            ...state,
            ViewStatus: {
                ...state.ViewStatus,
                ...action.payload,
            },
        };
    },
    initialState
);

export default reduceReducers(getLocalSettingsReducer, serverAppSettingReducer, setKnowledgeCenterSettingsReducer, setLocalSettingsReducer, setOnlineStatusReducer, viewStatusReducer);
