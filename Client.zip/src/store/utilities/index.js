import { createAction as reduxCreateAction, combineActions as reduxCombineActions, handleAction as reduxHandleAction } from 'redux-actions';
import { default as reduxReduceReducers } from 'reduce-reducers';
import dotProp from 'dot-prop-immutable';
import { handleRequestError } from '../ApiModule';

export { default as reduceReducers } from 'reduce-reducers';

const beginSuffix = '::BEGIN-REQUEST';
const endSuffix = '::END-REQUEST';
const errSuffix = '::ERROR-REQUEST';

const defaultError = {
    detail: null,
    hasError: false,
    message: '',
};

export function createAction(type, stateRoot, actionPayloadCreator, metaCreator) {
    const beginType = `${type}${beginSuffix}`;
    const endType = `${type}${endSuffix}`;
    const errType = `${type}${errSuffix}`;

    const actionAction = reduxCreateAction(type, actionPayloadCreator, metaCreator);
    const beginAction = reduxCreateAction(beginType, () => ({ isLoading: true, isLoaded: false, error: null }), metaCreator);
    const endAction = reduxCreateAction(endType, () => ({ isLoading: false, isLoaded: true }), metaCreator);
    const errorAction = reduxCreateAction(errType, (item) => ({ isLoading: false, isLoaded: true, ...item }), metaCreator);
    const catchAction = (err, message) => (dispatch) => {
        dispatch(
            errorAction({
                error: err,
                message: message != null ? message : err.message != null ? err.message : '',
            })
        );
        dispatch(handleRequestError(err));
        throw err;
    };
    const resolve = (payload) => (dispatch) => {
        dispatch(actionAction(payload));
        dispatch(endAction());
    };

    return {
        action: actionAction,
        begin: beginAction,
        end: endAction,
        error: errorAction,
        catch: catchAction,
        resolve,
        stateRoot,
        type,
    };
}

export function createState(initialState) {
    return {
        ...initialState,
        error: { ...defaultError },
        isLoading: false,
        isLoaded: false,
    };
}

export function handleAction(type, reducer, initialState) {
    const types = !Array.isArray(type) ? [type] : type;
    const reducers = [];

    types.forEach((t) => {
        const { action, begin, end, stateRoot, error } = t;
        reducers.push(reduxHandleAction(action, reducer, initialState));
        reducers.push(
            reduxHandleAction(
                reduxCombineActions(begin, end, error),
                (state, action) => {
                    return updateState(state, stateRoot, { ...action.payload });
                },
                initialState
            )
        );
    });

    return reduxReduceReducers(...reducers);
}

function updateState(state, stateRoot, value) {
    const newState =
        stateRoot != null && stateRoot !== ''
            ? dotProp.set(state, `${stateRoot}`, {
                  ...dotProp.get(state, stateRoot),
                  ...value,
              })
            : {
                  ...state,
                  ...value,
              };

    return newState;
}
