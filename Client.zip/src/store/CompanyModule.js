import _debounce from 'lodash/debounce';

import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

import { resetCompanyGrids } from './GridDataModule';
import { getNoteAttachments } from './FileModule';

import { merge } from '../Utils/listHelper';
import { getLocalData, setLocalData } from '../Utils/localStorageHelper';

const initialState = {
    Selected: createState({
        Data: null,
    }),
    CompanyList: createState({
        Data: [],
    }),
    CommentsInfo: {
        PortfolioActions: [],
        Boxes: [],
        pageNumber: 0,
        canLoadMore: true,
    },
    CSRReports: createState({
        Data: [],
    }),
    Meetings: createState({
        Data: [],
    }),
    Portfolio: createState({
        Data: null,
    }),
    Survey: createState({
        Data: null,
    }),
};

//====> FSA ACTION CREATORS <====//
const fetch = createAction('COMPANY', 'Selected');
const find = createAction('COMPANY::FIND', 'CompanyList');
const portfolio = createAction('COMPANY::PORTFOLIO', 'Portfolio');
const reset = createAction('COMPANY::RESET');
const select = createAction('COMPANY::SELECT');
const survey = createAction('COMPANY::SURVEY', 'Survey');
const meetings = createAction('COMPANY::GET-MEETINGS', 'Meetings');
const csrreports = createAction('COMPANY::GET-CSR', 'CSRReports');

//----------------
const fetchNotes = createAction('NOTES');
const noteCommentInsert = createAction('NOTES-DATA::COMMENT::INSERT');
const noteLikeDelete = createAction('NOTES-DATA::LIKE::DELETE');
const noteLikeInsert = createAction('NOTES-DATA::LIKE::INSERT');
//----------------

let abortController;
const companySearch = _debounce(async (query, dispatch) => {
    if (abortController != null) {
        abortController.abort();
    }
    abortController = new AbortController();

    dispatch(find.begin());
    try {
        const response = await axios.get('/companies/search', {
            signal: abortController.signal,
            params: { query },
        });
        const data = response?.data;
        return dispatch(find.resolve(data));
    } catch (error) {
        return dispatch(find.catch(error));
    }
}, 250);

//====> ACTIONS <====//
export const getCompanyByID = (companyId) => async (dispatch) => {
    dispatch(fetch.begin());
    try {
        const { data } = await axios.get(`/companies/${companyId}/security`);
        dispatch(fetch.resolve(data));
    } catch (err) {
        dispatch(fetch.catch(err));
    }
};

export const getCompanyMeetings = (companyID, userID) => async (dispatch) => {
    dispatch(meetings.begin());
    if (companyID == null || userID == null) {
        dispatch(meetings.resolve([]));
    } else {
        try {
            const response = await axios.get(`/companies/${companyID}/meetings/${userID}`);
            dispatch(meetings.resolve(response.data));
        } catch (err) {
            dispatch(meetings.catch(err));
        }
    }
};

export const getCompanySurvey = (surveyID) => (dispatch) => {
    dispatch(survey.begin());

    return axios
        .get(`/companies/calendar_survey/${surveyID}`)
        .then((res) => dispatch(survey.resolve(res.data)))
        .catch((err) => dispatch(survey.catch(err)));
};

export const getCompanySearch = (criteria) => (dispatch) => companySearch(criteria, dispatch);

export const resetCompany = () => (dispatch) => {
    dispatch(resetCompanyGrids());
    dispatch(reset.action());
    return Promise.resolve();
};

export const saveCompanySurvey = (data) => (dispatch) => {
    dispatch(survey.begin());

    return axios
        .put(`/companies/calendar_survey/${data.SurveyID}`, data)
        .then((response) => response.data)
        .then((data) => dispatch(survey.resolve(data)))
        .catch((err) => dispatch(survey.catch(err)));
};

export const selectCompany = (company) => (dispatch) => {
    dispatch(select.begin());
    return dispatch(resetCompany()).then(() => dispatch(select.resolve(company)));
};

export const selectCompanyByID = (companyID) => (dispatch, getState) => {
    return dispatch(getCompanyByID(companyID)).then(() => {
        const Selected = getState().CompanyReducer.Selected.Data;
        return dispatch(selectCompany(Selected));
    });
};

//----------------
export const getCSRReports = (companyID) => (dispatch) => {
    dispatch(csrreports.begin());

    return axios
        .get(`/companies/${companyID}/reports/csr`)
        .then((res) => dispatch(csrreports.resolve(res.data)))
        .catch((err) => dispatch(csrreports.catch(err)));
};

export const getNotes = (companyID, startDate, endDate, noteTypeID, query, noteID, pageNumber, teamID) => (dispatch) => {
    if (pageNumber === 1) {
        dispatch(
            fetchNotes.resolve({
                pageNumber: 1,
                Comments: [],
                PortfolioActions: [],
            })
        );
    }

    return axios
        .get(`/notes`, {
            params: { companyID, startDate, endDate, noteTypeID, query, noteID, pageNumber, teamID },
        })
        .then((response) => {
            //console.log('GetNotes', response.data.Comments);
            const noteIds = response.data != null && response.data.Comments != null ? response.data.Comments.map((comment) => comment.NoteID) : [];
            dispatch(getNoteAttachments(noteIds));
            dispatch(fetchNotes.resolve({ pageNumber, ...response.data }));
        })
        .catch((err) => dispatch(fetchNotes.catch(err)));
};
export const deleteLike = (like) => (dispatch) => {
    return axios
        .delete(`/notes/${like.NoteID}/likes`, like)
        .then(() => dispatch(noteLikeDelete.resolve(like)))
        .catch((err) => dispatch(noteLikeDelete.catch(err)));
};
export const insertComment = (comment) => (dispatch) => {
    return axios
        .post(`/notes/${comment.NoteID}/comments`, {
            noteID: comment.NoteID,
            comment: comment.Comment,
        })
        .then(() => dispatch(noteCommentInsert.resolve(comment)))
        .catch((err) => dispatch(noteCommentInsert.catch(err)));
};
export const insertLike = (like) => (dispatch) => {
    return axios
        .post(`/notes/${like.NoteID}/likes`)
        .then(() => dispatch(noteLikeInsert.resolve(like)))
        .catch((err) => dispatch(noteLikeInsert.catch(err)));
};
//----------------

//====> REDUCERS <====//
const fetchCompanyReducer = handleAction(
    fetch,
    (state, action) => {
        return {
            ...state,
            Selected: {
                ...state.Selected,
                Data: action.payload,
            },
        };
    },
    initialState
);
const findCompanyReducer = handleAction(
    find,
    (state, action) => {
        return {
            ...state,
            CompanyList: {
                ...state.CompanyList,
                Data: action.payload,
            },
        };
    },
    initialState
);

const getCSRReportsReducer = handleAction(
    csrreports,
    (state, action) => {
        return {
            ...state,
            CSRReports: {
                ...state.CSRReports,
                Data: action.payload,
            },
        };
    },
    initialState
);

const getCompanyMeetingsReducer = handleAction(
    meetings,
    (state, action) => {
        return {
            ...state,
            Meetings: {
                ...state.Meetings,
                Data: action.payload,
            },
        };
    },
    initialState
);
const getCompanySurveyReducer = handleAction(
    survey,
    (state, action) => {
        return {
            ...state,
            Survey: {
                ...state.Survey,
                Data: action.payload,
            },
        };
    },
    initialState
);
const getPortfolioReducer = handleAction(
    portfolio,
    (state, action) => ({
        ...state,
        Portfolio: {
            ...state.Portfolio,
            Data: action.payload,
        },
    }),
    initialState
);
const resetCompanyReducer = handleAction(
    reset,
    (state, action) => ({
        ...state,
        Selected: { ...initialState.Selected },
        CompanyList: { ...initialState.CompanyList },
    }),
    initialState
);
const selectCompanyReducer = handleAction(
    select,
    (state, action) => {
        return {
            ...state,
            Selected: {
                ...state.Selected,
                Data: action.payload,
            },
        };
    },
    initialState
);

//----------------
const fetchNotesReducer = handleAction(
    fetchNotes,
    (state, action) => {
        const { payload } = action;
        const canLoadMore = payload.Comments.length > 0;
        const comments = payload.pageNumber === 1 ? payload.Comments : merge(state.CommentsInfo.Boxes, payload.Comments, (source, data) => source.NoteID === data.NoteID);
        const portfolioActions =
            payload.pageNumber === 1
                ? payload.PortfolioActions
                : merge(state.CommentsInfo.PortfolioActions, payload.PortfolioActions, (source, data) => source.NoteID === data.NoteID && source.ProductID === data.ProductID);

        return {
            ...state,
            CommentsInfo: {
                Boxes: comments,
                PortfolioActions: portfolioActions,
                pageNumber: payload.pageNumber,
                canLoadMore: canLoadMore,
            },
        };
    },
    initialState
);
const notesCommentInsertReducer = handleAction(
    noteCommentInsert,
    (state, action) => {
        const { payload } = action;
        const noteIdx = state.CommentsInfo.Boxes.findIndex((n) => n.NoteID === payload.NoteID);

        // Create a new note object based on the old note object, but inserting the new value.
        const newCommentNote = {
            ...state.CommentsInfo.Boxes[noteIdx],
            CommentInfoList: [payload, ...state.CommentsInfo.Boxes[noteIdx].CommentInfoList],
        };

        // I know, this structure looks weird.  But it's absolutely essential that we do *NOT* accidentially mutate
        // our application state.  This is why it is preferred to have flat state information with composed reducers
        // instead of deeply nested object graphs.  Look here for more details:
        // https://redux.js.org/recipes/structuringreducers/immutableupdatepatterns#updating-nested-objects
        return {
            ...state,
            CommentsInfo: {
                ...state.CommentsInfo,
                Boxes: [...state.CommentsInfo.Boxes.slice(0, noteIdx), newCommentNote, ...state.CommentsInfo.Boxes.slice(noteIdx + 1)],
            },
        };
    },
    initialState
);
const notesLikeDeleteReducer = handleAction(
    noteLikeDelete,
    (state, action) => {
        const { payload } = action;
        const noteIdx = state.CommentsInfo.Boxes.findIndex((n) => n.NoteID === payload.NoteID);
        const likeIdx =
            state.CommentsInfo.Boxes[noteIdx] != null && Array.isArray(state.CommentsInfo.Boxes[noteIdx].LikeInfoList)
                ? state.CommentsInfo.Boxes[noteIdx].LikeInfoList.findIndex((l) => l.NoteID === payload.NoteID && l.UserID === payload.UserID)
                : -1;

        if (likeIdx < 0) {
            return state;
        }

        const removedLikeNote = {
            ...state.CommentsInfo.Boxes[noteIdx],
            LikeInfoList: [...state.CommentsInfo.Boxes[noteIdx].LikeInfoList.slice(0, likeIdx), ...state.CommentsInfo.Boxes[noteIdx].LikeInfoList.slice(likeIdx + 1)],
        };

        // I know, this structure looks weird.  But it's absolutely essential that we do *NOT* accidentially mutate
        // our application state.  This is why it is preferred to have flat state information with composed reducers
        // instead of deeply nested object graphs.  Look here for more details:
        // https://redux.js.org/recipes/structuringreducers/immutableupdatepatterns#updating-nested-objects
        return {
            ...state,
            CommentsInfo: {
                ...state.CommentsInfo,
                Boxes: [...state.CommentsInfo.Boxes.slice(0, noteIdx), removedLikeNote, ...state.CommentsInfo.Boxes.slice(noteIdx + 1)],
            },
        };
    },
    initialState
);
const notesLikeInsertReducer = handleAction(
    noteLikeInsert,
    (state, action) => {
        const { payload } = action;
        const noteIdx = state.CommentsInfo.Boxes.findIndex((n) => n.NoteID === payload.NoteID);

        // Create a new note object based on the old note object, but inserting the new value.
        const newLikeNote = {
            ...state.CommentsInfo.Boxes[noteIdx],
            LikeInfoList: [payload, ...state.CommentsInfo.Boxes[noteIdx].LikeInfoList],
        };

        // I know, this structure looks weird.  But it's absolutely essential that we do *NOT* accidentially mutate
        // our application state.  This is why it is preferred to have flat state information with composed reducers
        // instead of deeply nested object graphs.  Look here for more details:
        // https://redux.js.org/recipes/structuringreducers/immutableupdatepatterns#updating-nested-objects
        return {
            ...state,
            CommentsInfo: {
                ...state.CommentsInfo,
                Boxes: [...state.CommentsInfo.Boxes.slice(0, noteIdx), newLikeNote, ...state.CommentsInfo.Boxes.slice(noteIdx + 1)],
            },
        };
    },
    initialState
);
//----------------

export default reduceReducers(
    fetchCompanyReducer,
    findCompanyReducer,
    getCSRReportsReducer,
    getCompanyMeetingsReducer,
    getCompanySurveyReducer,
    getPortfolioReducer,
    resetCompanyReducer,
    selectCompanyReducer,

    //----------------
    fetchNotesReducer,
    notesCommentInsertReducer,
    notesLikeDeleteReducer,
    notesLikeInsertReducer
    //----------------
);
