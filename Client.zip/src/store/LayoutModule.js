import { createAction, handleAction, reduceReducers } from './utilities';
import { getUrlParameter } from '../Utils/layoutHelper';

const initialState = {
    HeaderSettings: {
        Title: '',
        ShowSecurityInfo: false,
    },
    Console: {
        log: [],
    },
};

//====> FSA ACTION CREATORS <====//
const setTitleAction = createAction('LAYOUT::SET_TITLE');
const consoleLogAction = createAction('LAYOUT::CONSOLE_LOG');

//====> ACTIONS <====//
export const setHeaderSettings = (settings) => (dispatch) => {
    dispatch(setTitleAction.action(settings));
    return Promise.resolve();
};

export const consoleLog = (message) => (dispatch) => {
    if (getUrlParameter('console') === 'true') {
        dispatch(consoleLogAction.action(message));
    }
    return Promise.resolve();
};

//====> REDUCERS <====//
const consoleLogReducer = handleAction(
    consoleLogAction,
    (state, action) => ({
        ...state,
        Console: {
            ...state.Console,
            log: [...state.Console.log, `${JSON.stringify(action.payload, null, 4)}`],
        },
    }),
    initialState
);

const headerSettingsReducer = handleAction(
    setTitleAction,
    (state, action) => ({
        ...state,
        HeaderSettings: action.payload,
    }),
    initialState
);

export default reduceReducers(consoleLogReducer, headerSettingsReducer);
