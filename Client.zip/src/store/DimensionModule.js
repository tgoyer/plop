import _debounce from 'lodash/debounce';

import axios from 'axios';
import { createAction, createState, handleAction, reduceReducers } from './utilities';

const initialState = createState({
    BMSearch: createState({
        Data: [],
    }),
    Consensus: null,
    Countries: createState({
        Data: [],
    }),
    DefaultTeam: null,
    DocumentSources: null,
    Effects: null,
    EscalationPaths: [],
    ActionTypes: [],
    GICSSectors: null,
    KeyIssues: {
        all: [],
        ab: {},
        msci: {},
    },
    OtherDocumentTypes: null,
    PortfolioActions: null,
    PortfolioProducts: null,
    PowerBIUrls: createState({
        Data: [],
    }),
    Products: null,
    ProductSearch: createState({
        Data: [],
    }),
    Publishers: createState({
        Data: [],
    }),
    SectorGuides: createState({
        Data: [],
    }),
    TeamRatings: null,
    Ratings: null,
    Regions: null,
    Teams: null,
    UserTeams: null,
    WatchlistAnalysts: null,
    WatchlistIndustries: null,
    WatchlistProducts: null,
    WatchlistSectors: null,
    WatchlistSubindustries: null,
    WatchlistTeams: null,
});

let abortController;
const benchmarkSearch = _debounce((criteria, dispatch) => {
    if (abortController != null) {
        abortController.abort();
    }
    abortController = new AbortController();

    const url = `/dimensions/searchbenchmarks?criteria=${criteria}`;
    const promise =
        url == null
            ? Promise.resolve([])
            : axios
                  .get(url, {
                      signal: abortController.signal,
                  })
                  .then((response) => response.data);

    return promise
        .then((data) => dispatch(searchBenchmarkAction.resolve(data)))
        .catch((err) => {
            dispatch(searchBenchmarkAction.resolve(initialState.BMSearch));
            dispatch(searchBenchmarkAction.catch(err));
        });
}, 250);

const abortControllerPS = new AbortController();
const debouncedProductSearch = _debounce((criteria, dispatch) => {
    abortControllerPS.abort();
    const url = `/dimensions/searchproducts?criteria=${criteria}`;

    const promise =
        url == null
            ? Promise.resolve([])
            : axios
                  .get(url, {
                      signal: abortControllerPS.signal,
                  })
                  .then((response) => response.data);

    return promise
        .then((data) => dispatch(searchProductAction.resolve(data)))
        .catch((err) => {
            dispatch(searchProductAction.resolve(initialState.ProductSearch));
            dispatch(searchProductAction.catch(err));
        });
}, 250);

//====> FSA ACTION CREATORS <====//
const fetchAnalysts = createAction('DIMENSIONS::ANALYSTS');
const fetchAnalystsForWatchlist = createAction('DIMENSIONS::ANALYSTS-FOR-WATCHLIST');
const fetchConsensus = createAction('DIMENSIONS::CONSENSUS');
const fetchCountries = createAction('DIMENSIONS::COUNTRIES', 'Countries');
const fetchDocumentSources = createAction('DIMENSIONS::DOCUMENT_SOURCES');
const fetchEffects = createAction('DIMENSIONS::EFFECTS');
const fetchEscalationPaths = createAction('DIMENSIONS::ESCALATION-PATHS');
const fetchActionTypes = createAction('DIMENSIONS::ACTION-TYPES');
const fetchGICSSectors = createAction('DIMENSIONS::GICS_SECTORS');
const fetchIndustriesForWatchlist = createAction('DIMENSIONS::INDUSTRIES-FOR-WATCHLIST');
const fetchKeyIssues = createAction('DIMENSIONS::KEY_ISSUES');
const fetchOtherDocumentTypes = createAction('DIMENSIONS::OTHER_DOCUMENT_TYPES');
const fetchPortfolioActions = createAction('DIMENSIONS::PORTFOLIO_ACTIONS');
const fetchPortfolioProducts = createAction('DIMENSIONS::PORTFOLIO_PRODUCTS');
const fetchPowerBIURLsAction = createAction('DIMENSIONS::POWERBI-URLS', 'PowerBIUrls');
const fetchPublishers = createAction('DIMENSIONS::PUBLISHERS', 'Publishers');
const fetchSectorsForWatchlist = createAction('DIMENSIONS::SECTORS-FOR-WATCHLIST');
const fetchSubindustriesForWatchlist = createAction('DIMENSIONS::SUB-INDUSTRIES-FOR-WATCHLIST');
const fetchTeamRatings = createAction('DIMENSIONS::TEAM_RATINGS');
const fetchRatings = createAction('DIMENSIONS::RATINGS');
const fetchRegions = createAction('DIMENSIONS::REGIONS');
const fetchSectorGuides = createAction('DIMENSIONS::SECTOR_GUIDES');
const createSectorGuideAction = createAction('DIMENSIONS::CREATE-SECTOR_GUIDES');
const deleteSectorGuideAction = createAction('DIMENSIONS::DELETE-SECTOR_GUIDES');
const fetchTeams = createAction('DIMENSIONS::TEAMS');
const fetchTeamsForWatchlist = createAction('DIMENSIONS::TEAMS-FOR-WATCHLIST');
const fetchUserTeams = createAction('DIMENSIONS::USER_TEAMS');
const searchBenchmarkAction = createAction('DIMENSIONS::SEARCH-BENCHMARKS', 'BMSearch');
const searchProductAction = createAction('DIMENSIONS::SEARCH-PRODUCTS', 'ProductSearch');

//====> ACTIONS <====//
export const getActionTypes = () => async (dispatch) => {
    dispatch(fetchActionTypes.begin());
    try {
        const { data } = await axios.get('/dimensions/action_types');
        dispatch(fetchActionTypes.resolve(data));
    } catch (err) {
        dispatch(fetchActionTypes.catch(err));
    }
};
export const getAnalysts = () => async (dispatch) => {
    dispatch(fetchAnalysts.begin());
    try {
        const { data } = await axios.get('/dimensions/analysts');
        dispatch(fetchAnalysts.resolve(data));
    } catch (err) {
        dispatch(fetchAnalysts.catch(err));
    }
};
export const getAnalystsForWatchlist = (userID) => async (dispatch) => {
    dispatch(fetchAnalystsForWatchlist.begin());
    try {
        const { data } = await axios.get('/dimensions/analystsforwatchlist', {
            params: { userID: userID },
        });
        dispatch(fetchAnalystsForWatchlist.resolve(data));
    } catch (err) {
        dispatch(fetchAnalystsForWatchlist.catch(err));
    }
};
export const getConsensus = () => async (dispatch) => {
    dispatch(fetchConsensus.begin());
    try {
        const { data } = await axios.get('/dimensions/consensus');
        dispatch(fetchConsensus.resolve(data));
    } catch (err) {
        dispatch(fetchConsensus.catch(err));
    }
};
export const getCountries = () => async (dispatch) => {
    dispatch(fetchCountries.begin());
    try {
        const { data } = await axios.get('/dimensions/countries');
        dispatch(fetchCountries.resolve(data));
    } catch (err) {
        dispatch(fetchCountries.catch(err));
    }
};
export const getDocumentSources = () => async (dispatch) => {
    dispatch(fetchDocumentSources.begin());
    try {
        const { data } = await axios.get('/dimensions/document_sources');
        dispatch(fetchDocumentSources.resolve(data));
    } catch (err) {
        dispatch(fetchDocumentSources.catch(err));
    }
};
export const getEffects = () => async (dispatch) => {
    dispatch(fetchEffects.begin());
    try {
        const { data } = await axios.get('/dimensions/effects');
        dispatch(fetchEffects.resolve(data));
    } catch (err) {
        dispatch(fetchEffects.catch(err));
    }
};
export const getEscalationPaths = () => async (dispatch) => {
    dispatch(fetchEscalationPaths.begin());
    try {
        const { data } = await axios.get('/dimensions/escalation_paths');
        dispatch(fetchEscalationPaths.resolve(data));
    } catch (err) {
        dispatch(fetchEscalationPaths.catch(err));
    }
};
export const getGICSSectors = () => async (dispatch) => {
    dispatch(fetchGICSSectors.begin());
    try {
        const { data } = await axios.get('/dimensions/gics_sectors');
        dispatch(fetchGICSSectors.resolve(data));
    } catch (err) {
        dispatch(fetchGICSSectors.catch(err));
    }
};
export const getIndustriesForWatchlist = (sectorsJson, userID) => async (dispatch) => {
    dispatch(fetchIndustriesForWatchlist.begin());
    try {
        const { data } = await axios.get('/dimensions/industriesforwatchlist', {
            params: {
                sectorIDJson: sectorsJson,
                userID: userID,
            },
        });
        dispatch(fetchIndustriesForWatchlist.resolve(data));
    } catch (err) {
        dispatch(fetchIndustriesForWatchlist.catch(err));
    }
};
export const getKeyIssues = () => async (dispatch) => {
    dispatch(fetchKeyIssues.begin());
    try {
        const { data } = await axios.get('/dimensions/key_issues');
        dispatch(fetchKeyIssues.resolve(data));
    } catch (err) {
        dispatch(fetchKeyIssues.catch(err));
    }
};
export const getOtherDocumentTypes = () => async (dispatch) => {
    dispatch(fetchOtherDocumentTypes.begin());
    try {
        const { data } = await axios.get('/dimensions/other_document_types');
        dispatch(fetchOtherDocumentTypes.resolve(data));
    } catch (err) {
        dispatch(fetchOtherDocumentTypes.catch(err));
    }
};
export const getPortfolioActions = () => async (dispatch) => {
    dispatch(fetchPortfolioActions.begin());
    try {
        const { data } = await axios.get('/dimensions/portfolio_actions');
        dispatch(fetchPortfolioActions.resolve(data));
    } catch (err) {
        dispatch(fetchPortfolioActions.catch(err));
    }
};
export const getPortfolioProducts = (TeamID) => async (dispatch) => {
    dispatch(fetchPortfolioProducts.begin());
    try {
        const { data } = await axios.get('/dimensions/portfolio_products', {
            params: {
                TeamID,
            },
        });
        dispatch(fetchPortfolioProducts.resolve(data));
    } catch (err) {
        dispatch(fetchPortfolioProducts.catch(err));
    }
};
export const getPowerBIURLs = () => async (dispatch) => {
    dispatch(fetchPowerBIURLsAction.begin());
    try {
        const { data } = await axios.get('/dimensions/powerbiurls');
        dispatch(fetchPowerBIURLsAction.resolve(data));
    } catch (err) {
        dispatch(fetchPowerBIURLsAction.catch(err));
    }
};
export const getPublishers = () => async (dispatch) => {
    dispatch(fetchPublishers.begin());
    try {
        const { data } = await axios.get('/dimensions/publishers');
        dispatch(fetchPublishers.resolve(data));
    } catch (err) {
        dispatch(fetchPublishers.catch(err));
    }
};
export const getRatings = () => async (dispatch) => {
    dispatch(fetchRatings.begin());
    try {
        const { data } = await axios.get('/dimensions/ratings');
        dispatch(fetchRatings.resolve(data));
    } catch (err) {
        dispatch(fetchRatings.catch(err));
    }
};
export const getRegions = () => async (dispatch) => {
    dispatch(fetchRegions.begin());
    try {
        const { data } = await axios.get('/dimensions/regions');
        dispatch(fetchRegions.resolve(data));
    } catch (err) {
        dispatch(fetchRegions.catch(err));
    }
};
export const getSectorGuides = () => async (dispatch) => {
    dispatch(fetchSectorGuides.begin());
    try {
        const { data } = await axios.get('/dimensions/sector_guides');
        dispatch(fetchSectorGuides.resolve(data));
    } catch (err) {
        dispatch(fetchSectorGuides.catch(err));
    }
};
export const getSectorsForWatchlist = (userID) => async (dispatch) => {
    dispatch(fetchSectorsForWatchlist.begin());
    try {
        const { data } = await axios.get('/dimensions/sectorsforwatchlist', {
            params: { userID: userID },
        });
        dispatch(fetchSectorsForWatchlist.resolve(data));
    } catch (err) {
        dispatch(fetchSectorsForWatchlist.catch(err));
    }
};
export const getSubindustriesForWatchlist = (industriesJson, sectorsJson, userID) => async (dispatch) => {
    dispatch(fetchSubindustriesForWatchlist.begin());
    try {
        const { data } = await axios.get('/dimensions/subindustriesforwatchlist', {
            params: { industryIDJson: industriesJson, sectorIDJson: sectorsJson, userID: userID },
        });
        dispatch(fetchSubindustriesForWatchlist.resolve(data));
    } catch (err) {
        dispatch(fetchSubindustriesForWatchlist.catch(err));
    }
};
export const getTeamRatings = (TeamID) => async (dispatch) => {
    dispatch(fetchTeamRatings.begin());
    try {
        const { data } = await axios.get('/dimensions/team_ratings', {
            params: { TeamID },
        });
        dispatch(fetchTeamRatings.resolve(data));
    } catch (err) {
        dispatch(fetchTeamRatings.catch(err));
    }
};
export const getTeams = () => async (dispatch) => {
    dispatch(fetchTeams.begin());
    try {
        const { data } = await axios.get('/dimensions/teams');
        dispatch(fetchTeams.resolve(data));
    } catch (err) {
        dispatch(fetchTeams.catch(err));
    }
};
export const getTeamsForWatchlist = (userID) => async (dispatch) => {
    dispatch(fetchTeamsForWatchlist.begin());
    try {
        const { data } = await axios.get('/dimensions/teamsforwatchlist', {
            params: { userID: userID },
        });
        dispatch(fetchTeamsForWatchlist.resolve(data));
    } catch (err) {
        dispatch(fetchTeamsForWatchlist.catch(err));
    }
};
export const getUserTeams = (userID, noteID) => async (dispatch) => {
    dispatch(fetchUserTeams.begin());
    try {
        const { data } = await axios.get('/dimensions/teams', {
            params: {
                userID,
                noteID,
            },
        });
        dispatch(fetchUserTeams.resolve(data));
    } catch (err) {
        dispatch(fetchUserTeams.catch(err));
    }
};
export const createSectorGuide = (guide) => async (dispatch) => {
    dispatch(createSectorGuideAction.begin());
    try {
        const { data } = await axios.post('/content/guide', guide);
        dispatch(createSectorGuideAction.resolve(data));
    } catch (err) {
        dispatch(createSectorGuideAction.catch(err));
    }
};
export const deleteSectorGuide = (id) => async (dispatch) => {
    dispatch(deleteSectorGuideAction.begin());
    try {
        const { data } = await axios.delete(`/content/guide/${id}`);
        dispatch(deleteSectorGuideAction.resolve(data));
    } catch (err) {
        dispatch(deleteSectorGuideAction.catch(err));
    }
};
export const searchBenchmarks = (criteria) => (dispatch) => {
    criteria = encodeURIComponent(criteria);
    dispatch(searchBenchmarkAction.begin());
    return benchmarkSearch(criteria, dispatch);
};
export const searchProducts = (criteria) => (dispatch) => {
    criteria = encodeURIComponent(criteria);
    dispatch(searchProductAction.begin());
    return debouncedProductSearch(criteria, dispatch);
};

//====> REDUCERS <====//
const searchBenchmarkReducer = handleAction(
    searchBenchmarkAction,
    (state, { payload }) => ({
        ...state,
        BMSearch: {
            ...state.BMSearch,
            Data: payload,
        },
    }),
    initialState
);
const searchProductReducer = handleAction(
    searchProductAction,
    (state, { payload }) => ({
        ...state,
        ProductSearch: {
            ...state.ProductSearch,
            Data: payload,
        },
    }),
    initialState
);
const fetchAnalystsReducer = handleAction(
    fetchAnalysts,
    (state, action) => ({
        ...state,
        Analysts: action.payload,
    }),
    initialState
);
const fetchConsensusReducer = handleAction(
    fetchConsensus,
    (state, action) => ({
        ...state,
        Consensus: action.payload,
    }),
    initialState
);
const fetchCountriesReducer = handleAction(
    fetchCountries,
    (state, action) => ({
        ...state,
        Countries: {
            ...state.Countries,
            Data: action.payload,
        },
    }),
    initialState
);
const fetchDocumentSourcesReducer = handleAction(
    fetchDocumentSources,
    (state, action) => ({
        ...state,
        DocumentSources: action.payload,
    }),
    initialState
);
const fetchEffectsReducer = handleAction(
    fetchEffects,
    (state, action) => ({
        ...state,
        Effects: action.payload,
    }),
    initialState
);
const fetchEscalationPathsReducer = handleAction(
    fetchEscalationPaths,
    (state, action) => ({
        ...state,
        EscalationPaths: action.payload,
    }),
    initialState
);
const fetchActionTypesReducer = handleAction(
    fetchActionTypes,
    (state, action) => ({
        ...state,
        ActionTypes: action.payload,
    }),
    initialState
);
const fetchGICSSectorsReducer = handleAction(
    fetchGICSSectors,
    (state, action) => ({
        ...state,
        GICSSectors: action.payload,
    }),
    initialState
);
const fetchKeyIssuesReducer = handleAction(
    fetchKeyIssues,
    (state, action) => ({
        ...state,
        KeyIssues: action.payload.reduce((agg, ki) => {
            const all = 'all';
            const source = ki.SourceName.toLowerCase();
            const pillar = ki.PillarName.toLowerCase();

            if (agg[all] == null) agg[all] = [];
            if (agg[source] == null) agg[source] = {};
            if (agg[source][pillar] == null) agg[source][pillar] = [];
            if (agg[source][all] == null) agg[source][all] = [];

            agg[all].push(ki);
            agg[source][all].push(ki);
            agg[source][pillar].push(ki);

            return agg;
        }, {}),
    }),
    initialState
);
const fetchOtherDocumentTypesReducer = handleAction(
    fetchOtherDocumentTypes,
    (state, action) => ({
        ...state,
        OtherDocumentTypes: action.payload,
    }),
    initialState
);
const fetchPortfolioActionsReducer = handleAction(
    fetchPortfolioActions,
    (state, action) => ({
        ...state,
        PortfolioActions: action.payload,
    }),
    initialState
);
const fetchPublishersReducer = handleAction(
    fetchPublishers,
    (state, action) => ({
        ...state,
        Publishers: {
            ...state.Publishers,
            Data: action.payload,
        },
    }),
    initialState
);
const fetchPortfolioProductsReducer = handleAction(
    fetchPortfolioProducts,
    (state, action) => ({
        ...state,
        PortfolioProducts: action.payload,
    }),
    initialState
);
const fetchRegionsReducer = handleAction(
    fetchRegions,
    (state, action) => ({
        ...state,
        Regions: action.payload,
    }),
    initialState
);
const fetchRatingsReducer = handleAction(
    fetchRatings,
    (state, action) => ({
        ...state,
        Ratings: action.payload,
    }),
    initialState
);
const fetchSectorGuidesReducer = handleAction(
    fetchSectorGuides,
    (state, action) => ({
        ...state,
        SectorGuides: {
            ...state.SectorGuides,
            Data: action.payload,
        },
    }),
    initialState
);
const createSectorGuidesReducer = handleAction(
    createSectorGuideAction,
    (state, action) => ({
        ...state,
        SectorGuides: {
            ...state.SectorGuides,
            Data: [...state.SectorGuides.Data, ...[action.payload]],
        },
    }),
    initialState
);
const deleteSectorGuideReducer = handleAction(
    deleteSectorGuideAction,
    (state, action) => ({
        ...state,
        SectorGuides: {
            ...state.SectorGuides,
            Data: state.SectorGuides.Data.filter((sg) => sg.SectorGuideID !== action.payload),
        },
    }),
    initialState
);
const fetchTeamRatingsReducer = handleAction(
    fetchTeamRatings,
    (state, action) => ({
        ...state,
        TeamRatings: action.payload,
    }),
    initialState
);
const fetchTeamsReducer = handleAction(
    fetchTeams,
    (state, action) => ({
        ...state,
        Teams: action.payload,
    }),
    initialState
);
const fetchUserTeamsReducer = handleAction(
    fetchUserTeams,
    (state, action) => {
        const { payload } = action;
        const foundItem = payload.find((item) => item.IsDefault === true);
        const defaultItem = foundItem != null ? foundItem : payload != null && payload.length > 0 ? payload[0] : null;

        return {
            ...state,
            UserTeams: payload,
            DefaultTeam: defaultItem,
            Error: null,
        };
    },
    initialState
);
const fetchAnalystsForWatchlistReducer = handleAction(
    fetchAnalystsForWatchlist,
    (state, action) => ({
        ...state,
        WatchlistAnalysts: action.payload,
    }),
    initialState
);
const fetchTeamsForWatchlistReducer = handleAction(
    fetchTeamsForWatchlist,
    (state, action) => ({
        ...state,
        WatchlistTeams: action.payload,
    }),
    initialState
);
const fetchSectorsForWatchlistReducer = handleAction(
    fetchSectorsForWatchlist,
    (state, action) => ({
        ...state,
        WatchlistSectors: action.payload,
    }),
    initialState
);
const fetchIndustriesForWatchlistReducer = handleAction(
    fetchIndustriesForWatchlist,
    (state, action) => ({
        ...state,
        WatchlistIndustries: action.payload,
    }),
    initialState
);
const fetchSubindustriesForWatchlistReducer = handleAction(
    fetchSubindustriesForWatchlist,
    (state, action) => ({
        ...state,
        WatchlistSubindustries: action.payload,
    }),
    initialState
);
const fetchPowerBIUrlsReducer = handleAction(
    fetchPowerBIURLsAction,
    (state, action) => ({
        ...state,
        PowerBIUrls: {
            ...state.PowerBIUrls,
            Data: action.payload,
        },
    }),
    initialState
);

export default reduceReducers(
    fetchAnalystsReducer,
    fetchConsensusReducer,
    fetchCountriesReducer,
    fetchDocumentSourcesReducer,
    fetchEffectsReducer,
    fetchEscalationPathsReducer,
    fetchActionTypesReducer,
    fetchGICSSectorsReducer,
    fetchKeyIssuesReducer,
    fetchOtherDocumentTypesReducer,
    fetchPortfolioActionsReducer,
    fetchPortfolioProductsReducer,
    fetchPowerBIUrlsReducer,
    fetchPublishersReducer,
    fetchRatingsReducer,
    fetchRegionsReducer,
    fetchTeamRatingsReducer,
    fetchTeamsReducer,
    fetchUserTeamsReducer,
    fetchAnalystsForWatchlistReducer,
    fetchTeamsForWatchlistReducer,
    fetchSectorGuidesReducer,
    createSectorGuidesReducer,
    deleteSectorGuideReducer,
    fetchSectorsForWatchlistReducer,
    fetchIndustriesForWatchlistReducer,
    fetchSubindustriesForWatchlistReducer,
    searchBenchmarkReducer,
    searchProductReducer
);
