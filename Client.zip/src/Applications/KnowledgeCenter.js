import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import HomeTab from './KnowledgeCenter/HomeTab';
import PowerBITab from './KnowledgeCenter/PowerBITab';
import SearchTab from './KnowledgeCenter/SearchTab';
import { Tab, TabSubHeader } from '../Layout/Header';
import UploadTab from './KnowledgeCenter/UploadTab';

import { setKnowledgeCenterSettings } from '../store/AppSettingsModule';

const initialTab = 0;
const KnowledgeCenter = () => {
    const dispatch = useDispatch();
    const permissions = useSelector((state) => state.UserReducer.UserInfo.Data.Permissions);
    const settings = useSelector((state) => state.AppSettingsReducer.KnowledgeCenter);
    const [tabIndex, setTabIndex] = React.useState(initialTab);

    const setKnowledgeCenterSettingsDispatcher = React.useCallback(
        (setting) => {
            dispatch(setKnowledgeCenterSettings(setting));
        },
        [dispatch]
    );

    const handleTabChange = (tabIndex) => {
        setTabIndex(tabIndex);
        setKnowledgeCenterSettingsDispatcher({ ActiveHeaderTab: tabIndex });
    };

    React.useEffect(() => {
        const tab = settings.ActiveHeaderTab != null ? settings.ActiveHeaderTab : initialTab;
        setTabIndex(tab);
    }, [dispatch,settings.ActiveHeaderTab]);

    const canUpload = permissions.CanWrite || permissions.CanAdmin;

    return (
        <React.Fragment>
            <TabSubHeader onTabChange={handleTabChange} activeTab={tabIndex}>
                <Tab label="Dashboard" />
                <Tab label="Search for Files" />
                <Tab label="Upload a File" disabled={!canUpload} />
                <Tab label="Power BI Reports" />
            </TabSubHeader>
            {tabIndex === 0 && <HomeTab />} {/* Should this change? Task 1602 */}
            {tabIndex === 1 && <SearchTab />}
            {tabIndex === 2 && canUpload && <UploadTab showResultPane={true} title={"Add Files to the Knowledge Center"} />}
            {tabIndex === 3 && <PowerBITab />}
        </React.Fragment>
    );
};

export default KnowledgeCenter;
