import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import _get from 'lodash/get';
import _groupBy from 'lodash/groupBy';

import Checkbox from '@material-ui/core/Checkbox';
import Collapse from '@material-ui/core/Collapse';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import { withStyles } from '@material-ui/core/styles';

import { Button, ButtonTypes } from '../../../components/Form';
import { Popover, DialogSizes } from '../../../components/Dialogs';
import Tooltip from '../../../UIComponents/Tooltip';

import AdminActions from '../HomeTab/AdminActions';
import FileInfoIcon from '../HomeTab/FileInfoIcon';
import SnippetList from './SnippetList';

import { setKnowledgeCenterSettings } from '../../../store/AppSettingsModule';

import { formatDate, toLocalDateTime } from '../../../Utils/dateHelper';

import { getFileTerms, subdomains } from '../utilities';
import { saveFavoriteFile, deleteFavoriteFile } from '../../../store/FileModule';
import Downloader from 'componentlibrary/file/Downloader';

const styles = (theme) => ({
    actions: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignSelf: 'flex-end',
        '& i': {
            backgroundColor: 'transparent',
            borderRadius: '50%',
            fontSize: 18,
            padding: 4,
            position: 'relative',
            marginRight: 4,
            transition: 'background-color 250ms ease-in',
            overflow: 'hidden',
            '&:after': {
                content: '""',
                background: '#ffffff',
                display: 'block',
                position: 'absolute',
                paddingTop: '300%',
                paddingLeft: '350%',
                marginLeft: '-20px !important',
                marginTop: '-120%',
                opacity: 0,
                transition: 'all 0.8s',
            },
            '&:hover': {
                backgroundColor: 'rgba(0, 0, 0, .15)',
            },
            '&:active:after': {
                padding: 0,
                margin: 0,
                opacity: 1,
                transition: '0s',
            },
        },
    },
    centerVert: {
        display: 'inline-flex',
        alignItems: 'center',
    },
    highlight: {
        border: '#faea38',
        backgroundColor: '#faea38',
    },
    fileListContainer: {
        display: 'none',
    },
    fileListContainerShow: {
        display: 'block',
    },
    fileListTitle: {
        alignItems: 'center',
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        cursor: 'pointer',
        display: 'flex',
        fontSize: 16,
        fontWeight: 700,
        height: 40,
        padding: 5,
        margin: 0,
        '& i': {
            fontSize: 12,
            paddingRight: 4,
        },
    },
    fileListTitleLabel: {
        flexGrow: 0,
        flexShrink: 0,
        flexBasis: '50%',
    },
    fileListTitleResults: {
        fontSize: 10,
        fontStyle: 'italic',
        flexGrow: 0,
        flexShrink: 0,
        flexBasis: '50%',
        textAlign: 'right',
    },
    fileMetaData: {
        display: 'inline',
        flexWrap: 'nowrap',
        whiteSpace: 'nowrap',
        '& span': {
            fontSize: 10,
            padding: '0 8px',
            borderRight: '1px solid #000000',
            '&:last-child': {
                borderRight: 'none',
            },
        },
        '& .author': {
            fontStyle: 'italic',
        },
        '& .date': {
            fontWeight: 700,
        },
        '& .team': {
            fontStyle: 'italic',
        },
    },
    fileName: {
        alignItems: 'center',
        display: 'inline-flex',
        fontWeight: 700,
        minWidth: 100,
        '& i': {
            marginRight: 4,
            padding: '0 4px',
        },
    },
    fileNameContainer: {
        display: 'flex',
        justifyContent: 'inherit',
        flexWrap: 'wrap',
        paddingRight: 8,
        '&.previewer div:nth-child(1)': {
            order: 1,
            maxWidth: 175,
            overflow: 'hidden',
        },
        '&.previewer div:nth-child(2)': {
            order: 3,
        },
        '&.previewer div:nth-child(3)': {
            order: 2,
        },
    },
    fileNameText: {
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
    },
    fileSubContainer: {
        backgroundColor: '#f2f2f2',
        display: 'flex',
        flexDirection: 'column',
        fontSize: 11,
        width: '100%',
        padding: '8px 8px 0px 8px',
        '& .categories': {
            fontStyle: 'italic',
            paddingBottom: 8,
            '& span': {
                fontStyle: 'initial',
            },
            '& .title': {
                fontWeight: 700,
            },
            '& .categoryList span': {
                '&:after': {
                    content: '", "',
                },
                '&:last-child:after': {
                    content: '""',
                },
            },
        },
        '& .synopsis': {
            margin: '0 0 8px',
            '& p': {
                margin: '0 0 8px',
                paddingLeft: 16,
                '&:last-child': {
                    margin: 0,
                },
            },
            '& span': {
                fontWeight: 700,
            },
        },
    },
    fileTypeIcon: {
        fontSize: '14px !important',
        width: 24,
    },
    foundSearchTerm: {
        fontWeight: 700,
    },
    headerText: {
        fontSize: 16,
        fontWeight: 700,
    },
    listItem: {
        display: 'flex',
        flexDirection: 'column',
        cursor: 'pointer',
        padding: '4px 8px 8px 8px',
    },
    listItemContainer: {
        '&:hover': {
            '& .snippetContainer:hover': {
                backgroundColor: '#f2f2f2',
                borderColor: '#e6e6e6',
            },
        },
    },
    listItemHeader: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        padding: 4,
        width: '100%',
        borderRadius: '8px 8px 0 0',
        backgroundColor: '#dce3ef',
    },
    terms: {
        display: 'inline',
        margin: '0 10px',
        fontSize: 10,
        fontStyle: 'italic',
        textAlign: 'right',
    },
    yellow: {
        color: '#f08f50',
    },
});

const idIsInList = (id, list) => {
    return (
        Array.isArray(list) &&
        list.reduce((acc, item) => {
            return acc || item.id === id;
        }, false)
    );
};

const mapCategoryValues = (classes, type, fileList, searchList, dimensions, idAccessor, fieldAccessor) => {
    return Array.isArray(fileList)
        ? fileList.map((value) => {
              if (value == null) return null;

              const dataItem = dimensions.find((item) => idAccessor(item) === idAccessor(value));
              const id = dataItem == null ? null : idAccessor(value);
              return dataItem == null ? null : (
                  <span key={type + '_' + id} className={cn({ [classes.foundSearchTerm]: idIsInList(id, _get(searchList, 'include', [])) })}>
                      {fieldAccessor(dataItem)}
                  </span>
              );
          })
        : [];
};

const FileList = ({ classes, files, data, selected, showDocument, onTabChange }) => {
    const dispatch = useDispatch();

    const settings = useSelector((state) => state.AppSettingsReducer.KnowledgeCenter);
    const analystDimensions = useSelector((state) => state.DimensionReducer.Analysts);
    const countryDimensions = useSelector((state) => state.DimensionReducer.Countries.Data);
    const keyIssueDimensions = useSelector((state) => state.DimensionReducer.KeyIssues.all);
    const gicsDimensions = useSelector((state) => state.DimensionReducer.GICSSectors);
    const regionDimensions = useSelector((state) => state.DimensionReducer.Regions);
    const snippetId = useSelector((state) => state.AppSettingsReducer.KnowledgeCenter.ActiveSnippetIndex);

    const favoriteFiles = useSelector((state) => state.FileReducer.FavoriteFiles.Data);

    const [selectedFiles, setSelectedFiles] = React.useState(selected || []);
    const [showCategoryList, setShowCategoryList] = React.useState({});
    const [showSellSideWarning, setShowSellSideWarning] = React.useState(false);
    const [ssWarnHide, setSSWarnHide] = React.useState(false);

    const setKnowledgeCenterSettingsDispatcher = React.useCallback(
        (setting) => {
            dispatch(setKnowledgeCenterSettings(setting));
        },
        [dispatch]
    );

    const deleteFavorite = React.useCallback(
        (fileId) => {
            dispatch(deleteFavoriteFile(fileId));
        },
        [dispatch]
    );

    const saveFavorite = React.useCallback(
        (fileId) => {
            dispatch(saveFavoriteFile(fileId));
        },
        [dispatch]
    );

    const handleFavoriteFile = (id, isFavorite) => (evt) => {
        evt.preventDefault();
        evt.stopPropagation();

        if (isFavorite) {
            deleteFavorite(id);
        } else {
            saveFavorite(id);
        }
    };

    const handleFileClick = (id) => (evt) => {
        evt.preventDefault();
        evt.stopPropagation();

        const files = isSelectedFile(id) ? selectedFiles.filter((file) => file !== id) : [...selectedFiles, id];

        setSelectedFiles(files);

        setKnowledgeCenterSettingsDispatcher({
            ...settings,
            ExpandedFile: null,
        });
    };

    const handleSSWarnHideChecked = () => {
        setSSWarnHide(!ssWarnHide);
    };

    const handleSellSideWarningClose = () => {
        setShowSellSideWarning(false);
    };

    const handleSellSideWarningConfirm = () => {
        setShowSellSideWarning(false);
        setCategoryList('Sell Side');
        setKnowledgeCenterSettingsDispatcher({ disableSellSideWarning: ssWarnHide });
    };

    const handleTagCategoryClick = (key) => (evt) => {
        const show = showCategoryList[key] == null ? true : !showCategoryList[key];
        const clickedCollapsedSellSide = key === 'Sell Side' && show === true;
        const warningDisabled = _get(settings, 'disableSellSideWarning', false);

        if (clickedCollapsedSellSide && !warningDisabled) {
            setShowSellSideWarning(true);
        } else {
            setCategoryList(key);
        }
    };

    const getAnalystName = (analystId) => {
        const analyst = analystDimensions.find((analyst) => analyst.UserID === analystId);
        return analyst != null ? analyst.FullName : '--';
    };

    const getCategoriesList = (fileExternals) => {
        const { GICSSectors, KeyIssues, Countries, Regions } = fileExternals;
        const { gicsSectors, keyIssues, countries, regions } = _get(data, 'categories', {});

        return [
            ...mapCategoryValues(
                classes,
                'countries',
                Countries,
                countries,
                countryDimensions,
                (item) => item,
                (item) => item
            ),
            ...mapCategoryValues(
                classes,
                'gicsSectors',
                GICSSectors,
                gicsSectors,
                gicsDimensions,
                (item) => item.SectorID,
                (item) => item.Name
            ),
            ...mapCategoryValues(
                classes,
                'keyIssues',
                KeyIssues,
                keyIssues,
                keyIssueDimensions,
                (item) => item.KeyIssueID,
                (item) => item.KeyIssueName
            ),
            ...mapCategoryValues(
                classes,
                'regions',
                Regions,
                regions,
                regionDimensions,
                (item) => item,
                (item) => item
            ),
        ];
    };

    const getDate = (file) => {
        const displayDate = _get(file, 'External.DisplayDate', null);
        const engagementDate = _get(file, 'External.EngagementDate', null);
        const uploadDate = _get(file, 'External.UploadedByDate', null);
        const date = displayDate != null ? toLocalDateTime(displayDate) : engagementDate != null ? toLocalDateTime(engagementDate) : uploadDate != null ? toLocalDateTime(uploadDate) : null;
        return formatDate(date);
    };

    const getPublishers = (file) => {
        const publishers = _get(file, 'External.Publishers', []);

        return Array.isArray(publishers) ? publishers.map((p) => p.Name).join(', ') : '';
    };

    const getTeam = (file) => {
        const subdomain = _get(file, 'External.SubDomain', '');
        const teamValue =
            subdomain !== subdomains.Notes ? getPublishers(file) : Array.isArray(file.External.Teams) && file.External.Teams.length > 0 ? _get(file, 'External.Teams.0.TeamName', '') : null;
        return teamValue != null ? <span className="team">{teamValue}</span> : null;
    };

    const setCategoryList = (key) => {
        const list = {
            ...showCategoryList,
            [key]: showCategoryList[key] == null ? true : !showCategoryList[key],
        };
        setKnowledgeCenterSettingsDispatcher({ CategoryList: list });
    };

    const isFileFavorite = (id) => {
        return favoriteFiles != null && Array.isArray(favoriteFiles) ? favoriteFiles.indexOf(id) >= 0 : false;
    };

    const isSelectedFile = (id) => {
        return selectedFiles != null && Array.isArray(selectedFiles) ? selectedFiles.indexOf(id) >= 0 : false;
    };

    const fileList = _groupBy(files, (file) => {
        const key = _get(file, 'External.DocumentSource.Name');
        return key == null ? 'Uncategorized' : key;
    });

    React.useEffect(() => {
        if (snippetId != null && onTabChange != null) {
            onTabChange(1);
        }
    }, [snippetId, onTabChange]);

    React.useEffect(() => {
        const list = settings.CategoryList || [];
        setShowCategoryList(list);
    }, [settings.CategoryList]);

    React.useEffect(() => {
        var files = Array.isArray(settings.ExpandedFiles) ? settings.ExpandedFiles : [];
        setSelectedFiles(files);
    }, [settings.ExpandedFiles]);

    return (
        <React.Fragment>
            {Object.keys(fileList)
                .sort()
                .map((key) => (
                    <List key={key}>
                        <div className={classes.fileListTitle} onClick={handleTagCategoryClick(key)}>
                            <div className={classes.fileListTitleLabel}>
                                <i className={cn('fas', { 'fa-chevron-right': !showCategoryList[key], 'fa-chevron-down': showCategoryList[key] })}></i>
                                {key}
                            </div>
                            <div className={classes.fileListTitleResults}>{Array.isArray(fileList[key]) && fileList[key].length} results</div>
                        </div>
                        <div className={cn(classes.fileListContainer, { [classes.fileListContainerShow]: showCategoryList[key] === true })}>
                            {fileList[key].map((file) => {
                                const id = file.Id;
                                const name = file.FileName;
                                const terms = getFileTerms(file).join(', ');
                                const categoryList = getCategoriesList(file.External);
                                const isFavorite = isFileFavorite(id);
                                return (
                                    <div key={id} className={classes.listItemContainer}>
                                        <ListItem onClick={handleFileClick(id, name)} className={classes.listItem}>
                                            <div className={classes.listItemHeader}>
                                                <div className={cn(classes.fileNameContainer, { previewer: showDocument })}>
                                                    <div className={classes.fileName}>
                                                        <i
                                                            className={cn('fas', {
                                                                'fa-chevron-right': !isSelectedFile(id),
                                                                'fa-chevron-down': isSelectedFile(id),
                                                            })}
                                                        ></i>
                                                        <span className={classes.fileNameText}>{String(file.FileName).replace('/', '')}</span>
                                                    </div>
                                                    <div className={classes.fileMetaData}>
                                                        <span className="date">{getDate(file)}</span>
                                                        <span className="author">{getAnalystName(file.External.UploadedByID)}</span>
                                                        {getTeam(file)}
                                                    </div>
                                                    <div className={classes.terms}>{terms}</div>
                                                </div>
                                                <div className={classes.actions}>
                                                    <FileInfoIcon file={file} />
                                                    <Downloader data-tip data-for="file_download" useApiResource={true} uri={`/files/${id}`}>
                                                        <i className="fas fa-download"></i>
                                                    </Downloader>
                                                    <i
                                                        data-tip
                                                        data-for="file_fav"
                                                        onClick={handleFavoriteFile(id, isFavorite)}
                                                        className={cn({ fas: isFavorite, far: !isFavorite, [classes.yellow]: isFavorite }, 'fa-star')}
                                                    ></i>
                                                    <AdminActions file={file} />
                                                </div>
                                                <Tooltip id="file_download" place="left">
                                                    Download
                                                </Tooltip>
                                                <Tooltip id="file_fav" place="left">
                                                    Mark as favourite
                                                </Tooltip>
                                            </div>
                                            {(file.External.Synopsis != null || categoryList.length > 0) && (
                                                <div className={cn(classes.fileSubContainer, 'fileNameSubContainer')}>
                                                    {categoryList != null && categoryList.length > 0 && (
                                                        <div className="categories">
                                                            <span className="title">Categories: </span>
                                                            <span className="categoryList">{categoryList}</span>
                                                        </div>
                                                    )}
                                                    {file.External.Synopsis != null && (
                                                        <div className="synopsis">
                                                            <span>Synopsis: </span>
                                                            {file.External.Synopsis.split('\n').map((content, idx) => {
                                                                return content != null && String(content).trim().length > 0 ? <p key={idx}>{content}</p> : null;
                                                            })}
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                        </ListItem>
                                        <Collapse in={isSelectedFile(id)} timeout="auto" unmountOnExit>
                                            <SnippetList searchText={data.query} file={file} fileId={id} />
                                        </Collapse>
                                    </div>
                                );
                            })}
                        </div>
                    </List>
                ))}
            <Popover
                onClose={handleSellSideWarningClose}
                show={showSellSideWarning}
                title="Compliance Notification"
                size={DialogSizes.SMALL}
                lockHeight={true}
                actions={
                    <React.Fragment>
                        <Button onClick={handleSellSideWarningConfirm} type={ButtonTypes.PRIMARY}>
                            Confirm
                        </Button>
                        <Button onClick={handleSellSideWarningClose} type={ButtonTypes.SECONDARY} style={{ marginLeft: 8 }}>
                            Cancel
                        </Button>
                    </React.Fragment>
                }
            >
                <div className={classes.headerText}>Compliance Notification:</div>
                <div className={classes.messageContainer}>
                    <p>
                        In-scope EMEA investment professionals operating under MiFID II Research rules – any third party i.e. broker research consumption must be from an approved research provider.
                        Equity/FI business management maintain an up to date list of these. You must check prior to consumption.
                    </p>
                    <p>
                        <Checkbox checked={ssWarnHide} onChange={handleSSWarnHideChecked} /> Do not show again during this session
                    </p>
                </div>
            </Popover>
        </React.Fragment>
    );
};

export default withStyles(styles)(FileList);
