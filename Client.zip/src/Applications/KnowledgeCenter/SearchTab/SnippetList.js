import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';
import Highlighter from "react-highlight-words";

import { setKnowledgeCenterSettings } from '../../../store/AppSettingsModule';
import { extractHitsFromSnippet, sanitize } from '../utilities';

const styles = theme => ({
    container: {
        borderLeft: '8px solid #f2f2f2',
        cursor: 'pointer',
        margin: '0 4px 4px 0',
        padding: 8,
        '&.selected':{
            backgroundColor: '#ffeccc',
            borderColor: '#ffda99',
        },
    },
    highlight: {
        backgroundColor: '#faea38',
    },
    snippetListContainer: {
        margin: '0 16px 0 40px',
        borderBottom: '3px solid #dce3ef',
        borderRight: '3px solid #dce3ef',
    }
});

const SnippetList = ({ classes, file }) => {
    const dispatch = useDispatch();
    const [ selected, setSelected ] = React.useState('');
    const settings = useSelector(state => state.AppSettingsReducer.KnowledgeCenter);
    const snippets = file.Content;

    const setKnowledgeCenterSettingsDispatcher = React.useCallback((setting) => {
        dispatch(setKnowledgeCenterSettings(setting))
    }, [dispatch])

    const handleSelect = (snip, highlights, idx) => event => {
        setKnowledgeCenterSettingsDispatcher({ 
            Snippet: snip,
            Highlights: highlights,
            ActiveSnippetIndex: `${file.Id}::${idx}`,
            ExpandedFile: file,
        });
    }

    React.useEffect(() => {
        setSelected(settings.ActiveSnippetIndex);
    }, [ settings.ActiveSnippetIndex ]);

    return snippets == null || snippets.length === 0
        ? <div className={classes.snippetListContainer}>
            <div className={cn(classes.container, 'snippetContainer')} onClick={ handleSelect() }><strong>No snippets were returned for your search.  Click to view the file.</strong></div>
        </div>
        : <div className={classes.snippetListContainer}>
            { snippets.map((snippet, idx) => {
                const rawHighlights = extractHitsFromSnippet(snippet);
                const highlights = rawHighlights.map(sanitize);
                const snip = sanitize(snippet);
                const selectedId = `${file.Id}::${idx}`;
                return (
                    <div key={ selectedId } className={cn(classes.container, 'snippetContainer', { 'selected': selectedId === selected })} onClick={ handleSelect(snip, rawHighlights, idx) }>
                        <Highlighter
                            autoEscape={true}
                            highlightClassName={classes.highlight}
                            searchWords={highlights}
                            textToHighlight={snip}
                        />
                    </div>
                );
            })}
        </div>
}

export default withStyles(styles)(SnippetList);
