import React from 'react';
import cn from 'classnames';

import _get from 'lodash/get';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import LoadingPanel from '../../../UIComponents/LoadingPanel';
import { Heading } from '../../../components/Content';

import SearchInstructions from './SearchInstructions';
import FileList from './FileList';
import FileViewer from '../FileManager/FileViewer';
import SearchBar from './SearchBar';
import SearchResults from './SearchResults';

const styles = theme => ({
    fileList: {
        height: 'calc(100vh - 265px)',
        overflow: 'hidden auto',
        padding: '0 12px',
    },
    fileListContainer: {
        flexBasis: '50%',
        '-ms-flex': 'auto',
    },
    fileViewerContainer: {
        marginLeft: '16px',
        flexBasis: 'calc(50% - 16px)',
        '-ms-flex': 'auto',
        '@media (max-width: 1024px)': {
            margin: 0,
        }
    },
    instructionsPanel: {
        padding: 8,
        '& li': {
            marginBottom: 4,
        }
    },
    loadingPanel: {
        marginTop: 16,
        width: '100%'
    },
    previewPaper: {
        margin: 0,
        opacity: 1,
        padding: 8,
        height: 'calc(100vh - 265px)',
    },
    previewPaperHidden: {
        display: 'none'
    },
    previewPaperPdf: {
        overflowY: 'auto'
    },
    section: {
        display: 'flex',
        flexFlow: 'row wrap',
        justifyContent: 'flex-start',
    },
    sectionContainer: {
        height: 'calc(100vh - 160px)',
        maxWidth: '100%',
        margin: '0 auto'
    },
    sectionItem: {
        height: '100%',
        flexGrow: 1,
        minWidth: 530,
        position: 'relative',
        padding: '16px 0',
        boxSizing: 'border-box',
        '&:last-child': {
            paddingRight: 0,
        }
    },
});

const DesktopView = ({
    classes, fileId, fileName, files, fileViewerOptions,
    searchData, searchTotal, showDocument,
    isLoading, isLoaded,
    onSearchSubmit, onSearchClear
}) => {
    return (
        <div className={classes.sectionContainer} style={{ margin: 0 }}>
            <div className={classes.section}>
                <SearchBar onSearch={onSearchSubmit} onClear={onSearchClear} defaultQuery={searchData} />
                {isLoading === true
                    ? <div className={classes.loadingPanel}><LoadingPanel /></div>
                    : isLoaded === true && <SearchResults files={files || []} totalCount={searchTotal} />
                }
            </div>
            <div className={cn(classes.section, classes.resultSection)}>
                <div className={cn(classes.sectionItem, classes.fileListContainer)}>
                    {isLoaded === false
                        ? isLoading === false && (
                            <React.Fragment>
                                <Paper className={classes.instructionsPanel}>
                                    <Heading title="Search Help" />
                                    <SearchInstructions />
                                </Paper>
                            </React.Fragment>
                        ) : (
                            <React.Fragment>
                                {_get(files, 'length', 0) > 0 &&
                                    <Paper className={classes.fileList}>
                                        <FileList
                                            data={searchData}
                                            files={files}
                                            selected={fileId}
                                            showDocument={showDocument}
                                        />
                                    </Paper>
                                }
                            </React.Fragment>
                        )
                    }
                </div>
                <div className={cn(classes.sectionItem, classes.fileViewerContainer, { [classes.previewPaperHidden]: !showDocument })}>
                    <Paper className={cn(classes.previewPaper)}>
                        <FileViewer
                            clear={!showDocument}
                            fileId={fileId}
                            fileName={fileName}
                            show={showDocument}
                            options={fileViewerOptions || {}}
                        />
                    </Paper>
                </div>
            </div>
        </div>
    );
}

export default withStyles(styles, { withTheme: true })(DesktopView);