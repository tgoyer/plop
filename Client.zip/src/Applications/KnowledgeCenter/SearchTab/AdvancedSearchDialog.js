import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import { Button, ButtonTypes, TextField } from '../../../components/Form';
import { FileSearch } from '../FileManager';
import { Popover, DialogSizes } from '../../../components/Dialogs';
import Tooltip from "../../../UIComponents/Tooltip";

import { pxToRem } from '../../../Utils/layoutHelper';

const styles = theme => ({
    body: {
        flexGrow: 1,
        height: '100%'
    },
    container: {
        display: 'flex',
        flexDirection: 'column',
    },
    header: {
        flexBasis: 42,
        flexGrow: 0,
        flexShrink: 0,
    },
    icon: {
        cursor: 'help',
    },
    popover: { 
        maxHeight: 1001 
    },
    queryInput: {
        height: 41,
        marginLeft: 8,
        width: '50%',
        '& input': {
            borderBottom: '1px solid #333',
            padding: '6px 0 0 !important',
            '&:hover': {
                borderBottom: '2px solid #333'
            }
        }
    },
    queryText: {
        backgroundColor: '#eeeeee',
        display: 'inline-block',
        fontSize: pxToRem(14),
        marginLeft: 8,
        marginTop: 4,
        padding: 4,
    },
    queryTitle: {
        color: 'rgba(0, 0, 0, 0.58)',
        fontSize: pxToRem(14),
        fontWeight: 700,
        paddingTop: 16,
        '&:first-child': {
            paddingTop: 0,
        }
    },
    title: {
        color: 'rgba(0, 0, 0, 0.58)',
        fontSize: 14,
        fontWeight: 700,
        paddingTop: 16,
    },
});

const AdvancedSearchDialog = ({ classes, show = true, query, onClose, onSearch }) => {
    const [ queryText, setQueryText ] = React.useState(query.query);
    const [ categories, setCategories ] = React.useState(query.categories);

    const handleCategoryChange = React.useCallback((data) => {
        setCategories(data);
    }, []);

    const handleQueryChange = React.useCallback((evt) => {
        setQueryText(evt.target.value);
    }, []);

    const handleCancelClick = () => {
        if (onClose != null) {
            onClose();
        }
    }

    const handleSearchClick = () => {
        if (onSearch != null) {
            onSearch({ query: queryText, categories });
        }
        if (onClose != null) {
            onClose();
        }
    }

    const isValid = () => {
        const { createdDate, ...rest } = categories;
        const hasCategories = rest != null && Object.keys(rest).length > 0;
        const hasDate = createdDate != null && createdDate.Start != null && createdDate.End != null;
        const hasQuery = queryText != null && queryText.length > 0;

        return hasCategories || hasDate || hasQuery;
    }

    React.useEffect(() => {
        setQueryText(query.query || '');
        setCategories(query.categories || {});
    }, [query.query, query.categories]);

    return (
        <Popover 
            onClose={onClose} 
            show={show} 
            title="Advanced Search" 
            size={DialogSizes.FULL}
            lockHeight={true}
            className={classes.popover}
            actions={
                <React.Fragment>
                    <Button type={ButtonTypes.SECONDARY} onClick={handleCancelClick}>Cancel</Button>
                    <Button type={ButtonTypes.PRIMARY} disabled={!isValid()} onClick={handleSearchClick}>Search</Button>
                </React.Fragment>
            }
            headerActions={
                <a href="/assets/documents/Knowledge_Center_User_Guide.pdf" target="_blank" rel="noreferrer noopener">
                    <i data-tip data-for="Help_File_TT" className={cn("fas fa-info-circle", classes.icon)}></i>
                </a>
            }
        >
            <Tooltip place="bottom" id="Help_File_TT">Click to view the search guide.</Tooltip>
            <div className={classes.container}>
                <div className={classes.header}>
                    <span className={classes.title}>Search Content:</span>
                    <TextField 
                        name="query"
                        title="Search Content"
                        placeholder="Search Knowledge Center Content"
                        defaultValue={queryText} 
                        onChange={handleQueryChange} 
                    />
                </div>
                <div className={classes.body}>
                    <FileSearch data={categories} onChange={handleCategoryChange}/>
                </div>
            </div>
        </Popover>    
    )
}

export default withStyles(styles)(AdvancedSearchDialog);