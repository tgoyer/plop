import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import _get from 'lodash/get';
import _partition from 'lodash/partition';

import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import InputBase from '@material-ui/core/InputBase';
import Paper from '@material-ui/core/Paper';
import ClearIcon from '@material-ui/icons/Clear';
import SearchIcon from '@material-ui/icons/ArrowForward';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from '../../../UIComponents/Tooltip';
import { FileSearchOptionValues } from '../FileManager';

import AdvancedSearchDialog from './AdvancedSearchDialog';

import { setKnowledgeCenterSettings } from '../../../store/AppSettingsModule';
import { clearSearchFiles, searchDocumentRepository } from '../../../store/FileModule';

import { categoryMap, esgTypes } from '../utilities';
import { toServerDateTime, formatDate } from '../../../Utils/dateHelper';
import { KeyCodes } from '../../../Utils/layoutHelper';

const styles = (theme) => ({
    advSearchIcon: {
        color: '#8a8a8a',
        fontSize: 10,
        marginLeft: 0,
        marginRight: 4,
        '& i.fa-plus': {
            fontSize: 10,
            marginLeft: 9,
            marginTop: -11,
        },
        '& i.fa-search': {
            fontSize: 18,
        },
    },
    badge: {
        position: 'absolute',
        top: -10,
        right: -10,
        width: 25,

        background: '#cc0000',
        borderRadius: '50%',
        boxShadow: '0 0 2px 0px rgb(77, 0, 0)',
        fontSize: 10,
        fontWeight: 700,
        color: '#ffffff',
        padding: '4px 6px',
    },
    category: {
        marginBottom: 10,
    },
    categoryItem: {
        fontWeight: 400,
        marginLeft: 20,
    },
    categoryName: {
        fontWeight: 700,
    },
    divider: {
        width: 1,
        height: 28,
        margin: 4,
    },
    formInput: {
        width: 450,
    },
    formPanel: {
        padding: 16,
    },
    input: {
        marginLeft: 8,
        flex: 1,
    },
    iconButton: {
        padding: 10,
    },
    panelMargin: {
        marginTop: 16,
    },
    paper: {
        display: 'flex',
        alignItems: 'center',
        width: '100%',
        height: 44,
    },
    tooltipIcon: {
        width: 25,
    },
});

const initalQuery = { query: '', categories: {} };

const buildFilters = (data) => {
    const { query, categories } = data || { ...initalQuery };
    const hasCategories = categories != null && Object.keys(categories).length > 0;
    const buildPayload = () => ({
        query,
        ...(!hasCategories
            ? {}
            : Object.keys(categories).reduce((acc, key) => {
                  const category = categories[key];

                  if (Array.isArray(category) && category.length > 0) {
                      const [include, exclude] = _partition(
                          category.filter((l) => l.value != null),
                          (item) => item.value === FileSearchOptionValues.INCLUDE
                      );

                      if (esgTypes.indexOf(key) >= 0) {
                          acc['keyIssues'] = {
                              include: [..._get(acc, ['keyIssues', FileSearchOptionValues.INCLUDE], []), ...include],
                              exclude: [..._get(acc, ['keyIssues', FileSearchOptionValues.EXCLUDE], []), ...exclude],
                          };
                      } else {
                          acc[key] = {
                              include: include,
                              exclude: exclude,
                          };
                      }
                  } else {
                      if (key === 'createdDate') {
                          if (category != null && category.Start != null && category.End != null) {
                              acc[key] = category;
                          }
                      } else {
                          acc[key] = category;
                      }
                  }

                  return acc;
              }, {})),
    });

    const filters = buildPayload();
    const count = Object.keys(filters).reduce((acc, key) => {
        const filter = filters[key];
        const count =
            Array.isArray(filter.include) || Array.isArray(filter.exclude)
                ? _get(filter, 'include.length', 0) + _get(filter, 'exclude.length', 0)
                : key === 'query'
                ? 0
                : filter != null
                ? 1
                : 0;
        acc = acc + count;
        return acc;
    }, 0);

    return { filters, count };
};

const getFilterDisplayRows = (filter, key, classes) => {
    switch (key) {
        case 'query':
            return null;
        case 'createdDate':
            return (
                <React.Fragment>
                    <dt className={classes.categoryName}>Created Date</dt>
                    <dd className={classes.categoryItem} key={'value_' + key}>
                        <i className={cn(classes.tooltipIcon, 'fas fa-check')}></i> {formatDate(filter.Start)} - {formatDate(filter.End)}
                    </dd>
                </React.Fragment>
            );
        default:
            return (
                (Array.isArray(filter.include) || Array.isArray(filter.exclude)) && (
                    <React.Fragment>
                        <dt className={classes.categoryName}>{categoryMap[key]}</dt>
                        {filter.include.map((item) => (
                            <dd className={classes.categoryItem} key={key + '_inc_' + item.id}>
                                <i className={cn(classes.tooltipIcon, 'fas fa-check')}></i> {item.name}
                            </dd>
                        ))}
                        {filter.exclude.map((item) => (
                            <dd className={classes.categoryItem} key={key + '_exc_' + item.id}>
                                <i className={cn(classes.tooltipIcon, 'fas fa-times')}></i> {item.name}
                            </dd>
                        ))}
                    </React.Fragment>
                )
            );
    }
};

const SearchBar = ({ classes, onSearch, onClear }) => {
    const [advFilters, setAdvFilters] = React.useState({ ...initalQuery });
    const [advFiltersCount, setAdvFiltersCount] = React.useState(0);
    const [query, setQuery] = React.useState({ ...initalQuery });
    const [showAdvSearch, setShowAdvSearch] = React.useState(false);

    const dispatch = useDispatch();
    const settings = useSelector((state) => state.AppSettingsReducer.KnowledgeCenter);

    const clearSearchFilesDispatcher = React.useCallback(() => {
        dispatch(clearSearchFiles());
    }, [dispatch]);
    const searchDocumentRepositoryDispatcher = React.useCallback(
        (query) => {
            dispatch(searchDocumentRepository(query));
        },
        [dispatch]
    );
    const setKnowledgeCenterSettingsDispatcher = React.useCallback(
        (setting) => {
            dispatch(setKnowledgeCenterSettings(setting));
        },
        [dispatch]
    );

    const handleAdvSearchClick = () => setShowAdvSearch(true);
    const handleAdvSearchClose = () => setShowAdvSearch(false);
    const handleAdvSearchSubmit = (options) => {
        const { filters, count } = buildFilters(options);

        handleSearchClear();

        setAdvFilters(filters);
        setAdvFiltersCount(count);
        setSearchData({ ...options });
        setKnowledgeCenterSettingsDispatcher({ Query: options });

        submitSearch(filters);
    };

    const handleInputChange = (evt) => setQuery({ query: _get(evt, 'target.value', ''), categories: query.categories });

    const handleKeyPress = (evt) => {
        if (evt.key === KeyCodes.ENTER) {
            handleSearchSubmit();
        }
    };

    const handleSearchClear = () => {
        const { ActiveHeaderTab } = settings;
        setSearchData(null);
        clearSearchFilesDispatcher();
        setAdvFilters({});
        setAdvFiltersCount(0);
        setKnowledgeCenterSettingsDispatcher(null);
        setKnowledgeCenterSettingsDispatcher({ ActiveHeaderTab });

        if (onClear != null) {
            onClear();
        }
    };

    const handleSearchSubmit = () => {
        const { filters } = buildFilters(query);

        handleSearchClear();

        setSearchData({ ...query });
        setKnowledgeCenterSettingsDispatcher({ Query: query });
        submitSearch(filters);
    };

    const setSearchData = React.useCallback(
        (query) => {
            const data = query != null ? query : { ...initalQuery };
            const { filters, count } = buildFilters(data);

            setAdvFilters(filters);
            setAdvFiltersCount(count);
            setQuery({ ...data });
            onSearch(filters);
        },
        [onSearch]
    );

    const submitSearch = React.useCallback(
        (data) => {
            if (data == null) {
                clearSearchFilesDispatcher();
                return;
            }

            const { query, createdDate, ...categories } = data;
            const queryEmpty = query == null || query.length === 0;
            const categoriesEmpty = categories == null || Object.keys(categories).length === 0;
            const dateEmpty = _get(createdDate, 'Start', null) == null || _get(createdDate, 'End', null) == null;

            if (queryEmpty && categoriesEmpty && dateEmpty) return;

            const startDate =
                dateEmpty || createdDate.Start == null
                    ? null
                    : toServerDateTime(new Date(createdDate.Start.getFullYear(), createdDate.Start.getMonth(), createdDate.Start.getDate()));
            const endDate =
                dateEmpty || createdDate.End == null
                    ? null
                    : toServerDateTime(new Date(createdDate.End.getFullYear(), createdDate.End.getMonth(), createdDate.End.getDate() + 1));
            searchDocumentRepositoryDispatcher({
                query: String(query).replace(/[\u201c|\u201d]/g, '"'),
                createdDate: { Start: formatDate(startDate, 'MM/dd/yyyy'), End: formatDate(endDate, 'MM/dd/yyyy') },
                ...Object.keys(categories).reduce((acc, key) => {
                    const category = categories[key];
                    if (Array.isArray(category.include) || Array.isArray(category.exclude)) {
                        acc[key] = {
                            include: category.include.map((i) => i.id),
                            exclude: category.exclude.map((e) => e.id),
                        };
                    } else {
                        acc[key] = category;
                    }
                    return acc;
                }, {}),
            });
        },
        [clearSearchFilesDispatcher, searchDocumentRepositoryDispatcher]
    );

    React.useEffect(() => {
        const data = settings.Query || { ...initalQuery };
        const { filters, count } = buildFilters(data);

        setAdvFilters(filters);
        setAdvFiltersCount(count);
        setQuery({ ...data });
    }, [settings.Query]);

    return (
        <React.Fragment>
            <Paper className={classes.paper}>
                <InputBase
                    autoFocus={true}
                    className={classes.input}
                    onChange={handleInputChange}
                    onKeyPress={handleKeyPress}
                    placeholder="Search Knowledge Center Content"
                    value={query.query}
                />
                <IconButton data-tip data-for="search_TT" className={classes.iconButton} onClick={handleSearchSubmit} aria-label="Search">
                    <SearchIcon />
                </IconButton>
                <Divider className={classes.divider} />
                <IconButton data-tip data-for="clearSearch_TT" className={classes.iconButton} onClick={handleSearchClear} aria-label="Clear">
                    <ClearIcon />
                </IconButton>
                <Divider className={classes.divider} />
                <IconButton data-tip data-for="advSearch_TT" className={classes.iconButton} onClick={handleAdvSearchClick} aria-label="Advanced Search">
                    <React.Fragment>
                        <span className={cn(classes.advSearchIcon, 'fa-stack')}>
                            <i className="fas fa-search fa-stack-1x"></i>
                            <i className="fas fa-plus fa-stack-1x"></i>
                        </span>
                        {advFiltersCount > 0 && (
                            <React.Fragment>
                                <span data-tip data-for="filterBadge_TT" className={classes.badge}>
                                    {advFiltersCount}
                                </span>
                                <Tooltip id="filterBadge_TT" place="left">
                                    <p>
                                        <strong>Additional Advanced Search Categories</strong>
                                    </p>
                                    {Object.keys(advFilters).map((key) => (
                                        <div key={key} className={classes.category}>
                                            {getFilterDisplayRows(advFilters[key], key, classes)}
                                        </div>
                                    ))}
                                </Tooltip>
                            </React.Fragment>
                        )}
                    </React.Fragment>
                </IconButton>
                <Tooltip id="search_TT" place="left">
                    Click to search
                </Tooltip>
                <Tooltip id="clearSearch_TT" place="left">
                    Clear your search criteria
                </Tooltip>
                {advFiltersCount === 0 && (
                    <Tooltip id="advSearch_TT" place="left">
                        Click to search content and categories(tags)
                    </Tooltip>
                )}
            </Paper>
            {showAdvSearch && <AdvancedSearchDialog query={query} onClose={handleAdvSearchClose} onSearch={handleAdvSearchSubmit} />}
        </React.Fragment>
    );
};

export default withStyles(styles)(SearchBar);
