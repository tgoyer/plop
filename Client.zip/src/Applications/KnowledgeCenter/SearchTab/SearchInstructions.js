import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    advSearchIcon: {
        color: '#8a8a8a',
        fontSize: 8,
        marginLeft: 6,
        marginRight: 6,
        '& i.fa-plus': {
            fontSize: 9,
            marginLeft: 7,
            marginTop: -9
        },
        '& i.fa-search': {
            fontSize: 16,
        }
    },
    container: {
        margin: 16,
        '& p': {
            marginTop: 8,
        }
    },
    example: {
        display: 'flex',
        alignItems: 'baseline',
        '& pre': {
            display: 'inline-block',
            margin: '0 4px',
            padding: '2px 4px'
        }
    },
});

const SearchInstructions = ({ classes }) => {
    return (
        <div className={classes.container}>
            <p>Type text to search document content.  Click the 
                <span className={cn(classes.advSearchIcon, "fa-stack")}>
                    <i className="fas fa-search fa-stack-1x"></i>
                    <i className="fas fa-plus fa-stack-1x"></i>
                </span>
                icon to additionally search by document tags.
            </p>
            <p>Content Search tips:</p>
            <ul>
                <li>
                    Put a plus (+) in front of a word or phrase to indicate it must exist<br/>
                    <span className={classes.example}>Example: <pre>+climate +change</pre></span>
                </li>
                <li>
                    Put a minus (-) in front of a word or phrase to indicate it must NOT exist
                    <span className={classes.example}>Example: <pre>+climate -change</pre></span>
                </li>
                <li>
                    Use double quotes to search for phrases
                    <span className={classes.example}>Example: <pre>“climate change”</pre></span>
                </li>
                <li>
                    The search will be smart enough to find variants of a word.  To have it search for an exact word, use double quotes.
                    <span className={classes.example}>Example: Searching for <pre>change</pre> may find terms like <pre>change</pre> <pre>changes</pre> <pre>changed</pre> and <pre>changing</pre></span>
                    <span className={classes.example}>Use <pre>“change”</pre> (in quotation marks) to find only exact matches.</span>
                </li>
            </ul>
        </div>
    );
}

export default withStyles(styles, { withTheme: true })(SearchInstructions);