import React from 'react';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import { getTerms } from '../utilities';

const styles = theme => ({
    paper: {
        alignItems: 'center',
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: 16,
        width: '100%',
        height: 35
    },
    resultsTerms: {
        fontSize: 12,
        fontWeight: 400,
        padding: 8,
        margin: '0 12px',
        fontStyle: 'italic',
        '& span': {
            marginLeft: 4,
            textDecoration: 'underline'
        }
    },
    resultsText: {
        fontSize: 12,
        fontWeight: 700,
        padding: 8,
    }
});

const SearchResults = ({ classes, files, totalCount }) => {
    const count = files != null ? files.length : 0;
    const label = count === 1 ? 'result' : 'results';
    
    const terms = getTerms(files);

    const resultsText = count < totalCount
        ? `Displaying ${ count } out of ${totalCount} total results.  Press the magnifying glass icon on the right side of the search bar to refine your search.`
        : `Found ${ count } file ${ label }.`

    return (
        <Paper className={classes.paper}>
            <span className={classes.resultsText}>{resultsText}</span>
            { Array.isArray(terms) && terms.length > 0 && <span className={classes.resultsTerms}>Found terms: <span>{ terms.join(', ') }</span></span> }
        </Paper>
    )
}

export default withStyles(styles)(SearchResults);















/*
*/
