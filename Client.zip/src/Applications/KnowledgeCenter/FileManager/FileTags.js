import React from 'react';
import { useSelector } from 'react-redux';

import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';

import _get from 'lodash/get';
import _orderBy from 'lodash/orderBy';

import Tooltip from '../../../UIComponents/Tooltip';
import { SelectList, mapSelectOptions } from '../../../components/Form';
import InputContainer from '../../../components/Form/Panels/InputContainer';
import BadgeList from '../../../components/Form/BadgeList';
import CountrySearch from '../../../components/Search/CountrySearch';
import PublisherSearch from '../../../components/Search/PublisherSearch';
import CompanySearch from '../../../components/Search/CompanySearch';

import { formatByteSize } from '../../../Utils/numberHelper';
import { sort } from '../../../Utils/listHelper';
import { documentSources } from '../utilities';

const styles = (theme) => ({
    actions: {
        display: 'flex',
        justifyContent: 'flex-end',
        flexBasis: 46,
        flexGrow: 0,
        flexShrink: 0,
        paddingTop: 10,
        '& button': {
            marginLeft: 10,
        },
    },
    alertBanner: {
        backgroundColor: '#f08f50',
        borderBottom: '1px solid white',
        borderRadius: 4,
        color: 'white',
        display: 'flex',
        fontSize: 16,
        fontWeight: 700,
        justifyContent: 'space-between',
        margin: '0 0 10px 0',
        padding: '4px 12px',
        textAlign: 'center',
        textShadow: '1px 1px rgba(65, 92, 139, 1)',
        width: '100%',
    },
    listContainer: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr 1fr',
        gridTemplateRows: '1fr',
    },
    taggerFullscreen: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-start',
    },
    textFieldRoot: {
        margin: '8px 8px 0 8px',
        width: 'calc(100% - 16px)',
    },
    title: {
        flexGrow: 0,
        flexBasis: 40,
        paddingBottom: 10,
        borderBottom: '2px solid #bdd7ff',
        '& > div': {
            display: 'inline-block',
            paddingRight: 20,
            '& strong': {
                fontSize: 18,
                marginRight: 5,
            },
            '& span': {
                backgroundColor: '#e6e6e6',
                padding: '4px 8px',
            },
        },
    },
    '@media (max-width: 1199px)': {
        title: {
            marginBottom: 12,
        },
    },
});

const mapDocumentSources = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.DocumentSourceID, item.Name));
const mapKeyIssues = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.KeyIssueID, item.KeyIssueName));
const mapGICSSectors = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.SectorID, item.Name));
const mapStrings = (items) => mapSelectOptions(items, (item, mapper) => mapper(item, item));
const mapTeams = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.TeamID, item.TeamName));

const sortKeyIssues = (issues) => {
    return _orderBy(
        issues.map((o) => ({
            ...o,
            SortBy: o.KeyIssueName === 'Other' ? null : Boolean(o.IsDeprecated) ? 0 : 1,
        })),
        ['SortBy', (o) => o.KeyIssueName.toLowerCase()],
        ['asc', 'asc']
    );
};

const FileTags = ({ actions, classes, data, onChange }) => {
    const file = _get(data, 'file', null);

    const stateDocumentSources = useSelector((state) => mapDocumentSources(state.DimensionReducer.DocumentSources));
    const stateGICSSectors = useSelector((state) => mapGICSSectors(state.DimensionReducer.GICSSectors));
    const stateEnvKeyIssues = useSelector((state) => mapKeyIssues(sortKeyIssues(state.DimensionReducer.KeyIssues.ab.environment)));
    const stateGovKeyIssues = useSelector((state) => mapKeyIssues(sortKeyIssues(state.DimensionReducer.KeyIssues.ab.governance)));
    const stateSocKeyIssues = useSelector((state) => mapKeyIssues(sortKeyIssues(state.DimensionReducer.KeyIssues.ab.social)));
    const stateOtherDocumentTypes = useSelector((state) => mapStrings(state.DimensionReducer.OtherDocumentTypes));
    const stateRegions = useSelector((state) => mapStrings(state.DimensionReducer.Regions));
    const stateTeams = useSelector((state) => mapTeams(state.DimensionReducer.Teams.filter((team) => team.TeamName !== 'EIMT')));

    const [companies, setCompanies] = React.useState([]);
    const [countries, setCountries] = React.useState([]);
    const [publishers, setPublishers] = React.useState([]);
    const [synopsis, setSynopsis] = React.useState('');

    const raiseOnChange = React.useCallback(
        (newData) => {
            if (onChange != null) {
                onChange({ ...data, ...newData });
            }
        },
        [data, onChange]
    );

    const handleListChange = (name, value) => raiseOnChange({ [name]: value });

    const handleCountryDelete = (item) => raiseOnChange({ countries: countries.filter((c) => c.id !== item.id) });
    const handleCompanyDelete = (item) => raiseOnChange({ companies: companies.filter((c) => c.id !== item.id) });
    const handlePublisherDelete = (item) => raiseOnChange({ publishers: publishers.filter((p) => p.id !== item.id) });

    const handleCountrySearch = (value) =>
        raiseOnChange({ countries: updateArray({ id: value.CountryID, isNew: value.IsNew === true, name: value.Name, value: 'include' }, countries) });
    const handleCompanySearch = (value) =>
        raiseOnChange({ companies: updateArray({ id: value.CompanyID, name: `${value.CompanyName} (${value.Ticker})`, value: 'include' }, companies) });
    const handlePublisherSearch = (value) =>
        raiseOnChange({
            publishers: updateArray(
                { id: value.PublisherID, name: value.Name, value: 'include', data: { documentSourceID: value.DocumentSourceID, isNew: value.IsNew === true } },
                publishers
            ),
        });

    const handleSynposisBlur = () => raiseOnChange({ synopsis });
    const handleSynposisChange = (evt) => setSynopsis(evt.target.value);

    const updateArray = (item, list) => {
        const found = list.find((i) => i.id === item.id);
        const newList = found == null ? [...list, item] : [...list];
        return newList.sort(sort('name'));
    };

    const publisherDataFilter = (p) => {
        return p.DocumentSourceID === _get(data, 'documentSources.0.id', null);
    };

    React.useEffect(() => {
        setCountries(data.countries || []);
        setPublishers(data.publishers || []);
        setCompanies(data.companies || []);
    }, [setCountries, setPublishers, setCompanies, data.countries, data.publishers, data.companies]);

    React.useEffect(() => {
        setSynopsis(data.synopsis);
    }, [data.synopsis]);

    return (
        <div className={classes.taggerFullscreen}>
            {file != null && file.isWarning && (
                <div className={classes.alertBanner}>
                    <span>{file.message}</span>
                </div>
            )}
            {file != null && (
                <div className={classes.title}>
                    <div>
                        <strong>File Name:</strong> <span>{file.file.name}</span>
                    </div>
                    <div>
                        <strong>File Size:</strong> <span>{formatByteSize(file.file.size)}</span>
                    </div>
                </div>
            )}
            <div className={classes.listContainer}>
                <SelectList
                    name="documentSources"
                    options={stateDocumentSources.filter((ds) => ds.id !== documentSources.Uncategorized)}
                    values={data.documentSources}
                    onChange={handleListChange}
                    title="Document Source"
                    multiple={false}
                    required={true}
                    style={{ minHeight: 150 }}
                />
                <SelectList
                    name="otherDocumentTypes"
                    options={stateOtherDocumentTypes}
                    values={data.otherDocumentTypes}
                    onChange={handleListChange}
                    title="Document Types"
                    multiple={false}
                    style={{ minHeight: 150 }}
                />
                <InputContainer title={'Synopsis'}>
                    <TextField
                        classes={{
                            root: classes.textFieldRoot,
                        }}
                        multiline={true}
                        name="synopsis"
                        onBlur={handleSynposisBlur}
                        onChange={handleSynposisChange}
                        placeholder="Enter description for this file"
                        value={synopsis}
                        rowsMax="5"
                        inputProps={{ maxLength: 1024 }}
                    />
                </InputContainer>
                <BadgeList data={countries} title="Country" onDelete={handleCountryDelete}>
                    <CountrySearch onSearch={handleCountrySearch} />
                </BadgeList>
                <BadgeList data={companies} title="Company" onDelete={handleCompanyDelete}>
                    <CompanySearch onSearch={handleCompanySearch} />
                </BadgeList>
                <BadgeList data={publishers} title="Publisher" onDelete={handlePublisherDelete}>
                    <div data-tip data-for="publisherDisabled_TT">
                        <PublisherSearch
                            filterBy={publisherDataFilter}
                            onSearch={handlePublisherSearch}
                            dataSource={data.documentSources}
                            disabled={data.documentSources == null}
                        />
                    </div>
                    {data.documentSources == null && (
                        <Tooltip id="publisherDisabled_TT" place="left">
                            Publisher tagging is disabled until the document source is selected.
                        </Tooltip>
                    )}
                </BadgeList>
                <SelectList
                    name="environment"
                    options={stateEnvKeyIssues}
                    values={data.environment}
                    onChange={handleListChange}
                    title="Environmental Key Issues"
                />
                <SelectList name="social" options={stateSocKeyIssues} values={data.social} onChange={handleListChange} title="Social Key Issues" />
                <SelectList name="governance" options={stateGovKeyIssues} values={data.governance} onChange={handleListChange} title="Governance Key Issues" />
                <SelectList name="regions" options={stateRegions} values={data.regions} onChange={handleListChange} title="Regions" />
                <SelectList name="gicsSectors" options={stateGICSSectors} values={data.gicsSectors} onChange={handleListChange} title="GICS Sectors" />
                <SelectList name="teams" options={stateTeams} values={data.teams} onChange={handleListChange} title="Teams" />
            </div>
            {actions != null && <div className={classes.actions}>{actions}</div>}
        </div>
    );
};
// FileTags.whyDidYouRender = { customName: 'FileTags' }
export default withStyles(styles)(React.memo(FileTags));
