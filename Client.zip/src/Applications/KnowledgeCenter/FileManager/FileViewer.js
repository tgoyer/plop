import React from 'react';
import cn from 'classnames';
import { useSelector } from 'react-redux';
// import WebViewer from '@pdftron/webviewer'

import NotificationBar from '../../../UIComponents/NotificationBar/NotificationBar';
import { withStyles } from '@material-ui/core/styles';

import { getEnvironment, getExtension, getFullyQualifiedUrl, isMobileBrowser } from '../../../Utils/layoutHelper';
import { sanitize } from '../utilities';
import Downloader from 'componentlibrary/file/Downloader';

const styles = {
    notSupportedPane: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        width: '100%',
        '& .fa-exclamation-triangle': {
            color: '#f08f50',
            fontSize: 75,
            margin: 0,
        },
        '& .message': {
            margin: '20px 50px',
        },
        '& .button': {
            margin: '20px 0',
            '& i': {
                fontSize: 24,
                marginRight: 12,
            },
            '& span': {
                fontWeight: 700,
            },
        },
    },
    viewer: {
        display: 'none',
        height: '100%',
        width: '100%',
        '& iframe': {
            border: 0,
        },
    },
    visible: {
        display: 'block !important',
    },
};

const env = getEnvironment();
const isMobile = isMobileBrowser();
const isHosted = env !== 'LOCAL';
const highlightColor = 'rgba(255, 125, 25, 0.25)';
const resultCodes = Object.freeze({
    END_OF_DOCUMENT: 0,
    RESULT_FOUND: 2,
});

const viewerDefaults = {
    isMobile,
    path: '/js/pdftron/lib',
    preload: 'all',
    zoom: 1,
};

const FileViewer = ({ classes, clear, fileId, fileName, options }) => {
    const [messages, setMessages] = React.useState(null);

    const viewerRef = React.useRef();
    const document = React.useRef();
    const docViewer = React.useRef();
    const webViewer = React.useRef();

    const useServer = useSelector((state) => state.AppSettingsReducer.ServerSettings.EnableWebViewerServer);
    const pdftronLicense = useSelector((state) => state.AppSettingsReducer.ServerSettings.Keys.PDFTron);
    const serverUrl = useSelector((state) => state.AppSettingsReducer.ServerSettings.WebViewerServerUrl);
    const userName = useSelector((state) => state.UserReducer.UserInfo.Data.UserName);

    const documentSearch = React.useCallback((term) => {
        const mode = docViewer.current.SearchMode.e_ambient_string | docViewer.current.SearchMode.e_page_stop | docViewer.current.SearchMode.e_highlight;

        //Convert callback to Promise.
        const doSearch = (phrase) => {
            const results = [];
            const promise = new Promise((resolve, reject) => {
                docViewer.current.textSearchInit(phrase, mode, true, (res) => {
                    results.push(res);

                    if (res.resultCode === resultCodes.RESULT_FOUND) {
                        docViewer.current.displayAdditionalSearchResult(res);
                    }

                    if (res.resultCode === resultCodes.END_OF_DOCUMENT) {
                        const found = results.filter((r) => r.resultCode === 2);
                        if (found.length > 0) {
                            resolve(found);
                        } else {
                            reject(results);
                        }
                    }
                });
            });
            return promise;
        };

        if (term != null) {
            docViewer.current.clearSearchResults();
            const searchTerm = sanitize(term);
            doSearch(searchTerm)
                .then((results) => docViewer.current.setActiveSearchResult(results[0]))
                .catch((results) => {
                    //Not Found.  Tell the user.
                    console.group('Search text not found.');
                    console.warn('Search term:', searchTerm);
                    console.warn('Results', results);
                    console.groupEnd();
                    setMessages({
                        cannotLocateSnippet: {
                            message:
                                "Could not locate the snippet text.  You can manually search for the location using the document viewer's built in search tool.  Look for the magnifying glass on the right side of the document viewer toolbar.",
                        },
                    });
                });
        }
    }, []);

    const documentLoad = React.useCallback(() => {
        if (document.current == null && fileName != null && fileId != null) {
            if (extensionSupported(fileName)) {
                const filePath = getFullyQualifiedUrl('/files/' + fileId);
                webViewer.current.loadDocument(filePath, {
                    ...viewerDefaults.loader,
                    cacheKey: fileId,
                    customHeaders: { 'X-User-ID': userName },
                    extension: getExtension(fileName),
                    filename: fileName,
                });
                docViewer.current.on('documentLoaded', () => {
                    try {
                        webViewer.current.setFitMode(webViewer.current.FitMode.FitWidth);
                        webViewer.current.setZoomLevel(viewerDefaults.zoom);

                        docViewer.current.setSearchHighlightColors({
                            searchResult: highlightColor,
                            activeSearchResult: highlightColor,
                        });

                        document.current = docViewer.current.getDocument();

                        if (options != null) {
                            documentSearch(options.term);
                        }
                    } catch (error) {
                        console.error(error);
                    }
                });
            }
        }
    }, [documentSearch, fileName, fileId, options, userName]);

    const extensionSupported = (fileName) => {
        const extension = getExtension(fileName);
        return (
            [
                // documents
                'docx',
                'pdf',
                'pptx',
                'xlsx',
                // images
                'jpg',
                'png',
            ].indexOf(String(extension).toLowerCase()) >= 0
        );
    };

    const handleNotificationClose = (key) => (evt) => setMessages(null);

    const initializeWebViewer = React.useCallback(() => {
        const useWebviewerServer = useServer && isHosted && !isMobile;
        return webViewer.current != null
            ? Promise.resolve()
            : window
                  .WebViewer(
                      {
                          licenseKey: pdftronLicense,
                          pdftronServer: useWebviewerServer ? serverUrl : null,
                          path: viewerDefaults.path,
                          backendType: 'ems',
                          disableWebsockets: true,
                          enableAzureWorkaround: true,
                          preloadWorker: useWebviewerServer ? null : viewerDefaults.preload,

                          // v5 options
                          // enableAnnotations: false,
                          // enableFilePicker: false,
                          // enableMeasurement: false,
                          // enableRedaction: false,
                      },
                      viewerRef.current
                  )
                  .then((instance) => {
                      // v5 options
                      // instance.disableDownload();
                      // instance.disableNotesPanel();

                      // v6 options
                      instance.disableFeatures([
                          instance.Feature.Annotations,
                          instance.Feature.Download,
                          instance.Feature.FilePicker,
                          instance.Feature.Measurement,
                          instance.Feature.NotesPanel,
                          instance.Feature.Redaction,
                      ]);

                      webViewer.current = instance;
                      docViewer.current = instance.docViewer;
                      docViewer.current.setSearchHighlightColors({
                          activeSearchResult: 'rgba(255, 218, 0, 0.75)',
                          searchResult: 'rgba(255, 218, 0, 0.75)',
                      });
                  });
    }, [useServer, pdftronLicense, serverUrl]);

    const reset = () => {
        if (webViewer.current != null && document.current != null) {
            document.current = null;
            if (webViewer.current.closeDocument) {
                webViewer.current.closeDocument();
            }
        }
    };

    React.useEffect(() => {
        initializeWebViewer();
    }, [initializeWebViewer]);

    React.useEffect(() => {
        reset();
    }, [clear, fileId, fileName]);

    React.useEffect(() => {
        if (document.current != null && options != null) {
            documentSearch(options.term);
        }
    }, [documentSearch, options]);

    React.useEffect(() => {
        if (webViewer.current != null) {
            documentLoad();
        }
    }, [documentLoad]);

    const isSupported = extensionSupported(fileName);
    return (
        <React.Fragment>
            <div ref={viewerRef} className={cn(classes.viewer, { [classes.visible]: isSupported })}></div>
            <div className={cn(classes.viewer, { [classes.visible]: !isSupported })}>
                <div className={classes.notSupportedPane}>
                    <i className="fas fa-exclamation-triangle"></i>
                    <div className="message">
                        <p>
                            <strong>This File Type Is Not Supported</strong>
                        </p>
                        <p>This type of file is not supported by the file viewer. If you wish to view the file, download it to your device and open it in the application of your choice.</p>
                    </div>
                    <Downloader useApiResource={true} uri={`/files/${fileId}`}>
                        <i className="fas fa-file-download"></i>
                        <span>Download</span>
                    </Downloader>
                </div>
            </div>
            {messages != null &&
                Object.keys(messages).map((key) => (
                    <NotificationBar open={true} key={key} variant="info" onClose={handleNotificationClose(key)}>
                        {messages[key].title && (
                            <p>
                                <strong>{messages[key].title}</strong>
                            </p>
                        )}
                        {messages[key].message}
                    </NotificationBar>
                ))}
        </React.Fragment>
    );
};

export default withStyles(styles)(FileViewer);
