import React from 'react';
import { useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';

import _orderBy from 'lodash/orderBy';

import DatePicker from 'components/Form/DatePicker';
import { SelectList, mapSelectOptions } from 'components/Form';
import InputContainer from 'components/Form/Panels/InputContainer';
import BadgeList from 'components/Form/BadgeList';
import CountrySearch from 'components/Search/CountrySearch';
import PublisherSearch from 'components/Search/PublisherSearch';
import CompanySearch from 'components/Search/CompanySearch';

import { sort } from 'Utils/listHelper';

const styles = (theme) => ({
    actions: {
        display: 'flex',
        justifyContent: 'flex-end',
        flexBasis: 46,
        flexGrow: 0,
        flexShrink: 0,
        paddingTop: 10,
        '& button': {
            marginLeft: 10,
        },
    },
    datePickerRoot: {
        width: '100%',
    },
    dateSeperator: {
        display: 'flex',
        fontWeight: 700,
        justifyContent: 'center',
        margin: '12px 0 0 0',
    },
    listContainer: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr 1fr',
        gridTemplateRows: '1fr',
    },
    taggerFullscreen: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-start',
    },
    title: {
        color: 'rgba(0, 0, 0, 0.58)',
        flexBasis: 40,
        flexGrow: 0,
        flexShrink: 0,
        fontSize: 14,
        fontWeight: 700,
        paddingTop: 16,
    },
});

export const optionValues = Object.freeze({
    DEFAULT: null,
    INCLUDE: 'include',
    EXCLUDE: 'exclude',
});

const listStates = [
    { component: <i className="far fa-plus-square"></i>, value: optionValues.INCLUDE },
    { component: <i className="far fa-minus-square"></i>, value: optionValues.EXCLUDE },
];

const mapDocumentSources = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.DocumentSourceID, item.Name));
const mapKeyIssues = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.KeyIssueID, item.KeyIssueName));
const mapGICSSectors = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.SectorID, item.Name));
const mapTeams = (items) => mapSelectOptions(items, (item, mapper) => mapper(item.TeamID, item.TeamName));
const mapStrings = (items) => mapSelectOptions(items, (item, mapper) => mapper(item, item));

const sortKeyIssues = (issues) => {
    return _orderBy(
        issues.map((o) => ({
            ...o,
            SortBy: o.KeyIssueName === 'Other' ? null : Boolean(o.IsDeprecated) ? 0 : 1,
        })),
        ['SortBy', (o) => o.KeyIssueName.toLowerCase()],
        ['asc', 'asc']
    );
};

const FileSearch = ({ classes, data = {}, onChange }) => {
    const stateDocumentSources = useSelector((state) => mapDocumentSources(state.DimensionReducer.DocumentSources));
    const stateGICSSectors = useSelector((state) => mapGICSSectors(state.DimensionReducer.GICSSectors));
    const stateEnvKeyIssues = useSelector((state) => mapKeyIssues(sortKeyIssues(state.DimensionReducer.KeyIssues.ab.environment)));
    const stateGovKeyIssues = useSelector((state) => mapKeyIssues(sortKeyIssues(state.DimensionReducer.KeyIssues.ab.governance)));
    const stateSocKeyIssues = useSelector((state) => mapKeyIssues(sortKeyIssues(state.DimensionReducer.KeyIssues.ab.social)));
    const stateOtherDocumentTypes = useSelector((state) => mapStrings(state.DimensionReducer.OtherDocumentTypes));
    const stateRegions = useSelector((state) => mapStrings(state.DimensionReducer.Regions));
    const stateTeams = useSelector((state) => mapTeams(state.DimensionReducer.Teams.filter((team) => team.TeamName !== 'EIMT')));

    const [dateRange, setDateRange] = React.useState({ End: null, Start: null });
    const [countries, setCountries] = React.useState([]);
    const [publishers, setPublishers] = React.useState([]);
    const [companies, setCompanies] = React.useState([]);

    const raiseOnChange = React.useCallback(
        (value) => {
            const newData = { ...data, ...value };

            if (onChange != null) {
                onChange({
                    ...Object.keys(newData).reduce((acc, key) => {
                        const d = newData[key];
                        const isNullOrEmpty = (Array.isArray(d) && d.length === 0) || d == null || d === '';
                        if (!isNullOrEmpty) {
                            acc[key] = d;
                        }
                        return acc;
                    }, {}),
                });
            }
        },
        [data, onChange]
    );

    const handleDateInputChange = (dateType) => (value) => {
        const dateValue = value != null ? value.toJSDate() : value;

        const date = {
            Start: dateType === 'Start' ? dateValue : dateRange.Start,
            End: dateType === 'End' ? dateValue : dateRange.End,
        };
        setDateRange(date);
        raiseOnChange({ createdDate: date });
    };
    const handleListChange = (name, value) => raiseOnChange({ [name]: value });

    const handleCountryDelete = (item) => raiseOnChange({ countries: countries.filter((c) => c.id !== item.id) });
    const handleCompanyDelete = (item) => raiseOnChange({ companies: companies.filter((c) => c.id !== item.id) });
    const handlePublisherDelete = (item) => raiseOnChange({ publishers: publishers.filter((p) => p.id !== item.id) });

    const handleCountrySearch = (value) => raiseOnChange({ countries: updateArray({ id: value.CountryID, name: value.Name, value: 'include' }, countries) });
    const handleCompanySearch = (value) =>
        raiseOnChange({ companies: updateArray({ id: value.CompanyID, name: `${value.CompanyName} (${value.Ticker})`, value: 'include' }, companies) });
    const handlePublisherSearch = (value) =>
        raiseOnChange({ publishers: updateArray({ id: value.PublisherID, name: value.Name, value: 'include' }, publishers) });

    const updateArray = (item, list) => {
        const found = list.find((i) => i.id === item.id);
        const newList = found == null ? [...list, item] : [...list];
        return newList.sort(sort('name'));
    };

    React.useEffect(() => {
        setCountries(data.countries || []);
        setPublishers(data.publishers || []);
        setCompanies(data.companies || []);
        setDateRange(data.createdDate || { End: null, Start: null });
    }, [setCountries, setPublishers, setCompanies, setDateRange, data.countries, data.publishers, data.companies, data.createdDate]);

    return (
        <div className={classes.taggerFullscreen}>
            <div className={classes.title}>Search Categories:</div>
            <div className={classes.listContainer}>
                <SelectList
                    name="documentSources"
                    options={stateDocumentSources}
                    values={data.documentSources}
                    onChange={handleListChange}
                    title="Document Source"
                    valueStates={listStates}
                />
                <SelectList
                    name="otherDocumentTypes"
                    options={stateOtherDocumentTypes}
                    values={data.otherDocumentTypes}
                    onChange={handleListChange}
                    title="Document Types"
                    valueStates={listStates}
                />
                <InputContainer
                    title={'Created Date'}
                    styles={{
                        controls: {
                            flexDirection: 'column',
                            maxWidth: 250,
                            margin: '0 12px',
                            height: 150,
                        },
                    }}
                >
                    <DatePicker
                        classes={{ root: classes.datePickerRoot }}
                        value={dateRange != null ? dateRange.Start : undefined}
                        maxDate={dateRange != null && dateRange.End != null ? dateRange.End : undefined}
                        onChange={handleDateInputChange('Start')}
                        animateYearScrolling={false}
                        disableFuture={false}
                        InputProps={{ style: { fontSize: 12 } }}
                        maxDateMessage="Date should not be after End date"
                    />
                    <div className={classes.dateSeperator}>TO</div>
                    <DatePicker
                        classes={{ root: classes.datePickerRoot }}
                        value={dateRange != null ? dateRange.End : undefined}
                        minDate={dateRange != null && dateRange.Start != null ? dateRange.Start : undefined}
                        onChange={handleDateInputChange('End')}
                        animateYearScrolling={false}
                        disableFuture={false}
                        InputProps={{ style: { fontSize: 12 } }}
                        minDateMessage="Date should not be before Start date"
                    />
                </InputContainer>
                <BadgeList data={countries} title="Country" onDelete={handleCountryDelete}>
                    <CountrySearch onSearch={handleCountrySearch} closeOnSearch={false} selected={data.countries} />
                </BadgeList>
                <BadgeList data={companies} title="Company" onDelete={handleCompanyDelete}>
                    <CompanySearch onSearch={handleCompanySearch} />
                </BadgeList>
                <BadgeList data={publishers} title="Publisher" onDelete={handlePublisherDelete}>
                    <PublisherSearch onSearch={handlePublisherSearch} closeOnSearch={false} selected={data.publishers} />
                </BadgeList>
                <SelectList
                    name="environment"
                    options={stateEnvKeyIssues}
                    values={data.environment}
                    onChange={handleListChange}
                    title="Environmental Key Issues"
                    valueStates={listStates}
                />
                <SelectList
                    name="social"
                    options={stateSocKeyIssues}
                    values={data.social}
                    onChange={handleListChange}
                    title="Social Key Issues"
                    valueStates={listStates}
                />
                <SelectList
                    name="governance"
                    options={stateGovKeyIssues}
                    values={data.governance}
                    onChange={handleListChange}
                    title="Governance Key Issues"
                    valueStates={listStates}
                />
                <SelectList name="regions" options={stateRegions} values={data.regions} onChange={handleListChange} title="Regions" valueStates={listStates} />
                <SelectList
                    name="gicsSectors"
                    options={stateGICSSectors}
                    values={data.gicsSectors}
                    onChange={handleListChange}
                    title="GICS Sectors"
                    valueStates={listStates}
                />
                <SelectList name="teams" options={stateTeams} values={data.teams} onChange={handleListChange} title="Teams" valueStates={listStates} />
            </div>
        </div>
    );
};
// FileSearch.whyDidYouRender = {
//     customName: 'FileTags'
// }
export default withStyles(styles)(React.memo(FileSearch));
