import axios from 'axios';
import _get from 'lodash/get';

export const uploadFile = (fileData, formData, onUpdate, onSuccess, onError, onComplete, fileInfoCallback) => {
    const item = fileData.file;
    const categories = fileData.categories;
    const { vendor, domain, subdomain, ...formDataRest } = (formData || {});
    const form = new FormData();

    form.append('file', item.file);
    form.append('vendor', vendor != null ? vendor : 'AB');
    form.append('domain', domain != null ? domain : 'ESIGHT');
    form.append('subdomain', subdomain != null ? subdomain : 'KnowledgeCenter::Upload');
    if (formDataRest != null) {
        Object.keys(formDataRest).forEach(key => {
            form.append(key, formDataRest[key]);
        });
    }

    if (fileData.synopsis != null) {
        form.append('synopsis', fileData.synopsis);
    }

    if (categories != null) {
        Object.keys(categories).forEach(key => {
            const category = categories[key];

            const values = Array.isArray(category)
                ? category
                    .filter(i => i.value != null && _get(i, 'data.isNew', false) !== true)
                    .map(i => i.id)
                : category;

            const newValues = Array.isArray(category)
                ? category
                    .filter(c => _get(c, 'data.isNew', false) === true)
                : [];

            form.append(key, values);
            if (newValues.length > 0) {
                form.append(key + 'New', JSON.stringify(newValues));
            }
        });
    }

    if (item.isNew && (item.isValid || item.isValid == null)) {
        item.isUploading = true;

        if (onUpdate != null) onUpdate(item);

        return axios.post('files', form, { timeout: 120000, })
            .then(({ data }) => {
                if (fileInfoCallback != null) {

                    const resData = data.Hits[0];
                    fileInfoCallback({
                        path: resData.Id, 
                        fileID: resData.Id,
                        fileName: `${resData.FileName}`
                    });
                }
                if (onSuccess != null) onSuccess(item);
            })
            .catch((error) => {
                if (onError != null) onError(item, error);
            })
            .finally(() => {
                if (onComplete != null) onComplete();
            });
    }
    return Promise.resolve();
}
