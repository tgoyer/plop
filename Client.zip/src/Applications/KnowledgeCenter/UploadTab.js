import React from 'react';
import cn from 'classnames';
import Dropzone from 'react-dropzone';
import NavigationPrompt from 'react-router-navigation-prompt';
import { useDispatch, useSelector } from 'react-redux';

import _get from 'lodash/get';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import Button from '../../componentlibrary/buttons/Button';
import { Popover } from '../../components/Dialogs';

import ErrorDialog from '../../UIComponents/MaterialUI/CommonErrorDialog';
import UploadStepper from './UploadTab/UploadStepper';
import { uploadFile } from './FileManager/utilities';

import { getPublishers } from '../../store/DimensionModule';
import { clearSearchFilesByName, getRecentFiles, searchFilesByName } from '../../store/FileModule';

import { generateId } from '../../Utils/layoutHelper';
import { formatByteSize } from '../../Utils/numberHelper';

const styles = (theme) => ({
    attachmentContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
    },
    button: {
        marginBottom: theme.spacing(2),
        marginTop: theme.spacing(2),
        '&:disabled': {
            backgroundColor: '#cccccc',
            boxShadow: 'none',
        },
    },
    dropZone: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 25,

        background: '#fefefe',
        border: '1px solid #dddddd',
        borderRadius: 4,
    },
    iconUpload: {
        fontSize: 32,
        padding: '0 15px 0 0',
    },
    previewPaper: {
        padding: 8,
        visibility: 'visible',
        width: 'calc(100% - 20px)',
    },
    previewPaperHidden: {
        height: 0,
        visibility: 'hidden',
        width: 0,
    },
    results: {
        height: 'calc(100vh - 155px)',
        overflowY: 'auto',
    },
    resultsTable: {
        border: 0,
        borderCollapse: 'collapse',
        fontSize: 12,
        width: '100%',
        '& thead th': {
            backgroundColor: '#6987B9',
            color: '#ffffff',
            fontWeight: 700,
            padding: '4px 8px',
            textAlign: 'center',
        },
        '& tbody tr': {
            '&:nth-child(odd)': {
                backgroundColor: '#eee',
            },
            backgroundColor: '#fafafa',
        },
        '& tbody td': {
            border: '2px solid #ffffff',
            color: '#000000',
            fontWeight: 400,
            margin: 2,
            padding: '4px 8px',
        },
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '0 0 25px 0',
        padding: 5,
    },
    tagger: {
        maxHeight: 1100,
    },
});

const UploadTab = ({ classes, title, showResultPane, fileUploadOnStart, fileUploadCallback }) => {
    const dispatch = useDispatch();
    const [droppedFiles, setDroppedFiles] = React.useState([]);
    const [errorMessages, setErrorMessages] = React.useState([]);
    const [isUploading, setIsUploading] = React.useState(false);
    const [showFileStepper, setShowFileStepper] = React.useState(false);
    const [fileMap, setFileMap] = React.useState({});

    const searchFiles = useSelector((state) => state.FileReducer.SearchFilesByName);

    const dropZoneRef = React.useRef();
    const maxFileSize = useSelector((state) => _get(state, 'AppSettingsReducer.ServerSettings.Attachments.FileSizeLimitInKB'));
    const maxFileCount = useSelector((state) => _get(state, 'AppSettingsReducer.ServerSettings.Attachments.MaxFiles'));

    const getRecentFilesDispatch = React.useCallback(() => {
        dispatch(getRecentFiles());
    }, [dispatch]);

    const getValidIcon = (item) => {
        return item == null ? null : item.isNew && !item.isUploading ? (
            <i className="fas fa-ellipsis-h"></i>
        ) : item.isUploading ? (
            <i className="fas fa-circle-notch fa-spin"></i>
        ) : item.isValid ? (
            <i className="fas fa-check" style={{ color: 'green' }}></i>
        ) : (
            <i className="fas fa-times" style={{ color: 'red' }}></i>
        );
    };

    const handleCancel = () => setFileMap({});
    const handleComplete = (data) => {
        setShowFileStepper(false);
        setIsUploading(true);
        performUpload(data);
        setIsUploading(false);
    };

    const handleDrop = (files) => {
        if (files.length > maxFileCount) {
            setErrorMessages(['Max number of files exceeded.  Maximum allowed files is ' + maxFileCount]);
            return;
        }

        dispatch(searchFilesByName(files.map((file) => file.name)));
        setDroppedFiles(files);
    };

    const handleErrorClose = () => setErrorMessages([]);
    const handleNavigationConfirm = () => setIsUploading(false);
    const handleNavigationClose = () => {};

    const performUpload = (data) => {
        const actions = data.map((dataItem) => {
            return uploadFile(
                dataItem,
                null,
                (item) => {
                    if (fileUploadOnStart != null) fileUploadOnStart();
                    setFileMap({ ...fileMap });
                },
                (item) => {
                    item.isNew = false;
                    item.isUploading = false;
                    item.isValid = true;
                    item.message = 'Upload successful';
                    setFileMap({ ...fileMap });
                },
                (item, error) => {
                    item.isNew = false;
                    item.isUploading = false;
                    item.isValid = false;
                    item.message = 'Error uploading.';
                    setFileMap({ ...fileMap });
                },
                () => dispatch(getPublishers(true)),
                (uploadedFileData) => fileUploadCallback(uploadedFileData)
            );
        });
        return Promise.all(actions).then(() => {
            getRecentFilesDispatch();
            setFileMap({ ...fileMap });
        });
    };

    const processFiles = React.useCallback(
        (droppedFiles, duplicates) => {
            const getDuplicateFile = (file) => duplicates.find((df) => df.FileName === file.name);
            const checkFileSize = (file, maxSize) => file.size <= Number(maxSize) && file.size >= 1;

            const newMap = droppedFiles.reduce((acc, file) => {
                const invalidSize = !checkFileSize(file, maxFileSize);
                const dupFile = getDuplicateFile(file);
                const isDuplicate = dupFile != null;

                acc[file.name] = {
                    id: generateId(),
                    file,
                    isNew: true,
                    isUploading: false,
                    isValid: invalidSize ? false : null,
                    isWarning: isDuplicate,
                    message: invalidSize
                        ? `File cannot be larger than ${formatByteSize(maxFileSize)} or less than 1 B file.`
                        : isDuplicate
                        ? `A file with this name has already been uploaded by ${_get(dupFile, 'External.UploadedBy.FullName', 'Unknown')}. You may continue to upload your file.`
                        : null,
                };

                return acc;
            }, {});

            setFileMap(newMap);
            setShowFileStepper(true);
        },
        [maxFileSize]
    );

    React.useEffect(() => {
        if (searchFiles.isLoaded) {
            processFiles(droppedFiles, searchFiles.Hits);
        }
    }, [searchFiles, droppedFiles, processFiles]);

    React.useEffect(() => {
        return () => {
            dispatch(clearSearchFilesByName());
        };
    }, [dispatch]);

    return (
        <div className="row up" style={{ margin: 0 }}>
            <div className={classes.attachmentContainer}>
                {title != null && <div className={classes.sectionHeader}>{title}</div>}
                <Dropzone
                    ref={dropZoneRef}
                    disableClick={true}
                    onDrop={handleDrop}
                    style={{
                        backgroundColor: '#eeeeee',
                        padding: 8,
                    }}
                    activeStyle={{
                        backgroundColor: '#dce3ef',
                        border: '3px dashed #6987B9',
                    }}
                    multiple
                >
                    {({ getRootProps }) => (
                        <div className={classes.dropZone} {...getRootProps()}>
                            <i className={cn(classes.iconUpload, 'fas fa-file-upload')}></i>
                            <span>
                                Drag and drop one or more files directly into this box to add them to the Knowledge Center. You can also press the <strong>Attach Files</strong> button below to bring
                                up a file browser.
                            </span>
                        </div>
                    )}
                </Dropzone>
                <Button onClick={() => dropZoneRef.current.open()}>Attach Files</Button>
            </div>
            <div>
                {showResultPane && fileMap != null && Object.keys(fileMap).length > 0 && (
                    <Paper className={cn(classes.previewPaper, classes.results)}>
                        <div className={classes.sectionHeader}>Upload Result</div>
                        <table className={classes.resultsTable}>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Size</th>
                                    <th>Status</th>
                                    <th>Result</th>
                                </tr>
                            </thead>
                            <tbody>
                                {Object.keys(fileMap).map((key) => (
                                    <tr key={key}>
                                        <td>{fileMap[key].file.name}</td>
                                        <td align="right">{formatByteSize(fileMap[key].file.size)}</td>
                                        <td align="center">{getValidIcon(fileMap[key])}</td>
                                        <td>{fileMap[key].message != null && String(fileMap[key].message)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </Paper>
                )}
            </div>

            <ErrorDialog onClose={handleErrorClose} messages={errorMessages} />

            <UploadStepper onCancel={handleCancel} onComplete={handleComplete} show={showFileStepper} files={fileMap} />

            <NavigationPrompt when={isUploading} afterClose={handleNavigationClose} afterConfirm={handleNavigationConfirm}>
                {({ isActive, onCancel, onConfirm }) => {
                    return isActive ? (
                        <Popover title="Wait!" open={isActive} onConfirm={onConfirm} onClose={onCancel}>
                            <span style={{ color: '#990000', marginBottom: 5 }}>You have uploads in progress!</span>
                            <br />
                            <span style={{ color: '#000000' }}>If you continue, the upload will be interrupted. Do you want to continue?</span>
                        </Popover>
                    ) : null;
                }}
            </NavigationPrompt>
        </div>
    );
};

export default withStyles(styles)(UploadTab);
