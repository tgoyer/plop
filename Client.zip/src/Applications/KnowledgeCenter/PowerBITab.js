import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';
import SearchableDropdown from '../../UIComponents/MaterialUI/SearchableDropdown';
import { getPowerBIURLs } from '../../store/DimensionModule';
import { toOptionsList } from '../../Utils/selectHelper';
import { isMobileBrowser } from '../../Utils/layoutHelper';

const isMobile = isMobileBrowser();
const styles = (theme) => ({
    notSupportedMessage: {
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'center',
        padding: '20px 50px',
        height: '50%',
        width: '50%',
        '& .fa-exclamation-triangle': {
            color: '#f08f50',
            fontSize: 75,
            margin: 0,
        },
        '& .message': {
            marginTop: 20,
        },
        '& .button': {
            margin: '20px 0',
            '& i': {
                fontSize: 24,
                marginRight: 12,
            },
            '& span': {
                fontWeight: 700,
            },
        },
    },
    notSupportedPane: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',

        margin: '10px 0 0 0',
        padding: 8,
        height: 'calc(100vh - 215px)',
        visibility: 'visible',
        width: 'calc(100% - 20px)',
        '& iframe': {
            padding: '10px 0 0 0',
            border: 0,
            height: '100%',
            width: '100%',
        },
        '@media (max-width: 1199px)': {
            width: '100%',
        },
    },
    report: {
        margin: '10px 0 0 0',
        padding: 8,
        height: 'calc(100vh - 215px)',
        visibility: 'visible',
        width: 'calc(100% - 20px)',
        '& iframe': {
            padding: '10px 0 0 0',
            border: 0,
            height: '100%',
            width: '100%',
        },
        '@media (max-width: 1199px)': {
            width: '100%',
        },
    },
    urlSelector: {
        margin: 0,
        padding: 8,
        height: 50,
        width: 'calc(50% - 20px)',
        '@media (max-width: 1199px)': {
            width: '100%',
        },
    },
});

const HomeTab = ({ classes }) => {
    const dispatch = useDispatch();
    const [selectedReportUrl, setSelectedReportUrl] = React.useState(null);

    React.useEffect(() => {
        dispatch(getPowerBIURLs());
    }, [dispatch]);

    const urls = toOptionsList(
        useSelector((store) => store.DimensionReducer.PowerBIUrls.Data),
        'Name',
        'URL'
    );

    const selectionChanged = () => async (item) => {
        setSelectedReportUrl(item?.value);
    };

    return isMobile ? (
        <div className={classes.notSupportedPane}>
            <Paper className={classes.notSupportedMessage}>
                <i className="fas fa-exclamation-triangle"></i>
                <div className="message">
                    <p>
                        <strong>Power BI is not supported on your device.</strong>
                    </p>
                    <p>
                        The Power BI reports are not supported on mobile devices. If you would like to view the reports, please open ESIGHT in the Chrome
                        browser on your desktop.
                    </p>
                </div>
            </Paper>
        </div>
    ) : (
        <React.Fragment>
            <Paper className={classes.urlSelector}>
                <SearchableDropdown id="url" placeholder={'Select Report'} dropdownItems={urls} onChange={selectionChanged()} />
            </Paper>
            {selectedReportUrl && (
                <Paper className={classes.report}>
                    <iframe title="Power BI Reports" src={selectedReportUrl} />
                </Paper>
            )}
        </React.Fragment>
    );
};

export default withStyles(styles)(HomeTab);
