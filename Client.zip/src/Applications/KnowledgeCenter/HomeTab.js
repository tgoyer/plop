import React from 'react';
import cn from 'classnames';

import { useDispatch, useSelector } from 'react-redux';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import Announcements from './HomeTab/Announcements';
import DynamicTab from './HomeTab/DynamicTab';
import SectorGuides from './HomeTab/SectorGuides';

import MyFavorites from './HomeTab/MyFavorites';
import MostPopular from './HomeTab/MostPopular';
import MyUploads from './HomeTab/MyUploads';
import RecentUploads from './HomeTab/RecentUploads';
import TopSearchByKeyword from './HomeTab/TopSearchByKeyword';
import TopSearchByTag from './HomeTab/TopSearchByTag';

import { Heading, TabHeading } from '../../components/Content';
import Tabs from '../../componentlibrary/tabs/Tabs';

import { getSearchMetrics } from '../../store/FileModule';

const styles = (theme) => ({
    paper: {
        margin: 0,
        padding: 8,
        visibility: 'visible',
        width: '100%',
        '& p': {
            marginLeft: 10,
            marginRight: 10,
        },
        '&:last-child': {
            marginBottom: 0,
        },
    },
    tabs: {
        padding: '0 8px',
    },
    gridsContainer: {
        marginTop: 20,
    },
    panelColumn: {
        '& > div + div': {
            marginTop: 12,
        },
    },
    viewContainer: {
        display: 'flex',
        flexDirection: 'column',
        '& > div + div': {
            marginTop: 12,
        },
    },
    '@media (min-width: 1450px)': {
        gridsContainer: {
            marginTop: 0,
        },
        viewContainer: {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            '& > div': {
                flex: '1 1 50%',
            },
            '& > div + div': {
                marginLeft: 12,
                marginTop: 0,
            },
        },
    },
});

const HomeTab = ({ classes }) => {
    const dispatch = useDispatch();
    const content = useSelector((state) => state.ContentReducer.Content);

    React.useEffect(() => {
        dispatch(getSearchMetrics());
    }, [dispatch]);

    const getTabs = () => {
        return content.Tabs.map((tab) => ({ label: tab.Name, component: () => <DynamicTab tab={tab} key={tab.TabID} /> }));
    };

    return (
        <div className={classes.viewContainer}>
            <div className={classes.panelColumn}>
                <Paper className={cn(classes.paper, classes.fileGrid)}>
                    <Tabs
                        className={classes.tabs}
                        tabs={[{ label: 'Announcements', component: () => <Announcements /> }, ...getTabs(), { label: 'Best-Practices Guides', component: () => <SectorGuides /> }]}
                    />
                </Paper>
            </div>
            <div className={cn(classes.panelColumn, classes.gridsContainer)}>
                <Paper className={cn(classes.paper, classes.fileGrid)}>
                    <Heading title="My Favorites" />
                    <MyFavorites />
                </Paper>
                <Paper className={cn(classes.paper, classes.fileGrid)}>
                    <TabHeading
                        title="Uploads"
                        tabs={[
                            { label: 'Recent', component: () => <RecentUploads /> },
                            { label: 'Most Popular', component: () => <MostPopular /> },
                            { label: 'Mine', component: () => <MyUploads /> },
                        ]}
                    />
                </Paper>
                <Paper className={cn(classes.paper, classes.fileGrid)}>
                    <TabHeading
                        title="Top Searches"
                        tabs={[
                            { label: 'By Category', component: () => <TopSearchByTag /> },
                            { label: 'By Keyword', component: () => <TopSearchByKeyword /> },
                        ]}
                    />
                </Paper>
            </div>
        </div>
    );
};

export default withStyles(styles)(HomeTab);
