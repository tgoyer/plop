import React from 'react';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    actions: {
        display: 'flex',
        justifyContent: 'flex-end',
        flexGrow: 0,
        flexBasis: 40,
        paddingTop: 10,
        '& button': {
            marginLeft: 10
        }
    },
    listContainer: {
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'column',
        flexGrow: 1,
        height: '100%',
        overflowX: 'hidden',
        overflowY: 'auto',
        marginTop: 20,
    },
    taggerFullscreen: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
    },
});

const Summary = ({ actions, children, classes }) => {
    return (
        <div className={classes.taggerFullscreen}>
            <div className={classes.listContainer}>
                { children }
            </div>
            { actions != null && (
                <div className={classes.actions}>
                    { actions }
                </div>
            )}
        </div>
    )
}

export default withStyles(styles)(
    React.memo(Summary)
);