import React from 'react';

import _get from 'lodash/get';
import _transform from 'lodash/transform';

import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import Stepper from '@material-ui/core/Stepper';
import { withStyles } from '@material-ui/core/styles';

import { Button, ButtonTypes } from '../../../components/Form';
import { Popover, DialogSizes } from '../../../components/Dialogs';

import FileTags from '../FileManager/FileTags';
import Summary from './Summary';
import { esgTypes } from '../utilities';

import { pluckFields } from '../../../Utils/objectHelpers';

const styles = (theme) => ({
    root: {
        width: '90%',
    },
    body: {
        flexGrow: 1,
        height: '100%',
    },
    container: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
    },
    connectorActive: {
        '& $connectorLine': {
            borderColor: theme.palette.secondary.main,
        },
    },
    connectorCompleted: {
        '& $connectorLine': {
            borderColor: theme.palette.primary.main,
        },
    },
    connectorDisabled: {
        '& $connectorLine': {
            borderColor: theme.palette.grey[100],
        },
    },
    connectorLine: {
        transition: theme.transitions.create('border-color'),
    },
    summaryMessage: {
        fontWeight: 700,
    },
});

const buildSteps = (fileMap, defaultValues) => {
    return _transform(
        fileMap,
        (acc, file) => {
            if (file.isNew) {
                acc.push({
                    label: file.file.name,
                    file: file,
                    ...(defaultValues || {}),
                });
            }
            return acc;
        },
        []
    );
};

const UploadStepper = ({ classes, defaultValues, files, onComplete, onCancel, show }) => {
    const [activeStep, setActiveStep] = React.useState(0);
    const [fileMap, setFileMap] = React.useState({});
    const [steps, setSteps] = React.useState([]);

    const newFileCount = React.useMemo(() => {
        return Object.keys(fileMap).reduce((acc, key) => (acc += fileMap[key].isNew ? 1 : 0), 0);
    }, [fileMap]);

    const cleanFileMap = () => {
        return _transform(
            fileMap,
            (acc, value, key) => {
                if (value.isNew) delete acc[key];
                return acc;
            },
            { ...fileMap }
        );
    };

    const handleComplete = (evt) => {
        const buildCategories = (step) => {
            return Object.keys(step).reduce((acc, key) => {
                const value = step[key];
                const isKeyIssue = esgTypes.indexOf(key) >= 0;
                if (isKeyIssue) {
                    acc['keyIssues'] = [...(acc['keyIssues'] || []), ...value];
                } else {
                    acc[key] = value;
                }

                return acc;
            }, {});
        };

        const builtSteps = steps.map((step) => {
            const [values, rest] = pluckFields(step, ['categories', 'label', 'file', 'synopsis']);
            return {
                ...values,
                categories: buildCategories(rest),
            };
        });
        onComplete(builtSteps);
    };

    const handleChange = (data) => {
        const newSteps = [...steps];
        newSteps[activeStep] = data;
        setSteps(newSteps);
    };

    const handleNext = () => setActiveStep(activeStep + 1);
    const handlePrevious = () => setActiveStep(activeStep - 1);
    const handleUploadClose = () => {
        const newMap = cleanFileMap();
        setFileMap({ ...newMap });
        if (onCancel) {
            onCancel(newMap);
        }
    };

    const isValid = () => {
        return _get(steps[activeStep], 'documentSources', []).reduce((acc, item) => {
            return acc || item.value != null;
        }, false);
    };

    React.useEffect(() => {
        if (!show) {
            setActiveStep(0);
        }
    }, [show]);

    React.useEffect(() => {
        setFileMap(files);
        setSteps(buildSteps(files, defaultValues));
    }, [files, defaultValues]);

    return (
        newFileCount > 0 && (
            <Popover
                onClose={handleUploadClose}
                show={show}
                title="Categorize Files for Upload"
                size={DialogSizes.FULL}
                lockHeight={true}
                className={classes.tagger}
                actions={
                    activeStep < steps.length ? (
                        <React.Fragment>
                            <Button type={ButtonTypes.SECONDARY} onClick={handlePrevious} className={classes.button} disabled={activeStep === 0}>
                                Previous
                            </Button>
                            <Button type={ButtonTypes.PRIMARY} onClick={handleNext} disabled={!isValid()} className={classes.button}>
                                Next
                            </Button>
                        </React.Fragment>
                    ) : (
                        <React.Fragment>
                            <Button type={ButtonTypes.SECONDARY} onClick={handlePrevious} className={classes.button}>
                                Previous
                            </Button>
                            <Button type={ButtonTypes.PRIMARY} onClick={handleComplete} className={classes.button}>
                                Upload Files
                            </Button>
                        </React.Fragment>
                    )
                }
            >
                <div className={classes.container}>
                    <div className={classes.header}>
                        <Stepper
                            alternativeLabel={true}
                            activeStep={activeStep}
                            connector={
                                <StepConnector
                                    classes={{
                                        active: classes.connectorActive,
                                        completed: classes.connectorCompleted,
                                        disabled: classes.connectorDisabled,
                                        line: classes.connectorLine,
                                    }}
                                />
                            }
                        >
                            {steps.map((step, idx) => (
                                <Step key={idx}>
                                    <StepLabel>{step.label}</StepLabel>
                                </Step>
                            ))}
                            <Step key="upload_files">
                                <StepLabel>Verify and Complete Upload</StepLabel>
                            </Step>
                        </Stepper>
                    </div>
                    <div className={classes.body}>
                        {activeStep < steps.length ? (
                            <FileTags key={activeStep} data={steps[activeStep]} onChange={handleChange} />
                        ) : (
                            <Summary>
                                <p className={classes.summaryMessage}>
                                    All files have been categorized. If you are satified with what you have entered, press the "Upload Files" button below.
                                </p>
                            </Summary>
                        )}
                    </div>
                </div>
            </Popover>
        )
    );
};

export default withStyles(styles)(React.memo(UploadStepper));
