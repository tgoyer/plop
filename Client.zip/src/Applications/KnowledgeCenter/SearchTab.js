import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import DesktopView from './SearchTab/DesktopView';
import MobileView from './SearchTab/MobileView';

import { setKnowledgeCenterSettings } from '../../store/AppSettingsModule';
import { getFileDefinitions } from '../../store/FileModule';
import { isMobileBrowser } from '../../Utils/layoutHelper';

const SearchTab = () => {
    const dispatch = useDispatch();
    const [ fileId, setFileId ] = React.useState(null);
    const [ fileName, setFileName ] = React.useState(null);
    const [ fileViewerOptions, setFileViewerOptions ] = React.useState(null);
    const [ searchData, setSearchData ] = React.useState({ query: '' });
    const [ showDocument, setShowDocument ] = React.useState(false);
    const isMobile = isMobileBrowser();

    const data = useSelector(state => state.FileReducer.Files.Data);
    const ids = useSelector(state => state.FileReducer.SearchFiles.Data);
    const isLoading = useSelector(state => state.FileReducer.SearchFiles.isLoading);
    const isLoaded = useSelector(state => state.FileReducer.SearchFiles.isLoaded);
    const settings = useSelector(state => state.AppSettingsReducer.KnowledgeCenter);
    const totalCount = useSelector(state => state.FileReducer.SearchFiles.Count);
    const files = getFileDefinitions(ids, data);

    const setKnowledgeCenterSettingsDispatch = React.useCallback((settings) => {
        dispatch(setKnowledgeCenterSettings(settings))
    }, [dispatch])

    const handleSearchClear = () => {
        setShowDocument(false);
    }

    const handleSearchSubmit = (options) => {
        setKnowledgeCenterSettingsDispatch({ SearchData: options });
        setFileViewerOptions(null);
    }

    const loadState = (file, highlights, snippet) => {
        if (file != null) {
            setFileId(file.Id);
            setFileName(file.FileName);
            setShowDocument(true);
            setFileViewerOptions({ term: snippet, highlights });
        }
    }

    React.useEffect(() => {
        const data = settings.SearchData || { query: '' };
        setSearchData(data);
    }, [settings.SearchData]);

    React.useLayoutEffect(() => {
        const { ExpandedFile, Highlights, Snippet } = settings;
        if (ExpandedFile != null) {
            loadState(ExpandedFile, Highlights, Snippet);
        }
    }, [ settings ]);

    return isMobile ? (
        <MobileView 
            fileId={fileId}
            fileName={fileName}
            files={files}
            fileViewerOptions={fileViewerOptions} 
            searchData={searchData}
            searchTotal={totalCount}
            showDocument={showDocument}
            isLoading={isLoading}
            isLoaded={isLoaded}
            onSearchSubmit={handleSearchSubmit} 
            onSearchClear={handleSearchClear}
        />
    ) : (
        <DesktopView 
            fileId={fileId}
            fileName={fileName}
            files={files}
            fileViewerOptions={fileViewerOptions} 
            searchData={searchData}
            searchTotal={totalCount}
            showDocument={showDocument}
            isLoading={isLoading}
            isLoaded={isLoaded}
            onSearchSubmit={handleSearchSubmit} 
            onSearchClear={handleSearchClear}
        />
    );
}

export default SearchTab;