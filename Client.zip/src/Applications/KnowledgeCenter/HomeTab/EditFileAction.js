import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import _get from 'lodash/get';
import { withStyles } from '@material-ui/core/styles';

import FileTags from '../FileManager/FileTags';
import { Button, ButtonTypes, mapSelectOptions } from '../../../components/Form';
import { Popover, DialogSizes } from '../../../components/Dialogs';
import Tooltip from "../../../UIComponents/Tooltip";

import { getPublishers } from '../../../store/DimensionModule';
import { saveFileData } from '../../../store/FileModule';

const styles = {
    disabled: {
        opacity: 0.35,
        cursor: 'not-allowed !important'
    }
};

const extractIds = (arr) => Array.isArray(arr) ? arr.filter(i => _get(i, 'data.isNew', false) === false).map(i => i.id) : []
const extractNewItems = (arr) => Array.isArray(arr) ? arr.filter(i => _get(i, 'data.isNew', false) === true) : []

const EditFileAction = ({ classes, disabled = false, file, onSave }) => {
    const dispatch = useDispatch();

    const stateDocumentSources = useSelector(state => state.DimensionReducer.DocumentSources)

    const [editVisible, setEditVisible] = React.useState(false);
    const [documentSources, setDocumentSources] = React.useState();
    const [otherDocumentTypes, setOtherDocumentTypes] = React.useState();
    const [environment, setEnvironment] = React.useState();
    const [governance, setGovernance] = React.useState();
    const [social, setSocial] = React.useState();
    const [gicsSectors, setGicsSectors] = React.useState();
    const [regions, setRegions] = React.useState();
    const [teams, setTeams] = React.useState();
    const [publishers, setPublishers] = React.useState();
    const [countries, setCountries] = React.useState();
    const [companies, setCompanies] = React.useState();
    const [synopsis, setSynopsis] = React.useState();

    const saveFileDataDispatch = React.useCallback((data) => {
        return dispatch(saveFileData({ 
            id: file.Id,
            domain: _get(file, 'External.Domain', ''),
            noteId: _get(file, 'External.NoteId', ''),
            subdomain: _get(file, 'External.SubDomain', ''),
            synopsis: data.synopsis,
            vendor: _get(file, 'External.Vendor', ''),
            uploadBy: _get(file, 'External.UploadedByID', ''),
            uploadDate: _get(file, 'External.UploadedByDate', ''),

            companies: extractIds(data.companies),
            countries: extractIds(data.countries),
            documentSource: _get(data, 'documentSources.0.id', null),
            gicsSectors: extractIds(data.gicsSectors),
            keyIssues: extractIds([ 
                ...(data.environment || []), 
                ...(data.social || []), 
                ...(data.governance || [])
            ]),
            otherDocumentType: _get(data, 'otherDocumentTypes.0.id', null),
            publishers: extractIds(data.publishers),
            publishersNew: extractNewItems(data.publishers),
            regions: extractIds(data.regions),
            teams: extractIds(data.teams),
        }));
    }, [ dispatch, file ]);

    const handleEditClick = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (!disabled) setEditVisible(true);
    }
    const handleEditClose = () => setEditVisible(false);
    const handleEditConfirm = () => saveFileDataDispatch(data).then(() => {
        dispatch(getPublishers(true)).then(() => {
            setEditVisible(false);
            if (onSave != null) onSave();
        });
    });

    const handleChange = (data) => {
        setDocumentSources(data.documentSources);
        setOtherDocumentTypes(data.otherDocumentTypes);
        setEnvironment(data.environment);
        setGovernance(data.governance);
        setSocial(data.social);
        setGicsSectors(data.gicsSectors);
        setRegions(data.regions);
        setTeams(data.teams);
        setPublishers(data.publishers);
        setCountries(data.countries);
        setCompanies(data.companies);
        setSynopsis(data.synopsis);
    }
    
    const isValid = () => _get(data, 'documentSources', []).reduce((acc, o) => {
        return acc || o.value;
    }, false);

    React.useEffect(() => {
        setDocumentSources(mapSelectOptions(
            file.External.DocumentSource == null ? [] : [ file.External.DocumentSource ], 
            (item, mapper) => mapper(item.DocumentSourceID, item.Name, true)
        ));
    }, [ file.External.DocumentSource, stateDocumentSources ]);

    React.useEffect(() => {
        setOtherDocumentTypes(mapSelectOptions(
            file.External.OtherDocumentType == null ? [] : [ file.External.OtherDocumentType ], 
            (item, mapper) => mapper(item, item, true)
        ));
    }, [ file.External.OtherDocumentType ]);

    React.useEffect(() => {
        setGicsSectors(mapSelectOptions(
            Array.isArray(file.External.GICSSectors) ? file.External.GICSSectors : [], 
            (item, mapper) => mapper(item.SectorID, item.Name, true)
        ));
    }, [ file.External.GICSSectors ]);

    React.useEffect(() => {
        setRegions(mapSelectOptions(
            Array.isArray(file.External.Regions) ? file.External.Regions : [], 
            (item, mapper) => mapper(item, item, true)
        ));
    }, [ file.External.Regions ]);

    React.useEffect(() => {
        setTeams(mapSelectOptions(
            Array.isArray(file.External.Teams) ? file.External.Teams : [], 
            (item, mapper) => mapper(item.TeamID, item.TeamName, true)
        ));
    }, [ file.External.Teams ]);

    React.useEffect(() => {
        setCountries(mapSelectOptions(
            Array.isArray(file.External.Countries) ? file.External.Countries : [], 
            (item, mapper) => mapper(item.CountryID, item.Name, true)
        ));
    }, [ file.External.Countries ]);

    React.useEffect(() => {
        setPublishers(mapSelectOptions(
            Array.isArray(file.External.Publishers) ? file.External.Publishers : [], 
            (item, mapper) => mapper(item.PublisherID, item.Name, true)
        ));
    }, [ file.External.Publishers ]);

    React.useEffect(() => {
        setCompanies(mapSelectOptions(
            Array.isArray(file.External.Companies) ? file.External.Companies : [], 
            (item, mapper) => mapper(item.CompanyID, `${item.CompanyName} (${item.Ticker})`, true)
        ));
    }, [ file.External.Companies ]);

    React.useEffect(() => {
        setSynopsis(file.External.Synopsis || '');
    }, [ file.External.Synopsis ]);

    React.useEffect(() => {
        if (Array.isArray(file.External.KeyIssues)) {
            setEnvironment(mapSelectOptions(
                Array.isArray(file.External.KeyIssues) 
                    ? file.External.KeyIssues.filter(ki => ki != null && ki.PillarID === 1) 
                    : [], 
                (item, mapper) => mapper(item.KeyIssueID, item.KeyIssueName, true)
            ));
    
            setSocial(mapSelectOptions(
                Array.isArray(file.External.KeyIssues) 
                    ? file.External.KeyIssues.filter(ki => ki != null && ki.PillarID === 2) 
                    : [], 
                (item, mapper) => mapper(item.KeyIssueID, item.KeyIssueName, true)
            ));
    
            setGovernance(mapSelectOptions(
                Array.isArray(file.External.KeyIssues) 
                    ? file.External.KeyIssues.filter(ki => ki != null && ki.PillarID === 3) 
                    : [], 
                (item, mapper) => mapper(item.KeyIssueID, item.KeyIssueName, true)
            ));
        }
    }, [ file.External.KeyIssues ]);

    const data = {
        documentSources, otherDocumentTypes, 
        environment, governance, social, 
        gicsSectors, regions, teams, 
        countries, publishers, companies,
        synopsis,
    };

    return (
        <React.Fragment>
            <i onClick={handleEditClick} className={cn("fas fa-edit", {[classes.disabled]: disabled}) } data-tip data-for="file_edit"></i>
            { editVisible && (
                <Popover 
                    onClose={handleEditClose} 
                    show={editVisible} 
                    title="Recategorize File"
                    size={ DialogSizes.FULL }
                    lockHeight={true}
                    className={classes.tagger}
                    actions={
                        <React.Fragment>
                            <Button type={ButtonTypes.SECONDARY} onClick={handleEditClose} className={classes.button}>Cancel</Button>
                            <Button type={ButtonTypes.PRIMARY} disabled={!isValid()} onClick={handleEditConfirm} className={classes.button}>Update</Button>
                        </React.Fragment>
                    }
                >
                    <FileTags data={data} onChange={handleChange}/>
                </Popover>
            )}
             <Tooltip id="file_edit" place="left">Edit categories(tags)</Tooltip>
        </React.Fragment>
    )
}

//EditFileAction.whyDidYouRender = { customName: 'EditFileAction' }
export default withStyles(styles)(
    React.memo(EditFileAction)
);