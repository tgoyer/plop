import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Popover, DialogSizes } from 'components/Dialogs';
import Button from 'componentlibrary/buttons/Button';
import Downloader from 'componentlibrary/file/Downloader';

import { deleteSectorGuide } from 'store/DimensionModule';

const SectorGuide = ({ guide }) => {
    const [showingDeleteDialog, setShowingDeleteDialog] = useState(false);
    const dispatch = useDispatch();
    const handleDeleteClose = () => setShowingDeleteDialog(false);
    const handleDeleteConfirm = () => {
        dispatch(deleteSectorGuide(guide.SectorGuideID));
        setShowingDeleteDialog(false);
    };

    // TODO make this a customHook
    const currentUser = useSelector((state) => {
        const user = state.UserReducer.UserInfo.Data;
        return {
            isAdmin: user.Permissions.CanAdmin,
            userInfo: user,
        };
    });

    const isAuthor = (authorID) => authorID === currentUser.userInfo.UserID;

    return (
        <div className="guides-list-guide">
            <span></span>
            {guide.URL ? (
                <Downloader useApiResource={true} uri={`/files/${guide.URL}`}>
                    {guide.Name}
                </Downloader>
            ) : (
                guide.Name
            )}
            {isAuthor(guide.AuthorID) && <i className="fas fa-trash-alt" onClick={() => setShowingDeleteDialog(true)}></i>}
            <Popover
                onClose={handleDeleteClose}
                show={showingDeleteDialog}
                title="Delete Guide"
                size={DialogSizes.CONFIRM}
                lockHeight={true}
                actions={
                    <React.Fragment>
                        <Button className="secondary" onClick={handleDeleteClose}>
                            Cancel
                        </Button>
                        <Button icon="delete" onClick={handleDeleteConfirm}>
                            <span>Delete</span>
                            <i className={`fas fa-trash-alt`}></i>
                        </Button>
                    </React.Fragment>
                }
            >
                <React.Fragment>
                    <p>This will remove the following guide from the Knowledge Center database:</p>
                    <p>
                        <b>{guide.Name}</b>
                    </p>
                    <p>Are you sure you want to continue?</p>
                </React.Fragment>
            </Popover>
        </div>
    );
};

export default SectorGuide;
