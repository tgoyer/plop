import React from 'react';
import FileUpload from '../UploadTab';
import LoadingSpinner from 'componentlibrary/spinners/Loading';
import Button from 'componentlibrary/buttons/Button';

import './AttachmentUpload.css';

const initialUploadedFileState = { path: null, fileName: null };
const AttachmentUpload = ({ uploadedFileInfo, setUploadedFileInfo, isUploading, setIsUploading }) => {
    return (
        <>
            <div name="url" className="post-content-upload">
                <div className="post-content-attachment">Attachment:</div>
                {!isUploading && uploadedFileInfo.fileName ? (
                    <Button className="chip" onClick={() => setUploadedFileInfo(initialUploadedFileState)}>
                        <span>{uploadedFileInfo.fileName}</span>
                        <i className={`fas fa-times-circle`}></i>
                    </Button>
                ) : (
                    <div className="post-content-placeholder">No File Attached</div>
                )}
            </div>

            {isUploading ? (
                <div>
                    <span className="mb-2">Uploading...</span>
                    <div className="m-2">
                        <LoadingSpinner />
                    </div>
                </div>
            ) : (
                !uploadedFileInfo.fileName && (
                    <FileUpload
                        showResultPane={false}
                        fileUploadOnStart={() => setIsUploading(true)}
                        fileUploadCallback={(file) => {
                            setUploadedFileInfo(file);
                            setIsUploading(false);
                        }}
                    />
                )
            )}
        </>
    );
};

export default AttachmentUpload;
