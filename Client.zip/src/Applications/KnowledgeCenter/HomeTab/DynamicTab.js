import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import { createContent } from '../../../store/ContentModule';

import Button from '../../../componentlibrary/buttons/Button';
import FilterSearch, { itemPassedAtLeastOneFilter } from '../../../components/Search/FilterSearch.js';

import { default as MuiTextField } from '@material-ui/core/TextField';
import { validateContent, getAuthor } from '../utilities.js';
import { formatDate } from '../../../Utils/dateHelper';

import EditContent from './EditContent';
import UploadTab from '../UploadTab';
import LoadingSpinner from 'componentlibrary/spinners/Loading';
import TabContentRichTextEditor from './TabContentRichEditor';

import './DynamicTab.css';

const styles = (theme) => ({
    heading: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'items-center',
        marginBottom: '10px',
        marginTop: '10px',
    },
    headerLabel: {
        margin: '0 0 0 10px',
        fontSize: '16px',
    },
    textField: {
        margin: '0px 0px 10px 0px',
    },
    cancel: {
        marginRight: '5px',
    },
});

const initialUploadedFileState = { path: null, fileName: null };

const TextField = ({ onChange, value, ...props }) => {
    const [val, setVal] = React.useState(value);

    const handleBlur = (evt) => onChange({ [props.name]: val });
    const handleChange = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        setVal(evt.currentTarget.value);
    };

    return <MuiTextField onBlur={handleBlur} onChange={handleChange} value={val} {...props} />;
};

const DynamicTab = ({ tab }) => {
    const currentUser = useSelector((state) => state.UserReducer.UserInfo.Data);
    const tabs = useSelector((state) => state.ContentReducer.Content.Tabs);
    const analysts = useSelector((state) => state.DimensionReducer.Analysts);
    const content = useSelector((state) => state.ContentReducer.Content.Active.Data.filter((c) => c.Tabs.includes(tab.TabID)));
    const [fields, setFields] = useState({ AuthorID: currentUser.UserID });
    const [showingForm, setShowingForm] = useState(false);
    const [isUploading, setIsUploading] = useState(false);

    const [validationMessage, setValidationMessage] = useState(null);

    const [uploadedFileInfo, setUploadedFileInfo] = useState(initialUploadedFileState);
    const [selectedTabIDs, setSelectedTabIDs] = useState([tab.TabID]);
    const [deletedTabIDs, setDeletedTabIDs] = useState([]);

    const [filterInputString, setFilterInputString] = useState('');
    const filterOptions = [
        { filterID: 1, filterName: 'Attachment Name', key: 'AttachmentName', getFormattedValue: (content) => content.AttachmentName, order: 1 },
        { filterID: 2, filterName: 'Author', key: 'AuthorID', getFormattedValue: (content) => getAuthor(content.AuthorID, analysts), order: 2 },
        { filterID: 3, filterName: 'Description', key: 'Description', getFormattedValue: (content) => content.Description, order: 3 },
        { filterID: 4, filterName: 'Date', key: 'InsertedDate', getFormattedValue: (content) => formatDate(content.InsertedDate), order: 4 },
        { filterID: 5, filterName: 'Title', key: 'Title', getFormattedValue: (content) => content.Title, order: 5 },
    ];
    const [activeFilters, setActiveFilters] = useState(filterOptions);

    const dispatch = useDispatch();

    const canEdit = (contentItem) => currentUser.UserID === contentItem.AuthorID;

    const handleChange = (event) => {
        setValidationMessage(null);
        setFields({ ...fields, ...event });
    };

    const handleEditorChange = (updatedText) => handleChange({ Description: updatedText });

    const handleSubmit = () => {
        const { isValid, message } = validateContent(fields);

        if (!isValid) {
            setValidationMessage(message);
            return;
        }

        dispatch(
            createContent({
                ...fields,
                tabs: selectedTabIDs,
                Url: uploadedFileInfo.path,
                AttachmentName: uploadedFileInfo.fileName,
            })
        );
        setShowingForm(false);
    };

    // Removes TabID and adds to DeletedIDs array
    const handleUncheckedTab = (tabItem, amountOfTabsSelected) => {
        if (amountOfTabsSelected === 1) return selectedTabIDs; // Min of 1 tab required
        setDeletedTabIDs([...deletedTabIDs, tabItem.TabID]);
        return selectedTabIDs.filter((tabID) => tabID !== tabItem.TabID);
    };

    const handleTabCheckbox = (event, tabItem) => {
        // Ensure if checked again its removed from deleted
        if (event.target.checked) setDeletedTabIDs(deletedTabIDs.filter((tabID) => tabID !== tabItem.TabID));

        setSelectedTabIDs(event.target.checked ? [...selectedTabIDs, tabItem.TabID] : handleUncheckedTab(tabItem, selectedTabIDs.length));
    };

    return (
        <div className="dynamic-tab">
            <div className="top-actions">
                <Button onClick={() => setShowingForm(!showingForm)}>
                    <span>Post to {tab.Name}</span>
                    <i className={`fas fa-${showingForm ? 'chevron-down' : 'chevron-right'}`}></i>
                </Button>
                <FilterSearch
                    filterOptions={filterOptions}
                    filterInputString={filterInputString}
                    setFilterInputString={setFilterInputString}
                    activeFilters={activeFilters}
                    setActiveFilters={setActiveFilters}
                    resetFilters={() => {
                        setFilterInputString('');
                        setActiveFilters(filterOptions);
                    }}
                />
            </div>
            {showingForm && (
                <TabContentRichTextEditor
                    textValue={fields.Description}
                    onChange={handleEditorChange}
                    actions={
                        <>
                            <Button className="secondary" onClick={() => setShowingForm(false)}>
                                Cancel
                            </Button>
                            <Button onClick={() => handleSubmit()}>
                                <span>Add</span>
                                <i className={`fas fa-plus-circle`} />
                            </Button>
                        </>
                    }
                >
                    <div className="post-content">
                        {showingForm && (
                            <>
                                <div className="post-content-title">
                                    <TextField onChange={(e) => handleChange(e)} name="Title" value={fields.title} placeholder="Title" className={'w-50 m-2'} />
                                </div>
                                <div className="post-content-tabs">
                                    <>
                                        <div className="tabs-include">
                                            <span className="ab-form-label">Include under Tabs:</span>
                                        </div>
                                        {tabs.map((tabItem) => (
                                            <div className="tabs-inputs" key={tabItem.TabID}>
                                                <span>{tabItem.Name}</span>
                                                <input className="ab-checkbox" checked={selectedTabIDs.includes(tabItem.TabID)} onChange={(e) => handleTabCheckbox(e, tabItem)} type="checkbox" />
                                            </div>
                                        ))}
                                    </>
                                </div>
                            </>
                        )}

                        <div className="post-content-upload">
                            Attachment:
                            {!isUploading && uploadedFileInfo.fileName ? (
                                <Button onClick={() => setUploadedFileInfo(initialUploadedFileState)}>
                                    <span>{uploadedFileInfo.fileName}</span>
                                    <i className="fa fa-times" />
                                </Button>
                            ) : (
                                <div className="post-content-placeholder">No File Attached</div>
                            )}
                        </div>

                        {isUploading ? (
                            <div>
                                <div className="tab-uploading">Uploading...</div>
                                <div className="tab-uploading-spinner">
                                    <LoadingSpinner />
                                </div>
                            </div>
                        ) : (
                            !uploadedFileInfo.fileName && (
                                <UploadTab
                                    showResultPane={false}
                                    fileUploadOnStart={() => setIsUploading(true)}
                                    fileUploadCallback={(file) => {
                                        setValidationMessage(null);
                                        setUploadedFileInfo(file);
                                        setIsUploading(false);
                                    }}
                                />
                            )
                        )}
                    </div>
                    {validationMessage && <div className="ab-validation-warning">{validationMessage}</div>}
                </TabContentRichTextEditor>
            )}
            {content
                .filter((contentItem) => itemPassedAtLeastOneFilter(activeFilters, filterInputString, contentItem))
                .map((contentItem) => (
                    <EditContent
                        author={getAuthor(contentItem.AuthorID, analysts)}
                        getAuthor={(userID) => getAuthor(userID, analysts)}
                        closeForms={() => setShowingForm(false)}
                        key={contentItem.ContentID}
                        tab={tab}
                        canEdit={canEdit(contentItem)}
                        contentItem={contentItem}
                    />
                ))}
        </div>
    );
};

export default withStyles(styles)(DynamicTab);
