import React from 'react';

import { useDispatch, useSelector } from 'react-redux';

import _get from 'lodash/get';

import Grid from './Grid';
import DeleteFileAction from './DeleteFileAction';
import EditFileAction from './EditFileAction';

import { getUploadedFiles, getFileDefinitions } from 'store/FileModule';

import { formatDate } from 'Utils/dateHelper';
import { getSubdomainLabel, subdomains } from '../utilities';
import Downloader from 'componentlibrary/file/Downloader';

const MyUploads = () => {
    const dispatch = useDispatch();
    const files = useSelector((state) => state.FileReducer.Files.Data);
    const ids = useSelector((state) => state.FileReducer.UploadedFiles.Data);
    const data = getFileDefinitions(ids, files);

    React.useEffect(() => {
        dispatch(getUploadedFiles());
    }, [dispatch]);

    const handleSave = () => dispatch(getUploadedFiles());

    return (
        <Grid
            data={data}
            sortBy="External.UploadedByDate"
            sortDir="desc"
            columns={[
                {
                    label: 'File Name',
                    field: 'FileName',
                    component: (file) => (
                        <Downloader useApiResource={true} uri={`/files/${file.Id}`}>
                            {file.FileName}
                        </Downloader>
                    ),
                },
                {
                    label: 'Source',
                    field: 'External.DocumentSource.Name',
                    component: (file) => _get(file, 'External.DocumentSource.Name', null) || 'Uncategorized',
                    width: 90,
                },
                {
                    label: 'Type',
                    field: 'External.SubDomain',
                    component: (file) => getSubdomainLabel(file, 'External.SubDomain'),
                    width: 90,
                },
                {
                    label: 'Upload Date',
                    field: 'External.UploadedByDate',
                    component: (file) => formatDate(_get(file, 'External.UploadedByDate', null)),
                    width: 110,
                },
            ]}
            actions={(file) => {
                const disabled = file.External.SubDomain === subdomains.Attachments;
                return (
                    <React.Fragment>
                        <EditFileAction file={file} onSave={handleSave} />
                        <DeleteFileAction file={file} disabled={disabled} />
                    </React.Fragment>
                );
            }}
        />
    );
};

export default MyUploads;
