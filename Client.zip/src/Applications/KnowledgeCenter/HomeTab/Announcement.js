import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import _get from 'lodash/get';
import dompurify from 'dompurify';

import Button from 'componentlibrary/buttons/Button';
import Downloader from 'componentlibrary/file/Downloader';
import { Popover, DialogSizes } from 'components/Dialogs';

import { deleteAnnouncement as deleteAnnouncementAction } from 'store/AnnouncementsModule';
import { setKnowledgeCenterSettings } from 'store/AppSettingsModule';

import { formatDate } from 'Utils/dateHelper';

import EditAnnouncement from './EditAnnouncement';
import SellSideWarning from '../../SellSideWarning.js';

import './Announcement.css';

const Announcement = ({ announcement, currentUser, getAuthor, analysts }) => {
    const [isEditing, setIsEditing] = useState(false);
    const settings = useSelector((state) => state.AppSettingsReducer.KnowledgeCenter);
    const dispatch = useDispatch();
    const deleteAnnouncement = () => dispatch(deleteAnnouncementAction(announcement.AnnouncementID));
    const author = getAuthor(announcement.AuthorID, analysts);

    const hasAuthor = author !== '';

    const [ssWarnHide, setSSWarnHide] = React.useState(false);
    const [showSellSideWarning, setShowSellSideWarning] = useState(false);

    const setKnowledgeCenterSettingsDispatcher = React.useCallback(
        (setting) => {
            dispatch(setKnowledgeCenterSettings(setting));
        },
        [dispatch]
    );

    const [showingDeleteDialog, setShowingDeleteDialog] = useState(false);
    const handleDeleteClose = () => setShowingDeleteDialog(false);
    const handleDeleteConfirm = () => {
        deleteAnnouncement();
        setShowingDeleteDialog(false);
    };

    const handleSSWarnHideChecked = () => {
        setSSWarnHide(!ssWarnHide);
    };

    const handleSellSideWarningConfirm = () => {
        setShowSellSideWarning(false);
        setKnowledgeCenterSettingsDispatcher({ disableSellSideWarning: ssWarnHide });
    };

    const handleSellSideWarningClose = () => {
        setShowSellSideWarning(false);
    };

    const ContentLink = ({ contentItem, announcementText }) => {
        if (!contentItem.Url) return <div className="ab-article-text" dangerouslySetInnerHTML={{ __html: dompurify.sanitize(announcementText) }}></div>;
        return !_get(settings, 'disableSellSideWarning', false) ? (
            <span className="text-link ab-article-text pointer" onClick={() => setShowSellSideWarning(true)} dangerouslySetInnerHTML={{ __html: dompurify.sanitize(announcementText) }}></span>
        ) : (
            <Downloader useApiResource={true} uri={`/files/${contentItem.Url}`} className="ab-article-text" dangerouslySetInnerHTML={{ __html: dompurify.sanitize(announcementText) }} />
        );
    };

    const ContentLastUpdated = ({ content }) => {
        if (!content.UpdatedByUserID) return null;

        const updatedByAuthor = content.UpdatedByUserID === content.AuthorID;

        return (
            <div className="ab-article-byline-content">
                <div>Updated {formatDate(content.UpdatedDate)}</div>
                {!updatedByAuthor && <div className="ab-article-author-content">({getAuthor(content.UpdatedByUserID, analysts)})</div>}
            </div>
        );
    };

    return (
        <>
            {isEditing ? (
                <EditAnnouncement announcement={announcement} currentUser={currentUser} setVisibility={() => setIsEditing(false)} />
            ) : (
                <div className="ab-article" key={announcement.AnnouncementID}>
                    <div className="ab-article-main">
                        <div className="ab-article-title">{announcement.Title}</div>
                        <div className="ab-article-byline">
                            <div>{formatDate(announcement.Date)}</div>
                            {announcement.AuthorID != null && <div className="ab-article-author"> {hasAuthor && '/  By ' + getAuthor(announcement.AuthorID, analysts)}</div>}
                            {announcement?.content && <ContentLastUpdated content={announcement.content} />}
                        </div>

                        {announcement.content ? (
                            <ContentLink contentItem={announcement.content} announcementText={announcement.Text} />
                        ) : (
                            <div className="ab-article-text" dangerouslySetInnerHTML={{ __html: dompurify.sanitize(announcement.Text) }}></div>
                        )}
                        {announcement.content && <div className="announcement-content" dangerouslySetInnerHTML={{ __html: dompurify.sanitize(announcement.content.Description) }}></div>}
                    </div>

                    <div className="ab-article-actions">
                        {announcement.IsPinned && <i className="fas fa-bookmark fa-2x"></i>}
                        {currentUser.isAdmin && (
                            <>
                                <i className="fas fa-edit" onClick={() => setIsEditing(true)}></i>
                                <i className="fas fa-trash-alt" onClick={() => setShowingDeleteDialog(true)}></i>
                            </>
                        )}
                    </div>
                </div>
            )}
            {announcement.content && (
                <SellSideWarning
                    ssWarnHide={ssWarnHide}
                    onClose={handleSellSideWarningClose}
                    isShowing={showSellSideWarning}
                    handleChecked={handleSSWarnHideChecked}
                    close={() => setShowSellSideWarning(false)}
                    confirm={handleSellSideWarningConfirm}
                    customActions={() => {
                        return (
                            <React.Fragment>
                                <Button className="secondary" onClick={handleSellSideWarningClose}>
                                    Cancel
                                </Button>
                                <Downloader useApiResource={true} uri={`/files/${announcement.content.Url}`} className="ab-article-text" onClick={handleSellSideWarningConfirm}>
                                    <Button>Confirm & Read</Button>
                                </Downloader>
                            </React.Fragment>
                        );
                    }}
                />
            )}
            <Popover
                onClose={handleDeleteClose}
                show={showingDeleteDialog}
                title="Delete Announcement"
                size={DialogSizes.CONFIRM}
                lockHeight={true}
                actions={
                    <React.Fragment>
                        <Button className="secondary" onClick={handleDeleteClose}>
                            Cancel
                        </Button>
                        <Button onClick={handleDeleteConfirm}>
                            <span>Delete</span>
                            <i className="fas fa-trash-alt"></i>
                        </Button>
                    </React.Fragment>
                }
            >
                <React.Fragment>
                    <p>This will remove the following announcement from the Knowledge Center database:</p>
                    <p>
                        <b>{announcement.Title}</b>
                    </p>
                    <p>Are you sure you want to continue?</p>
                </React.Fragment>
            </Popover>
        </>
    );
};

export default Announcement;
