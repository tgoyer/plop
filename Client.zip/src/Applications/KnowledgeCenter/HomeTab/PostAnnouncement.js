import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { DateTime } from 'luxon';

import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Button from '../../../componentlibrary/buttons/Button';
import RichTextEditorPost from './RichTextEditorPost';

import { withStyles } from '@material-ui/core/styles';
import { default as MuiTextField } from '@material-ui/core/TextField';

import { isAnnouncementValid } from '../utilities.js';

import { createAnnouncement } from '../../../store/AnnouncementsModule';

import './PostAnnouncement.css';

const TextField = ({ onChange, value, ...props }) => {
    const [val, setVal] = React.useState(value);

    const handleBlur = (evt) => onChange({ [props.name]: val });
    const handleChange = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        setVal(evt.currentTarget.value);
    };

    return <MuiTextField onBlur={handleBlur} onChange={handleChange} value={val} {...props} />;
};

const styles = (theme) => ({
    textField: {
        margin: '0px 0px 10px 0px',
    },
    cancel: {
        marginRight: '5px',
    },
});

const PostAnnouncement = ({ classes, currentUser, setVisibility }) => {
    const [fields, setFields] = useState({});
    const [pinnedPost, setPinnedPost] = useState(false);
    const [validationWarning, setValidationWarning] = useState(false);
    const dispatch = useDispatch();

    const handleChange = (event) => {
        setValidationWarning(null);
        setFields({ ...fields, ...event });
    };

    const handleEditorChange = (updatedText) => handleChange({ text: updatedText });

    const handleSubmit = async () => {
        dispatch(
            await createAnnouncement({
                ...fields,
                authorId: currentUser.userInfo.UserID,
                type: 1,
                isPinned: pinnedPost,
                date: DateTime.now().toISO(),
                isActive: 1,
                isDeleted: 0,
            })
        );

        setVisibility(false);
    };

    return (
        <div className="post-announcement">
            <RichTextEditorPost
                textValue={fields.text}
                currentUser={currentUser}
                handleEditorChange={handleEditorChange}
                actions={
                    <div className="post-announcement-footer">
                        <div className="post-announcement-pin">
                            <i className="fas fa-bookmark fa-2x"></i>
                            <FormControlLabel
                                value="start"
                                control={<Checkbox checked={pinnedPost} onChange={() => setPinnedPost(!pinnedPost)} />}
                                label="Pin post to the top"
                                labelPlacement="start"
                            />
                        </div>

                        <div className="post-announcement-actions">
                            <Button className="secondary" onClick={() => setVisibility(false)}>
                                Cancel
                            </Button>
                            <Button
                                onClick={() => {
                                    if (!isAnnouncementValid(fields)) {
                                        setValidationWarning('Please fill out all required fields');
                                        return;
                                    }
                                    handleSubmit();
                                    setFields({ title: '', text: '' });
                                    setPinnedPost(false);
                                }}
                            >
                                Post
                            </Button>
                            {validationWarning && <div className="ab-validation-warning">{validationWarning}</div>}
                        </div>
                    </div>
                }
            >
                <TextField fullWidth required value={fields.title} name="title" label="Title" placeholder="Title" className={classes.textField} onChange={(e) => handleChange(e)} />
            </RichTextEditorPost>
        </div>
    );
};

export default withStyles(styles)(PostAnnouncement);
