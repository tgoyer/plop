import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemText from '@material-ui/core/ListItemText';
import Switch from '@material-ui/core/Switch';
import { withStyles } from '@material-ui/core/styles';

//import { Heading } from '../../../components/Content';
import { Button, ButtonTypes } from '../../../components/Form';
import { Popover, DialogSizes } from '../../../components/Dialogs';
import { TextEditor } from '../../../components/TextEditor';

import { getAllAnnouncements } from '../../../store/AnnouncementsModule';
import { formatDate } from '../../../Utils/dateHelper';

const styles = theme => ({
    actions: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        '& button': {
            margin: '0 8px 0 0',
            '&:last-child': {
                margin: 0
            }
        }
    },
    active: {
        background: '#cc0000 !important',
        '&:before': {
            content: '\'active\' !important',
        }
    },
    badge: {
        background: '#999999',
        borderRadius: 8,
        color: 'white',
        display: 'inline',
        fontSize: 11,
        fontWeight: 700,
        height: 20,
        padding: '2px 10px',
        textShadow: '1px 1px rgba(65, 92, 139, 1);',
        textTransform: 'uppercase',
        '&:before': {
            content: '\'inactive\'',
        }
    },
    container: {
        display: 'flex',
    },
    editPane: {
        border: '2px solid #cccccc',
        padding: 20,
        flex: '70%',
    },
    listItem: {
        '&:hover': {
            backgroundColor: '#eeeeee',
            cursor: 'pointer',
        }
    },
    listPane: {
        flex: '30%',
    },
    byline: {
        fontStyle: 'italic',
        margin: '0 0 10px 0',
    },
    content: {
        margin: '8px 8px 8px 18px',
    },
    editMode: {
        backgroundColor: '#ffffcc'
    },
    sectionSubHeader: {
        fontWeight: 700,
    },
    titleContent: {
        display: 'inline-block'
    }
});

const AnnouncementsPanel = ({ classes }) => {
    const dispatch = useDispatch();
    const analysts = useSelector(state => state.DimensionReducer.Analysts);
    const userId = useSelector(state => state.UserReducer.UserInfo.Data.UserID);
    const allAnnouncments = useSelector(state => state.AnnouncementsReducer.All.Data);

    const [ showPopover, setShowPopover ] = React.useState(false);
    const [ activeIds, setActiveIds ] = React.useState([]);
    const [ announcement, setAnnouncement ] = React.useState(null);

    const activateAnnouncement = (id) => {
        const item = allAnnouncments.find(ann => ann.AnnouncementID === id);
        if (item != null) {
            setAnnouncement(item);
        }
    }
    const canEditAnnouncement = (authorId) => userId === authorId;
    const getAuthor = (authorId) => {
        const analyst = Array.isArray(analysts) ? analysts.find(analyst => analyst.UserID === authorId) : null;
        return (analyst != null) ? analyst.FullName : '';
    }

    const handleEditClick = () => {
        dispatch(getAllAnnouncements());
        setShowPopover(true);
    }
    const handlePopupClose = () => setShowPopover(false);
    const handleEditText = (value) => setAnnouncement({ ...announcement, Text: value });
    const handleEditTitle = (value) => setAnnouncement({ ...announcement, Title: value });
    const handleEditCancel = () => activateAnnouncement(announcement.AnnouncementID)();
    const handleEditSave = () => {
        console.log(announcement);
    }
    const handleItemClick = (id) => () => activateAnnouncement(id);

    const handleToggle = (value) => () => {
        const currentIndex = activeIds.indexOf(value);

        const newChecked = (currentIndex === -1)
            ? [...activeIds, value]
            : [...activeIds.filter(id => id !== value)];
        
        setActiveIds(newChecked);
    };

    React.useEffect(() => {
        if (Array.isArray(allAnnouncments)) {
            setAnnouncement(allAnnouncments[0]);
            setActiveIds(allAnnouncments.reduce((acc, announcement) => {
                if (announcement.IsActive) {
                    acc.push(announcement.AnnouncementID)
                }
                return acc;
            }, []))
        }
    }, [ allAnnouncments ])

    const canEdit = announcement != null && canEditAnnouncement(announcement.AuthorID)

    return (
        <React.Fragment>
            <Button type={ButtonTypes.SUBHEADER_PRIMARY} onClick={handleEditClick}>Edit</Button>
            <Popover 
                onClose={handlePopupClose} 
                show={showPopover} 
                title="Edit Announcements" 
                size={DialogSizes.FULL}
                lockHeight={true}
                actions={
                    <React.Fragment>
                        <Button type={ButtonTypes.SECONDARY} disabled={!canEdit} onClick={handleEditCancel}>Cancel</Button>
                        <Button type={ButtonTypes.PRIMARY} disabled={!canEdit} onClick={handleEditSave}>Save</Button>
                    </React.Fragment>
                }
            >
                <div className={classes.container}> 
                    <div className={classes.listPane}>
                        <List>
                            {Array.isArray(allAnnouncments) && allAnnouncments.map(announcement => {
                                return (
                                    <ListItem key={announcement.AnnouncementID} className={classes.listItem}>
                                        <ListItemText onClick={handleItemClick(announcement.AnnouncementID)} primary={announcement.Title} />
                                        <ListItemSecondaryAction>
                                            <Switch
                                                onChange={handleToggle(announcement.AnnouncementID)}
                                                checked={activeIds.indexOf(announcement.AnnouncementID) !== -1}
                                            />
                                        </ListItemSecondaryAction>
                                    </ListItem>
                                )
                            })}
                        </List>
                    </div>
                    {announcement != null && (
                        <div className={classes.editPane}>
                            <div className={classes.sectionSubHeader}>
                                <div className={classes.titleContent}>
                                    <span>{formatDate(announcement.Date)} - </span>
                                    <TextEditor value={announcement.Title} isEdit={canEdit} onChange={handleEditTitle} />
                                </div>
                            </div>
                            <div className={classes.byline}>By: {getAuthor(announcement.AuthorID)}</div>
                            <div className={classes.content}>
                                <TextEditor value={announcement.Text} isEdit={canEdit} onChange={handleEditText} />
                            </div>
                            <div className={classes.actions}>
                                <div className={cn(classes.badge, { [classes.active]: announcement.IsActive })} />
                            </div>
                        </div>
                    )}
                </div>
            </Popover>    
        </React.Fragment>
    )
}

export default withStyles(styles)(AnnouncementsPanel);