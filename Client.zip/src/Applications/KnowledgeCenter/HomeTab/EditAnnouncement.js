import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Button from '../../../componentlibrary/buttons/Button';
import RichTextEditorPost from './RichTextEditorPost';
import { isAnnouncementValid } from '../utilities.js';

import { withStyles } from '@material-ui/core/styles';
import { default as MuiTextField } from '@material-ui/core/TextField';

import { updateAnnouncement } from '../../../store/AnnouncementsModule';

import './EditAnnouncement.css';

const TextField = ({ onChange, value, ...props }) => {
    const [val, setVal] = React.useState(value);

    const handleBlur = (evt) => onChange({ [props.name]: val });
    const handleChange = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        setVal(evt.currentTarget.value);
    };

    return <MuiTextField onBlur={handleBlur} onChange={handleChange} value={val} {...props} />;
};

const styles = (theme) => ({
    textField: {
        margin: '0px 0px 10px 0px',
    },
    cancel: {
        marginRight: '5px',
    },
});

const EditAnnouncement = ({ announcement, classes, currentUser, setVisibility }) => {
    const [fields, setFields] = useState({ text: announcement.Text, title: announcement.Title });
    const [pinnedPost, setPinnedPost] = useState(announcement.IsPinned);
    const [validationWarning, setValidationWarning] = useState(false);
    const dispatch = useDispatch();

    const handleChange = (event) => {
        setValidationWarning(null);
        setFields({ ...fields, ...event });
    };

    const handleEditorChange = (updatedText) => handleChange({ text: updatedText });

    const handleSubmit = async () => {
        dispatch(
            await updateAnnouncement({
                ...announcement,
                Title: fields.title,
                Text: fields.text,
                IsPinned: pinnedPost,
            })
        );

        setVisibility(false);
    };

    return (
        <div className="edit-announcement">
            <RichTextEditorPost
                textValue={fields.text}
                currentUser={currentUser}
                handleEditorChange={handleEditorChange}
                actions={
                    <div className="edit-announcement-footer">
                        <div className="edit-announcement-pin">
                            <i className="fas fa-bookmark fa-2x"></i>
                            <FormControlLabel
                                value="start"
                                control={<Checkbox checked={pinnedPost} onChange={() => setPinnedPost(!pinnedPost)} />}
                                label="Pin post to the top"
                                labelPlacement="start"
                            />
                        </div>

                        <div className="edit-announcement-actions">
                            <Button className="secondary" onClick={() => setVisibility(false)}>
                                Cancel
                            </Button>
                            <Button
                                onClick={() => {
                                    if (!isAnnouncementValid(fields)) {
                                        setValidationWarning('Please fill out all required fields');
                                        return;
                                    }
                                    handleSubmit();
                                    setFields({ title: '', text: '' });
                                    setPinnedPost(false);
                                }}
                            >
                                Save
                            </Button>
                            {validationWarning && <div className="ab-validation-warning">{validationWarning}</div>}
                        </div>
                    </div>
                }
            >
                <TextField fullWidth value={fields.title} name="title" label="Title" placeholder="Title" className={classes.textField} onChange={(e) => handleChange(e)} />
            </RichTextEditorPost>
        </div>
    );
};

export default withStyles(styles)(EditAnnouncement);
