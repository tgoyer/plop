import React from 'react';
import { withStyles } from '@material-ui/core/styles';

import RichTextEditor from '../../../components/RichTextEditor/RichTextEditor';

const styles = (theme) => ({
    textField: {
        margin: '0px 0px 10px 0px',
    },
    cancel: {
        marginRight: '5px',
    },
});

const RichTextEditorPost = ({ textValue, handleEditorChange, children, actions }) => {
    return (
        <React.Fragment>
            <div className="w-100">{children}</div>
            <div className="ab-form-label">
                Text<span>*</span>
            </div>
            <RichTextEditor initialValue={textValue} onChange={handleEditorChange} />
            {actions}
        </React.Fragment>
    );
};

export default withStyles(styles)(RichTextEditorPost);
