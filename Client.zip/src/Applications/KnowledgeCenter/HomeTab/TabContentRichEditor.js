import React from 'react';
import RichTextEditor from '../../../components/RichTextEditor/RichTextEditor.js';
import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    editor: {
        display: `flex`,
        flexDirection: `column`,
        border: `3px solid`,
        borderColor: '#1e9BD7',
        borderRadius: '5px',
        padding: `10px`,
        marginTop: `10px`,
    },
    actions: {
        display: `flex`,
        flexDirection: `row`,
        justifyContent: 'flex-end',
        gap: 8,
    },
});

const TabContentRichTextEditor = ({ classes, textValue, onChange, children, actions }) => {
    const handleChange = (ev) => {
        if (onChange != null) {
            onChange(ev);
        }
    };

    return (
        <div className={classes.editor}>
            <div>{children}</div>
            <div className="ab-form-label">
                Description<span>*</span>
            </div>
            <RichTextEditor initialValue={textValue} onChange={handleChange} />
            <div className={classes.actions}>{actions}</div>
        </div>
    );
};

export default withStyles(styles)(TabContentRichTextEditor);
