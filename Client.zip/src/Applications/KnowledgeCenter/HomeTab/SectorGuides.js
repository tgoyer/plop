import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';

import TextField from './TextField';
import FileUpload from '../UploadTab';

import Button from '../../../componentlibrary/buttons/Button';
import { Select, toOptionList } from 'components/Form';

import SectorGuide from './SectorGuide';

import { createSectorGuide, getSectorGuides } from '../../../store/DimensionModule';
import { sort } from '../../../Utils/listHelper';

import './SectorGuides.css';

const styles = (theme) => ({
    container: {
        padding: '8px 0',
        '& li + li': {
            paddingTop: 4,
        },
    },
    heading: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'items-center',
        marginBottom: '10px',
        marginTop: '10px',
    },
    headerLabel: {
        margin: '0 0 0 10px',
        fontSize: '16px',
    },
    editor: {
        border: `3px solid`,
        borderColor: '#1E9BD7', //theme.palette.primary.main,
        borderRadius: '0px',
        padding: `10px`,
        marginTop: '10px',
        marginBottom: '5px',
    },
    cancel: {
        marginRight: '5px',
    },
});

const energyClimateGuide = {
    FileName: 'Climate_Best_Practices_Guide_Energy.pdf',
    Name: 'Energy - Climate Best Practices Guide',
};

const pillars = [
    { name: 'Environment', ID: 1 },
    { name: 'Social', ID: 2 },
    { name: 'Governance', ID: 3 },
];

const initialUploadedFileState = { path: '', fileName: '' };
const SectorGuides = ({ classes }) => {
    const dispatch = useDispatch();
    const guides = useSelector((state) => state.DimensionReducer.SectorGuides.Data);
    const sectors = useSelector((state) => state.DimensionReducer.GICSSectors);

    // TODO make this a customHook
    const currentUser = useSelector((state) => {
        const user = state.UserReducer.UserInfo.Data;
        return {
            isAdmin: user.Permissions.CanAdmin,
            userInfo: user,
        };
    });

    const [showingForm, setShowingForm] = useState(false);
    const [fields, setFields] = useState({ title: '' });
    const [pil, setPil] = useState(null);
    const [sectorID, setSectorID] = useState(null);
    const [uploadedFileInfo, setUploadedFileInfo] = useState(initialUploadedFileState);
    const [titleWarning, setTitleWarning] = useState(null);
    const [attachmentWarning, setAttachmentWarning] = useState(null);
    const [pillarWarning, setPillarWarning] = useState(null);

    const resetForm = () => {
        setUploadedFileInfo(initialUploadedFileState);
        setShowingForm(false);
        setFields({ title: '' });
        setPil(1);
        setSectorID(null);
    };

    const handleChange = (event) => {
        setFields({ ...fields, ...event });
    };
    const handleSubmit = () => {
        let hasError = false;

        if (fields['title'] === '') {
            setTitleWarning('Please provide a title');
            hasError = true;
        }

        if (uploadedFileInfo.fileName === '') {
            setAttachmentWarning('Please attach a file');
            hasError = true;
        }

        if (pil === null) {
            setPillarWarning('Please select a pillar');
            hasError = true;
        }

        if (hasError) return;

        dispatch(
            createSectorGuide({
                ...fields,
                authorID: currentUser.userInfo.UserID,
                name: fields.title,
                sectorID: sectorID,
                pillarID: pil,
                fileName: uploadedFileInfo.fileName,
                url: uploadedFileInfo.fileID,
            })
        );
        resetForm();
    };
    React.useEffect(() => {
        dispatch(getSectorGuides());
    }, [dispatch]);

    const sortedIndustryGuides = React.useMemo(() => [...guides, energyClimateGuide].sort(sort('Name')).filter((f) => f.Name !== 'Governance Guide'), [guides]);

    const fileUploadCallback = (file) => {
        setUploadedFileInfo(file);
        setAttachmentWarning(null);
    };

    const handlePillarChange = (e) => {
        setPil(parseInt(e.target.value));
        setPillarWarning(null);
    };

    return (
        <div className={classes.container}>
            <p>These are the guides used for engaging with companies on various ESG-related topics broken down by sector.</p>

            <Button onClick={() => setShowingForm(!showingForm)}>
                <span>Post New Guide</span>
                <i className={`fas fa-${showingForm ? 'chevron-down' : 'chevron-right'}`}></i>
            </Button>

            {showingForm && (
                <div className={classes.editor}>
                    <div className="sector-form">
                        <div className="sector-guide-title-box">
                            <div className="sector-title-field">
                                <label className="ab-form-label">
                                    Title<span className="ab-required">*</span>
                                </label>
                                <TextField
                                    required
                                    onChange={(e) => {
                                        setTitleWarning(null);
                                        handleChange(e);
                                    }}
                                    name="title"
                                    value={fields.title}
                                    className={'sector-guide-title'}
                                />
                            </div>
                            {titleWarning && <span className="title-warning">{titleWarning}</span>}
                        </div>
                        <div className="pillar-list">
                            <span className="pillar-label">
                                Pillar<span className="required">*</span>
                            </span>
                            <div className="pillars">
                                {pillars.map((pillar) => (
                                    <div className="pillar" key={pillar.ID}>
                                        <span className="m-2">{pillar.name}</span>
                                        <input className="mr-2" onChange={(e) => handlePillarChange(e)} type="radio" name={pillar.name} value={pillar.ID} checked={pillar.ID === pil} />
                                    </div>
                                ))}
                                {pillarWarning && <span className="pillar-warning">{pillarWarning}</span>}
                            </div>
                        </div>
                        <div>
                            <Select label="Sector" onChange={(option) => handleChange('ActionTypeID', option.value)} options={toOptionList(sectors, 'SectorID', 'Name')} value={null} />
                        </div>
                        <div className="sector-form-attachment">
                            <div name="url" className="attachment-label">
                                <span className="attachment-label-text">
                                    Attachment:<span className="ab-required">*</span>
                                </span>
                                {uploadedFileInfo.fileName ? (
                                    <Button className="chip" onClick={() => setUploadedFileInfo(initialUploadedFileState)}>
                                        <span>{uploadedFileInfo.fileName}</span>
                                        <i className="fas fa-times-circle"></i>
                                    </Button>
                                ) : (
                                    <span>No File Attached</span>
                                )}
                                {attachmentWarning && <span className="attachment-warning">{attachmentWarning}</span>}
                            </div>
                        </div>
                        {!uploadedFileInfo.fileName && <FileUpload showResultPane={false} fileUploadCallback={fileUploadCallback} />}
                        <div className="sector-buttons">
                            <Button className="secondary" onClick={() => setShowingForm(false)}>
                                <span>Cancel</span>
                            </Button>
                            <Button onClick={() => handleSubmit()}>
                                <span>Create</span>
                                <i className="fas fa-plus-circle"></i>
                            </Button>
                        </div>
                    </div>
                </div>
            )}
            <div className="guides-list">{Array.isArray(sortedIndustryGuides) && sortedIndustryGuides.map((guide, idx) => <SectorGuide guide={guide} key={idx} />)}</div>
        </div>
    );
};

export default withStyles(styles)(SectorGuides);
