import React from 'react';
import cn from 'classnames';

import { useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    category: {
        marginBottom: 10,
    },
    categoryItem: {
        fontWeight: 400,
        marginLeft: 20,
    },
    categoryName: {
        fontWeight: 700,
    },
    noRowsMessage: {
        display: 'flex',
        justifyContent: 'center',
        '&:last-child': {
            fontWeight: 700,
            padding: 10,
            width: '100% !important',
        }
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '0 0 10px 0',
        padding: 5
    },
    table: {
        border: 0,
        borderCollapse: 'collapse',
        '& th': {
            padding: 4,
        },
        '& td': {
            padding: 5,
        },
        '& thead': {
            display: 'table',
            width: 'calc(100% - 16px)',
            tableLayout: 'fixed',
        },
        '& tbody': {
            maxHeight: 200,
            display: 'block',
            overflowY: 'scroll',
        },
        '& thead tr': {
            backgroundColor: '#f7f7f7',
            borderBottom: '1px solid #bdd7ff',
            fontWeight: 700,
            width: '100%',
        },
        '& tbody tr': {
            width: '100%',
            tableLayout: 'fixed',
            borderBottom: '1px solid #eee',
            display: 'table',
            '& td i': {
                fontSize: 16,
                color: '#6987B9',
                '&.fa-link': {
                    fontSize: 14,
                    paddingLeft: 8,
                }
            },
            '& td': {
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                overflow: 'hidden'
            },
            '&:last-child': {
                borderBottom: 'none',
            }
        },
    },
    actions: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
});

const TopSearchByKeyword = ({ classes }) => {
    const terms = useSelector(state => state.FileReducer.SearchMetrics.Data.Terms);

    return (
        <React.Fragment>
            <table className={ cn(classes.table) }>
                <thead>
                    <tr>
                        <th>Keyword or Phrase</th>
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>
                { terms != null && Array.isArray(terms) && terms.map((term, idx) => (
                    <tr key={idx}>
                        <td>{ term.Phrase }</td>
                        <td>{ term.Count }</td>
                    </tr>
                )) }
                </tbody>
            </table>
        </React.Fragment>
    );
}

export default withStyles(styles)(TopSearchByKeyword);