import React from 'react';
import cn from 'classnames';

import { useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';

import { categoryMap } from '../utilities';

const styles = theme => ({
    category: {
        marginBottom: 10,
    },
    categoryItem: {
        fontWeight: 400,
        marginLeft: 20,
    },
    categoryName: {
        fontWeight: 700,
    },
    noRowsMessage: {
        display: 'flex',
        justifyContent: 'center',
        '&:last-child': {
            fontWeight: 700,
            padding: 10,
            width: '100% !important',
        }
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '0 0 10px 0',
        padding: 5
    },
    table: {
        border: 0,
        borderCollapse: 'collapse',
        '& th': {
            padding: 4,
        },
        '& td': {
            padding: 5,
        },
        '& thead': {
            display: 'table',
            width: 'calc(100% - 16px)',
            tableLayout: 'fixed',
        },
        '& tbody': {
            maxHeight: 200,
            display: 'block',
            overflowY: 'scroll',
        },
        '& thead tr': {
            backgroundColor: '#f7f7f7',
            borderBottom: '1px solid #bdd7ff',
            fontWeight: 700,
            width: '100%',
        },
        '& tbody tr': {
            width: '100%',
            tableLayout: 'fixed',
            borderBottom: '1px solid #eee',
            display: 'table',
            '& td i': {
                fontSize: 16,
                color: '#6987B9',
                '&.fa-link': {
                    fontSize: 14,
                    paddingLeft: 8,
                }
            },
            '& td': {
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                overflow: 'hidden'
            },
            '&:last-child': {
                borderBottom: 'none',
            }
        },
    },
    actions: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
});

const mapCountry = (list, value) => mapItems(list, value, item => String(item.CountryID), item => item.Name);
const mapDocumentSources = (list, value) => mapItems(list, value, item => String(item.DocumentSourceID), item => item.Name);
const mapKeyIssues = (list, value) => mapItems(list, value, item => String(item.KeyIssueID), item => item.KeyIssueName);
const mapGicsSectors = (list, value) => mapItems(list, value, item => String(item.SectorID), item => item.Name);
const mapPublisher = (list, value) => mapItems(list, value, item => String(item.PublisherID), item => item.Name);
const mapTeams = (list, value) => mapItems(list, value, item => String(item.TeamID), item => item.TeamName);

const mapItems = (list, value, idAccessor, fieldAccessor) => {
    const item = list == null ? null : list.find(item => String(idAccessor(item)) === String(value));
    return item != null ? fieldAccessor(item) : value;
}

const TopSearchByTag = ({ classes }) => {
    const countries = useSelector(state => state.DimensionReducer.Countries.Data);
    const documentSources = useSelector(state => state.DimensionReducer.DocumentSources);
    const keyIssues = useSelector(state => state.DimensionReducer.KeyIssues.all);
    const gicsSectors = useSelector(state => state.DimensionReducer.GICSSectors);
    const teams = useSelector(state => state.DimensionReducer.Teams);
    const publishers = useSelector(state => state.DimensionReducer.Publishers.Data);

    const tags = useSelector(state => state.FileReducer.SearchMetrics.Data.Tags);

    const mapValue = (tag) => {
        return tag.Category === 'country' ? mapCountry(countries, tag.Tag)
            : tag.Category === 'documentSource' ? mapDocumentSources(documentSources, tag.Tag)
                : ['keyIssue', 'keyIssues'].indexOf(tag.Category) >= 0 ? mapKeyIssues(keyIssues, tag.Tag)
                    : tag.Category === 'gicsSector' ? mapGicsSectors(gicsSectors, tag.Tag)
                        : tag.Category === 'team' ? mapTeams(teams, tag.Tag)
                            : tag.Category === 'publisher' ? mapPublisher(publishers, tag.Tag)
                                : tag.Tag;
    }

    return (
        <React.Fragment>
            <table className={cn(classes.table)}>
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Category</th>
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>
                    {tags != null && Array.isArray(tags) && tags.map((tag, idx) => (
                        <tr key={idx}>
                            <td>{categoryMap[tag.Category]}</td>
                            <td>{mapValue(tag)}</td>
                            <td>{tag.Count}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </React.Fragment>
    );
}

export default withStyles(styles)(TopSearchByTag);