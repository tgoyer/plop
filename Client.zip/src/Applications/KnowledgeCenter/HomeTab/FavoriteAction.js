import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';
import Tooltip from "../../../UIComponents/Tooltip";

import { saveFavoriteFile, deleteFavoriteFile } from '../../../store/FileModule';

const styles = theme => ({
    yellow: {
        color: '#f08f50 !important'      
    },
});

const AdminActions = ({classes, file}) => {
    const dispatch = useDispatch();
    const ids = useSelector(state => state.FileReducer.FavoriteFiles.Data);

    const deleteFavorite = React.useCallback((fileId) => {
        dispatch(deleteFavoriteFile(fileId));
    }, [dispatch]);

    const saveFavorite = React.useCallback((fileId) => {
        dispatch(saveFavoriteFile(fileId));
    }, [dispatch]);

    const handleFavoriteFile = (id, isFavorite) => (evt) => {
        evt.preventDefault();
        evt.stopPropagation();

        if (isFavorite) {
            deleteFavorite(id);
        } else {
            saveFavorite(id);
        }
    }

    const isFileFavorite = (id) => {
        return ids != null && Array.isArray(ids) 
            ? ids.find(i => i === id) != null
            : false;
    }

    const id = file.Id;
    const isFavorite = isFileFavorite(id);
    return (
        <div>
            <i data-tip data-for="file_fav" onClick={handleFavoriteFile(id, isFavorite)} className={cn( {"fas": isFavorite, "far": !isFavorite, [classes.yellow]: isFavorite  }, "fa-star" )}></i>
            <Tooltip id="file_fav" place="left">Mark as favourite</Tooltip>
        </div>
        
    )
}

export default withStyles(styles)(AdminActions);