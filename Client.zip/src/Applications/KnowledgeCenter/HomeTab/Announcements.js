import React, { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { getAnnouncements } from '../../../store/AnnouncementsModule';
import { withStyles } from '@material-ui/core/styles';

import Announcement from './Announcement';
import PostAnnouncement from './PostAnnouncement';
import FilterSearch, { itemPassedAtLeastOneFilter } from '../../../components/Search/FilterSearch';
import Button from '../../../componentlibrary/buttons/Button';

import { getAuthor } from '../utilities';
import { formatDate } from '../../../Utils/dateHelper';

import './Announcements.css';

const styles = (theme) => ({
    article: {
        display: 'block',
        paddingBottom: 8,
        position: 'relative',
        margin: '8px 8px 16px 8px',
        '&:after': {
            content: "''",
            position: 'absolute',
            width: '50%',
            height: 2,
            background: '#bdd7ff',
            top: '100%',
            left: '25%',
        },
        '&:last-child': {
            marginBottom: 0,
            '&:after': {
                height: 0,
            },
        },
    },
    byline: {
        fontStyle: 'italic',
        margin: '0 0 12px 0',
    },
    content: {
        margin: 0,
        '& > p': {
            margin: '8px 0 0 16px',
        },
        '& a': {
            fontWeight: 700,
            textDecoration: 'underline',
        },
    },
    sectionSubHeader: {
        display: 'inline-block',
        fontWeight: 700,
    },
    admin: {
        display: 'flex',
        flexDirection: 'column',
    },
    postBox: {
        display: 'flex',
        flexDirection: 'column',
        padding: '8px',
        marginTop: '2px',
    },
    heading: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'items-center',
        marginBottom: '10px',
    },
    headerLabel: {
        margin: '0 0 0 10px',
        fontSize: '16px',
    },
    textField: {
        margin: '0px 0px 10px 0px',
    },
    cancel: {
        marginRight: '5px',
    },
});

// If the Announcement has content preview, concat the content item's Description Field so we can include it in
const combineTextAndDescriptionStrings = (announcementText, contentDescription) => (contentDescription ? announcementText + contentDescription : announcementText);
const getAttachmentDataForContentID = (announcement, content) => {
    if (!announcement.ContentID) return announcement;

    const matchedContent = content.find((c) => c.ContentID === announcement.ContentID);
    if (!matchedContent) return announcement;

    return { ...announcement, AttachmentName: matchedContent.AttachmentName, content: matchedContent };
};
const getFilters = (analysts) => [
    { filterID: 1, filterName: 'Attachment Name', key: 'AttachmentName', getFormattedValue: (announcement) => announcement['AttachmentName'], order: 1 },
    { filterID: 2, filterName: 'Author', key: 'AuthorID', getFormattedValue: (announcement) => getAuthor(announcement['AuthorID'], analysts), order: 2 },
    { filterID: 3, filterName: 'Text', key: 'Text', getFormattedValue: (announcement) => combineTextAndDescriptionStrings(announcement['Text'], announcement.content?.Description), order: 3 },
    { filterID: 4, filterName: 'Date', key: 'Date', getFormattedValue: (announcement) => formatDate(announcement['Date']), order: 4 },
    { filterID: 5, filterName: 'Title', key: 'Title', getFormattedValue: (announcement) => announcement['Title'], order: 5 },
];

const Announcements = ({ classes }) => {
    const dispatch = useDispatch();
    const analysts = useSelector((state) => state.DimensionReducer.Analysts);
    const content = useSelector((state) => state.ContentReducer.Content.Active.Data);
    const userInfo = useSelector((state) => state.UserReducer.UserInfo.Data);
    const announcementsInfo = useSelector((state) => state.AnnouncementsReducer.Active.Data);

    const filterOptions = useMemo(() => getFilters(analysts), [analysts]);

    const [showingAdminBox, setShowingAdminBox] = useState(false);
    const [filterInputString, setFilterInputString] = useState('');
    const [activeFilters, setActiveFilters] = useState(filterOptions);

    const [pinned, nonpinned] = useMemo(() => {
        const sorted = announcementsInfo.sort((a, b) => b.Date - a.Date);
        return [sorted.filter((a) => a.IsPinned), sorted.filter((a) => !a.IsPinned)];
    }, [announcementsInfo]);
    const currentUser = useMemo(() => {
        return {
            isAdmin: userInfo?.Permissions?.CanAdmin,
            userInfo,
        };
    }, [userInfo]);

    useEffect(() => {
        dispatch(getAnnouncements());
    }, [dispatch]);
    return (
        <div className={classes.admin}>
            <div className="announcements-header">
                <div className={`top-actions ${currentUser?.isAdmin ? '' : 'non-admin'}`}>
                    {currentUser?.isAdmin && (
                        <div>
                            <Button onClick={() => setShowingAdminBox(!showingAdminBox)}>
                                <span>Post Announcement</span>
                                <i className={`fas fa-${showingAdminBox ? 'chevron-down' : 'chevron-right'}`}></i>
                            </Button>
                        </div>
                    )}
                    <FilterSearch
                        filterOptions={filterOptions}
                        filterInputString={filterInputString}
                        setFilterInputString={setFilterInputString}
                        activeFilters={activeFilters}
                        setActiveFilters={setActiveFilters}
                        resetFilters={() => {
                            setFilterInputString('');
                            setActiveFilters(filterOptions);
                        }}
                    />
                </div>
                {showingAdminBox && <PostAnnouncement currentUser={currentUser} setVisibility={setShowingAdminBox} />}
            </div>
            {Array.isArray([...pinned, ...nonpinned]) &&
                [...pinned, ...nonpinned]
                    .map((announcement) => getAttachmentDataForContentID(announcement, content))
                    .filter((announcement) => itemPassedAtLeastOneFilter(activeFilters, filterInputString, announcement))
                    .map((announcement) => (
                        <Announcement key={announcement.AnnouncementID} announcement={announcement} classes={classes} currentUser={currentUser} analysts={analysts} getAuthor={getAuthor} />
                    ))}
        </div>
    );
};

export default withStyles(styles)(Announcements);
