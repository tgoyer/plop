import React from 'react';
import cn from 'classnames';

import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import _get from 'lodash/get';

import Grid from './Grid';

import { deleteFavoriteFile, getFavoriteFiles, getFileDefinitions } from 'store/FileModule';

import { formatDate } from 'Utils/dateHelper';
import { getSubdomainLabel } from '../utilities';
import Downloader from 'componentlibrary/file/Downloader';

const styles = (theme) => ({
    yellow: {
        color: '#f08f50 !important',
    },
});

const MyFavorites = ({ classes }) => {
    const dispatch = useDispatch();
    const files = useSelector((state) => state.FileReducer.Files.Data);
    const ids = useSelector((state) => state.FileReducer.FavoriteFiles.Data);
    const data = getFileDefinitions(ids, files);

    const deleteFavorite = React.useCallback(
        (fileId) => {
            dispatch(deleteFavoriteFile(fileId));
        },
        [dispatch]
    );

    React.useEffect(() => {
        dispatch(getFavoriteFiles());
    }, [dispatch]);

    return (
        <Grid
            data={data}
            sortBy="FileName"
            sortDir="asc"
            columns={[
                {
                    label: 'File Name',
                    field: 'FileName',
                    component: (file) => (
                        <Downloader useApiResource={true} uri={`/files/${file.Id}`}>
                            {file.FileName}
                        </Downloader>
                    ),
                },
                {
                    label: 'Source',
                    field: 'External.DocumentSource.Name',
                    component: (file) => _get(file, 'External.DocumentSource.Name', null) || 'Uncategorized',
                    width: 90,
                },
                {
                    label: 'Type',
                    field: 'External.SubDomain',
                    component: (file) => getSubdomainLabel(file, 'External.SubDomain'),
                    width: 90,
                },
                {
                    label: 'Upload Date',
                    field: 'External.UploadedByDate',
                    component: (file) => formatDate(_get(file, 'External.UploadedByDate', null)),
                    width: 110,
                },
            ]}
            actions={(file) => <i onClick={() => deleteFavorite(file.Id)} className={cn('fas fa-star', classes.yellow)}></i>}
        />
    );
};

export default withStyles(styles)(MyFavorites);
