import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import FileInfoIcon from './FileInfoIcon';

import { sortList } from '../../../Utils/listHelper';

const styles = theme => ({
    activeSort: {
        backgroundColor: '#ebebeb',
        borderBottom: '1px solid #f08f50',
    },
    category: {
        marginBottom: 10,
    },
    categoryItem: {
        fontWeight: 400,
        marginLeft: 20,
    },
    categoryName: {
        fontWeight: 700,
    },
    noRowsMessage: {
        display: 'flex',
        justifyContent: 'center',
        '&:last-child': {
            fontWeight: 700,
            padding: 5,
            width: '100% !important',
        }
    },
    table: {
        border: 0,
        borderCollapse: 'collapse',
        height: '100%',
        minHeight: 55,
        '& th': {
            overflow: 'hidden',
            padding: '4px 8px',
            '& i': {
                marginLeft: 4,
                marginRight: 4,
            }
        },
        '& td': {
            padding: '4px 8px',
        },
        '& thead': {
            display: 'table',
            width: 'calc(100% - 16px)',
            tableLayout: 'fixed',
        },
        '& tbody': {
            display: 'block',
            minHeight: 'calc(100% - 27px)',
            maxHeight: 150,
            overflowY: 'scroll',
        },
        '& thead tr': {
            backgroundColor: '#f7f7f7',
            borderBottom: '1px solid #bdd7ff',
            fontWeight: 700,
            width: '100%',
        },
        '& tbody tr': {
            width: '100%',
            tableLayout: 'fixed',
            borderBottom: '1px solid #eee',
            display: 'table',
            '& td i': {
                fontSize: 16,
                color: '#6987B9',
                '&.fa-link': {
                    fontSize: 14,
                    paddingLeft: 8,
                }
            },
            '& td': {
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                padding: 5,
            },
            '&:last-child': {
                borderBottom: 'none',
            }
        },
    },
    actionsCell: {
        textAlign: 'center',
        width: 125,
    },
    actions: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        '& i': {
            cursor: 'pointer',
            margin: '0 6px',
        }
    },
});

const Grid = ({ actions, classes, columns, data, sortBy, sortDir }) => {
    const [sort, setSort] = React.useState(sortBy || null);
    const [dir, setDir] = React.useState(sortDir || 'asc');

    const handleSortClick = (field) => () => {
        if (field == null || data.length === 0) return;

        const newdir = sort !== field ? 'asc'
            : dir === 'asc' ? 'desc'
                : 'asc';

        setSort(field);
        setDir(newdir)
    }

    return (
        <table className={cn(classes.table)}>
            <thead>
                <tr>
                    {columns.map((c, idx) => {
                        const style = c.style || {};
                        const css = {
                            ...style,
                            width: c.width != null ? c.width : style.width,
                            cursor: c.field == null ? 'default' : 'pointer',
                        };
                        return (
                            <th
                                key={idx}
                                style={css}
                                className={cn({ [classes.activeSort]: c.field === sort })}
                                onClick={handleSortClick(c.field)}
                            >
                                {c.label}
                            </th>
                        )
                    })}
                    <th className={classes.actionsCell}>Actions</th>
                </tr>
            </thead>
            <tbody>
                {data.length === 0
                    ? <tr><td colSpan="4" className={classes.noRowsMessage}>There are no documents to show in this view.</td></tr>
                    : sortList(data, sort, dir).map(file => (
                        <tr key={file.Id}>
                            {columns.map((c, idx) => {
                                const style = c.style || {};
                                const css = {
                                    ...style,
                                    width: c.width != null ? c.width : style.width,
                                };
                                return <td key={idx} style={css}>{c.component(file)}</td>
                            })}
                            <td className={classes.actionsCell}>
                                <div className={classes.actions}>
                                    {actions != null && actions(file)}
                                    <FileInfoIcon file={file} />
                                </div>
                            </td>
                        </tr>
                    ))
                }
            </tbody>
        </table>
    );
}

export default withStyles(styles)(Grid);