import React from 'react';
import { useSelector } from 'react-redux';

import Tooltip from '../../../UIComponents/Tooltip';

import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    tooltipContent: {
        marginBottom: 10,
    },
    toolTipItem: {
        fontWeight: 400,
        marginLeft: 20,
    },
    toolTipTitle: {
        fontWeight: 700,
        marginTop: 12,
        '&:first-child': {
            marginTop: 0,
        },
    },
});

const mapCategoryValues = (classes, type, list, dimensions, idAccessor, fieldAccessor) => {
    return Array.isArray(list) && list.length > 0 ? (
        <React.Fragment key={type + '_title'}>
            <dt className={classes.toolTipTitle}>{type}</dt>
            {list.map((value) => {
                const item = dimensions?.find((item) => {
                    const id = item == null ? null : idAccessor(item);
                    const val = value == null ? null : idAccessor(value);
                    return id === val;
                });
                return (
                    item != null && (
                        <dd key={type + '_item_' + idAccessor(item)} className={classes.toolTipItem}>
                            {fieldAccessor(item)}
                        </dd>
                    )
                );
            })}
        </React.Fragment>
    ) : null;
};

const mapId = (classes, type, id, list, idAccessor, fieldAccessor) => {
    const item = Array.isArray(list)
        ? list.find((f) => {
              const val = f == null ? null : idAccessor(f);
              return val === id;
          })
        : null;
    return mapItem(classes, type, item, idAccessor, fieldAccessor);
};

const mapItem = (classes, type, item, idAccessor, fieldAccessor) => {
    return item != null ? (
        <React.Fragment key={type + '_item_' + idAccessor(item)}>
            <dt className={classes.toolTipTitle}>{type}</dt>
            <dd className={classes.toolTipItem}>{fieldAccessor(item)}</dd>
        </React.Fragment>
    ) : null;
};

const mapList = (classes, type, list, idAccessor, fieldAccessor) => {
    return Array.isArray(list) && list.length > 0 ? (
        <React.Fragment key={type + '_title'}>
            <dt className={classes.toolTipTitle}>{type}</dt>
            {list.map((item) => {
                return item == null ? null : (
                    <dd key={type + '_item_' + idAccessor(item)} className={classes.toolTipItem}>
                        {fieldAccessor(item)}
                    </dd>
                );
            })}
        </React.Fragment>
    ) : null;
};

const FileInfoIcon = ({ classes, file }) => {
    const analystDimensions = useSelector((state) => state.DimensionReducer.Analysts);
    const countryDimensions = useSelector((state) => state.DimensionReducer.Countries.Data);
    const publisherDimensions = useSelector((state) => state.DimensionReducer.Publishers.Data);
    const keyIssueDimensions = useSelector((state) => state.DimensionReducer.KeyIssues.all);
    const gicsDimensions = useSelector((state) => state.DimensionReducer.GICSSectors);
    const regionDimensions = useSelector((state) => state.DimensionReducer.Regions);
    const teamsDimensions = useSelector((state) => state.DimensionReducer.Teams);

    const getCategoriesList = ({ UploadedByID, Publishers, Companies, Teams, GICSSectors, KeyIssues, Countries, Regions }) => {
        const categories = [
            mapId(
                classes,
                'Analyst',
                UploadedByID,
                analystDimensions,
                (item) => item.UserID,
                (item) => item.FullName
            ),
            mapCategoryValues(
                classes,
                'Publishers',
                Publishers,
                publisherDimensions,
                (item) => item.PublisherID,
                (item) => item.Name
            ),
            mapCategoryValues(
                classes,
                'Countries',
                Countries,
                countryDimensions,
                (item) => String(item.CountryID),
                (item) => item.Name
            ),
            mapCategoryValues(
                classes,
                'GICS Sectors',
                GICSSectors,
                gicsDimensions,
                (item) => item.SectorID,
                (item) => item.Name
            ),
            mapCategoryValues(
                classes,
                'Key Issues',
                KeyIssues,
                keyIssueDimensions,
                (item) => item.KeyIssueID,
                (item) => item.KeyIssueName
            ),
            mapCategoryValues(
                classes,
                'Teams',
                Teams,
                teamsDimensions,
                (item) => item.TeamID,
                (item) => item.TeamName
            ),
            mapCategoryValues(
                classes,
                'Regions',
                Regions,
                regionDimensions,
                (item) => item,
                (item) => item
            ),
            mapList(
                classes,
                'Companies',
                Companies,
                (item) => item.CompanyID,
                (item) => item.CompanyName
            ),
        ];

        return categories.length > 0 ? categories : [<span key="no_category_data">No category information was selected for this file.</span>];
    };

    return (
        <React.Fragment>
            <i className="fas fa-info-circle" data-tip data-for={file.Id + '_additional_info_TT'}></i>
            <Tooltip id={file.Id + '_additional_info_TT'} place="left">
                <p>
                    <strong>Additional Information</strong>
                </p>
                <div className={classes.tooltipContent}>
                    <dt className={classes.toolTipTitle}>File Name</dt>
                    <dd className={classes.toolTipItem}>{file.FileName}</dd>
                    {getCategoriesList(file.External)}
                </div>
            </Tooltip>
        </React.Fragment>
    );
};

export default withStyles(styles)(FileInfoIcon);
