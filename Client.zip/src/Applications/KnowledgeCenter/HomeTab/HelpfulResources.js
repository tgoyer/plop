//
// DEPRECATED
import React from 'react';

import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    paper: {
        margin: 0,
        padding: 8,
        width: '100%',
    },
    resourceSection: {
        display: 'block',
        paddingBottom: 8,
        position: 'relative',
        margin: '8px 8px 16px 8px',
        textIndent: -24,
        paddingLeft: 24,
        '& a': {
            fontWeight: 700,
            textDecoration: 'underline',
        },
        '& li': {
            textIndent: 0,
        },
        '&:after': {
            content: "''",
            position: 'absolute',
            width: '50%',
            height: 2,
            background: '#bdd7ff',
            top: '100%',
            left: '25%',
        },
        '&:last-child': {
            marginBottom: 0,
            '&:after': {
                height: 0,
            },
        },
    },
    smallEmphasis: {
        fontStyle: 'italic',
        fontSize: 10,
        marginLeft: 10,
    },
});

const HelpfulResources = ({ classes }) => {
    return (
        <>
            <div className={classes.resourceSection}>
                <a href="https://www.worldbenchmarkingalliance.org/research/chrb-2020-results-data/" target="_blank" rel="noreferrer noopener">
                    Corporate Human Rights Benchmark
                </a>
                : The 2020 Corporate Human Rights Benchmark assesses 101 of the largest publicly traded companies in the world on a set of human rights indicators.
                <br />
                <span className={classes.smallEmphasis}>Sectors: Agricultural Products, Apparel, and Extractives</span>
            </div>
            <div className={classes.resourceSection}>
                <a href="https://knowthechain.org/about-us/" target="_blank" rel="noreferrer noopener">
                    KnowTheChain
                </a>
                : A resource for companies and investors to understand and address forced labor risks within their global supply chains.
                <br />
                <span className={classes.smallEmphasis}>Sectors covered:</span>
                <ul className={classes.smallEmphasis}>
                    <li>Information & Communications Technology: 40 companies, 20 with NA HQ, 14 Asia, 6 EU</li>
                    <li>Food and Beverage: 38 companies, 4 Asian, 2 Australian, 10 EU, 1 ME, 18, NA, 3 LATAM</li>
                    <li>Apparel & Footwear: 43 companies. 1 African, 12 Asian, 14 European, 16 NA</li>
                </ul>
            </div>
            <div className={classes.resourceSection}>
                <a href="https://sustainabledevelopment.un.org/?menu=1300" target="_blank" rel="noreferrer noopener">
                    SDGs
                </a>
                : The 2030 Agenda for Sustainable Development, adopted by all United Nations Member States in 2015, provides a shared blueprint for peace and prosperity for people and the planet, now
                and into the future. At its heart are the 17 Sustainable Development Goals (SDGs), which are an urgent call for action by all countries - developed and developing - in a global
                partnership. They recognize that ending poverty and other deprivations must go hand-in-hand with strategies that improve health and education, reduce inequality, and spur economic
                growth – all while tackling climate change and working to preserve our oceans and forest
                <br />
            </div>
            <div className={classes.resourceSection}>
                <a href="/assets/documents/Knowledge_Center_User_Guide.pdf" target="_blank" rel="noreferrer noopener">
                    Help Guide for Knowledge Center Search
                </a>
            </div>
            <div className={classes.resourceSection}>
                <a href="https://abglobal.sharepoint.com/eq/qrad/qrad/SitePages/MSCI-vs-Sustainalytics.aspx" target="_blank" rel="noreferrer noopener">
                    MSCI vs Sustainalytics
                </a>
                : A high level comparison of differences between MSCI and Sustainalytics.
            </div>
            <div className={classes.resourceSection}>
                <a href="https://abglobal.sharepoint.com/eq/qrad/qrad/SitePages/ESG-Data.aspx" target="_blank" rel="noreferrer noopener">
                    AB's ESG Data Assets
                </a>
                : A centralized location for visualizations, code, and documentation for AB’s ESG Data.
            </div>
            <div className={classes.resourceSection}>
                <a href="https://abglobal.sharepoint.com/:o:/t/FIRIH/EpT7vJdex2JDp60U6-QeVYIBdbV_hB0ZZyOIYCizzIlSDQ" target="_blank" rel="noreferrer noopener">
                    FI Responsible Investing Hub Notebook
                </a>
                : A helpful resource as you prep for client meetings and as we all continue to increase our fluency in ESG topics. There are FAQs, guides to the ESG dashboards in RAP, and more.
            </div>

            <div className={classes.resourceSection}>
                <a href="/assets/documents/Bloomberg_ESG_Fields_Updated_June_2019.xlsx" target="_blank" rel="noreferrer noopener">
                    Bloomberg ESG Data Fields
                </a>
                : Over 1100 available ESG data fields on Bloomberg plus descriptions of the items and field IDs. This includes third party data and company reported data.
            </div>
            <div className={classes.resourceSection}>
                <a href="/assets/documents/MSCI_2021_ESG_Ratings_ESG_Metrics_AllFactors_Screen_Definition.xlsx" target="_blank" rel="noreferrer noopener">
                    MSCI ESG Data Fields
                </a>
                : Nearly 2300 ESG data points available on MSCI ESG Manager.
            </div>
            <div className={classes.resourceSection}>
                <a href="/assets/documents/202009_AB_Panel_Modern_Slavery.pdf" target="_blank" rel="noreferrer noopener">
                    Modern Slavery Panel Presentation
                </a>
                : Representatives from Volkswagen and Be Slavery Free joined us on 25th Sept 2020 to share their experiences in addressing and reducing modern slavery and forced labour risks. For any
                questions, please contact <a href="mailto:saskia.kort-chick@alliancebernstein.com?subject=Modern%20Slavery%20Presentation%20Inquiry">Saskia Kort-Chick</a>. The accompanying{' '}
                <a href="/assets/documents/202009_AB_Panel_Modern_Slavery-Stop_The_Traffik.mp4" target="_blank" rel="noreferrer noopener">
                    Stop the Traffik video
                </a>{' '}
                can be downloaded for viewing.
            </div>
            <div className={classes.resourceSection}>
                <a href="/assets/documents/Sustainalytics_Standard_Datafeed_Report_Overview.xlsx" target="_blank" rel="noreferrer noopener">
                    Sustainalytics ESG Data Fields
                </a>
                : Over 5000 ESG data points available on Sustainalytics' platform.
            </div>
            <div className={classes.resourceSection}>
                <a href="https://www.brainshark.com/bernstein/vu?pi=zIxz16SGkYzchihz0" target="_blank" rel="noreferrer noopener">
                    Sustainalytics Training
                </a>
                : Replay of the original Sustainalytics training.
            </div>
            <div className={classes.resourceSection}>
                <a href="https://alliancebernstein.zoom.us/rec/share/mBDeglFm1blxC6xIsNBXIuDPIjD-4OZUwqL6Cvp-BAVpAbZ8-QOQd1_Tl2FvmUWy.3KdciXNZsOEJjaBk" target="_blank" rel="noreferrer noopener">
                    Sustainalytics Tools Training
                </a>
                : Replay of the Sustainalytics tools functionality. Please use passcode <strong>07523191</strong> to view.
            </div>
            <div className={classes.resourceSection}>
                <strong>MSCI Rating Enhancements</strong>: MSCI is updating its ESG ratings methodology, with the biggest changes coming to the governance pillar and the financial sector. There are
                two files available that describe{' '}
                <a href="/assets/documents/01Oct2020_MSCI_ESG_Ratings_Enhancements.pdf" target="_blank" rel="noreferrer noopener">
                    the changes in more detail
                </a>{' '}
                and provide{' '}
                <a href="/assets/documents/ESG_Ratings_Methodology_Pro_Forma_Scores.pdf" target="_blank" rel="noreferrer noopener">
                    a “pro-forma” version
                </a>{' '}
                of how the new aggregate would look.
                <ul>
                    <li>
                        In June 2020, MSCI released pro-forma scores for data points that will undergo change, including the Key Issues impacting the Financials sector, the Governance Pillar, and a
                        new Community Relations Key Issue
                    </li>
                    <li>Changes will take place in November (targeting end of Nov, but clients will receive email notification with exact dates)</li>
                    <li>Won't necessarily be a one-time update in November though, because IAS (and letter ratings) will gradually be changed as analysts review companies post-November.</li>
                </ul>
                <p>Re-ratings will be prioritized by magnitude of expected change, market cap, and date of last rating update.</p>
            </div>
        </>
    );
};

export default withStyles(styles)(HelpfulResources);
