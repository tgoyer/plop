import React from 'react';
import { useSelector } from 'react-redux';

import _get from 'lodash/get';

import DeleteFileAction from './DeleteFileAction';
import EditFileAction from './EditFileAction';

import { subdomains } from '../utilities';

const AdminActions = ({ file, onEditSave }) => {
    const isAdmin = useSelector(state => state.UserReducer.UserInfo.Data.Permissions.CanAdmin);
    const subdomain =  _get(file, 'External.SubDomain', '');
    const editDisabled = [subdomains.Notes].indexOf(subdomain) >= 0;
    const deleteDisabled = [subdomains.Attachments, subdomains.Notes].indexOf(subdomain) >= 0;

    return isAdmin && (
        <React.Fragment>
            <EditFileAction file={file} disabled={editDisabled} onSave={onEditSave} />
            <DeleteFileAction file={file} disabled={deleteDisabled} />
        </React.Fragment>
    )
}

export default AdminActions;