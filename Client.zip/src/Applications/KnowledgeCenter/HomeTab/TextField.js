import React from "react";
import { default as MuiTextField } from '@material-ui/core/TextField';

const TextField = ({ onChange, required, value, ...props }) => {
    const [val, setVal] = React.useState(value);

    const handleBlur = (evt) => onChange({ [props.name]: val });
    const handleChange = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        setVal(evt.currentTarget.value);
    };

    return <MuiTextField required={required} onBlur={handleBlur} onChange={handleChange} value={val} {...props} />;
};

export default TextField;