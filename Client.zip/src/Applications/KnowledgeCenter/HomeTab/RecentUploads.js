import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import _get from 'lodash/get';

import AdminActions from './AdminActions';
import FavoriteAction from './FavoriteAction';
import Grid from './Grid';

import { getRecentFiles, getFileDefinitions } from 'store/FileModule';

import { formatDate } from 'Utils/dateHelper';
import { getSubdomainLabel } from '../utilities';
import Downloader from 'componentlibrary/file/Downloader';

const RecentUploads = () => {
    const dispatch = useDispatch();
    const files = useSelector((state) => state.FileReducer.Files.Data);
    const ids = useSelector((state) => state.FileReducer.RecentFiles.Data);
    const data = getFileDefinitions(ids, files);

    React.useEffect(() => {
        dispatch(getRecentFiles());
    }, [dispatch]);

    return (
        <Grid
            data={data}
            sortBy="External.UploadedByDate"
            sortDir="desc"
            columns={[
                {
                    label: 'File Name',
                    field: 'FileName',
                    component: (file) => (
                        <Downloader useApiResource={true} uri={`/files/${file.Id}`}>
                            {file.FileName}
                        </Downloader>
                    ),
                },
                {
                    label: 'Source',
                    field: 'External.DocumentSource.Name',
                    component: (file) => _get(file, 'External.DocumentSource.Name', null) || 'Uncategorized',
                    width: 90,
                },
                {
                    label: 'Type',
                    field: 'External.SubDomain',
                    component: (file) => getSubdomainLabel(file, 'External.SubDomain'),
                    width: 90,
                },
                {
                    label: 'Upload Date',
                    field: 'External.UploadedByDate',
                    component: (file) => formatDate(_get(file, 'External.UploadedByDate', null)),
                    width: 110,
                },
            ]}
            actions={(file) => {
                return (
                    <React.Fragment>
                        <FavoriteAction file={file} />
                        <AdminActions file={file} />
                    </React.Fragment>
                );
            }}
        />
    );
};

export default RecentUploads;
