import React from 'react';
import cn from 'classnames';
import { useDispatch } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';

import LoadingSpinner from 'componentlibrary/spinners/Loading';
import { Button, ButtonTypes } from '../../../components/Form';
import { Popover, DialogSizes } from '../../../components/Dialogs';
import Tooltip from '../../../UIComponents/Tooltip';

import { deleteFile } from '../../../store/FileModule';

const styles = {
    disabled: {
        opacity: 0.35,
        cursor: 'not-allowed !important',
    },
    fileName: {
        fontSize: 12,
        fontWeight: 700,
        textDecoration: 'underline',
    },
};

const DeleteFileAction = ({ classes, disabled = false, file, onDelete }) => {
    const dispatch = useDispatch();

    const [inProgress, setInProgress] = React.useState(false);
    const [deleteVisible, setDeleteVisible] = React.useState(false);

    const deleteFileDispatcher = React.useCallback(
        (fileId) => {
            dispatch(deleteFile(fileId));
        },
        [dispatch]
    );

    const doDelete = (file) => {
        setInProgress(true);
        deleteFileDispatcher(file.Id);
    };

    const handleDeleteClick = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (!disabled) setDeleteVisible(true);
    };
    const handleDeleteClose = () => setDeleteVisible(false);
    const handleDeleteConfirm = () => doDelete(file);

    return (
        <React.Fragment>
            <i onClick={handleDeleteClick} className={cn('fas fa-trash-alt', { [classes.disabled]: disabled })} data-tip data-for="file_delete"></i>
            <Popover
                onClose={handleDeleteClose}
                show={deleteVisible}
                title="Delete file"
                size={DialogSizes.CONFIRM}
                lockHeight={true}
                actions={
                    <React.Fragment>
                        <Button type={ButtonTypes.SECONDARY} onClick={handleDeleteClose}>
                            Cancel
                        </Button>
                        <Button type={ButtonTypes.PRIMARY} onClick={handleDeleteConfirm}>
                            Delete
                        </Button>
                    </React.Fragment>
                }
            >
                {inProgress ? (
                    <LoadingSpinner />
                ) : (
                    <React.Fragment>
                        <p>This will remove the following file from the Knowledge Center database.</p>
                        <p className={classes.fileName}>{file.FileName}</p>
                        <p>Are you sure you want to continue?</p>
                    </React.Fragment>
                )}
            </Popover>
            <Tooltip id="file_delete" place="left">
                Delete Document
            </Tooltip>
        </React.Fragment>
    );
};

//DeleteFileAction.whyDidYouRender = { customName: 'DeleteFileAction' }
export default withStyles(styles)(React.memo(DeleteFileAction));
