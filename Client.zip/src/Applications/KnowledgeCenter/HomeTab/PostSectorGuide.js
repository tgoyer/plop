import React from "react";

const PostSectorGuide = ({setShowingForm}) => {

    return (
        <div>
            <div className={classes.heading} onClick={() => setShowingForm(!showingForm)}>
                <i className="far fa-plus-square fa-2x"></i>
                <span className={classes.headerLabel}>Post to {tab.Name}</span>
                <i className={`ml-2 fas ${showingForm ? 'fa-angle-up' : 'fa-angle-down'} fa-2x`} onClick={() => setShowingForm(!setShowingForm)}></i>
            </div>
        </div>
    );
};

export default PostSectorGuide;