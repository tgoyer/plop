import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import TabContentRichTextEditor from './TabContentRichEditor';
import dompurify from 'dompurify';
import { withStyles } from '@material-ui/core/styles';
import _get from 'lodash/get';
import cn from 'classnames';
import { setKnowledgeCenterSettings } from '../../../store/AppSettingsModule';

import { Popover, DialogSizes } from '../../../components/Dialogs';
import SellSideWarning from '../../SellSideWarning.js';

import { updateContent, deleteContent } from '../../../store/ContentModule';
import Button from '../../../componentlibrary/buttons/Button';
import Icon, { FA_ICONS_LIST, getFileExtensionIcon } from '../../../componentlibrary/icons/Icon';
import Tooltip from '../../../UIComponents/Tooltip';
import AttachmentUpload from './AttachmentUpload';
import TextField from './TextField';
import { getResourceUrl } from 'Utils/layoutHelper';

import './EditContent.css';
import { validateContent } from '../utilities';
import { formatDate } from 'Utils/dateHelper';
import Downloader from 'componentlibrary/file/Downloader';

const styles = (theme) => ({
    heading: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'items-center',
        marginBottom: '10px',
        marginTop: '20px',
    },
    headerLabel: {
        margin: '0 0 0 10px',
        fontSize: '16px',
    },
    textField: {
        margin: '0px 0px 10px 0px',
    },
    cancel: {
        marginRight: '5px',
    },
});

const EditContent = ({ closeForms, canEdit, contentItem, author, getAuthor }) => {
    const settings = useSelector((state) => state.AppSettingsReducer.KnowledgeCenter);

    const currentUser = useSelector((state) => {
        const user = state.UserReducer.UserInfo.Data;
        return {
            isAdmin: user.Permissions.CanAdmin,
            userInfo: user,
        };
    });

    const [isEditing, setIsEditing] = useState(false);
    const [deletedTabIDs, setDeletedTabIDs] = useState([]);
    const [selectedTabIDs, setSelectedTabIDs] = useState(contentItem.Tabs);
    const [fields, setFields] = useState(contentItem);

    const [uploadedFileInfo, setUploadedFileInfo] = useState({ path: contentItem.Url, fileName: contentItem.AttachmentName });
    const [isUploading, setIsUploading] = useState(false);

    const [validationMessage, setValidationMessage] = useState(null);

    const [ssWarnHide, setSSWarnHide] = React.useState(false);
    const [showSellSideWarning, setShowSellSideWarning] = useState(false);

    const dispatch = useDispatch();
    const setKnowledgeCenterSettingsDispatcher = React.useCallback(
        (setting) => {
            dispatch(setKnowledgeCenterSettings(setting));
        },
        [dispatch]
    );

    const tabs = useSelector((state) => state.ContentReducer.Content.Tabs);

    const enableEditMode = () => {
        closeForms(); // close the Post Creator form if editing an item to prevent too many open editors in the UI
        setIsEditing(true);
    };

    const handleChange = (event) => {
        setValidationMessage(null);
        setFields({ ...fields, ...event });
    };

    const handleEditorChange = (updatedText) => handleChange({ Description: updatedText });

    // Removes TabID and adds to DeletedIDs array
    const handleUncheckedTab = (tabItem, amountOfTabsSelected) => {
        if (amountOfTabsSelected === 1) return selectedTabIDs; // Min of 1 tab required
        setDeletedTabIDs([...deletedTabIDs, tabItem.TabID]);
        return selectedTabIDs.filter((tabID) => tabID !== tabItem.TabID);
    };

    const handleTabCheckbox = (event, tabItem) => {
        // Ensure if checked again its removed from deleted
        if (event.target.checked) setDeletedTabIDs(deletedTabIDs.filter((tabID) => tabID != tabItem.TabID));

        setSelectedTabIDs(event.target.checked ? [...selectedTabIDs, tabItem.TabID] : handleUncheckedTab(tabItem, selectedTabIDs.length));
    };

    const [showingDeleteDialog, setShowingDeleteDialog] = useState(false);
    const handleDeleteClose = () => setShowingDeleteDialog(false);
    const handleDeleteConfirm = () => {
        dispatch(deleteContent(contentItem.ContentID));
        setShowingDeleteDialog(false);
    };

    const handleUpdateContent = () => {
        const { isValid, message } = validateContent(fields);

        if (!isValid) {
            setValidationMessage(message);
            return;
        }

        dispatch(
            updateContent({
                ...fields,
                AttachmentName: uploadedFileInfo.fileName,
                Url: uploadedFileInfo.path,
                Tabs: selectedTabIDs,
                DeletedTabs: deletedTabIDs,
                UpdatedByUserID: currentUser.userInfo.UserID,
            })
        );
        setIsEditing(false);
    };

    const cancelEdit = () => {
        setFields(contentItem);
        setUploadedFileInfo({ path: contentItem.Url, fileName: contentItem.AttachmentName });
        setSelectedTabIDs(contentItem.Tabs);
        setIsEditing(false);
    };

    const handleSSWarnHideChecked = () => {
        setSSWarnHide(!ssWarnHide);
    };

    const handleSellSideWarningConfirm = () => {
        setShowSellSideWarning(false);
        setKnowledgeCenterSettingsDispatcher({ disableSellSideWarning: ssWarnHide });
    };

    const handleSellSideWarningClose = () => {
        setShowSellSideWarning(false);
    };

    const GuardWithSellSideWarning = ({ MessageGuard, NoMessageGuard }) => {
        return !_get(settings, 'disableSellSideWarning', false) ? <MessageGuard /> : <NoMessageGuard />;
    };

    const NewTooltip = ({ children }) => <div className="tooltiptext">{children}</div>;

    const ContentIcon = ({ contentItem }) => {
        return (
            <GuardWithSellSideWarning
                MessageGuard={() => (
                    <div className="content-icon tooltip-wrapper">
                        <Icon
                            iconType="DEFAULT"
                            label="1 Attachment"
                            classes="pointer"
                            iconName={getFileExtensionIcon(contentItem.AttachmentName, FA_ICONS_LIST)}
                            onClick={() => setShowSellSideWarning(true)}
                        />

                        <NewTooltip>{contentItem.AttachmentName}</NewTooltip>
                    </div>
                )}
                NoMessageGuard={() => (
                    <Downloader className="content-icon tooltip-wrapper" useApiResource={true} uri={'/files/' + contentItem.Url}>
                        <Icon iconType="DEFAULT" label="1 Attachment" classes="pointer" iconName={getFileExtensionIcon(contentItem.AttachmentName, FA_ICONS_LIST)} />
                        <NewTooltip>{contentItem.AttachmentName}</NewTooltip>
                    </Downloader>
                )}
            />
        );
    };

    const ContentLink = ({ contentItem }) => {
        return (
            <GuardWithSellSideWarning
                MessageGuard={() => (
                    <span className="body-text-link pointer" onClick={() => setShowSellSideWarning(true)}>
                        {contentItem.Title}
                    </span>
                )}
                NoMessageGuard={() => (
                    <Downloader useApiResource={true} className="body-text-link pointer" uri={'/files/' + contentItem.Url}>
                        {contentItem.Title}
                    </Downloader>
                )}
            />
        );
    };

    const ContentLastUpdated = ({ content, getAuthor }) => {
        if (!content.UpdatedByUserID) return null;

        const updatedByAuthor = content.UpdatedByUserID === content.AuthorID;

        return (
            <div className="ab-article-byline-content">
                <div>Updated {formatDate(content.UpdatedDate)}</div>
                {!updatedByAuthor && <div className="ab-article-author-content">({getAuthor(content.UpdatedByUserID)})</div>}
            </div>
        );
    };

    return (
        <div>
            {isEditing ? (
                <TabContentRichTextEditor
                    onChange={handleEditorChange}
                    textValue={fields.Description}
                    actions={
                        <>
                            {validationMessage && <div className="ab-validation-warning">{validationMessage}</div>}
                            <Button className="secondary" onClick={() => cancelEdit()}>
                                Cancel
                            </Button>
                            <Button onClick={() => handleUpdateContent()}>Save</Button>
                        </>
                    }
                >
                    <div className="edit-content-header">
                        <div className="edit-content-title w-100 flex flex-col">
                            <TextField onChange={(e) => handleChange(e)} name="Title" value={fields.Title} required placeholder="Title" className={'w-50 m-2'} />
                        </div>
                        <div className="edit-content-tabs">
                            <>
                                <div className="tabs-include flex flex-row items-center">
                                    <span className="ab-form-label">Include under Tabs:</span>
                                </div>
                                {tabs.map((tabItem) => (
                                    <div className="tabs-inputs flex flex-row items-center mx-2" key={tabItem.TabID}>
                                        <span className="m-2">{tabItem.Name}</span>
                                        <input className="mr-2" checked={selectedTabIDs.includes(tabItem.TabID)} onChange={(e) => handleTabCheckbox(e, tabItem)} type="checkbox" />
                                    </div>
                                ))}
                            </>
                        </div>

                        <AttachmentUpload isUploading={isUploading} setIsUploading={setIsUploading} uploadedFileInfo={uploadedFileInfo} setUploadedFileInfo={setUploadedFileInfo} />
                    </div>
                </TabContentRichTextEditor>
            ) : (
                <div className="content-item" key={contentItem.ContentID}>
                    <div className="content-item-top">
                        <span className="ab-event">
                            <div className="content-item-header">
                                <div className="content-item-title">
                                    <div>
                                        {contentItem.Url ? <ContentLink contentItem={contentItem} /> : <span className="body-text-link-disabled">{contentItem.Title}</span>}
                                        {contentItem.Url && <ContentIcon contentItem={contentItem} />}
                                    </div>
                                    {(currentUser.isAdmin || canEdit) && (
                                        <div className="content-item-actions">
                                            <Icon iconName="EDIT" onClick={() => enableEditMode()}></Icon>
                                            <Icon iconName="TRASH" onClick={() => setShowingDeleteDialog(true)}></Icon>
                                        </div>
                                    )}
                                </div>
                                <div className="content-item-info">
                                    <span className="content-item-info-date">{formatDate(contentItem.InsertedDate)}</span>
                                    <span className="content-item-info-author"> / By {author}</span>
                                    <ContentLastUpdated content={contentItem} getAuthor={getAuthor} />
                                </div>
                            </div>
                        </span>
                    </div>
                    <span dangerouslySetInnerHTML={{ __html: dompurify.sanitize(contentItem.Description) }}></span>
                </div>
            )}

            <SellSideWarning
                ssWarnHide={ssWarnHide}
                onClose={handleSellSideWarningClose}
                isShowing={showSellSideWarning}
                handleChecked={handleSSWarnHideChecked}
                close={() => setShowSellSideWarning(false)}
                confirm={handleSellSideWarningConfirm}
                customActions={() => {
                    return (
                        <React.Fragment>
                            <Button className="secondary" onClick={handleSellSideWarningClose}>
                                Cancel
                            </Button>
                            <Downloader useApiResource={true} uri={'/files/' + contentItem.Url} onClick={handleSellSideWarningConfirm}>
                                <Button>Confirm & Read</Button>
                            </Downloader>
                        </React.Fragment>
                    );
                }}
            />
            <Popover
                onClose={handleDeleteClose}
                show={showingDeleteDialog}
                title="Delete Post"
                size={DialogSizes.CONFIRM}
                lockHeight={true}
                actions={
                    <React.Fragment>
                        <Button className="secondary" onClick={handleDeleteClose}>
                            Cancel
                        </Button>
                        <Button onClick={handleDeleteConfirm}>
                            <span>Delete</span>
                            <i className="fas fa-trash-alt"></i>
                        </Button>
                    </React.Fragment>
                }
            >
                <React.Fragment>
                    <p>This will remove the following post from the Knowledge Center database:</p>
                    <p>
                        <b>{contentItem.Title}</b>
                    </p>
                    <p>Are you sure you want to continue?</p>
                </React.Fragment>
            </Popover>
        </div>
    );
};

export default withStyles(styles)(EditContent);
