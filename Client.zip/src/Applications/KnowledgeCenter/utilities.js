import _get from 'lodash/get';
import { isNullOrEmpty } from '../../Utils/stringHelper';

export const categoryMap = Object.freeze({
    company: 'Company',
    companies: 'Companies',
    country: 'Country',
    countries: 'Countries',
    documentSource: "Document Source",
    documentSources: 'Document Sources',
    industries: "Industries",
    keyIssue: 'ESG Key Issues',
    keyIssues: 'ESG Key Issues',
    environment: 'Environment Issues',
    gicsSector: 'GICS Sector',
    gicsSectors: 'GICS Sector',
    governance: 'Governance Issues',
    otherDocumentType: "Document Type",
    otherDocumentTypes: 'Document Types',
    publisher: 'Publisher',
    publishers: 'Publishers',
    region: 'Region',
    regions: 'Regions',
    securities: 'Securities',
    social: 'Social Issues',
    team: "Team",
    teams: "Teams",
});

export const esgTypes = Object.freeze(['environment', 'social', 'governance']);

export const documentSources = Object.freeze({
    Internal: 1,
    NonSellSide: 2,
    SellSide: 3,
    Uncategorized: 4,
});

export const subdomains = Object.freeze({
    Uploads: 'KnowledgeCenter::Upload',
    Attachments: 'Note::Attachments',
    Notes: 'Note',
});

export const subdomainLabels = Object.freeze({
    [subdomains.Uploads]: 'Upload',
    [subdomains.Attachments]: 'Attachment',
    [subdomains.Notes]: 'Note',
});

export const extractHitsFromSnippet = (snippet) => snippet.match(/<em>(.*?)<\/em>/g) || [];

export const getFileTerms = (file, dedup = true) => {
    const rawHighlights = Array.isArray(file.Content)
        ? file.Content.map(extractHitsFromSnippet)
        : [];

    const highlights = rawHighlights.reduce((acc, highlight) => {
        return [
            ...acc,
            ...highlight.map(i => sanitize(String(i).toLowerCase()))
        ];
    }, []);

    return dedup === true
        ? [...new Set(highlights)]
        : highlights;
}

export const getSubdomainLabel = (file, field) => subdomainLabels[_get(file, field)];

export const getTerms = (files) => files.reduce((acc, file) => {
    const terms = [...acc, ...getFileTerms(file, false)];

    return [...new Set(terms)];
}, []);

export const sanitize = raw => {
    const fragment = raw == null ? '' : raw.replace(/<\/?[^>]+(>|$)/g, '');
    return String(fragment).trim().replace(/\n/g, ' ').replace(/\s+/g, ' ');
};

export const isAnnouncementValid = (fields) => {
    let isValid = true;
    // Regex for Quill.js text input to filter the html tags
    const textIsBlank = fields['text'].replace(/<(.|\n)*?>/g, '').trim().length === 0;
    if (!fields.title || textIsBlank) {
        isValid = false;
    }
    return isValid;
};

export const validateContent = (fields) => {
    // Regex for Quill.js text input to filter the html tags
    const isFieldBlank = (value) => value == null || value.replace(/<(.|\n)*?>/g, '').trim().length === 0;

    const rules = [
        { ruleName: 'hasTitle', field: "Title", isFieldValid: value => !isNullOrEmpty(value), validationMessage: "Title" },
        { ruleName: 'hasDescription', field: "Description", isFieldValid: value => !isFieldBlank(value), validationMessage: "Description" },
    ];

    const result =  rules.map(rule => ({ ...rule, isValid: rule.isFieldValid(fields[rule.field]) }));
    const allFieldsAreValid = result.filter(r=>!r.isValid).length === 0;

    return ({
            isValid: allFieldsAreValid,
            message:  !allFieldsAreValid ? "Missing required fields: " + result
                                .filter(r=> !r.isValid)
                                .map(r=>r.validationMessage)
                                .join(", ") : ""
            })
};

export const reverseNameOrder =  fullName => fullName.split(", ").reverse().join(" ");

export const getAuthor = (authorId, analysts) => {
    const analyst = Array.isArray(analysts) ? analysts.find((analyst) => analyst.UserID === authorId) : null;
    return analyst != null ? analyst.FullName : '';
};
