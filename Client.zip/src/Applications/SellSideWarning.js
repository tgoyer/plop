import React from 'react';

import { withStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '../componentlibrary/buttons/Button';
import { Popover, DialogSizes } from '../components/Dialogs';

const styles = (theme) => ({
    paper: {
        margin: 0,
        padding: 8,
        visibility: 'visible',
        width: '100%',
        '& p': {
            marginLeft: 10,
            marginRight: 10,
        },
        '&:last-child': {
            marginBottom: 0,
        },
    },
    gridsContainer: {
        marginTop: 20,
    },
    panelColumn: {
        '& > div + div': {
            marginTop: 12,
        },
    },
    viewContainer: {
        display: 'flex',
        flexDirection: 'column',
        '& > div + div': {
            marginTop: 12,
        },
    },
    '@media (min-width: 1450px)': {
        gridsContainer: {
            marginTop: 0,
        },
        viewContainer: {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            '& > div': {
                flex: '1 1 50%',
            },
            '& > div + div': {
                marginLeft: 12,
                marginTop: 0,
            },
        },
    },
});

const SellSideWarning = ({ ssWarnHide, classes, onClose, isShowing, handleChecked, confirm, close, customActions }) => {
    return (
        <Popover
            onClose={onClose}
            show={isShowing}
            title="Compliance Notification"
            size={DialogSizes.SMALL}
            lockHeight={true}
            actions={
                customActions ? (
                    customActions()
                ) : (
                    <React.Fragment>
                        <Button className="secondary" onClick={close}>
                            Cancel
                        </Button>
                        <Button onClick={confirm}>Confirm</Button>
                    </React.Fragment>
                )
            }
        >
            <div className={classes.headerText}>Compliance Notification:</div>
            <div className={classes.messageContainer}>
                <p>
                    In-scope EMEA investment professionals operating under MiFID II Research rules – any third party i.e. broker research consumption must be from an approved research provider. CARS
                    Team maintains an up to date list of these. You must check prior to consumption.
                </p>
                <p>
                    <Checkbox checked={ssWarnHide} onChange={handleChecked} /> Do not show again during this session
                </p>
            </div>
        </Popover>
    );
};

export default withStyles(styles)(SellSideWarning);
