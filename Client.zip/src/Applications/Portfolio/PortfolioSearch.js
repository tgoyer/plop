import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { default as Search } from '../../UIComponents/PortfolioSearch';

import { setLocalSetting } from '../../store/AppSettingsModule';
import { selectAccount } from '../../store/PortfolioModule';

const PortfolioSearch = (props) => {
    const { Account, history, onSearch, isFavorite, onFavoriteClick, selectAccountDispatcher, setLocalSettingDispatcher } = props;

    const handleOnChange = (item) => {
        const { accountID } = item;
        Promise.all([selectAccountDispatcher(item), setLocalSettingDispatcher({ accountId: accountID })]);
        history.push(`/Portfolio/${accountID}`);

        if (onSearch != null) {
            onSearch(item);
        }
    };

    return <Search Account={Account} isFavorite={isFavorite} onFavoriteClick={onFavoriteClick} onSearch={handleOnChange} />;
};

const mapStateToProps = (state) => {
    return {
        Account: state.PortfolioReducer.Account.Data,
    };
};

const mapDispatchToProps = (dispatch) => ({
    selectAccountDispatcher: (account) => dispatch(selectAccount(account)),
    setLocalSettingDispatcher: (value) => dispatch(setLocalSetting('Portfolio', value)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(PortfolioSearch));
