import { formatCurrency, roundDecimal } from '../../Utils/numberHelper';
import { formatDate } from '../../Utils/dateHelper';

const crlf = String.fromCharCode(10) + String.fromCharCode(13);

export const getExcelColumnDefinitions = (gridSettings) => {
    return getColumns(gridSettings).reduce((acc, column) => {
        const excelMapping = excelColumnMap.find((ecm) => column.id === ecm.key);

        return excelMapping != null && column != null && column.show && excelMapping != null
            ? [...acc, { key: excelMapping.key, value: excelMapping.value }]
            : acc;
    }, []);
};

export const getExcelData = (gridRef, gridSettings) => () => {
    const grid = gridRef.current;
    const data = grid.getResolvedState().sortedData;
    const columnDefinitions = getColumns(gridSettings);
    
    return data == null
        ? []
        : data.map((item) => {
              return Object.keys(item).reduce((acc, key) => {
                  try {
                      const column = columnDefinitions.find((c) => c.id === key);
                      if (column != null && column.show) {
                          const def = excelColumnMap.find((ecm) => ecm.key === key);
                          acc[key] = def != null ? formatExcelData(item[key], def.dataType) : item[key];
                      }
                  } catch (ex) {
                      console.log(key, item);
                  }
                  return acc;
              }, {});
          });
};

const formatExcelData = (value, dataType) => {
    if (value == null || String(value).trim() === '') return '';
    if (dataType == null) return value;

    const typeParamDelimiter = ':';
    const typeParams = dataType.split(typeParamDelimiter);
    const decimalPrecision = typeParams[1] != null ? Number(typeParams[1]) : 2;
    const percentPrecision = typeParams[1] != null ? Number(typeParams[1]) : 4;
    const splitDelimiter = typeParams[1] != null ? typeParams[1] : '|';

    switch (typeParams[0]) {
        case 'bool':
            return Boolean(value) || parseInt(value) === 1 || String(value).toLowerCase().trim() === 'yes';
        case 'date':
            return new Date(value).toISOString().substring(0,10);
        case 'decimal':
            return Number(roundDecimal(value, decimalPrecision + 2).toFixed(decimalPrecision));
        case 'decimal100':
            return Number(roundDecimal(value * 100, decimalPrecision + 2).toFixed(decimalPrecision));
        case 'split':
            return String(value)
                .split(splitDelimiter)
                .map((i) => String(i).trim())
                .join(' ' + crlf);
        case 'int':
            return parseInt(value, 10);
        case 'money':
            return formatCurrency(value);
        case 'percent':
            return `${Number(value.toFixed(percentPrecision))}%`;
        case 'yesblank':
            return Boolean(value) || parseInt(value) === 1 || String(value).toLowerCase().trim() === 'yes' ? 'Yes' : '';
        case 'yesno':
            return Boolean(value) || parseInt(value) === 1 || String(value).toLowerCase().trim() === 'yes' ? 'Yes' : value != null ? 'No' : '';
        case 'MARKET':
            return value === 'Developed Markets' ? 'DM' : value === 'Emerging' ? 'EM' : value;
        case 'RSRCHNOTE':
            return extractResearchNotes(value);
        default:
            return String(value).trim();
    }
};

const extractResearchNotes = (value) => {
    const sectionMap = { e: 'Env', s: 'Soc', g: 'Gov' };
    return Object.keys(value).reduce((acc, key) => {
        if (value[key] != null) {
            acc += `${sectionMap[key]}: ${value[key]}${crlf}`;
        }
        return acc;
    }, '');
};

const getColumns = (gridSettings) => {
    return gridSettings.reduce((acc, section) => [...acc, ...section.columns], []);
};

const excelColumnMap = [
    { key: 'AccountID', dataType: 'int', value: 'Account ID' },
    { key: 'AccountName', dataType: 'string', value: 'Account Name' },
    { key: 'CompanyID', dataType: 'int', value: 'Company ID' },
    { key: 'GICSIndustry', dataType: 'string', value: 'GICS Industry' },
    { key: 'CompanyName', dataType: 'string', value: 'Company Name' },
    { key: 'Region', dataType: 'string', value: 'Region' },
    { key: 'GICSSector', dataType: 'string', value: 'Sector' },
    { key: 'HeldWeight', dataType: 'decimal100:4', value: 'Port Wgt' },
    { key: 'BenchmarkWeight', dataType: 'decimal100:4', value: 'Bench Wgt' },
    { key: 'BenchmarkName', dataType: 'string', value: 'Bench Name' },
    { key: 'LastRsrchNote', dataType: 'RSRCHNOTE', value: 'Esight Research - Research Notes' },
    { key: 'LastRsrchNoteKI', dataType: 'split', value: 'Esight Research - Key Issues' },
    { key: 'LastRsrchNoteDate', dataType: 'date', value: 'Esight Research - Note Date'},
    { key: 'LastRsrchNoteAnalyst', dataType: 'string', value: 'Esight Research - Analyst' },
    { key: 'LastRsrchNoteMRC', dataType: 'string', value: 'Esight Research - Rating Consensus' },
    { key: 'ERating', dataType: 'string', value: 'Esight Research - E Score' },
    { key: 'SRating', dataType: 'string', value: 'Esight Research - S Score' },
    { key: 'GRating', dataType: 'string', value: 'Esight Research - G Score' },

    { key: 'HasViolations', dataType: 'string', value: 'Compliance Overview - Needs Oversight' },
    { key: 'CCC', dataType: 'string', value: 'Compliance Overview - CCC Rating' },
    { key: 'GovLT3', dataType: 'string', value: 'Compliance Overview - Gov < 3' },
    { key: 'UNGCViolator', dataType: 'string', value: 'Compliance Overview - UNGC Violator' },
    { key: 'StaleEngagement', dataType: 'string', value: 'Compliance Overview - Stale Engagement' },

    { key: 'LastEngNoteKI', dataType: 'split', value: 'Esight Engagement - Key Issues' },
    { key: 'LastEngNoteObjective', dataType: 'string', value: 'Esight Engagement - Objective' },
    { key: 'LastEngNoteDate', dataType: 'date', value: 'Esight Engagement - Date', formatting: 'mm-dd-yyyy' },
    { key: 'LastEngNoteAnalyst', dataType: 'string', value: 'Esight Engagement - Analyst' },
    { key: 'LastEngNoteEIF', dataType: 'string', value: 'Esight Engagement - Effect on Inv Thesis' },
    { key: 'LastEngNotePA', dataType: 'string', value: 'Esight Engagement - Port Action' },
    { key: 'MSCIRating', dataType: 'string', value: 'MSCI - Letter Rating' },
    { key: 'MSCIRatingDate', dataType: 'date', value: 'MSCI - Rating Date' },
    { key: 'RatingTrend', dataType: 'string', value: 'MSCI - 12 Mth Rating Change' },
    { key: 'ABVAnticipatedRating', dataType: 'string', value: 'MSCI - Anticipated Rating' },
    { key: 'ABVOverrideRating', dataType: 'string', value: 'MSCI - AB Value Proprietary Rating' },
    { key: 'MSCIEPillarQuartile', dataType: 'int', value: 'MSCI - E Pillar Quartile' },
    { key: 'MSCILowestEQuartile', dataType: 'int', value: 'MSCI - E Pillar Lowest Quartile' },
    { key: 'MSCILowestEQuartileIssueName', dataType: 'string', value: 'MSCI - E Pillar Lowest Key Issue' },
    { key: 'MSCILowestEScore', dataType: 'decimal', value: 'MSCI - E Pillar Lowest Score' },
    { key: 'MSCISPillarQuartile', dataType: 'int', value: 'MSCI - S Pillar Quartile' },
    { key: 'MSCILowestSQuartile', dataType: 'int', value: 'MSCI - S Pillar Lowest Quartile' },
    { key: 'MSCILowestSQuartileIssueName', dataType: 'string', value: 'MSCI - S Pillar Lowest Key Issue' },
    { key: 'MSCILowestSScore', dataType: 'decimal', value: 'MSCI - S Pillar Lowest Score' },
    { key: 'MSCIGPillarScore', dataType: 'decimal', value: 'MSCI - G Pillar Score' },
    { key: 'MSCIGPillarQuartile', dataType: 'int', value: 'MSCI - G Pillar Quartile' },
    { key: 'MSCIOverallCorpGovPercentile', dataType: 'string', value: 'MSCI - Overall Corp Gov Percentile' },
    { key: 'CorporateBehaviorBottomScore', dataType: 'string', value: 'MSCI - Corp Beh Bottom Score' },
    { key: 'BusinessEthicsMgmtScore', dataType: 'decimal', value: 'MSCI - Business Ethics Man Score' },
    { key: 'AntiCompMgmtScore', dataType: 'decimal', value: 'MSCI - Anti-Comp Man Score' },
    { key: 'CorruptInstQuartile', dataType: 'int', value: 'MSCI - Corruption & Instability Quartile' },
    { key: 'FinSystemInstabilityQuartile', dataType: 'string', value: 'MSCI - Financial System Instability Quartile' },
    { key: 'CoporateGovLowUnderlyingScore', dataType: 'string', value: 'MSCI - Corp Gov Low Underlying Score' },
    { key: 'CoporateGovLowestPercentile', dataType: 'int', value: 'MSCI - Corp Gov Lowest Percentile' },
    { key: 'CoporateGovLowestPercentileIssue', dataType: 'string', value: 'MSCI - Corp Gov Lowest Percentile Issue' },
    { key: 'HighestControversy', dataType: 'string', value: 'Sustainalytics - Highest Controversy' },
    { key: 'HighestControversyDate', dataType: 'date', value: 'Sustainalytics - Highest Controversy Date' },
    { key: 'ControveryIssues', dataType: 'split', value: 'Sustainalytics - Highest Controversy Key Issues' },
    { key: 'RiskRatingScore', dataType: 'decimal', value: 'Sustainalytics - Risk Rating' },
    { key: 'RiskRatingDate', dataType: 'date', value: 'Sustainalytics - Risk Rating Date' },
    { key: 'ProxyMeetingDate', dataType: 'date', value: 'Proxy Vote - Last Meeting Date' },
    { key: 'VoteAgainst', dataType: 'yesno', value: 'Proxy Vote - Vote(s) Against Mgmt' },
    { key: 'Sedol', dataType: 'string', value: '7-Digit Sedol' },
    { key: 'Cusip', dataType: 'string', value: 'Cusip' },
    { key: 'Isin', dataType: 'string', value: 'ISIN' },
    { key: 'MSCIIssuerID', dataType: 'string', value: 'MSCI Issuer ID' },
    { key: 'Ticker', dataType: 'string', value: 'AB Ticker' },
    { key: 'Quantity', dataType: 'int', value: 'Quantity' },
    { key: 'ValueUSD', dataType: 'money', value: 'Value (USD)' },
    { key: 'MktCapMM', dataType: 'decimal:3', value: 'Market Cap (MM)' },
    { key: 'SharesOutMM', dataType: 'decimal:5', value: 'Shares Outstanding (MM)' },
    { key: 'Market', dataType: 'MARKET', value: 'Market' },
    { key: 'Country', dataType: 'string', value: 'Country' },
    { key: 'GrowthAnalyst', dataType: 'split:;', value: 'Growth Analysts' },
    { key: 'ValueAnalyst', dataType: 'split:;', value: 'Value Analysts' },
    { key: 'FirmValueUSD', dataType: 'money', value: 'Securities Firm Value (USD)' },
    { key: 'AccSecFirmValueUSD', dataType: 'money', value: 'Acc Securities Firm Value (USD)' },
    { key: 'CompanyFirmValueUSD', dataType: 'money', value: 'Firm All Value (USD)' },
    { key: 'OwnershipCategory', dataType: 'string', value: 'Ownership Category' },
    { key: 'BoardIndependencePct', dataType: 'percent:2', value: 'Board Independence' },
    { key: 'FemaleDirectorsPct', dataType: 'percent:2', value: 'Female Directors' },
    { key: 'NomberOfControversies', dataType: 'string', value: 'Number of Controversies' },
    { key: 'OneShareOneVoteIssue', dataType: 'yesno', value: 'One Share One Vote' },
    { key: 'CombinedCEOChair', dataType: 'yesno', value: 'Combined CEO Chair' },
    { key: 'EntranchedBoard', dataType: 'yesno', value: 'Entrenched Board' },
    { key: 'OtherHighImpactGovEvents', dataType: 'yesno', value: 'Other High Impact Governance' },
];
