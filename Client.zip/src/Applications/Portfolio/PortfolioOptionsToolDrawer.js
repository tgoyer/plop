import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from '../../UIComponents/Tooltip';
import { DrawerSection, GlobalFiltersDrawerSection, ToolDrawer } from '../../UIComponents/ToolDrawer';
import { DraggableContainer } from '../../UIComponents/DraggableContainer';
import SaveDialog from '../../UIComponents/MaterialUI/CommonDialog';

import { pxToRem } from '../../Utils/layoutHelper';
import { findIndex } from '../../Utils/listHelper';

const styles = (theme) => ({
    actionsContainer: {
        display: 'inline-block',
        float: 'right',
    },
    actionIcons: {
        float: 'right',
    },
    columnSortHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: pxToRem(14),
        margin: '5px 0px 5px 20px',
        padding: 5,
    },
    columnSortItem: {
        backgroundColor: '#fff',
        borderBottom: '2px solid #fff',
        color: '#000',
        margin: '0 0 0 20px',
        padding: 1,
        userSelect: 'none',
        zIndex: 5000,
        '&:hover': {
            backgroundColor: '#fff3d6',
        },
    },
    columnSortItemDisabled: {
        backgroundColor: '#fff',
        color: '#999',
        cursor: 'not-allowed',
        '&:hover': {
            backgroundColor: '#fff',
        },
    },
    columnIconDisabled: {
        color: 'white',
        '&:hover': {
            color: '#999',
        },
    },
    columnIconEnabled: {
        color: 'black',
    },
    configArrow: {
        fontWeight: 700,
        paddingRight: 5,
    },
    configActive: {
        color: 'black',
    },
    configInactive: {
        color: 'transparent',
    },
    drawerActions: {
        backgroundColor: 'white',
        bottom: 0,
        borderTop: '1px solid #ccc',
        boxShadow: '0px -2px 2px 1px rgba(0, 0, 0, 0.1)',
        padding: 10,
        position: 'absolute',
        right: 0,
        width: '100%',
        '& > button': {
            margin: '0 5px',
        },
    },
    icon: {
        cursor: 'pointer',
        padding: '8px',
    },
    linkButton: {
        background: 'none',
        border: 0,
        color: theme.palette.primary.main,
        margin: 0,
        padding: 0,
        minWidth: 40,
        cursor: 'pointer',
    },
    primaryButton: {
        backgroundColor: theme.palette.primary.main,
        color: '#eee',
        '&:disabled': {
            color: '#fff',
            opacity: 0.45,
        },
        '&:hover': {
            backgroundColor: '#495e81',
            color: '#fff',
        },
    },
    savedItemName: {
        cursor: 'pointer',
        display: 'inline-block',
        overflow: 'hidden',
        padding: '4px 0 4px 26px',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        width: 'calc(100% - 32px)',
    },
    sectionGlobalFilters: {
        maxHeight: '150px',
    },
    sortIcons: {
        cursor: 'ns-resize',
    },
    subHeaderButton: {
        fontWeight: 700,
        padding: '0 12px',
    },
});

const initialState = {
    dialog: {
        message: null,
        show: false,
    },
    canSaveName: false,
    saveAsName: '',
    saveAsNameExists: false,
    sections: [],
    expanded: {
        toolSections: {
            columnSort: false,
            globalFilters: false,
        },
    },
};

class PortfolioOptionsToolDrawer extends React.Component {
    constructor(props) {
        super(props);

        this.state = { ...initialState };
    }

    componentWillMount = () => {
        this.setState(this.getColumnSections());
    };

    getColumnSections = () => {
        const { columnSections } = this.props;
        return {
            sections: columnSections.map((cs) => ({
                id: cs.id,
                label: cs.label,
                fixed: cs.fixed,
                columns: cs.columns.map((column) => ({
                    id: column.id,
                    accessor: column.accessor,
                    collapsable: column.collapsable,
                    hidden: column.hidden,
                    label: column.label,
                })),
            })),
        };
    };

    getColumnValue = (sectionName, columnName, fieldName) => {
        const sections = this.state.sections;
        const idx = findIndex(sections, (setting) => setting.id === sectionName);
        const column = sections[idx]['columns'].find((c) => c.id === columnName);

        return column != null ? column[fieldName] : null;
    };

    handleColumnApply = (e) => {
        e.preventDefault();
        e.stopPropagation();

        e.preventDefault();
        e.stopPropagation();

        const { onColumnApply } = this.props;
        const { sections } = this.state;
        if (onColumnApply != null) {
            onColumnApply(sections);
        }
    };

    handleColumnReset = (e) => {
        e.preventDefault();
        e.stopPropagation();

        const { onColumnReset } = this.props;

        if (onColumnReset != null) {
            onColumnReset();
        }
    };

    handleColumnSave = (e) => {
        e.preventDefault();
        e.stopPropagation();

        const dialog = {
            ...this.state.dialog,
            show: true,
            onClose: this.onDialogClose,
            onConfirm: async () => {
                const { onColumnSave } = this.props;
                const { saveAsName, sections } = this.state;
                this.setState(
                    {
                        dialog: {
                            ...initialState.dialog,
                            onClose: this.onDialogClose,
                            onConfirm: () => {},
                        },
                        saveAsName: '',
                        saveAsNameExists: false,
                        canSaveName: false,
                    },
                    () => {
                        if (onColumnSave != null) {
                            onColumnSave(saveAsName, sections);
                        }
                    }
                );
            },
        };

        this.setState({ dialog });
    };

    handleSaveAsNameChange = (evt) => {
        const { gridConfigurations } = this.props;
        const saveAsName = evt.target.value;
        const savedConfig = gridConfigurations != null && Object.keys(gridConfigurations).find((key) => gridConfigurations[key].name === saveAsName);
        const saveAsNameExists = savedConfig != null;

        this.setState({
            saveAsName,
            saveAsNameExists,
            canSaveName: saveAsName != null && saveAsName.length > 0,
        });
    };

    onLoadFavorite = (key) => () => {
        const { onLoadFavorite } = this.props;

        if (onLoadFavorite) {
            onLoadFavorite(key);
        }
    };

    onLoadSavedConfig = (key) => () => {
        const { onLoadSavedConfig } = this.props;

        if (onLoadSavedConfig) {
            onLoadSavedConfig(key);
        }
    };

    onToggleFavorite = (key) => (evt) => {
        const { onToggleFavorite } = this.props;

        if (onToggleFavorite) {
            onToggleFavorite(key);
        }
    };

    onDeleteSavedConfig = (key) => (evt) => {
        const { onDeleteSavedConfig } = this.props;

        if (onDeleteSavedConfig) {
            onDeleteSavedConfig(key);
        }
    };

    onDialogClose = () => {
        this.setState(
            {
                dialog: {
                    ...this.state.dialog,
                    show: false,
                },
            },
            () => {
                setTimeout(
                    () =>
                        this.setState({
                            dialog: {
                                ...this.state.dialog,
                                ...initialState.dialog,
                                onClose: this.onDialogClose,
                                onConfirm: () => null,
                            },
                            saveAsName: '',
                            saveAsNameExists: false,
                            canSaveName: false,
                        }),
                    500
                );
            }
        );
    };

    onHide = (sectionName, columnName) => () => {
        const isPinned = !this.getColumnValue(sectionName, columnName, 'collapsable');
        const isVisible = !this.getColumnValue(sectionName, columnName, 'hidden');

        if (isPinned && isVisible) {
            this.toggleColumnValue(sectionName, columnName, 'collapsable');
        }
        this.toggleColumnValue(sectionName, columnName, 'hidden');
    };

    onOrderChange = (sectionId) => (element, columns) => {
        const sections = this.state.sections;
        const sectionIndex = findIndex(sections, (section) => section.id === sectionId);

        if (sectionIndex >= 0) {
            sections[sectionIndex].columns = columns;
            this.setState({ sections });
        }
    };

    onPin = (sectionName, columnName) => () => {
        this.toggleColumnValue(sectionName, columnName, 'collapsable');
    };

    toggleColumnValue = (sectionName, columnName, fieldName) => {
        const sections = this.state.sections;
        const idx = findIndex(sections, (setting) => setting.id === sectionName);

        sections[idx]['columns'].forEach((c) => {
            c[fieldName] = c.id === columnName ? !c[fieldName] : c[fieldName];
        });

        this.setState({ sections });
    };

    render = () => {
        const {
            classes,
            favoritePortfolios,
            filterDate,
            filterTeam,
            gridConfigurations,
            loadedConfigKey,
            onGlobalFilterSave,
            showDateSelection,
            showTeamSelection,
        } = this.props;

        return (
            <React.Fragment>
                <ToolDrawer>
                    <GlobalFiltersDrawerSection
                        onSave={onGlobalFilterSave}
                        filterDate={filterDate}
                        filterTeam={filterTeam}
                        showDateSelection={showDateSelection}
                        showTeamSelection={showTeamSelection}
                    />
                    <DrawerSection label="Saved Items">
                        <div className={classes.sectionBlock}>
                            <div className={classes.columnSortHeader}>Favorite Portfolios</div>
                            {favoritePortfolios == null || Object.keys(favoritePortfolios).length === 0 ? (
                                <div className={cn(classes.columnSortItem, classes.columnSortItemDisabled)}>
                                    You have no favorite portfolios. Click the "star" beside the Account Search field to designate an account as one of your
                                    favorites!
                                </div>
                            ) : (
                                Object.keys(favoritePortfolios)
                                    .map((key) => ({ key, name: favoritePortfolios[key] }))
                                    .sort((a, b) => (a.name === b.name ? 0 : a.name > b.name ? 1 : -1))
                                    .map(({ key, name }) => {
                                        return (
                                            <div key={key} className={classes.columnSortItem}>
                                                <div>
                                                    <span
                                                        data-tip={true}
                                                        data-for={`${key}_Name_TT`}
                                                        onClick={this.onLoadFavorite(key)}
                                                        className={classes.savedItemName}
                                                    >
                                                        {name}
                                                    </span>
                                                    <Tooltip id={`${key}_Name_TT`}>{name}</Tooltip>
                                                    <span className={classes.actionIcons}>
                                                        <i
                                                            onClick={this.onToggleFavorite(key)}
                                                            data-tip={true}
                                                            data-for={`${key}_Delete_TT`}
                                                            className={cn(classes.icon, 'fas fa-trash-alt')}
                                                        ></i>
                                                        <Tooltip id={`${key}_Delete_TT`}>{`Un-favorite the "${name}" portfolio.`}</Tooltip>
                                                    </span>
                                                </div>
                                            </div>
                                        );
                                    })
                            )}
                        </div>
                        <div className={classes.sectionBlock}>
                            <div className={classes.columnSortHeader}>Saved Grid Layouts</div>
                            {gridConfigurations == null || Object.keys(gridConfigurations).length === 0 ? (
                                <div className={cn(classes.columnSortItem, classes.columnSortItemDisabled)}>
                                    You have no saved custom grid layouts. Open the "Modify Columns" panel to create one!
                                </div>
                            ) : (
                                Object.keys(gridConfigurations).map((key) => {
                                    const config = gridConfigurations[key];
                                    const name = config.name;
                                    return (
                                        <div key={key} className={classes.columnSortItem}>
                                            <div>
                                                <span onClick={this.onLoadSavedConfig(key)} className={classes.savedItemName}>
                                                    <i
                                                        className={cn('fas fa-arrow-right', classes.configArrow, {
                                                            [classes.configActive]: loadedConfigKey === key,
                                                            [classes.configInactive]: loadedConfigKey !== key,
                                                        })}
                                                    />
                                                    {name}
                                                </span>
                                                <span className={classes.actionIcons}>
                                                    <i
                                                        onClick={this.onDeleteSavedConfig(key)}
                                                        data-tip={true}
                                                        data-for={`${key}_Delete_TT`}
                                                        className={cn(classes.icon, 'fas fa-trash-alt')}
                                                    ></i>
                                                    <Tooltip id={`${key}_Delete_TT`}>{`Delete the "${name}" grid configuration.`}</Tooltip>
                                                </span>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </div>
                    </DrawerSection>
                    <DrawerSection
                        label="Modify Columns"
                        actions={(props) => (
                            <React.Fragment>
                                <Button
                                    disabled={!props.active}
                                    data-tip={true}
                                    data-for="reset_TT"
                                    color="primary"
                                    className={cn(classes.linkButton, classes.subHeaderButton)}
                                    onClick={this.handleColumnReset}
                                >
                                    <i className="fas fa-undo"></i>
                                </Button>
                                <Button
                                    disabled={!props.active}
                                    data-tip={true}
                                    data-for="apply_TT"
                                    className={cn(classes.linkButton, classes.subHeaderButton)}
                                    onClick={this.handleColumnApply}
                                >
                                    <i className="fas fa-arrow-alt-circle-down" style={{ marginRight: 8 }}></i>apply
                                </Button>
                                <Button
                                    disabled={!props.active}
                                    color="primary"
                                    className={cn(classes.linkButton, classes.subHeaderButton, classes.primaryButton)}
                                    onClick={this.handleColumnSave}
                                >
                                    <i className="fas fa-save" style={{ marginRight: 8 }}></i>save
                                </Button>
                                <Tooltip id="reset_TT">Reset the current grid view to the default layouts settings.</Tooltip>
                                <Tooltip id="apply_TT">Apply this layout to the grid without saving.</Tooltip>
                            </React.Fragment>
                        )}
                    >
                        {this.state.sections.map((section) => (
                            <div className={classes.sectionBlock} key={section.id}>
                                <div className={classes.columnSortHeader}>{section.label}</div>
                                <DraggableContainer onDrop={this.onOrderChange(section.id)} data={section.columns}>
                                    {(item) => {
                                        const pinnedTooltipText = (
                                            <span>
                                                {`This column ${item.collapsable ? 'has not been' : 'is'} pinned.`}
                                                <br />
                                                When pinned and marked visible, this column
                                                <br />
                                                will show when the group is collapsed.
                                            </span>
                                        );

                                        const showHideTooltipText = item.hidden ? (
                                            <span>This column is hidden. Click this icon to make it visible.</span>
                                        ) : (
                                            <span>This column is visible. Click this icon to hide it.</span>
                                        );

                                        return (
                                            <div key={item.accessor} className={classes.columnSortItem}>
                                                <i className={cn(classes.icon, classes.sortIcons, item.className, 'fas fa-bars')}></i>
                                                {item.label}
                                                <span className={classes.actionIcons}>
                                                    <i
                                                        onClick={this.onPin(section.id, item.id)}
                                                        data-tip={true}
                                                        data-for={`${item.id}_Pinned_TT`}
                                                        className={cn(classes.icon, 'fas fa-thumbtack', {
                                                            [classes.columnIconEnabled]: !item.collapsable,
                                                            [classes.columnIconDisabled]: item.collapsable,
                                                        })}
                                                    ></i>
                                                    <Tooltip id={`${item.id}_Pinned_TT`}>{pinnedTooltipText}</Tooltip>

                                                    <i
                                                        onClick={this.onHide(section.id, item.id)}
                                                        data-tip={true}
                                                        data-for={`${item.id}_ShowHide_TT`}
                                                        className={cn(classes.icon, classes.columnVisibleIcon, 'far fa-eye', {
                                                            [classes.columnIconEnabled]: !item.hidden,
                                                            [classes.columnIconDisabled]: item.hidden,
                                                        })}
                                                    ></i>
                                                    <Tooltip id={`${item.id}_ShowHide_TT`}>{showHideTooltipText}</Tooltip>
                                                </span>
                                            </div>
                                        );
                                    }}
                                </DraggableContainer>
                            </div>
                        ))}
                    </DrawerSection>
                </ToolDrawer>
                <SaveDialog
                    showActions={true}
                    canConfirm={this.state.canSaveName}
                    title="Save and Apply..."
                    open={this.state.dialog.show}
                    onClose={this.state.dialog.onClose}
                    onConfirm={this.state.dialog.onConfirm}
                >
                    <p>
                        Enter a name for this grid configuration. If you enter the name of an existing configuration, the new configuration will replace the old
                        one. This configuration will also be applied to the current grid view.
                    </p>
                    <div style={{ marginLeft: 20 }}>
                        <TextField
                            id="txtSaveAsName"
                            multiline={false}
                            placeholder="Configuration Name"
                            onChange={this.handleSaveAsNameChange}
                            inputProps={{ maxLength: 140 }}
                            value={this.state.saveAsName}
                        />
                        {this.state.saveAsNameExists && (
                            <div style={{ color: '#f08f50', fontSize: 11, paddingTop: 5 }}>
                                This name already exists. Saving will overwrite this configuration.
                            </div>
                        )}
                    </div>
                </SaveDialog>
            </React.Fragment>
        );
    };
}

PortfolioOptionsToolDrawer.propTypes = {
    columnSections: PropTypes.array.isRequired,
    onColumnReset: PropTypes.func.isRequired,
    onColumnSave: PropTypes.func.isRequired,
    onExpandClick: PropTypes.func.isRequired,

    showDateSelection: PropTypes.bool,
    showTeamSelection: PropTypes.bool,
};

export default withStyles(styles)(PortfolioOptionsToolDrawer);
