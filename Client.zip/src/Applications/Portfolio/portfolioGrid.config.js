import React from 'react';
import cn from 'classnames';

import Tooltip from 'componentlibrary/tooltip/Tooltip';
import Downloader from 'componentlibrary/file/Downloader';

import CompanyLink from 'UIComponents/CompanyLink';
import { DataGridDateCell, DataGridLongTextCell, DataGridBooleanCell, DataGridNullDashCell, DataGridPercentCell } from 'UIComponents/DataGrid/Cells';
import { DataGridBooleanFilter, DataGridDateRangeFilter, DataGridDelimitedDropDownFilter, DataGridDropDownFilter, DataGridNumericRangeFilter, DataGridTextFilter } from 'UIComponents/DataGrid/Filters';
import { ExpandableHeader } from 'UIComponents/DataGrid/Header';

import { toDateTime } from 'Utils/dateHelper';
import { formatCurrency, roundDecimal, toPercent } from 'Utils/numberHelper';
import { padEnd } from 'Utils/stringHelper';

export const getGridDefinition = (data, localSettings, classes, onColumnExpandClick) => {
    const sectionExpanded = (sectionName, defaultValue) => {
        const userSetting = localSettings != null && localSettings.length > 0 ? localSettings.find((setting) => setting.id === sectionName) : null;

        return userSetting != null ? userSetting.expanded : defaultValue;
    };

    const columnHidden = (sectionName, columnName, defaultValue) => {
        const section = localSettings.find((s) => s.id === sectionName);
        const column = section != null ? section['columns'].find((col) => col.id === columnName) : null;
        return column != null ? column.hidden : defaultValue;
    };

    const baseColumnGroup = (groupId, label, bgColor, canExpand = true) => {
        return {
            Header: () => (
                <ExpandableHeader canExpand={canExpand} onClick={onColumnExpandClick(groupId)} expanded={sectionExpanded(groupId, false)} style={{ backgroundColor: bgColor }}>
                    {label}
                </ExpandableHeader>
            ),
            id: groupId,
            expanded: sectionExpanded(groupId, false),
            label,
        };
    };

    const baseColumn = (groupId, label, id, width) => ({
        Cell: (props) =>
            props.value == null || props.value === '' ? <DataGridNullDashCell.Component value={props.value} /> : <DataGridLongTextCell.Component>{props.value}</DataGridLongTextCell.Component>,
        Header: label,
        accessor: id,
        collapsable: true,
        headerClassName: classes.gridSubHeader,
        id,
        label,
        hidden: columnHidden(groupId, id, false),
        show: sectionExpanded(groupId, false) && !columnHidden(groupId, id, false),
        style: { textAlign: 'left' },
        width: width || 125,
    });

    const booleanFilterColumn = (groupId, label, id, width) => ({
        ...baseColumn(groupId, label, id, width),
        Cell: (props) => <DataGridBooleanCell.Component value={props.value} />,
        Filter: DataGridBooleanFilter.Filter(data, id),
        filterMethod: DataGridBooleanFilter.filterMethod,
        getProps: (state, row, column) => DataGridBooleanCell.getProps(row, id),
        getHeaderProps: (state, row, column) => DataGridBooleanCell.getHeaderProps(row, id),
        sortMethod: DataGridBooleanFilter.sortMethod,
    });

    const dateRangeFilterColumn = (groupId, label, id, width) => ({
        ...baseColumn(groupId, label, id, width),
        Cell: (props) => (props.value === null ? <DataGridNullDashCell.Component value={props.value} /> : <DataGridDateCell.Component value={props.value} />),
        Filter: DataGridDateRangeFilter.Filter(data, id),
        filterMethod: DataGridDateRangeFilter.filterMethod,
        getHeaderProps: (state, row, column) => DataGridDateCell.getHeaderProps(row, id),
    });

    const delimitedDropdownFilterColumn = (groupId, label, id, delimiter, width) => ({
        ...baseColumn(groupId, label, id, width),
        Cell: (props) =>
            props.value === null ? (
                <DataGridNullDashCell.Component value={props.value} />
            ) : (
                <DataGridLongTextCell.Component>
                    {props.value.split(delimiter).map((val, i) => (
                        <div key={i} className={classes.paragraph}>
                            {val}
                        </div>
                    ))}
                </DataGridLongTextCell.Component>
            ),
        Filter: DataGridDelimitedDropDownFilter.Filter(data, id, delimiter),
        filterMethod: DataGridDelimitedDropDownFilter.filterMethod,
    });

    const dropdownFilterColumn = (groupId, label, id, width, exact = true) => ({
        ...baseColumn(groupId, label, id, width),
        Filter: DataGridDropDownFilter.Filter(data, id, exact),
        filterMethod: DataGridDropDownFilter.filterMethod,
    });

    const numericRangeFilterColumn = (groupId, label, id, width, precision, type) => ({
        ...baseColumn(groupId, label, id, width),
        Filter: DataGridNumericRangeFilter.Filter(data, id, precision, type),
        filterMethod: DataGridNumericRangeFilter.filterMethod,
    });

    const textFilterColumn = (groupId, label, id, width) => ({
        ...baseColumn(groupId, label, id, width),
        Filter: DataGridTextFilter.Filter(data, id),
        filterMethod: DataGridTextFilter.filterMethod,
        getHeaderProps: DataGridLongTextCell.getHeaderProps,
    });

    const bgColors = {
        green: '#DEFFDE',
        redDark: '#E57373',
        redLight: '#FFCDD2',
    };

    const headerStyle = {
        fontWeight: 700,
        fontSize: '12px !important',
        height: '100%',
    };

    const defaultConfiguration = [
        {
            ...baseColumnGroup('company', 'Company', '#daebd5'),
            fixed: 'left',
            columns: [
                {
                    ...textFilterColumn('company', '7-Digit Sedol', 'Sedol', 80),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>
                                7-Digit
                                <br />
                                Sedol
                            </span>
                        </div>
                    ),
                },
                {
                    ...textFilterColumn('company', 'Ticker', 'Ticker', 100),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Ticker</span>
                        </div>
                    ),
                },
                {
                    ...textFilterColumn('company', 'Company', 'CompanyName', 150),
                    Cell: (props) => {
                        return (
                            <CompanyLink to={`/CompanyAnalysis/${props.original.CompanyID}`} companyID={props.original.CompanyID}>
                                {props.value}
                            </CompanyLink>
                        );
                    },
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Company</div>}>The company name</Tooltip>,
                    collapsable: false,
                    style: { cursor: 'pointer' },
                },
            ],
        },
        {
            ...baseColumnGroup('general_info', 'General Information', '#cce5f1'),
            columns: [
                {
                    ...dropdownFilterColumn('general_info', 'Sector', 'GICSSector', 90),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Sector</div>}>GICS Level 1</Tooltip>,
                    collapsable: false,
                },
                {
                    ...numericRangeFilterColumn('general_info', 'Port Wgt', 'HeldWeight', 75, 4, DataGridNumericRangeFilter.Types.Percent),
                    Cell: (props) => (props.value == null ? <DataGridNullDashCell.Component value={props.value} /> : toPercent(props.value, 6).toFixed(4)),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Port
                                    <br />
                                    Wgt
                                </div>
                            }
                        >
                            Portfolio Weight
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const hw = row != null && row.original != null && row.original.HeldWeight;
                        return hw == null ? { style: { textAlign: 'center' } } : { style: { textAlign: 'right' } };
                    },
                    collapsable: false,
                },
                {
                    ...dropdownFilterColumn('general_info', 'Region', 'Region', 90),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Region</div>}>Region</Tooltip>,
                },
                {
                    ...numericRangeFilterColumn('general_info', 'BM Wgt', 'BenchmarkWeight', 75, 4, DataGridNumericRangeFilter.Types.Percent),
                    Cell: (props) => (props.value == null ? <DataGridNullDashCell.Component value={props.value} /> : toPercent(props.value, 6).toFixed(4)),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    BM
                                    <br />
                                    Wgt
                                </div>
                            }
                        >
                            Benchmark Weight
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const bmw = row != null && row.original != null && row.original.BenchmarkWeight;
                        return bmw == null ? { style: { textAlign: 'center' } } : { style: { textAlign: 'right' } };
                    },
                },
            ],
        },
        {
            ...baseColumnGroup('esg_compliance_overview', 'ESG Compliance Overview', '#e9edcd'),
            columns: [
                {
                    ...dropdownFilterColumn('esg_compliance_overview', 'Needs Oversight', 'HasViolations', 75),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Needs
                                    <br />
                                    Oversight
                                </div>
                            }
                        >
                            Needs compliance oversight
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('esg_compliance_overview', 'CCC', 'CCC', 70),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>CCC</div>}>Has CCC MSCI Rating</Tooltip>,
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('esg_compliance_overview', 'Gov < 3', 'GovLT3', 70),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Gov
                                    <br />
                                    {`< 3`}
                                </div>
                            }
                        >
                            Has Governance Score Less Than 3
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('esg_compliance_overview', 'UNGC Violator', 'UNGCViolator', 75),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    UNGC
                                    <br />
                                    Violator
                                </div>
                            }
                        >
                            Has UNGC Violations
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('esg_compliance_overview', 'Stale Engagement', 'StaleEngagement', 95),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Stale
                                    <br />
                                    Engagement
                                </div>
                            }
                        >
                            Last Engagement more than 12 mos ago
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
            ],
        },
        {
            ...baseColumnGroup('ab_esight_research', 'AB Esight Research', '#e9edcd'),
            columns: [
                {
                    ...delimitedDropdownFilterColumn('ab_esight_research', 'Key Issues', 'LastRsrchNoteKI', '|', 90),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Key
                                    <br />
                                    Issues
                                </div>
                            }
                        >
                            Most Recent ESG Research Key Issues
                        </Tooltip>
                    ),
                    collapsable: false,
                },
                {
                    ...dateRangeFilterColumn('ab_esight_research', 'Date', 'LastRsrchNoteDate', 100),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Date</div>}>Most Recent ESG Research Date</Tooltip>,
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const lastDate = row != null && row.original != null && row.original != null && toDateTime(row.original.LastRsrchNoteDate);
                        const dateThreshold = toDateTime(new Date()).minus({ days: 30 });
                        const isNew = lastDate > dateThreshold && lastDate != null;
                        return isNew === true ? { style: { backgroundColor: bgColors.green, fontWeight: 700 } } : {};
                    },
                },
                {
                    ...textFilterColumn('ab_esight_research', 'Note', 'LastRsrchNote', 150),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Note</div>}>Most Recent ESG Note</Tooltip>,
                    Cell: (props) => {
                        const note = props.row.LastRsrchNote;
                        return note == null ? (
                            <DataGridNullDashCell.Component value={note} />
                        ) : (
                            <DataGridLongTextCell.Component>
                                {[
                                    note.e != null && String(note.e).trim() !== '' && (
                                        <div key={'noteECell_' + props.row.CompanyID} className={classes.paragraph}>
                                            Env: {note.e}
                                        </div>
                                    ),
                                    note.s != null && String(note.s).trim() !== '' && (
                                        <div key={'noteSCell_' + props.row.CompanyID} className={classes.paragraph}>
                                            Soc: {note.s}
                                        </div>
                                    ),
                                    note.g != null && String(note.g).trim() !== '' && (
                                        <div key={'noteGCell_' + props.row.CompanyID} className={classes.paragraph}>
                                            Gov: {note.g}
                                        </div>
                                    ),
                                ]}
                            </DataGridLongTextCell.Component>
                        );
                    },
                    accessor: (data) => {
                        return data.LastRsrchENote == null && data.LastRsrchSNote == null && data.LastRsrchGNote == null
                            ? null
                            : {
                                  e: data.LastRsrchENote != null ? data.LastRsrchENote : null,
                                  s: data.LastRsrchSNote != null ? data.LastRsrchSNote : null,
                                  g: data.LastRsrchGNote != null ? data.LastRsrchGNote : null,
                              };
                    },
                    filterMethod: (filter, row, column) => {
                        if (filter == null || filter.value == null) return true;
                        if (row[filter.id] == null) return false;

                        const filterValue = String(filter.value).toUpperCase();
                        const { e, s, g } = row[filter.id];

                        let testStr = '';
                        if (e != null) testStr += String(e).toUpperCase();
                        if (s != null) testStr += String(s).toUpperCase();
                        if (g != null) testStr += String(g).toUpperCase();

                        return testStr.indexOf(filterValue) >= 0;
                    },
                    sortMethod: (a, b) => {
                        const regex = /[a-z0-9]/gi;
                        const aStr = a != null ? `${a.e != null ? a.e : ''}${a.s != null ? a.s : ''}${a.g != null ? a.g : ''}`.toLowerCase().trim() : '';
                        const bStr = b != null ? `${b.e != null ? b.e : ''}${b.s != null ? b.s : ''}${b.g != null ? b.g : ''}`.toLowerCase().trim() : '';

                        const aMatch = aStr.match(regex);
                        const bMatch = bStr.match(regex);

                        const aVal = aMatch != null ? aMatch.join('') : null;
                        const bVal = bMatch != null ? bMatch.join('') : null;

                        if (aVal === null) {
                            return 1;
                        } else if (bVal === null) {
                            return -1;
                        } else if (aVal === bVal) {
                            return 0;
                        }
                        return aVal < bVal ? -1 : 1;
                    },
                },
                {
                    ...dropdownFilterColumn('ab_esight_research', 'Analyst', 'LastRsrchNoteAnalyst', 115),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Analyst</div>}>Research Input Analyst</Tooltip>,
                },
                {
                    ...dropdownFilterColumn('ab_esight_research', 'Rating Consensus', 'LastRsrchNoteMRC', 80),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Rating
                                    <br />
                                    Consensus
                                </div>
                            }
                        >
                            <p className={classes.paragraph}>
                                Shows the MSCI letter score rating at the time of the research evaluation along with the analyst's view on that rating.
                                <br />
                                <br />
                                "+" means analyst thinks actual rating will increase.
                                <br />
                                "=" means rating will remain the same.
                                <br />
                                "-" means rating will decrease.
                            </p>
                        </Tooltip>
                    ),
                    sortMethod: (a, b) => {
                        const symbols = ['+', '=', '-', ''];
                        const regex = /[+\-=]$/;

                        const aStr = a == null ? '' : a;
                        const aSym = aStr.match(regex);
                        const aVal = padEnd(aStr.replace(aSym, ''), 5, '~') + symbols.indexOf(aSym != null && aSym.length >= 1 ? aSym[0] : '');

                        const bStr = b == null ? '' : b;
                        const bSym = bStr.match(regex);
                        const bVal = padEnd(bStr.replace(bSym, ''), 5, '~') + symbols.indexOf(bSym != null && bSym.length >= 1 ? bSym[0] : '');

                        return aVal > bVal ? 1 : bVal > aVal ? -1 : 0;
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('ab_esight_research', 'E Score', 'ERating', 90),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    E<br />
                                    Score
                                </div>
                            }
                        >
                            Analyst Aggregated score on Environmental issues.{' '}
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('ab_esight_research', 'S Score', 'SRating', 90),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    S<br />
                                    Score
                                </div>
                            }
                        >
                            Analyst Aggregated score on Social issues.{' '}
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('ab_esight_research', 'G Score', 'GRating', 90),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    G<br />
                                    Score
                                </div>
                            }
                        >
                            Analyst Aggregated score on Governance issues.{' '}
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
            ],
        },
        {
            ...baseColumnGroup('ab_esight_engagement', 'AB Esight Engagement', '#e9edcd'),
            columns: [
                {
                    ...delimitedDropdownFilterColumn('ab_esight_engagement', 'Key Issues', 'LastEngNoteKI', '|', 90),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Key
                                    <br />
                                    Issues
                                </div>
                            }
                        >
                            Analyst Key Issues in Engagement Note
                        </Tooltip>
                    ),
                    collapsable: false,
                },
                {
                    ...dateRangeFilterColumn('ab_esight_engagement', 'Date', 'LastEngNoteDate', 100),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Date</div>}>Most Recent ESG Engagement Date</Tooltip>,
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const lastDate = row != null && row.original != null && row.original != null && toDateTime(row.original.LastEngNoteDate);
                        const dateThreshold = toDateTime(new Date()).minus({ days: 30 });
                        const isNew = lastDate > dateThreshold && lastDate != null;
                        return isNew === true ? { style: { backgroundColor: bgColors.green, fontWeight: 700 } } : {};
                    },
                },
                {
                    ...textFilterColumn('ab_esight_engagement', 'Objective', 'LastEngNoteObjective', 115),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Objective</div>}>Reason for having the engagement meeting with the company.</Tooltip>,
                },
                {
                    ...dropdownFilterColumn('ab_esight_engagement', 'Analyst', 'LastEngNoteAnalyst', 115),
                    Header: () => <Tooltip trigger={<div style={headerStyle}>Analyst</div>}>Engagement Analyst</Tooltip>,
                },
                {
                    ...dropdownFilterColumn('ab_esight_engagement', 'Effect on Inv Thesis', 'LastEngNoteEIF', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Effect on
                                    <br />
                                    Inv Thesis
                                </div>
                            }
                        >
                            Engagement Analyst Effect on Investment Thesis
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('ab_esight_engagement', 'Portfolio Action', 'LastEngNotePA', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Portfolio
                                    <br />
                                    Action
                                </div>
                            }
                        >
                            Engagement Analyst Portfolio Action
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
            ],
        },
        {
            ...baseColumnGroup('msci_rating', 'MSCI / ABV Ratings', '#d3dbe7'),
            columns: [
                {
                    ...dropdownFilterColumn('msci_rating', 'Letter Score', 'MSCIRating', 80, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Letter
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            <p>
                                MSCI Letter Scoring Rating. Ratings are created using bottom up exposure and management scores, then weighting E, S, G issues depending on industry and then finally
                                creating a score relative to a narrow Peer Group.
                            </p>
                            <p>AAA is the best score, AA, A... and CCC is the worst.</p>
                            <p>These scores can be useful, but also many times can be misleading as they are relative to a peer group. For example, you can be a AAA tobacco company.</p>
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const rating = row != null && row.original != null && row.original.MSCIRating;
                        const alert = rating === 'B' || rating === 'CCC' ? true : false;
                        return alert === true ? { style: { textAlign: 'center', backgroundColor: bgColors.redLight, fontWeight: 700 } } : { style: { textAlign: 'center' } };
                    },
                    sortMethod: (a, b) => {
                        const aVal = padEnd(a == null ? '' : a, 5, '~');
                        const bVal = padEnd(b == null ? '' : b, 5, '~');

                        return aVal > bVal ? 1 : bVal > aVal ? -1 : 0;
                    },
                },
                {
                    ...dropdownFilterColumn('msci_rating', '12 Mth Change', 'RatingTrend', 80, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    12 Mth
                                    <br />
                                    Change
                                </div>
                            }
                        >
                            <p>Change in the MSCI Letter Rating since the last observation 12 months prior. +1 indicates the score now is better than it's previous rating.</p>
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const ratingTrend = row != null && row.original != null && row.original.RatingTrend;
                        const backgroundColor = ratingTrend > 0 ? bgColors.green : ratingTrend < 0 ? bgColors.redLight : null;

                        return backgroundColor != null ? { style: { backgroundColor } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_rating', 'Anticipated Rating', 'ABVAnticipatedRating', 100, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Anticipated
                                    <br />
                                    MSCI Rating
                                </div>
                            }
                        >
                            <p>
                                Anticipated MSCI Letter Scoring Rating. Like the MSCI rating, this rating is created using bottom up exposure and management scores, then weighting E, S, G issues
                                depending on industry and then finally creating a score relative to a narrow peer group.
                            </p>
                            <p>AAA is the best score, AA, A... and CCC is the worst.</p>
                            <p>MSCI updates key issue scores periodically throughout the year, but they only update the company aggregate rating annually.</p>
                            <p>This rating represents what AB anticipates the value to be if it were recalculated today.</p>
                        </Tooltip>
                    ),
                    collapsable: true,
                    getProps: (state, row, column) => {
                        const rating = row?.original?.ABVAnticipatedRating;
                        const alert = rating === 'B' || rating === 'CCC' ? true : false;
                        return alert === true ? { style: { textAlign: 'center', backgroundColor: bgColors.redLight, fontWeight: 700 } } : { style: { textAlign: 'center' } };
                    },
                    sortMethod: (a, b) => {
                        const aVal = padEnd(a == null ? '' : a, 5, '~');
                        const bVal = padEnd(b == null ? '' : b, 5, '~');

                        return aVal > bVal ? 1 : bVal > aVal ? -1 : 0;
                    },
                },
                {
                    ...dropdownFilterColumn('msci_rating', 'AB Value Proprietary Rating', 'ABVOverrideRating', 100, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    AB Value
                                    <br />
                                    Proprietary
                                    <br />
                                    Rating
                                </div>
                            }
                        >
                            <p>
                                AB Value Proprietary Rating. Like the MSCI rating, this rating is created using bottom up exposure and management scores, then weighting E, S, G issues depending on
                                industry and then finally creating a score relative to a narrow peer group.
                            </p>
                            <p>AAA is the best score, AA, A... and CCC is the worst.</p>
                            <p>AB Value analysts can enter proprietary scores per key issue that will override key issue scores provided by MSCI.</p>
                            <p>
                                This rating represents AB's calculated overall letter rating with the AB Value proprietary override scores included. If the value is blank, then there are no AB Value
                                overrides entered for this company.
                            </p>
                        </Tooltip>
                    ),
                    collapsable: true,
                    getProps: (state, row, column) => {
                        const rating = row?.original?.ABVOverrideRating;
                        const style = ['B', 'BB', 'CCC'].includes(rating) ? { backgroundColor: bgColors.redLight, fontWeight: 700 } : {};
                        return { style: { textAlign: 'center', ...style } };
                    },
                    sortMethod: (a, b) => {
                        const aVal = padEnd(a == null ? '' : a, 5, '~');
                        const bVal = padEnd(b == null ? '' : b, 5, '~');
                        return aVal > bVal ? 1 : bVal > aVal ? -1 : 0;
                    },
                },
                {
                    ...dropdownFilterColumn('msci_rating', 'AB Affirmed Rating', 'ABVCompanyRating', 100, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    AB Value
                                    <br />
                                    Affirmed
                                    <br />
                                    Rating
                                </div>
                            }
                        >
                            <p>AB Value Affirmed Company Rating. This is the AB Value rating snapshot that was saved when the covering analyst last entered their rationale.</p>
                            <p>
                                This should match either the MSCI Anticipated Rating or the AB Value Proprietary Rating. If it does not, the covering analyst should review the scores and values in the
                                ESG grid on the Company Analysis page and either adjust the scores or provide a rationale for any changes.
                            </p>
                            <p>AAA is the best score, AA, A... and CCC is the worst.</p>
                        </Tooltip>
                    ),
                    collapsable: true,
                    getProps: (state, row) => {
                        const scoreDiscrepency = row?.original?.ABVNeedsRationale === 'Y';
                        const mismatchStyle = scoreDiscrepency ? { color: bgColors.redDark, fontWeight: 700 } : {};
                        const companyRating = row?.original?.ABVCompanyRating;
                        const lowRatingStyle = companyRating != null && ['B', 'BB', 'CCC'].includes(companyRating) ? { backgroundColor: bgColors.redLight, fontWeight: 700 } : {};
                        return { style: { textAlign: 'center', ...lowRatingStyle, ...mismatchStyle } };
                    },
                    sortMethod: (a, b, c) => {
                        const aVal = padEnd(a == null ? '' : a, 5, '~');
                        const bVal = padEnd(b == null ? '' : b, 5, '~');
                        return aVal > bVal ? 1 : bVal > aVal ? -1 : 0;
                    },
                },
                {
                    ...textFilterColumn('msci_rating', 'AB Affirmed Rationale', 'ABVCompanyRationale', 100, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    AB Value
                                    <br />
                                    Affirmed
                                    <br />
                                    Rationale
                                </div>
                            }
                        >
                            <p>AB Value Affirmed Company Rationale. This is the rationale entered by the covering analyst defending their AB Value specific override scores.</p>
                        </Tooltip>
                    ),
                    collapsable: true,
                    getProps: (state, row) => {
                        const scoreDiscrepency = row?.original?.ABVNeedsRationale === 'Y';
                        const mismatchStyle = scoreDiscrepency ? { color: bgColors.redDark, fontWeight: 700 } : {};
                        return { style: { ...mismatchStyle } };
                    },
                },
                {
                    ...dateRangeFilterColumn('msci_rating', 'AB Affirmed Date', 'ABVCompanyDate', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    AB Value
                                    <br />
                                    Affirmed
                                    <br />
                                    Date
                                </div>
                            }
                        >
                            <p>AB Value Affirmed Company Rationale Date. This is the date on which the rationale was last entered by the covering analyst.</p>
                        </Tooltip>
                    ),
                    collapsable: true,
                    getProps: (state, row) => {
                        const scoreDiscrepency = row?.original?.ABVNeedsRationale === 'Y';
                        const mismatchStyle = scoreDiscrepency ? { color: bgColors.redDark, fontWeight: 700 } : {};
                        return { style: { ...mismatchStyle } };
                    },
                },
                {
                    ...dropdownFilterColumn('msci_rating', 'ABV Stale', 'ABVStale', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    AB Value
                                    <br />
                                    Stale
                                    <br />
                                    Engagement
                                </div>
                            }
                        >
                            This denotes postions with a BB, B, or CCC ABV score where the last engagement was more than 12 mos ago.
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_rating', 'ABV Score Discrepancy', 'ABVNeedsRationale', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    AB Value
                                    <br />
                                    Score
                                    <br />
                                    Discrepancy
                                </div>
                            }
                        >
                            <p>This denotes issuers where: </p>
                            <ul>
                                <li>there are override values that have not been affirmed</li>
                                <li>the calculated score (anticipated MSCI + AB Value overrides) does not match the score affirmed with rationale</li>
                            </ul>
                        </Tooltip>
                    ),
                    getProps: (state, row) => {
                        const scoreDiscrepency = row?.original?.ABVNeedsRationale === 'Y';
                        const mismatchStyle = scoreDiscrepency ? { color: bgColors.redDark, fontWeight: 700 } : {};
                        return { style: { textAlign: 'center', ...mismatchStyle } };
                    },
                },
            ],
        },
        {
            ...baseColumnGroup('msci_env', 'MSCI Env', '#d3dbe7'),
            columns: [
                {
                    ...dropdownFilterColumn('msci_env', 'Env Quartile', 'MSCIEPillarQuartile', 80),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Env
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            Aggregated Environmental Quartile Score. 4 is worst quartile.
                        </Tooltip>
                    ),
                    headerClassName: cn(classes.gridSubHeader, classes.gridSubHeaderDivider),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.MSCIEPillarQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_env', 'Worst Sub-Env Quartile', 'MSCILowestEQuartile', 80),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Worst
                                    <br />
                                    Sub-Env
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            Of all the underlying environmental materiality issues quartiles. This is the one with the lowest Quartile.
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.MSCILowestEQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_env', 'Worst Sub-Env Quartile Key Issue', 'MSCILowestEQuartileIssueName', 100),
                    Cell: (props) => <DataGridLongTextCell.Component>{props.value}</DataGridLongTextCell.Component>,
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Worst
                                    <br />
                                    Sub-Env
                                    <br />
                                    Quartile
                                    <br />
                                    Key Issue
                                </div>
                            }
                        >
                            The sub-issue with the lowest environmental quartile.
                        </Tooltip>
                    ),
                },
                {
                    ...numericRangeFilterColumn('msci_env', 'Lowest Sub-Env Score', 'MSCILowestEScore', 80, 2),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Lowest
                                    <br />
                                    Sub-Env
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            The lowest sub-issue score of Environmental issues.
                        </Tooltip>
                    ),
                    Cell: (props) => <DataGridNullDashCell.Component value={props.value == null ? null : roundDecimal(props.value, 4).toFixed(2)} />,
                    style: { textAlign: 'center' },
                },
            ],
        },
        {
            ...baseColumnGroup('msci_soc', 'MSCI Social', '#d3dbe7'),
            columns: [
                {
                    ...dropdownFilterColumn('msci_soc', 'Soc Quartile', 'MSCISPillarQuartile', 80),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Soc
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            Aggregated social Quartile Score. 4 is worst quartile.
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.MSCISPillarQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    headerClassName: cn(classes.gridSubHeader, classes.gridSubHeaderDivider),
                    collapsable: false,
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_soc', 'Worst Sub-Soc Quartile', 'MSCILowestSQuartile', 80),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Worst
                                    <br />
                                    Sub-Soc
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            Of all the underlying social materiality issues quartiles. This is the one with the lowest Quartile.
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.MSCILowestSQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_soc', 'Worst Sub-Soc Quartile Key Issue', 'MSCILowestSQuartileIssueName', 100),
                    Cell: (props) => <DataGridLongTextCell.Component>{props.value}</DataGridLongTextCell.Component>,
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Worst
                                    <br />
                                    Sub-Soc
                                    <br />
                                    Quartile
                                    <br />
                                    Key Issue
                                </div>
                            }
                        >
                            The sub-issue with the lowest social quartile.
                        </Tooltip>
                    ),
                },
                {
                    ...numericRangeFilterColumn('msci_soc', 'Lowest Sub-Soc Score', 'MSCILowestSScore', 80, 2),
                    Cell: (props) => <DataGridNullDashCell.Component value={props.value == null ? null : roundDecimal(props.value, 4).toFixed(2)} />,
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Lowest
                                    <br />
                                    Sub-Soc
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            The lowest sub-issue score of social issues
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
            ],
        },
        {
            ...baseColumnGroup('msci_gov', 'MSCI Governance', '#d3dbe7'),
            columns: [
                //MSCIGPillarScore
                {
                    ...numericRangeFilterColumn('msci_gov', 'Gov Score', 'MSCIGPillarScore', 90, 2),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Gov
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            The total Governance Score
                        </Tooltip>
                    ),
                    headerClassName: cn(classes.gridSubHeader, classes.gridSubHeaderDivider),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.MSCIGPillarScore;
                        const alert = Number(quartile) < 3 && Number(quartile) > 0 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    Cell: (props) => <DataGridNullDashCell.Component value={props.value == null ? null : roundDecimal(props.value, 4).toFixed(2)} />,

                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_gov', 'Gov Quartile', 'MSCIGPillarQuartile', 90),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Gov
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            The overall Governance Quartile Score
                        </Tooltip>
                    ),
                    headerClassName: cn(classes.gridSubHeader),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.MSCIGPillarQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...textFilterColumn('msci_gov', 'Overall Corp Gov Percentile', 'MSCIOverallCorpGovPercentile', 110),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Overall
                                    <br />
                                    Corp Gov
                                    <br />
                                    Percentile
                                </div>
                            }
                        >
                            Looking at Board, Pay, Ownership and Accounting this is the percentile score that the company achieves. Both compared globally (GL), but also in its home market (HM). 100
                            is best. 1 is worst. There might be some country bias in these numbers, so sometimes one might want to use Home instead of Global if accounted for otherwise.
                        </Tooltip>
                    ),
                    accessor: (data) =>
                        data.MSCIOverallCorpGovGlobalPercentile != null && data.MSCIOverallCorpGovHomePercentile != null
                            ? 'GL: ' + data.MSCIOverallCorpGovGlobalPercentile + ' / HM: ' + data.MSCIOverallCorpGovHomePercentile
                            : data.MSCIOverallCorpGovGlobalPercentile != null
                            ? 'GL: ' + data.MSCIOverallCorpGovGlobalPercentile
                            : data.MSCIOverallCorpGovGlobalPercentile != null
                            ? 'HM: ' + data.MSCIOverallCorpGovHomePercentile
                            : null,
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const globalScore =
                            row != null && row.original != null && row.original.MSCIOverallCorpGovGlobalPercentile != null ? Number(row.original.MSCIOverallCorpGovGlobalPercentile) : null;
                        const homeScore = row != null && row.original != null && row.original.MSCIOverallCorpGovHomePercentile != null ? Number(row.original.MSCIOverallCorpGovHomePercentile) : null;
                        const alert = (globalScore != null && globalScore < 10) || (homeScore != null && homeScore < 10) ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_gov', 'Corp Behavior Bottom Score', 'CorporateBehaviorBottomScore', 80, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Corp
                                    <br />
                                    Behavior
                                    <br />
                                    Bottom
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            "Yes" means Business Ethics has management score below 5, an Anti-competitive Practices has score below 5, Corruption & Instability is a quartile 4, or Financial System
                            instability is quartile 4. This all means that there is an issue in one of these four areas that need closer attention.
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const isYes = row != null && row.original != null && row.original.CorporateBehaviorBottomScore === 'Yes';
                        return isYes === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...numericRangeFilterColumn('msci_gov', 'Business Ethics Mgmt Score', 'BusinessEthicsMgmtScore', 90, 2),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Business
                                    <br />
                                    Ethics
                                    <br />
                                    Mgmt Score
                                </div>
                            }
                        >
                            Companies may face regulatory or legal risks or loss of investor confidence due to ethics issues such as fraud, executive misconduct, or insider trading. Threatened license
                            to operate, restrictions on growth. Reputational risk, decline in consumer trust or brand value.
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const score = row != null && row.original != null && row.original.BusinessEthicsMgmtScore != null ? Number(row.original.BusinessEthicsMgmtScore) : null;
                        return score == null
                            ? {}
                            : score < 4
                            ? { style: { backgroundColor: bgColors.redDark, color: 'white', fontWeight: 700 } }
                            : score < 5
                            ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } }
                            : {};
                    },
                },
                {
                    ...numericRangeFilterColumn('msci_gov', 'Anti-comp Mgmt Score', 'AntiCompMgmtScore', 90, 2),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Anti-comp
                                    <br />
                                    Mgmt Score
                                </div>
                            }
                        >
                            Companies may face regulatory risks relating to anti-competitive practices, such as monopoly or oligopoly pricing, that have an adverse impact on customers, communities.
                            Regulatory and legal risks. Threatened license to operate, restrictions on growth. Reputational risk, decline in consumer trust or brand value.
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const score = row != null && row.original != null && row.original.AntiCompMgmtScore != null ? Number(row.original.AntiCompMgmtScore) : null;
                        return score == null
                            ? {}
                            : score < 4
                            ? { style: { backgroundColor: bgColors.redDark, color: 'white', fontWeight: 700 } }
                            : score < 5
                            ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } }
                            : {};
                    },
                },
                {
                    ...dropdownFilterColumn('msci_gov', 'Corruption & Instability Quartile', 'CorruptInstQuartile', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Corruption
                                    <br />& Instability
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            Companies may face regulatory risks or lost market access due to corruption scandals or political and social instability. Loss of company assets and infrastructure due to
                            political events or violence, including nationalization or expropriation. Loss of access to market due to political events or violence. Increased costs and increased
                            uncertainty regarding future costs to maintain operations due to demands for bribes. Increased costs from liabilities and fines associated with violations of foreign
                            corruption laws. Operational disruptions due to political events, bribe demands. Operational disruptions or loss of market access due to community opposition.
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.CorruptInstQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_gov', 'Financial System Instability Quartile', 'FinSystemInstabilityQuartile', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Financial
                                    <br />
                                    System
                                    <br />
                                    Instability
                                    <br />
                                    Quartile
                                </div>
                            }
                        >
                            This issue evaluates the extent to which companies may face enhanced regulatory scrutiny as a result of their contributions to systemic risk in financial markets. Loss of
                            growth opportunities or access to market through regulatory changes. Bankruptcy or forced merger/acquisition. Reputational damage.
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const quartile = row != null && row.original != null && row.original.FinSystemInstabilityQuartile;
                        const alert = Number(quartile) === 4 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_gov', 'Corporate Gov Low Underlying Score', 'CoporateGovLowUnderlyingScore', 100, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Corporate
                                    <br />
                                    Gov Low
                                    <br />
                                    Underlying
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            The lowest score of the 4 GLOBAL percentile scores: Board, Pay, Accounting, and Ownership. If lowest score is less than 10%, then "Yes". This indicates if there might be a
                            red flag on one of these four items.
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const isYes = row != null && row.original != null && row.original.CoporateGovLowUnderlyingScore === 'Yes';
                        return isYes === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...numericRangeFilterColumn('msci_gov', 'Corporate Gov Lowest Percentile', 'CoporateGovLowestPercentile', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Corp Gov
                                    <br />
                                    Lowest
                                    <br />
                                    Percentile
                                </div>
                            }
                        >
                            The lowest percentile of Board, Pay, Ownership, Accounting
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...dropdownFilterColumn('msci_gov', 'Corporate Gov Lowest Percentile Issue', 'CoporateGovLowestPercentileIssue', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Corp Gov
                                    <br />
                                    Lowest
                                    <br />
                                    Percentile
                                    <br />
                                    Issue
                                </div>
                            }
                        >
                            The issue with the lowest percentile of the four Corporate Governance issues.
                        </Tooltip>
                    ),
                },
            ],
        },
        {
            ...baseColumnGroup('sustainalytics', 'Sustainalytics', '#d6ece9'),
            columns: [
                {
                    ...dropdownFilterColumn('sustainalytics', 'Highest Controversy', 'HighestControversy', 110),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Highest
                                    <br />
                                    Controversy
                                </div>
                            }
                        >
                            The highest controversy level for the company. 5 is the worst. 1 is the best. Generally 5, 4, and 3 are important.
                        </Tooltip>
                    ),
                    collapsable: false,
                    getProps: (state, row, column) => {
                        const controversy = row != null && row.original != null && row.original.HighestControversy;
                        const alert = Number(controversy) >= 3 ? true : false;
                        return alert === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
                {
                    ...dateRangeFilterColumn('sustainalytics', 'Highest Date', 'HighestControversyDate', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Highest
                                    <br />
                                    Date
                                </div>
                            }
                        >
                            The date of this high controversy issue (will only be one of the highest controversies).
                        </Tooltip>
                    ),
                    accessor: (data) => (data != null ? toDateTime(data.HighestControversyDate) : null),
                    getProps: (state, row, column) => {
                        const lastDate = row != null && row.original != null && row.original != null && toDateTime(row.original.HighestControversyDate);
                        const dateThreshold = toDateTime(new Date()).minus({ days: 30 });
                        const isNew = lastDate > dateThreshold && lastDate != null;
                        return isNew === true ? { style: { backgroundColor: bgColors.green, fontWeight: 700 } } : {};
                    },
                },
                {
                    ...delimitedDropdownFilterColumn('sustainalytics', 'Highest Controversy Key Issues', 'ControveryIssues', '|', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Highest
                                    <br />
                                    Controversy
                                    <br />
                                    Key Issues
                                </div>
                            }
                        >
                            The highest controvery issues.
                        </Tooltip>
                    ),
                },
                {
                    ...textFilterColumn('sustainalytics', 'Risk Rating', 'RiskRatingScore', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Risk Rating
                                    <br />
                                    Score
                                </div>
                            }
                        >
                            The latest risk rating.
                        </Tooltip>
                    ),
                },
                {
                    ...dateRangeFilterColumn('sustainalytics', 'Risk Rating Date', 'RiskRatingDate', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Risk Rating
                                    <br />
                                    Date
                                </div>
                            }
                        >
                            The latest risk rating date.
                        </Tooltip>
                    ),
                    accessor: (data) => (data != null ? toDateTime(data.RiskRatingDate) : null),
                },
                {
                    ...textFilterColumn('sustainalytics', 'Sustainalytics Report', 'SustainalyticsID', 175),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Sustainalytics
                                    <br />
                                    Reports
                                </div>
                            }
                        >
                            Download links for the latest Sustainalytics reports.
                        </Tooltip>
                    ),
                    accessor: (data) =>
                        data.SustainalyticsCompanyID != null ? (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                                <Downloader useApiResource={true} uri={`/companies/${data.CompanyID}/reports/sustainalytics/${data.SustainalyticsCompanyID}/controversy`}>
                                    Controversy Report
                                </Downloader>
                                <Downloader useApiResource={true} uri={`/companies/${data.CompanyID}/reports/sustainalytics/${data.SustainalyticsCompanyID}/risk/full`}>
                                    Full Risk Rating Report
                                </Downloader>
                                <Downloader useApiResource={true} uri={`/companies/${data.CompanyID}/reports/sustainalytics/${data.SustainalyticsCompanyID}/risk/summary`}>
                                    Summary Risk Rating Report
                                </Downloader>
                            </div>
                        ) : (
                            <DataGridNullDashCell.Component value={null} />
                        ),
                    filterable: false,
                },
            ],
        },
        {
            ...baseColumnGroup('proxy_vote', 'Proxy Voting', '#daebd5'),
            columns: [
                {
                    ...dateRangeFilterColumn('proxy_vote', 'Last Proxy Meeting', 'ProxyMeetingDate', 115),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Last
                                    <br />
                                    Proxy
                                    <br />
                                    Meeting
                                </div>
                            }
                        >
                            The date of the most recent shareholder meeting.
                        </Tooltip>
                    ),
                    collapsable: false,
                },
                {
                    ...dropdownFilterColumn('proxy_vote', 'Vote(s) Against Mgmt', 'VoteAgainst', 80, true),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Vote(s)
                                    <br />
                                    Against
                                    <br />
                                    Mgmt
                                </div>
                            }
                        >
                            Whether or not AB voted against management recommendation on any proposal from the meeting agenda.{' '}
                        </Tooltip>
                    ),
                    accessor: (data) => data?.VoteAgainst,
                    collapsable: false,
                    getProps: (state, row, column) => {
                        return row?.original?.VoteAgainst === 'Yes' ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                    style: { textAlign: 'center' },
                },
            ],
        },
        {
            ...baseColumnGroup('additional_info', 'Additional Info', '#f9ebca'),
            columns: [
                {
                    ...textFilterColumn('additional_info', 'Cusip', 'Cusip', 100),
                    Cell: (props) => <DataGridNullDashCell.Component value={props.value} />,
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Cusip</span>
                        </div>
                    ),
                    collapsable: false,
                },
                {
                    ...textFilterColumn('additional_info', 'Isin', 'Isin', 100),
                    Cell: (props) => <DataGridNullDashCell.Component value={props.value} />,
                    Header: () => (
                        <div style={headerStyle}>
                            <span>ISIN</span>
                        </div>
                    ),
                    collapsable: true,
                },
                {
                    ...textFilterColumn('additional_info', 'MSCI Issuer ID', 'MSCIIssuerID', 200),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>MSCI Issuer ID</span>
                        </div>
                    ),
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Quantity', 'Quantity', 100),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Quantity</span>
                        </div>
                    ),
                    style: { textAlign: 'right' },
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Value (USD)', 'ValueUSD', 150, 2, DataGridNumericRangeFilter.Types.Currency),
                    Cell: (props) => formatCurrency(props.value),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Value (USD)</span>
                        </div>
                    ),
                    style: { textAlign: 'right' },
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Shares Outstanding (MM)', 'SharesOutMM', 140, 3),
                    Cell: (props) => props.value != null && props.value.toFixed(3),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>
                                Shares
                                <br />
                                Outstanding (MM)
                            </span>
                        </div>
                    ),
                    style: { textAlign: 'right' },
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Market Cap (MM)', 'MktCapMM', 150, 5),
                    Cell: (props) => props.value != null && props.value.toFixed(5),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Market Cap (MM)</span>
                        </div>
                    ),
                    style: { textAlign: 'right' },
                },
                {
                    ...dropdownFilterColumn('additional_info', 'Market', 'Market', 200),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Market</span>
                        </div>
                    ),
                },
                {
                    ...dropdownFilterColumn('additional_info', 'Country', 'Country', 150),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Country</span>
                        </div>
                    ),
                },
                {
                    ...delimitedDropdownFilterColumn('additional_info', 'Value Analyst', 'ValueAnalyst', ';', 150),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Value Analyst</span>
                        </div>
                    ),
                },
                {
                    ...delimitedDropdownFilterColumn('additional_info', 'Growth Analyst', 'GrowthAnalyst', ';', 250),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>Growth Analyst</span>
                        </div>
                    ),
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Acc Securities Firm Value (USD)', 'AccSecFirmValueUSD', 150, 2, DataGridNumericRangeFilter.Types.Currency),
                    Cell: (props) => formatCurrency(props.value),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>
                                Acc Securities
                                <br />
                                Firm Value (USD)
                            </span>
                        </div>
                    ),
                    style: { textAlign: 'right' },
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Firm All Value (USD)', 'CompanyFirmValueUSD', 150, 2, DataGridNumericRangeFilter.Types.Currency),
                    Cell: (props) => formatCurrency(props.value),
                    Header: () => (
                        <div style={headerStyle}>
                            <span>
                                Firm All
                                <br />
                                Value (USD)
                            </span>
                        </div>
                    ),
                    style: { textAlign: 'right' },
                },
                {
                    ...dropdownFilterColumn('additional_info', 'Ownership Category', 'OwnershipCategory', 200),
                    Cell: (props) => <DataGridNullDashCell.Component value={props.value} />,
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Ownership
                                    <br />
                                    Category
                                </div>
                            }
                        >
                            AB's ownership on the company - principal shareholder or through index investment. Labelled "controlled" for companies with a controlling shareholder.
                        </Tooltip>
                    ),
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Board Independence', 'BoardIndependencePct', 100, 2),
                    Cell: (props) => <DataGridPercentCell.Component value={props.value} precision={2} />,
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Board
                                    <br />
                                    Independence
                                </div>
                            }
                        >
                            Representation of independent directors at the board level.
                        </Tooltip>
                    ),
                    getProps: DataGridPercentCell.getProps,
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Female Directors', 'FemaleDirectorsPct', 100, 2),
                    Cell: (props) => <DataGridPercentCell.Component value={props.value} precision={2} />,
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Female
                                    <br />
                                    Directors
                                </div>
                            }
                        >
                            Representation of female directors at the board.
                        </Tooltip>
                    ),
                    getProps: DataGridPercentCell.getProps,
                },
                {
                    ...numericRangeFilterColumn('additional_info', 'Number of Controversies', 'NomberOfControversies', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Number of
                                    <br />
                                    Controversies
                                </div>
                            }
                        >
                            Number of events derived from a company's activities that could affect the company’s reputation, operation and/or performance.
                        </Tooltip>
                    ),
                    style: { textAlign: 'center' },
                },
                {
                    ...booleanFilterColumn('additional_info', 'One Share One Vote', 'OneShareOneVoteIssue', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    One Share
                                    <br />
                                    One Vote
                                </div>
                            }
                        >
                            <p>Whether the company has capital structure that provides equal voting rights for all shares (multi class vs. single class share structure).</p>
                            <p>"No"" means this is not a concern for the company</p>
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const value = row != null && row.original != null && row.original.OneShareOneVoteIssue != null ? Boolean(row.original.OneShareOneVoteIssue) : null;
                        return value === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                },
                {
                    ...booleanFilterColumn('additional_info', 'Combined CEO Chair', 'CombinedCEOChair', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Combined
                                    <br />
                                    CEO Chair
                                </div>
                            }
                        >
                            <p>Whether the CEO also serves as the Board Chair or not.</p>
                            <p>"No" means this is not a concern for the company.</p>
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const value = row != null && row.original != null && row.original.CombinedCEOChair != null ? Boolean(row.original.CombinedCEOChair) : null;
                        return value === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                },
                {
                    ...booleanFilterColumn('additional_info', 'Entrenched Board', 'EntranchedBoard', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Entrenched
                                    <br />
                                    Board
                                </div>
                            }
                        >
                            <p>Generally, the directors of an entrenched board tend to have long tenure with high age who do not act in the best interest of all shareholders.</p>
                            <p>
                                These companies may have founders/majority owners and have shareholder unfriendly provisions such as: classified boards, plurality voting, etc. Due to the absence of
                                board refreshment, these boards may also lack diversity.
                            </p>
                            <p>"No" means this is not a concern for the company.</p>
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const value = row != null && row.original != null && row.original.EntranchedBoard != null ? Boolean(row.original.EntranchedBoard) : null;
                        return value === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                },
                {
                    ...booleanFilterColumn('additional_info', 'Other High Impact Governance', 'OtherHighImpactGovEvents', 100),
                    Header: () => (
                        <Tooltip
                            trigger={
                                <div style={headerStyle}>
                                    Other High
                                    <br />
                                    Impact Governance
                                </div>
                            }
                        >
                            Existence of other concerns that may negatively impact the company's governance.{' '}
                        </Tooltip>
                    ),
                    getProps: (state, row, column) => {
                        const value = row != null && row.original != null && row.original.OtherHighImpactGovEvents != null ? Boolean(row.original.OtherHighImpactGovEvents) : null;
                        return value === true ? { style: { backgroundColor: bgColors.redLight, fontWeight: 700 } } : {};
                    },
                },
            ],
        },
    ];

    try {
        return defaultConfiguration.map((group) => {
            const localSetting = localSettings != null ? localSettings.find((setting) => setting.id === group.id) : null;

            const expanded = localSetting == null ? group.expanded : localSetting.expanded;

            const hasStaticColumn = group.columns.findIndex((c) => c.collapsable === false) >= 0;

            const columns =
                localSetting == null || localSetting.columns == null
                    ? group.columns.map((column, idx) => ({
                          ...column,
                          show: column.show || column.collapsable === false || (!hasStaticColumn && idx === 0),
                      }))
                    : localSetting['columns'].map((column, idx) => {
                          const defaultColumn = group.columns.find((c) => c.id === column.id);

                          column.show = !column.hidden && (column.collapsable === false || (!hasStaticColumn && idx === 0)) ? true : defaultColumn.show;

                          return {
                              ...defaultColumn,
                              ...column,
                          };
                      });

            return {
                ...group,
                expanded,
                columns,
            };
        });
    } catch {
        // Error mapping local setting, just use the default setup.
        return defaultConfiguration.map((group) => {
            const expanded = group.expanded;
            const hasStaticColumn = group.columns.findIndex((c) => c.collapsable === false) >= 0;
            const columns = group.columns.map((column, idx) => ({
                ...column,
                show: column.show || column.collapsable === false || (!hasStaticColumn && idx === 0),
            }));

            return {
                ...group,
                expanded,
                columns,
            };
        });
    }
};
