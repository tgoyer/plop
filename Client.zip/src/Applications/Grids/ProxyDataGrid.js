import React from 'react';
import { withStyles } from '@material-ui/core/styles';

import { CollectionView, Tooltip } from '@grapecity/wijmo';
import { FlexGrid as CoreGrid, HeadersVisibility, CellType } from '@grapecity/wijmo.grid';
import { FlexGrid, FlexGridColumn } from '@grapecity/wijmo.react.grid';
import { FlexGridDetailProvider } from '@grapecity/wijmo.grid.detail';

const styles = () => ({
    gridCell: {
        '& .fa-stack': {
            lineHeight: '1em',
        },
        '& i.red': {
            color: 'red',
        },
        '& i.gray': {
            color: '#999999',
        },
        '& i.green': {
            color: 'green',
        },
    },
});

const ProxyDataGrid = ({ ProxySummaryData, ProxyDetailsData, classes }) => {
    const getSAProxyVoteAgainstData = () => new CollectionView(ProxySummaryData);

    const initGrid = (el) => {
        if (el == null) return;

        let grid = el.control;
        let dp = new FlexGridDetailProvider(grid);

        // use animation when showing details
        dp.isAnimated = true;
        // create detail cells for a given row
        dp.createDetailCell = (row) => {
            let update = true;

            let cell = document.createElement('div');
            cell.style.height = '400px'; //(document.documentElement.clientHeight - 350) + "px";// "700px";
            new CoreGrid(cell, {
                allowSorting: false,
                alternatingRowStep: 1,
                autoGenerateColumns: false,
                autoRowHeights: true,
                headersVisibility: HeadersVisibility.Column,
                itemsSource: getDetailsData(),
                isReadOnly: true,
                columns: [
                    { header: 'Company ID', binding: 'CompanyID', visible: false },
                    { header: '#', binding: 'ProposalNumber', width: 55 },
                    { header: 'Proposal', binding: 'ProposalText', width: '2*', wordWrap: true },
                    { header: 'Mgmt', binding: 'ManagementRecommendation', width: 45, wordWrap: true },
                    { header: 'ISS', binding: 'ISSRecommendation', width: 45, wordWrap: true },
                    { header: 'AB', binding: 'ABVote', width: 45 },
                    { header: 'Proponent', binding: 'Proponent', width: 100 },
                    { header: 'AB Vote Rationale', binding: 'BlendedRationale', width: '2.5*', wordWrap: true },
                ],
                formatItem: (s, e) => {
                    const item = s.rows[e.row].dataItem;
                    const field = s.columns[e.col].binding;
                    const isProposalNumberCell = field === 'ProposalNumber';
                    const isVoteCell = ['ManagementRecommendation', 'ISSRecommendation', 'ABVote'].indexOf(field) >= 0;
                    const isColumnHeader = e.panel.cellType === CellType.ColumnHeader;

                    let content = '';

                    e.cell.classList.add(classes.gridCell);
                    if (isProposalNumberCell) {
                        e.cell.style.textAlign = 'center';
                    }

                    if (isVoteCell && !isColumnHeader) {
                        if (item[field] == null || String(item[field]).trim() === '') {
                            content = '';
                        } else {
                            switch (item[field]) {
                                case 'Abstain':
                                case 'Do Not Vote':
                                case 'None':
                                    content = '<span class="fa-stack"><i class="fas fa-ban gray" /></span>';
                                    break;
                                case 'Against':
                                case 'Withhold':
                                    content = '<span class="fa-stack"><i class="fas fa-times fa-stack-1x red" /></span>';
                                    break;
                                case 'For':
                                    content = '<span class="fa-stack"><i class="fas fa-check fa-inverse green" /></span>';
                                    break;
                                case 'One Year':
                                    content = '<span style="font-weight: 400; font-size: 12px">1yr</span>';
                                    break;
                                case 'Two Years':
                                    content = '<span style="font-weight: 400; font-size: 12px">2yrs</span>';
                                    break;
                                case 'Three Years':
                                    content = '<span style="font-weight: 400; font-size: 12px">3yrs</span>';
                                    break;
                                default:
                                    content = '<span class="fa-stack"><i class="fas fa-info-circle blue" /></span>';
                                    break;
                            }
                        }

                        e.cell.classList.add('icon-cell');
                        e.cell.title = item[field];
                        e.cell.innerHTML = content;
                    }
                },
                updatedView: (grid, event) => {
                    if (update) {
                        update = false;
                        var row = grid.columnHeaders.rows[0];
                        grid.autoSizeRows(0, grid.rows.length, false, 5);
                        row.wordWrap = true;
                    }
                },
            });
            return cell;
        };

        dp.rowHasDetail = (row) => {
            return ProxyDetailsData.length > 0;
        };
    };

    const formatItem = (s, e) => {
        if (e.panel === s.cells) {
            const item = s.rows[e.row].dataItem;
            if (item != null && s.columns[e.col].binding === 'ProxyVoteAgainst') {
                e.cell.innerHTML = '';

                const titleSpan = document.createElement('span');
                const titleTip = new Tooltip();
                titleSpan.innerText = item.ProxyVoteAgainst;
                titleTip.setTooltip(titleSpan, 'Proxy votes against Management, Board, Compensation or Shareholder proposals.');
                e.cell.appendChild(titleSpan);

                const methodologyLink = document.createElement('a');
                const methodologyTip = new Tooltip();
                methodologyLink.innerHTML = '&nbsp;&nbsp;<i class="fas fa-info-circle"></i>';
                methodologyLink.addEventListener(
                    'click',
                    (event) => {
                        event.preventDefault();
                        const win = window.open('https://www.alliancebernstein.com/corporate/en/corporate-responsibility/corporate-governance/proxy-voting.html', '_blank');
                        win.focus();
                    },
                    false
                );
                methodologyLink.style.cursor = 'help';
                methodologyTip.setTooltip(methodologyLink, 'Visit AB Proxy Voting portal to view current policy documents');
                e.cell.appendChild(methodologyLink);
            }
        }
    };

    const updatedView = (s, e) => (s.rows.defaultSize = 25);

    const getDetailsData = () => {
        if (Array.isArray(ProxyDetailsData) && ProxyDetailsData.length > 0) {
            const data = ProxyDetailsData;

            //Data should be sorted based on the SortOrder column, the logic for which is in the API.
            data.sort((a, b) => {
                const detailA = a.SortOrder;
                const detailB = b.SortOrder;

                let comparison = 0;
                if (detailA > detailB) {
                    comparison = 1;
                } else if (detailA < detailB) {
                    comparison = -1;
                }

                return comparison;
            });

            return data;
        } else {
            return [{ ProposalNumber: null, ManagementRecommendation: null, ISSRecommendation: null, ABVote: null, Proponent: null, BlendedRationale: null }];
        }
    };

    return (
        <div data-test="proxy-grid">
            <FlexGrid
                alternatingRowStep={1}
                autoGenerateColumns={false}
                formatItem={formatItem}
                itemsSource={getSAProxyVoteAgainstData()}
                ref={initGrid}
                selectionMode="None"
                updatedView={updatedView}
            >
                <FlexGridColumn header="Proxy Vote" binding="ProxyVoteAgainst" width="2*"></FlexGridColumn>
                <FlexGridColumn header="Date" binding="Date" width="2*" align="center"></FlexGridColumn>
                <FlexGridColumn header="Mgmt" binding="Mgmt" width="*" align="center"></FlexGridColumn>
                <FlexGridColumn header="Board" binding="Board" width="*" align="center"></FlexGridColumn>
                <FlexGridColumn header="Comp" binding="Comp" width="*" align="center"></FlexGridColumn>
                <FlexGridColumn header="SHP" binding="SHP" width="*" align="center"></FlexGridColumn>
            </FlexGrid>
        </div>
    );
};

export default React.memo(withStyles(styles)(ProxyDataGrid));
