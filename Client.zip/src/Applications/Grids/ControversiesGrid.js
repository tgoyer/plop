import React, { useState } from 'react';
import { withStyles } from '@material-ui/core/styles';

import { CollectionView } from '@grapecity/wijmo';
import { FlexGrid as CoreGrid, HeadersVisibility } from '@grapecity/wijmo.grid';
import { FlexGrid, FlexGridColumn, FlexGridCellTemplate } from '@grapecity/wijmo.react.grid';
import { FlexGridDetailProvider } from '@grapecity/wijmo.grid.detail';

import Downloader from 'componentlibrary/file/Downloader';
import Tooltip from 'componentlibrary/tooltip/Tooltip';
import Dialog from 'UIComponents/MaterialUI/CommonDialog';
import { hasEntries } from 'Utils/arrayHelpers';

const styles = () => ({
    controversyCell: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
    },
    riskReportCell: {
        display: 'flex',
        flexDirection: 'row',
        gap: 8,
    },
    ungcCell: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        '& i': {
            color: '#4183c4',
        },
    },
});

const ControversiesGrid = ({ classes, ControversySummaryData, SustainalyticsDetailsData, UNGCDetailsData }) => {
    const getControversiesData = () => new CollectionView(ControversySummaryData);
    const getSustainalyticsDetailsData = () => new CollectionView(hasEntries(SustainalyticsDetailsData) ? SustainalyticsDetailsData : [{ CategoryName: null, IndicatorName: null, Assessment: null }]);
    const getUNGCDetailsData = () => new CollectionView(hasEntries(UNGCDetailsData) ? UNGCDetailsData : [{ CategoryName: null, IndicatorName: null, Assessment: null }]);

    const [showDialog, setShowDialog] = useState(false);
    const [downloadError, setDownloadError] = useState(false);
    const [showUNGCInfoDialog, setShowUNGCInfoDialog] = useState(false);

    const closeErrorDialog = () => {
        setShowDialog(false);
        setDownloadError('');
    };
    const closeUNGCInfoDialog = () => setShowUNGCInfoDialog(false);

    const getItemDefinition = (item) => {
        if (item == null) return null;

        switch (item.ControversyType) {
            case 'Sustainalytics':
                return {
                    // uri:
                    methodology: (
                        <Tooltip trigger={<Downloader uri="/assets/documents/Sustainalytics_Research_Methodology_with_FAQs.pdf">Methodology</Downloader>}>
                            Download Controversy Report Methodology and FAQs guide
                        </Tooltip>
                    ),

                    report: (
                        <Tooltip
                            trigger={
                                <Downloader useApiResource={true} uri={`/companies/${item.CompanyID}/reports/sustainalytics/${item.SustainalyticsCompanyID}/controversy`}>
                                    Controversy Report
                                </Downloader>
                            }
                        >
                            Download Controversy Report
                        </Tooltip>
                    ),
                };
            case 'RiskRating':
                return {
                    // uri:
                    methodology: (
                        <Tooltip trigger={<Downloader uri="/assets/documents/Sustainalytics_Risk_Rating_Methodology.pdf">Methodology</Downloader>}>
                            Download Sustainalytics ESG Risk Rating Methodology
                        </Tooltip>
                    ),

                    report: (
                        <div className={classes.riskReportCell}>
                            <span>Risk Reports: </span>
                            <Tooltip
                                trigger={
                                    <Downloader useApiResource={true} uri={`/companies/${item.CompanyID}/reports/sustainalytics/${item.SustainalyticsCompanyID}/risk/summary`}>
                                        Summary
                                    </Downloader>
                                }
                            >
                                Download Sustainalytics Risk Rating Summary Report
                            </Tooltip>
                            <span>|</span>
                            <Tooltip
                                trigger={
                                    <Downloader useApiResource={true} uri={`/companies/${item.CompanyID}/reports/sustainalytics/${item.SustainalyticsCompanyID}/risk/full`}>
                                        Full
                                    </Downloader>
                                }
                            >
                                Download Sustainalytics Risk Rating Full Report
                            </Tooltip>
                        </div>
                    ),
                };
            case 'UNGC':
                return {
                    methodology: (
                        <Tooltip trigger={<Downloader uri="/assets/documents/Sustainalytics_Global Compact Compliance Service_Methodology_2017.pdf">Methodology</Downloader>}>
                            Download UNGC Methodology guide
                        </Tooltip>
                    ),

                    report: (
                        <div className={classes.ungcCell}>
                            <span>UNGC</span>
                            <Tooltip trigger={<i onClick={() => setShowUNGCInfoDialog(true)} className="fas fa-info-circle"></i>}>View UNGC Principles</Tooltip>
                        </div>
                    ),
                };
            default:
                return null;
        }
    };

    const initGrid = (el) => {
        if (el == null) return;

        var grid = el.control;
        var dp = new FlexGridDetailProvider(grid);

        // use animation when showing details
        dp.isAnimated = true;

        // create detail cells for a given row
        dp.createDetailCell = (row) => {
            // eslint-disable-next-line
            let update = true;
            let cell = document.createElement('div');

            if (row.dataItem.ControversyType === 'Sustainalytics') {
                cell.style.height = '400px';
                new CoreGrid(cell, {
                    headersVisibility: HeadersVisibility.Column,
                    autoGenerateColumns: false,
                    itemsSource: getSustainalyticsDetailsData(),
                    isReadOnly: true,
                    columns: [
                        { header: 'Company ID', binding: 'CompanyID', visible: false },
                        { header: 'Category ID', binding: 'CategoryID', visible: false },
                        { header: 'Category Name', binding: 'CategoryName', width: '1.5*' },
                        { header: 'Indicator ID', binding: 'IndicatorID', visible: false },
                        { header: 'Indicator Name', binding: 'IndicatorName', width: '1.5*', wordWrap: true },
                        { header: 'Assessment', binding: 'Assessment', width: '3*', wordWrap: true },
                    ],
                    updatedView: (s, e) => {
                        var row = s.columnHeaders.rows[0];
                        row.wordWrap = true;
                        s.autoSizeRows(0, s.rows.length, false); //, 5);
                        update = false;
                    },
                });
            } else if (row.dataItem.ControversyType === 'UNGC') {
                cell.style.height = '175px';
                new CoreGrid(cell, {
                    headersVisibility: HeadersVisibility.Column,
                    autoGenerateColumns: false,
                    itemsSource: getUNGCDetailsData(),
                    isReadOnly: true,
                    columns: [
                        { header: 'Company ID', binding: 'CompanyID', visible: false },
                        { header: 'Violation/Watchlist', binding: 'ComplianceStatus', width: '*' },
                        {
                            header: 'Global Compact Principle',
                            binding: 'GlobalCompactPrinciple',
                            width: '3*',
                            wordWrap: true,
                        },
                        {
                            header: 'Reason for Non-Compliance',
                            binding: 'ReasonForNonCompliance',
                            width: '2.25*',
                            wordWrap: true,
                        },
                    ],
                    updatedView: (s, e) => {
                        var row = s.columnHeaders.rows[0];
                        row.wordWrap = true;
                        s.autoSizeRows(0, s.rows.length, false); //, 5);
                        update = false;
                    },
                });
            }

            return cell;
        };

        dp.rowHasDetail = (row) => {
            if (row.dataItem.ControversyType === 'Sustainalytics') {
                return SustainalyticsDetailsData.length > 0;
            } else if (row.dataItem.ControversyType === 'UNGC') {
                return UNGCDetailsData.length > 0;
            }
            return false;
        };
    };

    return (
        <div data-test="controversies-grid">
            <FlexGrid itemsSource={getControversiesData()} alternatingRowStep={1} ref={initGrid} isReadyOnly="true" selectionMode="None">
                <FlexGridColumn header="Company ID" binding="CompanyID" width="2.8*" visible={false}></FlexGridColumn>
                <FlexGridColumn header="Sustainalytics" binding="Controversies" width="2.8*">
                    <FlexGridCellTemplate
                        cellType="Cell"
                        template={({ item, col: { binding } }) => {
                            const def = getItemDefinition(item);

                            return (
                                <div className={classes.controversyCell}>
                                    {def?.report}
                                    {def?.methodology}
                                </div>
                            );
                        }}
                    />
                </FlexGridColumn>
                <FlexGridColumn header="Date" binding="Date" width={100} align="center"></FlexGridColumn>
                <FlexGridColumn header="Rating" binding="Score" width={90} align="center">
                    <FlexGridCellTemplate
                        cellType="Cell"
                        template={({ item, col: { binding } }) => {
                            return item?.ControversyType === 'RiskRating' ? (
                                <Tooltip trigger={<span>{item?.Score}</span>}>Measured on a scale of 1-100 with 1 as the lowest risk and 100 as the highest risk.</Tooltip>
                            ) : (
                                <span>{item?.Score}</span>
                            );
                        }}
                    />
                </FlexGridColumn>
            </FlexGrid>
            <Dialog title="Authorization Error!" open={showDialog} showActions={true} onClose={closeErrorDialog} isInformation={true}>
                {downloadError}
            </Dialog>
            <Dialog title="UNGC Information" open={showUNGCInfoDialog} showActions={true} onClose={closeUNGCInfoDialog} isInformation={true}>
                <UngcInformation />
            </Dialog>
        </div>
    );
};

export default withStyles(styles)(ControversiesGrid);

const ungcStyles = {
    container: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
    },
};

const UngcInformationContent = ({ classes }) => {
    return (
        <div className={classes.container}>
            <div>
                <strong>Human Rights</strong>
                <p>Principle 1: Businesses should support and respect the protection of internationally proclaimed human rights; and</p>
                <p>Principle 2: make sure that they are not complicit in human rights abuses.</p>
            </div>
            <div>
                <strong>Labour</strong>
                <p>Principle 3: Businesses should uphold the freedom of association and the effective recognition of the right to collective bargaining;</p>
                <p>Principle 4: the elimination of all forms of forced and compulsory labour;</p>
                <p>Principle 5: the effective abolition of child labour; and </p>
                <p>Principle 6: the elimination of discrimination in respect of employment and occupation.</p>
            </div>
            <div>
                <strong>Environment</strong>
                <p>Principle 7: Businesses should support a precautionary approach to environmental challenges;</p>
                <p>Principle 8: undertake initiatives to promote greater environmental responsibility; and</p>
                <p>Principle 9: encourage the development and diffusion of environmentally friendly technologies.</p>
            </div>
            <div>
                <strong>Anti-Corruption</strong>
                <p>Principle 10: Businesses should work against corruption in all its forms, including extortion and bribery.</p>
            </div>
        </div>
    );
};

const UngcInformation = withStyles(ungcStyles)(UngcInformationContent);
