import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import ControversiesGrid from 'Applications/Grids/ControversiesGrid';
import ProxyDataGrid from 'Applications/Grids/ProxyDataGrid';
import LoadingPanel from 'UIComponents/LoadingPanel';
import ErrorPanel from 'UIComponents/ErrorPanel';

import { hasEntries } from 'Utils/arrayHelpers';
import { getControversy, getProxy } from 'store/GridDataModule';

const ControversyProxyGrids = ({ companyID, companyName }) => {
    const dispatch = useDispatch();

    const CompanyControversyInfo = useSelector((state) => state.GridDataReducer.ControversyInfo);
    const CompanyProxyInfo = useSelector((state) => state.GridDataReducer.ProxyInfo);

    const data = CompanyControversyInfo?.Data;
    const proxyData = CompanyProxyInfo?.Data;

    const controversySummaryData = data?.SummaryData != null ? data.SummaryData : [];
    const sustainalyticsDetailsData = data?.SustainalyticsDetailsData != null ? data.SustainalyticsDetailsData : [];
    const ungcDetailsData = data?.UNGCDetailsData != null ? data?.UNGCDetailsData : [];

    const proxySummaryData = proxyData?.SummaryData != null ? proxyData?.SummaryData : [];
    const proxyDetailsData = proxyData?.DetailsData != null ? proxyData?.DetailsData : [];

    React.useEffect(() => {
        if (companyID != null) {
            dispatch(getControversy(companyID));
            dispatch(getProxy(companyID));
        }
    }, [dispatch, companyID]);

    return (
        <>
            {CompanyControversyInfo?.isLoading ? (
                <LoadingPanel />
            ) : hasEntries(controversySummaryData) ? (
                <ControversiesGrid ControversySummaryData={controversySummaryData} SustainalyticsDetailsData={sustainalyticsDetailsData} UNGCDetailsData={ungcDetailsData} CompanyName={companyName} />
            ) : (
                <ErrorPanel message="No controversies data entries found." />
            )}
            {CompanyProxyInfo?.isLoading ? (
                <LoadingPanel />
            ) : hasEntries(proxySummaryData) ? (
                <ProxyDataGrid ProxySummaryData={proxySummaryData} ProxyDetailsData={proxyDetailsData} />
            ) : (
                <ErrorPanel message="No proxy data entries found." />
            )}
        </>
    );
};

export default ControversyProxyGrids;
