import React, { useEffect, useState } from 'react';

import Downloader from 'componentlibrary/file/Downloader';

import { useCsrReports } from 'hooks/data/useCsrReports';

import { hasEntries } from 'Utils/arrayHelpers';
import { dateFormat, formatDate } from 'Utils/dateHelper';
import { isNullOrEmpty } from 'Utils/stringHelper';

import './CSRGrid.css';

const CSRGrid = ({ companyID }) => {
    const [isCollapsed, setIsCollapsed] = useState(true);
    const [{ data: reports, status }, getReports] = useCsrReports(companyID);

    const handleCollapse = () => {
        setIsCollapsed(!isCollapsed);
    };

    useEffect(() => {
        if (companyID != null) {
            getReports({ companyID });
        }
    }, [companyID, getReports]);

    return (
        status === 'SUCCESS' &&
        hasEntries(reports) && (
            <div className="csr-wrapper">
                <div className="csr-wrapper">
                    <div className="csr-top">
                        <div className="csr-title">Corporate Sustainability and Other Reports (CSR) Links</div>
                        <div className="csr-actions">
                            {reports.length > 1 && (
                                <div className="csr-collapse-icon">
                                    <i onClick={handleCollapse} className={`ab-primary fas fa-chevron-${isCollapsed ? 'down' : 'up'}`}></i>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="csr-main">
                        <table className="csr-reports">
                            <thead>
                                <tr className="csr-report-headers">
                                    <th className="csr-label">Report Title</th>
                                    <th className="csr-label">File Date</th>
                                </tr>
                            </thead>
                            <tbody className="csr-report-rows">
                                {(isCollapsed ? reports.slice(0, 1) : reports).map((report) => {
                                    var fileName = report.ReportFileName;
                                    var sanitizedFilename = encodeURIComponent(fileName).replace(/%[0-9A-Fa-f]{2}/g, '_');
                                    return (
                                        <tr key={report.ReportID}>
                                            <td className="csr-report-name csr-value">
                                                {isNullOrEmpty(report.ReportFileName) ? (
                                                    report.DisplayTitle
                                                ) : (
                                                    <Downloader useApiResource={true} className="csr-report-downloader" fileName={sanitizedFilename} uri={`/files/csr/${report.SecurityID}/${fileName}/${report.UUID}`}>
                                                        {isNullOrEmpty(report.DisplayTitle) ? 'Untitled' : report.DisplayTitle}{' '}
                                                    </Downloader>
                                                )}
                                            </td>
                                            <td className="csr-report-date csr-value">{formatDate(report.FileDate, dateFormat)}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        )
    );
};

export default CSRGrid;
