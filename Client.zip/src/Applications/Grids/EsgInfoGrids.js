import React from 'react';
import { useSelector } from 'react-redux';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import CSRGrid from './CSRGrid.js';
import ControversyProxyGrids from './ControversyProxyGrids';
import ModernSlaveryRiskExposureGrid from './MSRisk/ModernSlaveryRiskExposureGrid';
import CTAlignmentFrameworkGrid from './CTAlignmentFramework/CTAlignmentFrameworkGrid';

import MaterialityMaps from './MaterialityMaps';

const styles = (theme) => ({
    esgGridSection: {
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
        padding: 6,
    },
    csrGrid: {
        margin: '0 0 10px 0',
    },
    msRatingGrid: {
        margin: '0 0 10px 0',
    },
    esgInfoGrids: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        height: 'calc(100vh - 145px)',
        margin: 0,
        overflowY: 'scroll',
        '& .wj-header': {
            backgroundColor: '#B5C7E7',
            borderColor: 'grey',
            fontWeight: 700,
            verticalAlign: 'middle',
            textAlign: 'center',
            color: 'black',
        },
        '& .wj-content [wj-part="root"]': {
            overflowX: 'hidden !important',
        },
    },

    '@media (max-width: 990px)': {
        esgInfoGrids: {
            height: 'calc(50vh - 135px)',
        },
    },
});

const EsgInfoGrids = ({ classes }) => {
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const companyID = company?.CompanyID;
    const companyName = company?.CompanyName;

    return (
        companyID != null && (
            <div className={classes.esgInfoGrids}>
                <Paper className={classes.esgGridSection} elevation={1}>
                    <ControversyProxyGrids companyID={companyID} companyName={companyName} />
                    <CSRGrid companyID={companyID} />
                    <CTAlignmentFrameworkGrid companyID={companyID} />
                    <ModernSlaveryRiskExposureGrid companyID={companyID} />
                </Paper>
                <Paper className={classes.esgGridSection} elevation={1}>
                    <MaterialityMaps companyID={companyID} />
                </Paper>
            </div>
        )
    );
};

export default withStyles(styles, { withTheme: true })(EsgInfoGrids);
