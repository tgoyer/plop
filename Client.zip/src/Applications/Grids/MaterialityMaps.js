import React, { useMemo } from 'react';
import { withStyles } from '@material-ui/core';
import cn from 'classnames';

import Tooltip from 'componentlibrary/tooltip/Tooltip';
import Downloader from 'componentlibrary/file/Downloader';
import { TabHeading } from 'components/Content';

import ABGrid from 'Applications/Grids/MaterialityMap/ABGrid';
import MsciGrids from 'Applications/Grids/MaterialityMap/MsciGrids';

import useFeatureFlagUsers from 'hooks/data/useFeatureFlagUsers';

import { pxToRem } from 'Utils/layoutHelper';

const AB_PRISM_GRID_FLAG = 'AB-PRISM Materiality Grid';

const styles = () => ({
    infoIcon: {
        color: '#6987B9',
        cursor: 'help',
        fontSize: pxToRem(13, true),
        marginLeft: 8,
    },
    title: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
    },
    tooltip: {
        display: 'flex',
        flexDirection: 'row',
    },
});

const MaterialityMaps = ({ classes, ...props }) => {
    const { hasFlag } = useFeatureFlagUsers();

    const tabs = useMemo(() => {
        const list = [];

        if (hasFlag(AB_PRISM_GRID_FLAG)) {
            list.push({ label: 'AB-PRISM', component: () => <ABGrid {...props} /> });
        }

        list.push({
            label: (
                <div className={classes.title}>
                    <span>MSCI</span>
                    <Tooltip side="bottom" trigger={<i className={cn('fas', 'fa-info-circle', classes.infoIcon)} />}>
                        <div className={classes.tooltip}>
                            <span>View the&nbsp;</span>
                            <Downloader uri="/assets/documents/MSCI-Legend.pdf">MSCI terms glossary</Downloader>
                        </div>
                    </Tooltip>
                </div>
            ),
            component: () => <MsciGrids {...props} />,
        });
        return list;
    }, [classes, hasFlag, props]);

    return <TabHeading title="Materiality Maps" tabs={tabs} />;
};

export default withStyles(styles)(MaterialityMaps);
