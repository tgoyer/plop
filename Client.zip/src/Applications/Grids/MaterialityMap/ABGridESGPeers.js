import React, { useEffect, useState } from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import LoadingSpinner from 'componentlibrary/spinners/Loading';

import { useMaterialityMapESGPeers } from 'hooks/data/useMaterialityMapESGPeers';
import { isNullOrEmpty } from 'Utils/stringHelper';
import Tooltip from 'componentlibrary/tooltip/Tooltip';
import { Table, TableBody, TableCell, TableHeader, TableRow, TableSortHeader } from 'componentlibrary/table';

const styles = () => ({
    selected: {
        background: '#ffeeee',
        fontWeight: 700,
    },
    grid: {
        maxHeight: 500,
        position: 'relative',
        border: 0,
        borderCollapse: 'collapse',
        minWidth: 550,
        width: '50vw',
    },
    tooltipGrid: {
        minWidth: 350,
        '& > tbody td': {
            textAlign: 'center',
            padding: 8,
        },
    },
});

const ABGridESGPeers = ({ classes, companyID, factorID }) => {
    const [aggregates, setAggregates] = useState(null);
    const [issuers, setIssuers] = useState([]);
    const [sort, setSort] = useState(null);

    const [response, fetchPeers] = useMaterialityMapESGPeers();

    const handleSort = ({ field, direction }) => {
        const newDir = field === sort?.field ? direction : 'ASC';
        if (newDir == null) {
            setSort(null);
        } else {
            setSort({ field, direction: newDir });
        }
    };

    const getValue = (value, precision = 2) => {
        const pow = 10 ** precision;
        return isNullOrEmpty(value) ? '--' : isNaN(value) ? value : (Math.round(Number(value) * pow) / pow).toFixed(precision);
    };

    useEffect(() => {
        setAggregates(response?.data?.Aggregates);
    }, [response?.data?.Aggregates]);

    useEffect(() => {
        if (sort == null) {
            setIssuers([...(response?.data?.Issuers ?? [])]);
        } else {
            setIssuers(
                [...(response?.data?.Issuers ?? [])].sort((a, b) => {
                    const aValue = isNaN(a[sort.field]) ? a[sort.field] : Number(a[sort.field]);
                    const bValue = isNaN(b[sort.field]) ? b[sort.field] : Number(b[sort.field]);
                    const result = sort?.direction === 'ASC' ? aValue > bValue : aValue < bValue;
                    return result ? 1 : -1;
                })
            );
        }
    }, [response?.data?.Issuers, sort]);

    useEffect(() => {
        if (companyID != null) {
            fetchPeers({ companyID, factorID, name: 'ab' });
        }
    }, [companyID, factorID, fetchPeers]);

    return response?.status === 'FETCHING' ? (
        <Table className={classes.grid}>
            <TableHeader title="Loading..."></TableHeader>
            <TableBody>
                <TableRow>
                    <TableCell>
                        <LoadingSpinner />
                    </TableCell>
                </TableRow>
            </TableBody>
        </Table>
    ) : response?.success ? (
        <Table className={classes.grid}>
            <TableHeader title={`${aggregates?.CompanyName} Industry Peer ESG Scores`}>
                <TableRow>
                    <TableSortHeader field="CompanyName" sort={sort} onClick={handleSort}>
                        Issuer Name
                    </TableSortHeader>
                    <TableSortHeader field="EScore" sort={sort} onClick={handleSort}>
                        <span>E Score</span>
                        <Tooltip padded={false} trigger={<i className="fas fa-info-circle"></i>}>
                            <Table className={classes.tooltipGrid}>
                                <TableHeader title="Industry Environmental Scale">
                                    <TableRow>
                                        <TableCell as="th">Min E</TableCell>
                                        <TableCell as="th">Avg E</TableCell>
                                        <TableCell as="th">Max E</TableCell>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>{aggregates?.EMin}</TableCell>
                                        <TableCell>{aggregates?.EAvg}</TableCell>
                                        <TableCell>{aggregates?.EMax}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </Tooltip>
                    </TableSortHeader>
                    <TableSortHeader field="SScore" sort={sort} onClick={handleSort}>
                        <span>S Score</span>
                        <Tooltip padded={false} trigger={<i className="fas fa-info-circle"></i>}>
                            <Table className={classes.tooltipGrid}>
                                <TableHeader title="Industry Social Scale">
                                    <TableRow>
                                        <TableCell as="th">Min S</TableCell>
                                        <TableCell as="th">Avg S</TableCell>
                                        <TableCell as="th">Max S</TableCell>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>{aggregates?.SMin}</TableCell>
                                        <TableCell>{aggregates?.SAvg}</TableCell>
                                        <TableCell>{aggregates?.SMax}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </Tooltip>
                    </TableSortHeader>
                    <TableSortHeader field="GScore" sort={sort} onClick={handleSort}>
                        <span>G Score</span>
                        <Tooltip padded={false} trigger={<i className="fas fa-info-circle"></i>}>
                            <Table className={classes.tooltipGrid}>
                                <TableHeader title="Industry Governance Scale">
                                    <TableRow>
                                        <TableCell as="th">Min G</TableCell>
                                        <TableCell as="th">Avg G</TableCell>
                                        <TableCell as="th">Max G</TableCell>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>{aggregates?.GMin}</TableCell>
                                        <TableCell>{aggregates?.GAvg}</TableCell>
                                        <TableCell>{aggregates?.GMax}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </Tooltip>
                    </TableSortHeader>
                    <TableSortHeader field="ESGScore" sort={sort} onClick={handleSort}>
                        <span>ESG Score</span>
                        <Tooltip padded={false} trigger={<i className="fas fa-info-circle"></i>}>
                            <Table className={classes.tooltipGrid}>
                                <TableHeader title="Industry ESG Aggregates">
                                    <TableRow>
                                        <TableCell as="th">Min ESG</TableCell>
                                        <TableCell as="th">Avg ESG</TableCell>
                                        <TableCell as="th">Max ESG</TableCell>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>{aggregates?.ESGMin}</TableCell>
                                        <TableCell>{aggregates?.ESGAvg}</TableCell>
                                        <TableCell>{aggregates?.ESGMax}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </Tooltip>
                    </TableSortHeader>
                </TableRow>
            </TableHeader>
            <TableBody>
                {issuers?.map((issuer) => (
                    <TableRow className={cn({ [classes.selected]: issuer.CompanyIsSelected })}>
                        <TableCell>{issuer.CompanyName}</TableCell>
                        <TableCell>{getValue(issuer.EScore, 2)}</TableCell>
                        <TableCell>{getValue(issuer.SScore, 2)}</TableCell>
                        <TableCell>{getValue(issuer.GScore, 2)}</TableCell>
                        <TableCell>{getValue(issuer.ESGScore, 2)}</TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    ) : null;
};

export default withStyles(styles)(ABGridESGPeers);
