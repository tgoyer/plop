import React, { useEffect, useState } from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import LoadingSpinner from 'componentlibrary/spinners/Loading';

import { useMaterialityMapPeers } from 'hooks/data/useMaterialityMapPeers';
import { isNullOrEmpty } from 'Utils/stringHelper';
import { Table, TableBody, TableCell, TableHeader, TableRow, TableSortHeader } from 'componentlibrary/table';

const styles = () => ({
    selected: {
        background: '#fee',
        fontWeight: 700,
    },
    grid: {
        maxHeight: 500,
        position: 'relative',
        border: 0,
        borderCollapse: 'collapse',
        minWidth: 550,
        width: '50vw',
    },
});

const ABGridPeers = ({ classes, companyID, factorID }) => {
    const [factors, setFactors] = useState([]);
    const [sort, setSort] = useState(null);

    const [response, fetchPeers] = useMaterialityMapPeers();

    const getValue = (value, precision = 2) => {
        const pow = 10 ** precision;
        return isNullOrEmpty(value) ? '' : isNaN(value) ? value : (Math.round(Number(value) * pow) / pow).toFixed(precision);
    };
    const handleSort = ({ field, direction }) => {
        const newDir = field === sort?.field ? direction : 'ASC';
        if (newDir == null) {
            setSort(null);
        } else {
            setSort({ field, direction: newDir });
        }
    };

    useEffect(() => {
        if (sort == null) {
            setFactors([...(response?.data?.Factors ?? [])]);
        } else {
            setFactors(
                [...(response?.data?.Factors ?? [])].sort((a, b) => {
                    const aValue = isNaN(a[sort.field]) ? a[sort.field] : Number(a[sort.field]);
                    const bValue = isNaN(b[sort.field]) ? b[sort.field] : Number(b[sort.field]);
                    const result = sort?.direction === 'ASC' ? aValue > bValue : aValue < bValue;
                    return result ? 1 : -1;
                })
            );
        }
    }, [response?.data?.Factors, sort]);
    useEffect(() => {
        if (companyID != null) {
            fetchPeers({ companyID, factorID, name: 'ab' });
        }
    }, [companyID, factorID, fetchPeers]);

    const companyFactor = Array.isArray(response?.data?.Factors) ? response?.data?.Factors.find((f) => f.CompanyIsSelected === true) : null;

    return response?.status === 'FETCHING' ? (
        <Table className={classes.grid}>
            <TableHeader title="Loading..."></TableHeader>
            <TableBody>
                <TableRow>
                    <TableCell>
                        <LoadingSpinner />
                    </TableCell>
                </TableRow>
            </TableBody>
        </Table>
    ) : response?.success ? (
        <Table className={classes.grid}>
            <TableHeader title={companyFactor != null ? `${companyFactor.CompanyName} Peer Factor Scores` : null}>
                <TableRow>
                    <TableSortHeader field="CompanyName" sort={sort} onClick={handleSort}>
                        Issuer Name
                    </TableSortHeader>
                    <TableSortHeader field="FactorScore" sort={sort} onClick={handleSort}>
                        Score
                    </TableSortHeader>
                    <TableSortHeader field="FactorValue" sort={sort} onClick={handleSort}>
                        Value
                    </TableSortHeader>
                    <TableSortHeader field="FactorRawValue" sort={sort} onClick={handleSort}>
                        Raw Value
                    </TableSortHeader>
                    <TableSortHeader field="FactorOverrideValue" sort={sort} onClick={handleSort}>
                        Analyst Override
                    </TableSortHeader>
                </TableRow>
            </TableHeader>
            <TableBody>
                {factors?.map((factor) => (
                    <TableRow className={cn({ [classes.selected]: factor.CompanyIsSelected })}>
                        <TableCell>{factor.CompanyName}</TableCell>
                        <TableCell>{getValue(factor.FactorScore, 2)}</TableCell>
                        <TableCell>{getValue(factor.FactorValue, 2)}</TableCell>
                        <TableCell>{getValue(factor.FactorRawValue, 6)}</TableCell>
                        <TableCell>{getValue(factor.FactorOverrideValue, 2)}</TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    ) : null;
};

export default withStyles(styles)(ABGridPeers);
