import React, { useEffect, useMemo, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';
import cn from 'classnames';

import Button from 'componentlibrary/buttons/Button';
import Tooltip from 'componentlibrary/tooltip/Tooltip';
import Dialog from 'componentlibrary/dialog/Dialog';

import EnvironmentalGrid from 'Applications/Grids/Msci/MsciEnvironmentalGrid';
import GovernanceGrid from 'Applications/Grids/Msci/MsciGovernanceGrid';
import SocialGrid from 'Applications/Grids/Msci/MsciSocialGrid';
import CompanyOverride from 'Applications/Grids/Msci/CompanyOverride';

import { getMsci, toggleGridValidationErrorsModal } from 'store/GridDataModule';

import { hasEntries } from 'Utils/arrayHelpers';
import { formatDate } from 'Utils/dateHelper';
import { pxToRem } from 'Utils/layoutHelper';
import { isNullOrEmpty } from 'Utils/stringHelper';
import Downloader from 'componentlibrary/file/Downloader';

const styles = () => ({
    companyRating: {
        display: 'flex',
        flexDirection: 'row',
        gap: 2,
        cursor: 'default',
        fontWeight: 700,
        padding: '8px 12px',
        '& > .rating': {
            color: '#6987b9',
            fontWeight: 700,
            marginLeft: 4,
            '& > .required': {
                display: 'flex',
                flexDirection: 'row',
                gap: 4,
                alignItems: 'center',

                color: 'red',
            },
        },
    },
    docLinks: {
        '& a + a': {
            marginLeft: 24,
        },
    },
    grids: {
        '& > div + div': {
            marginTop: 8,
        },
    },
    infoIcon: {
        color: '#6987B9',
        cursor: 'help',
        fontSize: pxToRem(13, true),
        marginLeft: 8,
    },
    input: {
        padding: '2px !important',
        '& > input': {
            fontSize: '12px !important',
            fontWeight: 700,
            height: '24px !important',
            padding: '2px !important',
            margin: '0px !important',
        },
    },
    modal: {
        bottom: 'auto',
        left: 'auto',
        right: 'auto',
        top: 'auto',
        fontWeight: 700,
    },
    msciGrid: {
        display: 'flex',
        flexDirection: 'column',
        margin: 0,
    },
    msciHeader: {
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
        '& .msci-heading': {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 8,
            fontWeight: 700,
        },
    },
    ratingDown: {
        color: '#ff0000',
        fontWeight: 700,
        fontSize: pxToRem(13),
        paddingLeft: 4,
    },
    ratingUp: {
        color: '#00b252',
        fontWeight: 700,
        fontSize: pxToRem(13),
        paddingLeft: 4,
    },
    subHeader: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',

        backgroundColor: '#f2f2f2',
        border: '1px solid #dcdcdc',
        borderRadius: 4,
        margin: 0,

        '& > div': {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
        },
    },
    title: {
        display: 'flex',
        flexShrink: '1',
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 4,
    },
    tooltip: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        '& .tooltip-content-grid': {
            display: 'grid',
            gridTemplateColumns: 'auto auto',
            gap: 8,
            '& > div': {
                display: 'flex',
                flexDirection: 'row',
                gap: 8,
            },
            '& > div:nth-child(odd)': {
                fontWeight: 700,
            },
        },
        '& .tooltip-content': {
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'baseline',
            gap: 8,
        },
    },
    '@media (max-width: 1280px)': {
        companyRating: {
            fontSize: pxToRem(11),
        },
    },
});

const showABVScores = true; // DEBUG Flag.  True. Set to true to enable ABV functionality
const showWijmoGrids = true; // DEBUG Flag.  True. Set to true to show Wijmo grids
const allowAllCanEdit = false; // DEBUG Flag.  False. Set to false for PROD to enable covering analyst restriction

const emptyMsciData = {
    msciID: null,
    fullReportLink: null,
    abvCompanyRating: null,
    abvRatingDate: null,
    anticipatedRating: null,
    companyRating: null,
    ratingDate: null,
    previousRating: null,
    previousRatingDate: null,
};
const ratingsMap = Object.freeze({
    AAAA: 99,
    AAA: 98,
    AA: 97,
    A: 96,
    BBBB: 89,
    BBB: 88,
    BB: 87,
    B: 86,
    CCCC: 79,
    CCC: 78,
    CC: 77,
    C: 76,
});

const mapMsciData = (msciDataInfo, companyID) => {
    if (!isNullOrEmpty(msciDataInfo) && hasEntries(msciDataInfo.Details)) {
        const details = msciDataInfo.Details[0];
        return {
            abvCompanyRating: details.ABCompanyRating,
            msciID: details.MSCIIssuerID,
            fullReportLink: companyID != null && details?.MSCIIssuerID != null ? `/companies/${companyID}/reports/msci/${details.MSCIIssuerID}` : null,
            abvRatingDate: details.ABCompanyRatingDate,
            anticipatedRating: details.AnticipatedCompanyRating,
            companyRating: details.CompanyRating,
            ratingDate: details.RatingDate,
            previousRating: details.PreviousRating,
            previousRatingDate: details.PreviousRatingDate,
        };
    }
    return emptyMsciData;
};

const MsciGrids = ({ classes }) => {
    const dispatch = useDispatch();
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const user = useSelector((state) => state.UserReducer.UserInfo.Data);

    const msciDataInfo = useSelector((state) => state.GridDataReducer.MSCIInfo.Data);
    const msciDataLoaded = useSelector((state) => state.GridDataReducer.MSCIInfo.isLoaded);
    const peerComparisonLink = useSelector((state) => state.AppSettingsReducer.ServerSettings.StreamlightUrl);
    const gridValidation = useSelector((state) => state.GridDataReducer.GridValidation);

    const [showAllKIs, setShowAllKIs] = useState(true);
    const [canEditScores, setCanEditScores] = useState(false);

    const companyID = company?.CompanyID;
    const msciData = useMemo(() => mapMsciData(msciDataInfo, companyID), [msciDataInfo, companyID]);
    const { fullReportLink, anticipatedRating, companyRating, ratingDate, previousRating, previousRatingDate } = msciData;

    const getRatingTrendIndicator = (companyRating, previousRating) => {
        return ratingsMap[companyRating] > ratingsMap[previousRating] ? (
            <i className={cn(classes.ratingUp, 'fa fa-long-arrow-alt-up')}></i>
        ) : ratingsMap[companyRating] < ratingsMap[previousRating] ? (
            <i className={cn(classes.ratingDown, 'fa fa-long-arrow-alt-down')}></i>
        ) : null;
    };

    const handleShowAllKIsChanged = () => {
        setShowAllKIs((show) => !show);
    };
    const handleValidationModalClose = () => {
        dispatch(toggleGridValidationErrorsModal(false, []));
    };

    useEffect(() => {
        if (company != null && user != null) {
            const isCovering = hasEntries(company.CoveringAnalysts) && company.CoveringAnalysts.indexOf(user.UserID) >= 0;
            setCanEditScores(allowAllCanEdit || isCovering);
        }
    }, [company, user]);

    useEffect(() => {
        if (companyID != null) {
            dispatch(getMsci(companyID));
        }
    }, [dispatch, companyID]);

    return (
        <div id="divMsciGrids" className={classes.msciGrid}>
            <>
                {msciDataLoaded && (msciDataInfo?.Details == null || msciDataInfo?.Details?.length === 0) ? null : (
                    <div className={classes.msciHeader} data-test="msci-grid-header">
                        <div className="msci-heading">
                            <div></div>
                            <div className={classes.docLinks}>
                                <Tooltip
                                    side="bottom"
                                    trigger={
                                        <a target="_blank" rel="noreferrer noopener" href={peerComparisonLink}>
                                            Peer Comparison
                                        </a>
                                    }
                                >
                                    View Peer Comparisons
                                </Tooltip>
                            </div>
                            <div className={classes.docLinks}>
                                {fullReportLink != null ? (
                                    <Tooltip
                                        side="bottom"
                                        trigger={
                                            <Downloader useApiResource={true} fileName={`${company.Ticker}_full_report.pdf`} uri={fullReportLink}>
                                                Full Report
                                            </Downloader>
                                        }
                                    >
                                        View the full MSCI report for this security.
                                    </Tooltip>
                                ) : (
                                    <span>Company not rated by MSCI</span>
                                )}
                            </div>
                            <div className={classes.docLinks}>
                                <Tooltip side="bottom" trigger={<Downloader uri="/assets/documents/MSCI_Ratings_Methodology.pdf">Ratings Methodology</Downloader>}>
                                    View the MSCI Ratings Methodology guide.
                                </Tooltip>
                            </div>
                            <div>
                                <Tooltip
                                    side="bottom"
                                    trigger={
                                        <div>
                                            <Button onClick={handleShowAllKIsChanged}>{showAllKIs ? 'Hide Non-weighted' : 'Show All'}</Button>
                                        </div>
                                    }
                                >
                                    Show or hide the display of unweighted key issues.
                                </Tooltip>
                            </div>
                        </div>
                        <div className={classes.subHeader}>
                            {isNullOrEmpty(companyRating) && isNullOrEmpty(anticipatedRating) && <div />}
                            {!isNullOrEmpty(companyRating) && (
                                <Tooltip
                                    side="bottom"
                                    trigger={
                                        <div className={cn(classes.companyRating, 'first')}>
                                            <span>Published Rating:</span>
                                            <span className="rating">
                                                {companyRating}
                                                {getRatingTrendIndicator(companyRating, previousRating)}
                                            </span>
                                        </div>
                                    }
                                >
                                    <div className={classes.tooltip}>
                                        <strong>MSCI Published Rating Trend</strong>
                                        <div className="tooltip-content">
                                            <strong>{companyRating}</strong>
                                            <em>({formatDate(ratingDate)})</em>
                                        </div>
                                        <div className="tooltip-content">
                                            <strong>{previousRating}</strong>
                                            <em>({formatDate(previousRatingDate)})</em>
                                        </div>
                                        <div className="tooltip-content">
                                            <p>These values represent MSCI's official published ratings as of the dates shown.</p>
                                        </div>
                                    </div>
                                </Tooltip>
                            )}
                            {!isNullOrEmpty(anticipatedRating) && (
                                <Tooltip
                                    side="bottom"
                                    trigger={
                                        <div className={classes.companyRating}>
                                            <span>Anticipated Rating:</span>
                                            <span className="rating">
                                                {anticipatedRating}
                                                {getRatingTrendIndicator(anticipatedRating, companyRating)}
                                            </span>
                                        </div>
                                    }
                                >
                                    <div className={classes.tooltip}>
                                        <div className="tooltip-content">
                                            <strong>MSCI Published Rating:</strong>
                                            <span>{companyRating}</span>
                                        </div>
                                        <div className="tooltip-content">
                                            <strong>MSCI Anticipated Rating:</strong>
                                            <span>{anticipatedRating}</span>
                                        </div>
                                        <div className="tooltip-content">
                                            <span>MSCI updates key issue scores periodically throughout the year, but they only update the company aggregate rating annually.</span>
                                        </div>
                                        <div className="tooltip-content">
                                            <span>This rating represents what AB anticipates the value to be if it were recalculated today.</span>
                                        </div>
                                    </div>
                                </Tooltip>
                            )}
                            <CompanyOverride canEdit={canEditScores} companyID={companyID} msci={msciData} show={showABVScores} />
                        </div>
                        {showWijmoGrids && (
                            <>
                                <EnvironmentalGrid showAllKIs={showAllKIs} showABVScores={showABVScores} canEditABVScores={canEditScores} />
                                <SocialGrid showAllKIs={showAllKIs} showABVScores={showABVScores} canEditABVScores={canEditScores} />
                                <GovernanceGrid showAllKIs={showAllKIs} showABVScores={showABVScores} canEditABVScores={canEditScores} />
                            </>
                        )}
                    </div>
                )}
                <Dialog
                    onOpenChange={handleValidationModalClose}
                    open={gridValidation.modalIsOpen}
                    title="Validation Error"
                    description={gridValidation.errors.length > 0 && gridValidation.errors.map((err, i) => <p key={i}>{err}</p>)}
                    actions={<Button onClick={() => handleValidationModalClose()}>Close</Button>}
                />
            </>
        </div>
    );
};

export default withStyles(styles)(MsciGrids);
