import React, { Fragment, useEffect, useMemo, useState } from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import ABGridPeers from 'Applications/Grids/MaterialityMap/ABGridPeers';
import ABGridESGPeers from 'Applications/Grids/MaterialityMap/ABGridESGPeers';

import Dialog from 'componentlibrary/dialog/Dialog';
import LoadingSpinner from 'componentlibrary/spinners/Loading';
import Tooltip from 'componentlibrary/tooltip/Tooltip';
import { Button, ButtonBar } from 'componentlibrary/buttons';
import { Table, TableBody, TableCell, TableFooter, TableHeader, TableRow } from 'componentlibrary/table';
import { DropdownCheckboxItem, DropdownMenu } from 'componentlibrary/menu/DropdownMenu';

import { useMaterialityMap } from 'hooks/data/useMaterialityMap';

import { isNullOrEmpty, isNotNullOrEmpty } from 'Utils/stringHelper';
import { hasEntries } from 'Utils/arrayHelpers';
import { roundDecimal } from 'Utils/numberHelper';

const FilterStatus = Object.freeze({
    BELOW_AVG_2: 40,
    BELOW_AVG_1: 50,
    ABOVE_AVG: 100,
    DEFAULT: null,
});

const DisplayModes = Object.freeze({
    ALL: 'all',
    WEIGHTED: 'weighted',
    ABOVE_AVG: 'above_avg',
    BELOW_AVG: 'below_avg',
});
const styles = () => ({
    headerSection: {
        display: 'flex',
        flexDirection: 'row',
        gap: 8,
    },
    grid: {
        '& .white': {
            color: 'white',
        },
        '& .tableIcon': {
            fontSize: '1.1rem',
        },
        '& .tableIconCell': {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'center',
        },
        '& .textRight': {
            textAlign: 'right',
        },
        '& > thead': {
            '& th:nth-child(1), & th:nth-child(2)': {
                textAlign: 'left',
                width: '100%',
            },
            '& th:nth-child(2)': {
                width: 150,
            },
        },
        '& > tfoot': {
            '& tr.overall td': {
                backgroundColor: '#6f6f6f',
                color: '#fff',
                fontWeight: 700,
                textTransform: 'uppercase',
            },
        },
        '& > tbody': {
            '& tr:has(.factor)': {
                backgroundColor: '#fff',
            },
            '& tr:has(.factor):nth-child(even)': {
                backgroundColor: '#f6f6f6',
            },
            '& tr:has(.theme):hover': {
                cursor: 'pointer',
            },
            '& td': {
                '&:nth-child(1)': {
                    minWidth: 'fit-content',
                },
                '& div.factor': {
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 12,
                    height: '100%',
                    width: '100%',
                    '&.title': {
                        paddingLeft: 16,
                        maxWidth: 200,
                    },
                    '&.name': {
                        fontWeight: 700,
                    },
                    '&.value': {
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'baseline',
                        justifyContent: 'flex-start',
                        gap: '8px',
                        '&.textRight': {
                            justifyContent: 'flex-end',
                        },
                    },
                },
                '&:nth-child(1) div.factor': {
                    paddingLeft: 4,
                },
                '&.aboveAvg': {
                    backgroundColor: '#d9f2d9',
                },
                '&.belowAvgLt': {
                    backgroundColor: '#ffcccc',
                },
                '&.belowAvgDk': {
                    backgroundColor: '#ff6666',
                    color: 'white',
                    fontWeight: 700,
                },
                '&.centered': {
                    textAlign: 'center',
                    '& > div': {
                        justifyContent: 'center',
                    },
                },
                '&.pillar': {
                    color: '#fff',
                    fontSize: '1rem',
                    padding: '8px 10px',
                    fontWeight: 700,
                    '&.E': {
                        backgroundColor: '#60ba53',
                    },
                    '&.S': {
                        backgroundColor: '#1e98d7',
                    },
                    '&.G': {
                        backgroundColor: '#f08f50',
                    },
                    '& .pillarNote': {
                        color: 'inherit',
                        padding: '0 0 0 0.8rem',
                    },
                },
                '&.theme': {
                    backgroundColor: '#e6e6e6',
                    fontWeight: 700,
                    width: '100%',
                    '& > div': {
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        cursor: 'pointer',
                        gap: 8,
                        '&.last': {
                            display: 'flex',
                            flexDirection: 'row',
                            justifyContent: 'center',
                        },
                    },
                },
            },
        },
    },
    gridContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
    },
    keyIssueNameTooltip: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        '& > div': {
            display: 'flex',
            flexDirection: 'column',
            gap: 4,
        },
    },
    linkHeader: {
        display: 'flex',
        flexDirection: 'row',
        gap: 8,
        alignItems: 'center',
        justifyContent: 'space-between',
        fontWeight: 700,
        width: '100%',
        padding: '4px 0 4px 8px',
        '& i.commentIcon': {
            fontSize: '1.35rem',
            padding: '0 0 0 0.8rem',
        },
    },
    linkSubHeader: {
        backgroundColor: '#eee',
        border: '1px solid #ccc',
        borderRadius: 4,
        padding: '8px 12px',
    },
    ratingUp: {
        color: '#00b252',
        fontWeight: 700,
        fontSize: 13,
        paddingLeft: 4,
    },
});

const filterFactors = (data, mode) => {
    return data.map((p) => ({
        ...p,
        children: p.children.map((t) => ({
            ...t,
            children: t.children.map((f) => ({
                ...f,
                visible: isMode(f, mode),
            })),
        })),
    }));
};
const getKey = (items) => {
    return hasEntries(items) ? items[0].PillarName + '::' + sanitize(items[0].ThemeName ?? '') : null;
};
const getPillars = (data) => {
    return getUnique(data, 'PillarName').map((name) => {
        const items = data.filter((item) => item.PillarName === name);
        const pillar = hasEntries(items) ? items[0] : {};
        return {
            ...pillar,
            children: getThemes(items),
        };
    });
};
const getStatus = (item) => {
    const theme = item.ThemeName;
    const isRF = isRedFlags(theme);
    const score = isNullOrEmpty(item?.FactorScore) ? null : Number(getFixed(item?.FactorScore));

    switch (true) {
        case isNullOrEmpty(score):
        case isRF && score > 0.9:
            return FilterStatus.DEFAULT;
        case isRF && score > 0.75:
            return FilterStatus.BELOW_AVG_1;
        case isRF && score <= 0.75:
            return FilterStatus.BELOW_AVG_2;
        case isRF:
            return null;
        case score >= 7:
            return FilterStatus.ABOVE_AVG;
        case score <= 3:
            return FilterStatus.BELOW_AVG_1;
        default:
            return null;
    }
};
const getStatusStyle = (item) => {
    switch (getStatus(item)) {
        case FilterStatus.BELOW_AVG_1:
            return 'belowAvgLt';
        case FilterStatus.BELOW_AVG_2:
            return 'belowAvgDk';
        case FilterStatus.ABOVE_AVG:
            return 'aboveAvg';
        default:
            return '';
    }
};
const getThemes = (data) => {
    return getUnique(data, 'ThemeName').reduce((acc, name) => {
        const children = data
            .filter((i) => i.ThemeName === name)
            .map((factor) => ({
                ...factor,
                visible: false,
            }));

        const theme = hasEntries(children) ? children[0] : {};

        if (hasEntries(children)) {
            acc.push({
                ...theme,
                children,
                expanded: false,
                key: getKey(children),
            });
        }

        return acc;
    }, []);
};
const getUnique = (data, key) => {
    return [...new Set(data.map((i) => i[key]))];
};
const getValue = (value, precision = 2) => {
    return isNaN(value) ? value : getFixed(value, precision, '--');
};
const getFixed = (value, precision = 2, defaultValue = '') => {
    const pow = 10 ** precision;
    return isNullOrEmpty(value) ? defaultValue : (Math.round(Number(value) * pow) / pow).toFixed(precision);
};
const isMode = (item, mode) => {
    const aboveAvg = 7;
    const belowAvg = 3;
    const theme = isNullOrEmpty(item?.ThemeName) ? null : item?.ThemeName;
    const score = isNullOrEmpty(item?.FactorScore) ? null : Number(item?.FactorScore);
    const weight = isNullOrEmpty(item?.FactorWeight) ? null : Number(item?.FactorWeight);
    const isRF = isRedFlags(theme);
    const status = isRF && getStatus(item) != null ? getStatus(item) : null;

    switch (mode) {
        case DisplayModes.ABOVE_AVG:
            return (isNotNullOrEmpty(score) && !isRF && score >= aboveAvg) || (isRF && status === FilterStatus.ABOVE_AVG);
        case DisplayModes.BELOW_AVG:
            return (isNotNullOrEmpty(score) && !isRF && score <= belowAvg) || (isRF && isNotNullOrEmpty(status) && status <= FilterStatus.BELOW_AVG_1);
        case DisplayModes.WEIGHTED:
            return (isNotNullOrEmpty(weight) && !isRF && weight > 0) || isRF;
        case DisplayModes.ALL:
        default:
            return true;
    }
};
const isRedFlags = (theme) => {
    return ['Red Flags'].includes(theme);
};
const sanitize = (value) => {
    return String(value).replaceAll(' ', '-').toUpperCase();
};
const setThemeExpanded = (data, theme) => {
    return data.map((p) => ({
        ...p,
        children: p.children.map((t) => ({
            ...t,
            expanded: theme.key === t.key ? theme.expanded : t.expanded,
        })),
    }));
};
const toggleThemeExpandedAll = (data, expanded) => {
    return data.map((p) => ({
        ...p,
        children: p.children.map((t) => ({
            ...t,
            expanded,
        })),
    }));
};

const ABGrid = ({ classes, companyID }) => {
    const [displayMode, setDisplayMode] = useState(DisplayModes.WEIGHTED);
    const [mappedData, setMap] = useState(null);
    const [schemas, setSchemas] = useState(null);
    const [schemaID, setSchemaID] = useState(1);
    const [showPeers, setShowPeers] = useState(false);

    const [response, fetchMap] = useMaterialityMap();

    useEffect(() => {
        const factors = response?.data?.Factors ?? [];
        const schemas = response?.data?.Schemas ?? [];
        const mode = DisplayModes.WEIGHTED;
        const map = getPillars(factors);

        setDisplayMode(mode);
        setMap(filterFactors(map, mode));
        setSchemas(schemas);
    }, [response?.data]);

    useEffect(() => {
        if (companyID != null) {
            fetchMap({ companyID, schemaID, name: 'ab' });
        }
    }, [companyID, schemaID, fetchMap]);

    const handleModeClick = (mode) => () => {
        setDisplayMode(mode);
        setMap(filterFactors(mappedData, mode));
    };
    const handleThemeChange = (theme) => {
        setMap(setThemeExpanded(mappedData, theme));
    };
    const handleToggleAll = (expanded) => () => {
        setMap(toggleThemeExpandedAll(mappedData, expanded));
    };

    const companyItem = useMemo(() => {
        return hasEntries(response?.data?.Factors) ? response?.data?.Factors[0] : {};
    }, [response?.data?.Factors]);

    return response?.status === 'FETCHING' ? (
        <LoadingSpinner />
    ) : response?.success ? (
        <div className={classes.gridContainer}>
            <div className={classes.linkHeader}>
                <div className={classes.headerSection}>
                    {/* <Tooltip
                        side="bottom"
                        trigger={
                            <a href="/" target="_blank" rel="noreferrer noopener">
                                Engagement Question List
                            </a>
                        }
                    >
                        View Engagement Question List
                    </Tooltip> */}
                </div>
                <div className={classes.headerSection}>
                    <ButtonBar>
                        <Button className={cn(classes.button, { secondary: displayMode !== DisplayModes.WEIGHTED })} onClick={handleModeClick(DisplayModes.WEIGHTED)}>
                            Weighted
                        </Button>
                        <Button className={cn(classes.button, { secondary: displayMode !== DisplayModes.ABOVE_AVG })} onClick={handleModeClick(DisplayModes.ABOVE_AVG)}>
                            Above Avg
                        </Button>
                        <Button className={cn(classes.button, { secondary: displayMode !== DisplayModes.BELOW_AVG })} onClick={handleModeClick(DisplayModes.BELOW_AVG)}>
                            Below Avg
                        </Button>
                        <Button className={cn(classes.button, { secondary: displayMode !== DisplayModes.ALL })} onClick={handleModeClick(DisplayModes.ALL)}>
                            All
                        </Button>
                    </ButtonBar>
                    <ButtonBar className={classes.buttonBar}>
                        <Button className={cn(classes.button, 'secondary')} onClick={handleToggleAll(true)}>
                            Expand All
                        </Button>
                        <Button className={cn(classes.button, 'secondary')} onClick={handleToggleAll(false)}>
                            Collapse All
                        </Button>
                        {hasEntries(schemas) && schemas.length > 1 && (
                            <>
                                <DropdownMenu
                                    align="end"
                                    side="left"
                                    title="Rating Schema"
                                    trigger={
                                        <Button className={cn(classes.trigger, 'secondary')} aria-label="Set Schema">
                                            <i className="fas fa-exchange-alt"></i>
                                        </Button>
                                    }
                                >
                                    {schemas.map((s) => (
                                        <DropdownCheckboxItem checked={s.SchemaID === schemaID} onSelect={() => setSchemaID(s.SchemaID)}>
                                            {s.SchemaName}
                                        </DropdownCheckboxItem>
                                    ))}
                                </DropdownMenu>
                            </>
                        )}
                    </ButtonBar>
                </div>
            </div>
            <Table className={classes.grid}>
                <TableHeader>
                    <TableRow>
                        <TableCell as="th">{companyItem.IndustryName}</TableCell>
                        <TableCell as="th">Value</TableCell>
                        <TableCell as="th">Score</TableCell>
                        <TableCell as="th">Min</TableCell>
                        <TableCell as="th">Avg</TableCell>
                        <TableCell as="th">Max</TableCell>
                        <TableCell as="th">Weight</TableCell>
                        <TableCell as="th">
                            <Tooltip
                                trigger={
                                    <div className="factor value tableIconCell" onClick={() => setShowPeers(true)}>
                                        <i className="fas fa-table tableIcon"></i>
                                    </div>
                                }
                            >
                                View Industry Peer ESG Scores
                            </Tooltip>
                            <Dialog
                                onOpenChange={setShowPeers}
                                open={showPeers}
                                title={`Industry Peer ESG Scores`}
                                description={companyItem.IndustryName}
                                actions={
                                    <>
                                        <Button className="secondary" onClick={() => setShowPeers(false)}>
                                            Close
                                        </Button>
                                    </>
                                }
                            >
                                <ABGridESGPeers companyID={companyItem.CompanyID} factorID={companyItem.FactorID} />
                            </Dialog>
                        </TableCell>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {mappedData?.map((pillar) => (
                        <Pillar key={pillar.name} classes={classes} pillar={pillar} onThemeChange={handleThemeChange} />
                    ))}
                </TableBody>
                <TableFooter>
                    <TableRow className="overall">
                        <TableCell colSpan={2}>Overall ESG Values</TableCell>
                        <TableCell className="textRight">{getValue(companyItem.CompanyScore)}</TableCell>
                        <TableCell className="textRight">{getValue(companyItem.CompanyMin)}</TableCell>
                        <TableCell className="textRight">{getValue(companyItem.CompanyAvg)}</TableCell>
                        <TableCell className="textRight">{getValue(companyItem.CompanyMax)}</TableCell>
                        <TableCell className="textRight">{getValue(100)}</TableCell>
                        <TableCell></TableCell>
                    </TableRow>
                </TableFooter>
            </Table>
        </div>
    ) : null;
};

export default withStyles(styles)(ABGrid);

const Pillar = ({ classes, pillar, onThemeChange }) => {
    const pillerLetter = String(pillar.PillarName).substring(0, 1);
    return (
        <Fragment key={pillar.PillarName}>
            <TableRow key={pillar.PillarName}>
                <TableCell className={cn('pillar', pillerLetter)} colSpan={2}>
                    {pillar.PillarName}
                </TableCell>
                <TableCell className={cn('pillar centered textRight', pillerLetter)}>{getValue(pillar.PillarScore)}</TableCell>
                <TableCell className={cn('pillar centered textRight', pillerLetter)}>{getValue(pillar.PillarMin)}</TableCell>
                <TableCell className={cn('pillar centered textRight', pillerLetter)}>{getValue(pillar.PillarAvg)}</TableCell>
                <TableCell className={cn('pillar centered textRight', pillerLetter)}>{getValue(pillar.PillarMax)}</TableCell>
                <TableCell className={cn('pillar centered textRight', pillerLetter)}>{getValue(roundDecimal(Number(pillar.PillarWeight), 3))}</TableCell>
                <TableCell className={cn('pillar centered', pillerLetter)}></TableCell>
            </TableRow>
            {pillar?.children?.map((theme) => (
                <Theme key={theme.name} classes={classes} theme={theme} onChange={onThemeChange} />
            ))}
        </Fragment>
    );
};
const Theme = ({ classes, theme, onChange }) => {
    const handleThemeClick = () => {
        if (onChange != null) {
            onChange({
                ...theme,
                expanded: !theme.expanded,
            });
        }
    };

    return (
        hasEntries(theme?.children) &&
        theme.children.some((f) => f?.visible) && (
            <Fragment>
                <TableRow onClick={handleThemeClick}>
                    <TableCell colSpan={2} className="theme">
                        <div>
                            <i className={`fas fa-chevron-${theme.expanded ? 'down' : 'right'}`}></i>
                            <span>{theme.ThemeName}</span>
                        </div>
                    </TableCell>
                    <TableCell className="theme textRight">{getValue(theme.ThemeScore)}</TableCell>
                    <TableCell className="theme textRight">{getValue(theme.ThemeMin)}</TableCell>
                    <TableCell className="theme textRight">{getValue(theme.ThemeAvg)}</TableCell>
                    <TableCell className="theme textRight">{getValue(theme.ThemeMax)}</TableCell>
                    <TableCell className="theme textRight">{getValue(roundDecimal(Number(theme.ThemeWeight), 3))}</TableCell>
                    <TableCell className="theme"></TableCell>
                </TableRow>
                {theme.expanded && theme?.children?.map((factor) => <Factor key={factor.FactorID} classes={classes} factor={factor} />)}
            </Fragment>
        )
    );
};
const Factor = ({ classes, factor }) => {
    const [showPeers, setShowPeers] = useState(false);
    const displayValue = isNullOrEmpty(factor.FactorOrgDescription) ? getValue(factor.FactorFormattedValue) : factor.FactorOrgDescription;

    return (
        factor.visible && (
            <TableRow>
                <TableCell className="factor">
                    <Tooltip style={{ width: '100%' }} trigger={<div className="factor name">{factor.DisplayName}</div>} side="left">
                        <div className={classes.keyIssueNameTooltip}>
                            <div>
                                <strong>Name: </strong>
                                <span>{factor.DisplayName}</span>
                            </div>
                            <div>
                                <strong>Source: </strong>
                                <span>{factor.Source}</span>
                            </div>
                            <div>
                                <strong>Description: </strong>
                                <p>{factor.Definition}</p>
                            </div>
                        </div>
                    </Tooltip>
                </TableCell>
                <TableCell>
                    <div className={cn('factor value', { numeric: !isNaN(displayValue) })}>{displayValue}</div>
                </TableCell>
                <TableCell className={getStatusStyle(factor)}>
                    <div className="factor value textRight">{getValue(factor.FactorScore)}</div>
                </TableCell>
                <TableCell>
                    <div className="factor value textRight">{getValue(factor.FactorMin)}</div>
                </TableCell>
                <TableCell>
                    <div className="factor value textRight">{getValue(factor.FactorAvg)}</div>
                </TableCell>
                <TableCell>
                    <div className="factor value textRight">{getValue(factor.FactorMax)}</div>
                </TableCell>
                <TableCell>
                    <div className="factor value textRight">{getValue(roundDecimal(Number(factor.FactorWeight), 3))}</div>
                </TableCell>
                <TableCell className="factor centered">
                    <Tooltip
                        trigger={
                            <div className="tableIconCell" onClick={() => setShowPeers(true)}>
                                <i className="fas fa-table tableIcon"></i>
                            </div>
                        }
                    >
                        View Industry Peer Factor Scores
                    </Tooltip>
                    <Dialog
                        onOpenChange={setShowPeers}
                        open={showPeers}
                        title={`${factor.IndustryName} Industry Peers`}
                        description={`${factor.DisplayName} Factor`}
                        actions={
                            <>
                                <Button className="secondary" onClick={() => setShowPeers(false)}>
                                    Close
                                </Button>
                            </>
                        }
                    >
                        <ABGridPeers companyID={factor.CompanyID} factorID={factor.FactorID} />
                    </Dialog>
                </TableCell>
            </TableRow>
        )
    );
};
