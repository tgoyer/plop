import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { CollectionView, PopupPosition, Tooltip } from '@grapecity/wijmo';
import { CellType, GroupRow, HeadersVisibility, SelectionMode } from '@grapecity/wijmo.grid';
import { FlexGrid, FlexGridColumn, FlexGridCellTemplate } from '@grapecity/wijmo.react.grid';

import ErrorPanel from 'UIComponents/ErrorPanel';
import LoadingSpinner from 'componentlibrary/spinners/Loading';

import ABValueOverride from 'Applications/Grids/Msci/ABValueOverride';
import { round, filterGrid, parseNumber, showAllFilter } from 'Applications/Grids/Msci/utils';

import { saveMsciOverride } from 'store/GridDataModule';

import { hasEntries } from 'Utils/arrayHelpers';
import { isNullOrEmpty } from 'Utils/stringHelper';

export default React.memo(({ showAllKIs, showABVScores, canEditABVScores }) => {
    const dispatch = useDispatch();
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const msciData = useSelector((state) => state.GridDataReducer.MSCIInfo.Data);
    const msciDataLoaded = useSelector((state) => state.GridDataReducer.MSCIInfo.isLoaded);

    const [data, setData] = React.useState(null);
    const kis = React.useMemo(() => (msciData?.KeyIssues != null ? msciData.KeyIssues.filter(filterGrid('Social')) : []), [msciData]);

    const formatItem = (s, e) => {
        if (s.rows[e.row] == null) return;

        const column = s.columns[e.col];
        const panel = e.panel;
        const isGroupRow = panel.rows[e.row] instanceof GroupRow;
        const tip = new Tooltip();
        tip.showDelay = 500;

        if (column != null && column.binding === 'OV_SCORE' && panel === s.columnHeaders) {
            tip.setTooltip(e.cell, 'AB Value Proprietary Score', PopupPosition.BelowRight);
        }
        if (panel === s.cells) {
            const item = s.rows[e.row].dataItem;

            switch (column.binding) {
                case 'KeyIssueName':
                    let tipText = '';
                    if (isGroupRow && panel.cellType !== CellType.RowHeader && e.cell.innerHTML.indexOf('items') > 0) {
                        e.cell.innerHTML = "<span class='wj-elem-collapse wj-glyph-down-right' role='button'></span> <b>" + item.name + '</b>';
                        e.cell.style.color = '#000000';
                        tipText = item.name;
                    } else if (item.KeyIssueName.startsWith('Total ')) {
                        tipText = item.KeyIssueName;
                    } else {
                        e.cell.innerHTML = item.KeyIssueName;
                        e.cell.style.backgroundColor = '';
                        e.cell.style.color = '#000000';
                        e.cell.style.fontWeight = '';
                        tipText =
                            !isNullOrEmpty(item.MappedKeyIssueName) && !isNullOrEmpty(item.Definition)
                                ? `<p>${item.Definition}</p><p>Maps to AB key issue: ${item.MappedKeyIssueName}</p>`
                                : !isNullOrEmpty(item.MappedKeyIssueName)
                                ? `<p>Maps to AB key issue: ${item.MappedKeyIssueName}</p>`
                                : !isNullOrEmpty(item.Definition)
                                ? `<p>${item.Definition}</p>`
                                : `<p>${item.KeyIssueName}</p>`;
                    }
                    tip.setTooltip(e.cell, tipText);
                    break;
                case 'EXP_SCORE':
                    if (!isGroupRow && panel.cellType === CellType.Cell) {
                        let style = getScoreStyles(item.ExpWarningLevel);
                        e.cell.style.backgroundColor = style.backgroundColor;
                        e.cell.style.color = style.color;
                        e.cell.style.fontWeight = style.fontWeight;
                    }
                    break;
                case 'MGMT_SCORE':
                    if (!isGroupRow && panel.cellType === CellType.Cell) {
                        let style = getScoreStyles(item.MgmtWarningLevel);
                        e.cell.style.backgroundColor = style.backgroundColor;
                        e.cell.style.color = style.color;
                        e.cell.style.fontWeight = style.fontWeight;
                    }
                    break;
                case 'SCORE':
                    if (!isGroupRow && panel.cellType === CellType.Cell) {
                        let style = getScoreStyles(item.ScoreWarningLevel);
                        e.cell.style.backgroundColor = style.backgroundColor;
                        e.cell.style.color = style.color;
                        e.cell.style.fontWeight = style.fontWeight;
                    }
                    break;
                case 'QUARTILE':
                    if (!isGroupRow && panel.cellType === CellType.Cell) {
                        let style = getScoreStyles(item.QuartileWarningLevel);
                        e.cell.style.backgroundColor = style.backgroundColor;
                        e.cell.style.color = style.color;
                        e.cell.style.fontWeight = style.fontWeight;
                    }
                    break;
                default:
                    e.cell.style.backgroundColor = null;
                    e.cell.style.color = null;
                    e.cell.style.fontWeight = 400;
                    break;
            }

            if (isGroupRow && panel.cellType !== CellType.RowHeader) {
                // && e.cell.innerHTML.indexOf("items") > 0) {
                if (e.cell.innerHTML.indexOf('Total Social') >= 0) {
                    s.rows[e.row].visible = false;
                    return;
                }
            } else {
                if (item.KeyIssueName != null && ['Total Social'].indexOf(item.KeyIssueName) >= 0) {
                    e.cell.style.backgroundColor = '#1e98d7';
                    e.cell.style.fontWeight = 'bold';
                    e.cell.style.color = 'white';
                }
            }
        }
    };

    const updatedView = (s, e) => {
        s.rows.defaultSize = 25;
    };

    const getScoreStyles = (value) => {
        return value == null || value === 0 || value === 'NA'
            ? { backgroundColor: '', color: 'black', fontWeight: 400 } // 0
            : value === 1
            ? { backgroundColor: '#FFCDD2', color: 'black', fontWeight: 700 } // 1
            : { backgroundColor: '#E57373', color: 'black', fontWeight: 700 }; // 2
    };

    const handleScoreChange = (item, field) => async (value) => {
        value = isNullOrEmpty(value) ? null : value;

        let type;
        switch (field) {
            case 'OV_SCORE':
                type = 'Score';
                break;
            case 'OV_WEIGHT':
                type = 'Weight';
                break;
            default:
                break;
        }

        dispatch(saveMsciOverride(item.OV_ID, company.CompanyID, item.KeyIssueID, type, value, msciData));
    };

    React.useEffect(() => {
        setData(
            !hasEntries(kis)
                ? null
                : new CollectionView(kis.filter(showAllFilter(showAllKIs)), {
                      groupDescriptions: ['ThemeName'],
                  })
        );
    }, [kis, showAllKIs]);

    return !msciDataLoaded ? (
        <LoadingSpinner />
    ) : data == null ? (
        <ErrorPanel message="No social entries found." />
    ) : (
        <FlexGrid
            allowMerging="Cells"
            allowSorting={false}
            alternatingRowStep={1}
            autoGenerateColumns={false}
            formatItem={formatItem}
            headersVisibility={HeadersVisibility.Column}
            height="350"
            itemsSource={data}
            selectionMode={SelectionMode.None}
            updatedView={updatedView}
            className="msciGridSocial"
        >
            <FlexGridColumn header="Social" binding="KeyIssueName" width="3.25*" align="left" />
            <FlexGridColumn header="Exp" binding="EXP_SCORE" width="0.75*" align="center" />
            <FlexGridColumn header="Mgmt" binding="MGMT_SCORE" width="0.75*" align="center" />
            <FlexGridColumn header="Wgt" binding="WEIGHT" width="1.0*" aggregate="Sum" align="center" />
            <FlexGridColumn header="Score" binding="SCORE" width="1.0*" align="center" />
            <FlexGridColumn header="Quartile" binding="QUARTILE" width="*" align="center" />
            <FlexGridColumn header="ABV Wgt" binding="OV_WEIGHT" width="1.0*" align="center" visible={showABVScores}>
                <FlexGridCellTemplate
                    cellType="Cell"
                    template={({ item, col: { binding } }) => {
                        const isTotal = item.KeyIssueName.startsWith('Total ');
                        const value = parseNumber(item[binding], true) == null ? null : round(item[binding], 1, true);
                        return isTotal ? (
                            value !== null && parseFloat(value).toFixed(1)
                        ) : (
                            <ABValueOverride isWeight={true} canEdit={canEditABVScores} value={value} label={item.KeyIssueName} onChange={handleScoreChange(item, binding)} isTotalRow={isTotal} />
                        );
                    }}
                />
            </FlexGridColumn>
            <FlexGridColumn header="ABV Score" binding="OV_SCORE" width="1.5*" align="center" visible={showABVScores}>
                <FlexGridCellTemplate
                    cellType="Cell"
                    template={({ item, col: { binding } }) => {
                        const isTotal = item.KeyIssueName.startsWith('Total ');

                        const value = parseNumber(item[binding], true) == null ? null : round(item[binding], 1, true);
                        return isTotal ? (
                            value !== null && parseFloat(value).toFixed(1)
                        ) : (
                            <ABValueOverride canEdit={canEditABVScores} value={value} label={item.KeyIssueName} onChange={handleScoreChange(item, binding)} isTotalRow={isTotal} />
                        );
                    }}
                />
            </FlexGridColumn>
        </FlexGrid>
    );
});
