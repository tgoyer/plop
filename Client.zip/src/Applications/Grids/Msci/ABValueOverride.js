import React from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import { isNullOrEmpty } from 'Utils/stringHelper';
import { round, parseNumber } from 'Applications/Grids/Msci/utils';

const styles = () => ({
    editCell: {
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'row',
        height: '100%',
        width: '100%',
        '& input': {
            color: '#000000',
            fontWeight: 400,
            height: '100%',
            width: '100%',
        },
        '& > div': {
            display: 'flex',
            justifyContent: 'center',
            flexDirection: 'row',
            height: '100%',
            width: '100%',
        },
        '& > div i': {
            display: 'none',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#6987B9',
        },
        '& > div i.headerCell': {
            color: '#ffffff',
        },
        '&:hover > div i': {
            display: 'flex',
        },
        '&:hover > div span + i': {
            marginLeft: 8,
        },
    },
});


const getMinMax = (isNegative, isWeight) => {
   const getUpperLimit = isWeight => isWeight ? 100 : 10; // Weight Max = 100; Score Max = 10
   return  isNegative ? { min: -10, max: 0 } : { min: 0, max: getUpperLimit(isWeight) } // Only Governance Deduction (OV_Deduction) will ever be: isNegative = true
};

const ABValueOverride = ({ classes, canEdit, label, isTotalRow = false, isNegative = false, isWeight, value = null, onChange }) => {
    const inputRef = React.useRef();
    const [cellValue, setCellValue] = React.useState('');
    const [enableEdit, setEnableEdit] = React.useState(false);

    const { min, max } = getMinMax(isNegative, isWeight);

    const handleBlur = (evt) => {
        const value =
            parseNumber(evt.currentTarget.value, true) == null ? null : round(evt.currentTarget.value, 1, true);
        const score = value == null ? null : value < min ? min : value > max ? max : value;

        setEnableEdit(false);
        setCellValue(score);
        onChange(score);
    };

    const handleChange = (evt) => {
        const value = evt.currentTarget.value;
        setCellValue(value);
    };

    const handleFocus = (evt) => {
        inputRef.current.select();
    };

    const handleKeyDown = (evt) => {
        if (evt.key === 'Enter') {
            handleBlur(evt);
        }
    };

    React.useEffect(() => {
        if (enableEdit) {
            inputRef.current.focus();
        }
    }, [enableEdit]);

    React.useEffect(() => {
        setCellValue(value == null ? '' : value);
    }, [label, value]);



    return canEdit ? (
        <div className={classes.editCell}>
            {enableEdit ? (
                <input
                    type="number"
                    value={cellValue}
                    ref={inputRef}
                    min={min}
                    max={max}
                    onChange={handleChange}
                    onFocus={handleFocus}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                />
            ) : (
                <div onClick={() => setEnableEdit(true)}>
                    <span>{isNullOrEmpty(cellValue) ? '' : parseFloat(cellValue).toFixed(1)}</span>
                    <i className={cn('fas fa-pencil-alt', { headerCell: isTotalRow })}></i>
                </div>
            )}
        </div>
    ) : (
        <span>{isNullOrEmpty(cellValue) ? '' : parseFloat(cellValue).toFixed(1)}</span>
    );
};

export default withStyles(styles)(ABValueOverride);
