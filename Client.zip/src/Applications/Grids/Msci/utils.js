import { isNullOrEmpty } from 'Utils/stringHelper';

export const round = (value = 0, digits = 0, truncate = false) => {
    const power = Math.pow(10, digits);
    const num = parseNumber(value, true);

    if (num == null) return null;
    if (truncate) {
        return parseFloat(value).toFixed(digits);
    } else {
        return parseInt(Math.round(num * power)) / power;
    }
};

export const parseNumber = (value, nullable = false) => (!isNaN(value) && !isNullOrEmpty(value) ? Number(value) : nullable ? null : 0);
export const filterGrid = (pillarName) => (item) => item.PillarName === pillarName;

const isExcluded = item => item.PillarName === 'Governance';
export const showAllFilter = (showAll) => (item) => showAll || item.HasData === 1 || isExcluded(item);

export const handleScoreChange = (item, field, dispatch, onSave, company) => async (value) => {
    value = isNullOrEmpty(value) ? null : value;
    let type;
    switch (field) {
        case 'OV_SCORE':
            type = 'Score';
            break;
        case 'OV_WEIGHT':
            type = 'Weight';
            break;
        case 'OV_DEDUCTION':
            type = 'Deduction';
            break;
        default:
            break;
    }

    dispatch(onSave(item.OV_ID, company.CompanyID, item.KeyIssueID, type, value));
};

export const validateWeights = (msciData, keyIssueUpdate) => {
    let errors = [];
    const isTotal = keyIssueName => keyIssueName.startsWith('Total ');

    // immutably find and develop a calulation with the value being added/updated/deleted
    // build up the desired change value and calc what the totals would be
    const ratingsWithUserChanges = msciData.KeyIssues.map(k => k.KeyIssueID === keyIssueUpdate.keyIssueId ? { ...k, OV_WEIGHT: parseFloat(keyIssueUpdate.value) } : k);

    // Checks to consider
    // 1: Will user updates change any of the below keys?
    // 2: 
    const totalMSCIWeight = ratingsWithUserChanges
        .filter(k => !isTotal(k.KeyIssueName) && k.OV_WEIGHT === null)
        .reduce((acc, currentValue) => acc + currentValue.WEIGHT, 0);


    const sumOfWeightsAndOverrideWeights = ratingsWithUserChanges
        .filter(k => !isTotal(k.KeyIssueName) && k.OV_WEIGHT >= 0)
        .reduce((acc, currentValue) => acc + currentValue.OV_WEIGHT, totalMSCIWeight);


    const governanceConstant = 100; // Governance Pillar Weight is always equal to 100 - (E Pillar Weight + S Pillar Weight)
    const governanceConstantMinusOtherPillars = governanceConstant - sumOfWeightsAndOverrideWeights
    const governanceMinusOtherPillarsIsZero = governanceConstantMinusOtherPillars >= 0 ? true : false;

    // Test against rules 
    // Sum of weights and override weights must be >= 100
    if (!governanceMinusOtherPillarsIsZero) errors = [...errors, `The total sum of Environment and Social Pillar weights and their overrides cannot be greater than 100. Please adjust weights overrides to comply.`];
    
    return {
        remainder: governanceConstantMinusOtherPillars,
        isValid: errors.length === 0,
        errors: errors
    }
};