import { validateWeights } from './utils';


describe('==> ABV Weight validator', () => {
    test('Removing the last override leaving regular MSCI ratings should be valid', () => {
        const msciData = {"KeyIssues": [{
            "PillerID": 1,
            "KeyIssueID": 1,
            "KeyIssueName": "Carbon Emissions ",
            "ThemeID": 1,
            "ThemeName": "Climate Change",
            "SCORE": 4.5,
            "WEIGHT": 50.0,
            "DEDUCTION": null,
            "OV_ID": null,
            "OV_SCORE": null,
            "OV_WEIGHT": 50.0 ,
            "OV_DEDUCTION": null,
          },
          {
            "PillerID": 1,
            "KeyIssueID": 2,
            "KeyIssueName": "Carbon Emissions ",
            "ThemeID": 1,
            "ThemeName": "Climate Change",
            "SCORE": 5.0,
            "WEIGHT": 55.0,
            "DEDUCTION": null,
            "OV_ID": null,
            "OV_SCORE": null,
            "OV_WEIGHT": null,
            "OV_DEDUCTION": null,
          }]};
        const keyIssueUpdate = {keyIssueId: 1, value: null, type: "Weight"};

        const expected = true;
        const actual =  validateWeights(msciData, keyIssueUpdate);

        expect(actual.isValid).toBe(expected);
    });

    test('Overriding an MSCI Weight greater than zero with an ABV Weight value that is 0 should be accounted for', () => {
      const msciData = {"KeyIssues": [{
          "PillerID": 1,
          "KeyIssueID": 1,
          "KeyIssueName": "Carbon Emissions ",
          "ThemeID": 1,
          "ThemeName": "Climate Change",
          "SCORE": 4.5,
          "WEIGHT": 48.0,
          "DEDUCTION": null,
          "OV_ID": null,
          "OV_SCORE": null,
          "OV_WEIGHT": null,
          "OV_DEDUCTION": null,
        },
        {
          "PillerID": 1,
          "KeyIssueID": 2, // This is the KI we are overriding 
          "KeyIssueName": "Product Carbon Footprint",
          "ThemeID": 1,
          "ThemeName": "Climate Change",
          "SCORE": 5.0,
          "WEIGHT": 48.0,
          "DEDUCTION": null,
          "OV_ID": null,
          "OV_SCORE": null,
          "OV_WEIGHT": null,
          "OV_DEDUCTION": null,
        },
        {
          "PillerID": 2,
          "KeyIssueID": 14,
          "KeyIssueName": "Human Capital Development",
          "ThemeID": 1,
          "ThemeName": "Human Capital",
          "SCORE": 5.0,
          "WEIGHT": 2.0,
          "DEDUCTION": null,
          "OV_ID": null,
          "OV_SCORE": null,
          "OV_WEIGHT": null,
          "OV_DEDUCTION": null,
        }]};
      const keyIssueUpdate = {keyIssueId: 2, value: 0, type: "Weight"};

      const expected = true;
      const expectedRemainder = 50;
      const actual =  validateWeights(msciData, keyIssueUpdate);


      // Since the keyIssueUpdate will override the WEIGHT of 48 with 0, the remainder should be 50 because -> 100 - (48 + 2 + 0) = 50)
      expect(actual.isValid).toBe(expected);
      expect(actual.remainder).toBe(expectedRemainder);
  });

  test('Update of an ABV override that results in E and S Weight SUM greater than 100 should be invalid', () => {
    const msciData = {"KeyIssues": [{
        "PillerID": 1,
        "KeyIssueID": 1,
        "KeyIssueName": "Carbon Emissions ",
        "ThemeID": 1,
        "ThemeName": "Climate Change",
        "SCORE": 4.5,
        "WEIGHT": 50.0,
        "DEDUCTION": null,
        "OV_ID": null,
        "OV_SCORE": null,
        "OV_WEIGHT": 95.0 ,
        "OV_DEDUCTION": null,
      },
      {
        "PillerID": 1,
        "KeyIssueID": 2, // This is the KI we are updating
        "KeyIssueName": "Product Carbon Footprint",
        "ThemeID": 1,
        "ThemeName": "Climate Change",
        "SCORE": 5.0,
        "WEIGHT": 5.0,
        "DEDUCTION": null,
        "OV_ID": null,
        "OV_SCORE": null,
        "OV_WEIGHT": null,
        "OV_DEDUCTION": null,
      }]};
    const keyIssueUpdate = {keyIssueId: 2, value: 99, type: "Weight"};

    const expected = false;
    const expectedRemainder = -94; // Expect in invalid negative number from this invalid overrride
    const actual =  validateWeights(msciData, keyIssueUpdate);

    expect(actual.remainder).toBe(expectedRemainder);
    expect(actual.isValid).toBe(expected);
});

test('Update of an ABV override that results in E and S Weight SUM less than 100 should be valid', () => {
  const msciData = {"KeyIssues": [{
      "PillerID": 1,
      "KeyIssueID": 1,
      "KeyIssueName": "Carbon Emissions ",
      "ThemeID": 1,
      "ThemeName": "Climate Change",
      "SCORE": 4.5,
      "WEIGHT": 12.0,
      "DEDUCTION": null,
      "OV_ID": null,
      "OV_SCORE": null,
      "OV_WEIGHT": null ,
      "OV_DEDUCTION": null,
    },
    {
      "PillerID": 1,
      "KeyIssueID": 2, // This is the KI we are updating
      "KeyIssueName": "Product Carbon Footprint",
      "ThemeID": 1,
      "ThemeName": "Climate Change",
      "SCORE": 5.0,
      "WEIGHT": 5.0,
      "DEDUCTION": null,
      "OV_ID": null,
      "OV_SCORE": null,
      "OV_WEIGHT": 5.0,
      "OV_DEDUCTION": null,
    }]};
  const keyIssueUpdate = {keyIssueId: 2, value: 10.8, type: "Weight"};

  const expected = true;
  const expectedRemainder = 77.2; // Expect in invalid negative number from this invalid overrride
  const actual =  validateWeights(msciData, keyIssueUpdate);

  expect(actual.remainder).toBe(expectedRemainder);
  expect(actual.isValid).toBe(expected);
});

    


});