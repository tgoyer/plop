import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { CollectionView, PopupPosition, Tooltip } from '@grapecity/wijmo';
import { CellType, GroupRow, HeadersVisibility, SelectionMode } from '@grapecity/wijmo.grid';
import { FlexGrid, FlexGridColumn, FlexGridCellTemplate } from '@grapecity/wijmo.react.grid';

import ErrorPanel from 'UIComponents/ErrorPanel';
import LoadingSpinner from 'componentlibrary/spinners/Loading';

import ABValueOverride from 'Applications/Grids/Msci/ABValueOverride';
import { round, filterGrid, parseNumber, showAllFilter, handleScoreChange } from 'Applications/Grids/Msci/utils';

import { saveMsciOverride } from 'store/GridDataModule';

import { hasEntries } from 'Utils/arrayHelpers';
import { isNullOrEmpty } from 'Utils/stringHelper';

import './governance.css';

export default React.memo(({ showAllKIs, showABVScores, canEditABVScores }) => {
    const dispatch = useDispatch();
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const msciData = useSelector((state) => state.GridDataReducer.MSCIInfo.Data);
    const msciDataLoaded = useSelector((state) => state.GridDataReducer.MSCIInfo.isLoaded);

    const [data, setData] = React.useState(null);
    const kis = React.useMemo(() => (msciData?.KeyIssues != null ? msciData.KeyIssues.filter(filterGrid('Governance')) : []), [msciData]);

    const formatItem = (s, e) => {
        if (s.rows[e.row] == null) return;

        const column = s.columns[e.col];
        const panel = e.panel;
        const isGroupRow = panel.rows[e.row] instanceof GroupRow;
        const tip = new Tooltip();
        tip.showDelay = 500;

        if (isGroupRow && column.binding === 'WEIGHT') e.cell.innerHTML = '';

        if (s.rows[e.row]._data.KeyIssueName === 'Total Governance') s.rows[e.row].height = 40;

        if (panel === s.cells) {
            const item = s.rows[e.row].dataItem;

            switch (column.binding) {
                case 'KeyIssueName':
                    let tipText = '';
                    if (isGroupRow && panel.cellType !== CellType.RowHeader && e.cell.innerHTML.indexOf('items') > 0) {
                        e.cell.innerHTML = "<span class='wj-elem-collapse wj-glyph-down-right' role='button'></span> <b>" + item.name + '</b>';
                        e.cell.style.color = '#000000';
                        tipText = item.name;
                    } else if (item.KeyIssueName.startsWith('Total ')) {
                        tipText = item.KeyIssueName;
                    } else {
                        e.cell.innerHTML = item.KeyIssueName;
                        e.cell.style.backgroundColor = '';
                        e.cell.style.color = '#000000';
                        e.cell.style.fontWeight = '';
                        tipText =
                            !isNullOrEmpty(item.MappedKeyIssueName) && !isNullOrEmpty(item.Definition)
                                ? `<p>${item.Definition}</p><p>Maps to AB key issue: ${item.MappedKeyIssueName}</p>`
                                : !isNullOrEmpty(item.MappedKeyIssueName)
                                ? `<p>Maps to AB key issue: ${item.MappedKeyIssueName}</p>`
                                : !isNullOrEmpty(item.Definition)
                                ? `<p>${item.Definition}</p>`
                                : `<p>${item.KeyIssueName}</p>`;
                    }
                    tip.setTooltip(e.cell, tipText);
                    break;
                case 'OV_WEIGHT':
                    if (item.KeyIssueName.startsWith('Total ')) {
                        tip.setTooltip(e.cell, 'G Pillar Weight = 100 - (E Pillar Weight + S Pillar Weight)', PopupPosition.BelowLeft);
                    }
                    break;
                case 'OV_DEDUCTION':
                    if (item?.KeyIssueName && item.KeyIssueName.startsWith('Total ')) {
                        tip.setTooltip(e.cell, 'Total Deduction = Σ(Key Issue Deductions), Score = 10 - Total Deduction', PopupPosition.Left);
                    } else if (item?.KeyIssueName && item.KeyIssueName === 'Corporate Behavior') {
                        tip.setTooltip(e.cell, 'Corporate Behavior Deduction = Σ(Key Issue Deductions) * 0.39', PopupPosition.Left);
                    } else if (item?.KeyIssueName && !(item.KeyIssueName.startsWith('Total ') || item.KeyIssueName.startsWith('Corporate '))) {
                        //tip.setTooltip(e.cell, 'Key Issue Deductions indicate how many points to subtract from 10', PopupPosition.Left);
                    }

                    break;
                case 'QUARTILE':
                    if (!isGroupRow && panel.cellType === CellType.Cell) {
                        let style = getScoreStyles(item.QuartileWarningLevel);
                        e.cell.style.backgroundColor = style.backgroundColor;
                        e.cell.style.color = style.color;
                        e.cell.style.fontWeight = style.fontWeight;
                    }
                    break;
                default:
                    e.cell.style.backgroundColor = null;
                    e.cell.style.color = null;
                    e.cell.style.fontWeight = 400;
                    break;
            }

            if (isGroupRow && panel.cellType !== CellType.RowHeader) {
                // && e.cell.innerHTML.indexOf("items") > 0) {
                if (e.cell.innerHTML.indexOf('Total Governance') >= 0) {
                    s.rows[e.row].visible = false;
                    return;
                }
            } else {
                if (item.KeyIssueName != null && ['Total Governance', 'Corporate Governance'].indexOf(item.KeyIssueName) >= 0) {
                    e.cell.style.backgroundColor = '#f08f50';
                    e.cell.style.fontWeight = 'bold';
                    e.cell.style.color = 'white';
                }
            }
        }
    };

    const updatedView = (s, e) => {
        s.rows.defaultSize = 25;
    };

    const getScoreStyles = (value) => {
        return value == null || value === 0 || value === 'NA'
            ? { backgroundColor: '', color: 'black', fontWeight: 400 } // 0
            : value === 1
            ? { backgroundColor: '#FFCDD2', color: 'black', fontWeight: 700 } // 1
            : { backgroundColor: '#E57373', color: 'black', fontWeight: 700 }; // 2
    };

    React.useEffect(() => {
        setData(
            !hasEntries(kis)
                ? null
                : new CollectionView(kis.filter(showAllFilter(showAllKIs)), {
                      groupDescriptions: ['ThemeName'],
                  })
        );
    }, [kis, showAllKIs]);

    const TotalGovernance = ({ deduction, score }) => (
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
            }}
        >
            {score && (
                <>
                    <span className="m-1">{deduction ? deduction : 0.0}</span>
                    <span style={{ margin: '0px 5px' }}>Score: {score}</span>
                </>
            )}
        </div>
    );

    return !msciDataLoaded ? (
        <LoadingSpinner />
    ) : data == null ? (
        <ErrorPanel message="No governance entries found." />
    ) : (
        <FlexGrid
            allowMerging="Cells"
            allowSorting={false}
            alternatingRowStep={1}
            autoGenerateColumns={false}
            formatItem={formatItem}
            headersVisibility={HeadersVisibility.Column}
            height="350"
            itemsSource={data}
            selectionMode={SelectionMode.None}
            updatedView={updatedView}
            className="msciGridGovernance"
        >
            <FlexGridColumn header="Governance" binding="KeyIssueName" width="3.25*" align="left" />
            <FlexGridColumn header="Global" binding="GLOBAL" width="0.75*" align="center"></FlexGridColumn>
            <FlexGridColumn header="Home" binding="HOME" width="0.75*" align="center"></FlexGridColumn>
            <FlexGridColumn header="Wgt" binding="WEIGHT" width="1.0*" aggregate="Sum" align="center"></FlexGridColumn>
            <FlexGridColumn header="Deduction" binding="DEDUCTION" width="1.0*" align="center">
                <FlexGridCellTemplate
                    cellType="Cell"
                    template={({ item, col: { binding } }) => {
                        const isTotal = item.KeyIssueName.startsWith('Total ');

                        const value = parseNumber(item[binding], true) == null ? null : round(item[binding], 2, true);

                        return isTotal ? <TotalGovernance deduction={item.DEDUCTION} score={item.SCORE} /> : value;
                    }}
                ></FlexGridCellTemplate>
            </FlexGridColumn>
            <FlexGridColumn header="ABV Wgt" binding="OV_WEIGHT" width="1.0*" align="center" visible={showABVScores}></FlexGridColumn>
            <FlexGridColumn header="ABV Deduction" binding="OV_DEDUCTION" width="1.0*" align="center" visible={showABVScores}>
                <FlexGridCellTemplate
                    cellType="Cell"
                    template={({ item, col: { binding } }) => {
                        const isTotal = item.KeyIssueName.startsWith('Total ');

                        const value = parseNumber(item[binding], true) == null ? null : round(item[binding], 2, true);
                        return isTotal || item.HasData ? (
                            <TotalGovernance deduction={item.OV_DEDUCTION} score={item.OV_SCORE} />
                        ) : (
                            <ABValueOverride
                                isNegative={true}
                                canEdit={canEditABVScores}
                                value={value}
                                label={item.KeyIssueName}
                                onChange={handleScoreChange(item, binding, dispatch, saveMsciOverride, company)}
                                isTotalRow={isTotal}
                            />
                        );
                    }}
                />
            </FlexGridColumn>
        </FlexGrid>
    );
});
