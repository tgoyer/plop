import React, { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';
import cn from 'classnames';

import { DropdownMenu, DropdownItem } from 'componentlibrary/menu/DropdownMenu';
import Button from 'componentlibrary/buttons/Button';
import Dialog from 'componentlibrary/dialog/Dialog';
import Tooltip from 'componentlibrary/tooltip/Tooltip';

import LoadingSpinner from 'componentlibrary/spinners/Loading';

import { hasEntries } from 'Utils/arrayHelpers';
import { formatDate, toDate } from 'Utils/dateHelper';
import { pxToRem } from 'Utils/layoutHelper';
import { isNullOrEmpty } from 'Utils/stringHelper';

import { getMsci } from 'store/GridDataModule';
import { useCompanyRatingOverride } from 'hooks/data/useCompanyRatingOverride';

const ratingSchemes = Object.freeze({
    ABV: {
        key: 'ABV',
        label: 'AB Value',
        rationaleRequired: true,
        dataKey: 'abvRating',
    },
    MSCI: {
        key: 'MSCI',
        label: 'MSCI',
        rationaleRequired: true,
        dataKey: 'anticipatedRating',
    },
});

const getScheme = (scheme, useDefault = false) => {
    const found = ratingSchemes[scheme];
    return found != null ? found : useDefault ? ratingSchemes.MSCI : null;
};
const needsRationale = (ratingInfo) => {
    const abvRating = ratingInfo?.abvRating;
    const affirmedRating = ratingInfo?.companyOverrideRating;
    const rating = abvRating ?? ratingInfo?.anticipatedRating;

    const abvDate = toDate(ratingInfo?.abvRatingDate);
    const rationaleDate = toDate(ratingInfo?.companyOverrideDate);

    const isAbvRated = !isNullOrEmpty(abvRating);
    const isAffirmedRated = !isNullOrEmpty(affirmedRating);

    const isRated = isAbvRated || isAffirmedRated;
    const requiresRationale = abvDate > rationaleDate || rating !== affirmedRating;
    return isRated && (!isAffirmedRated || requiresRationale);
};

const styles = () => ({
    dialog: {
        maxWidth: 450,
    },
    trigger: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        border: 'none',
        padding: '8px 10px',
        height: '100%',
        '&:hover': {
            background: '#00000011',
        },
    },
    icon: {
        color: 'rgb(105, 135, 185)',
    },
    dialogContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,

        backgroundColor: '#f2f2f2',
        border: '1px solid #dcdcdc',
        borderRadius: 4,
        padding: 12,
    },
    dialogContent: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'baseline',
        gap: 8,
        whiteSpace: 'pre-line',

        '&.emphasis': {
            fontStyle: 'italic',
        },
        '&.stacked': {
            flexDirection: 'column',
            gap: 0,
        },
        '&.end': {
            justifyContent: 'flex-end',
        },
        '& input, & textarea': {
            border: '1px solid #6987b9',
            borderRadius: 4,
            outline: 'none',
            padding: 6,
        },
        '& small.required': {
            color: '#990000',
            paddingTop: 2,
        },
    },
    companyRating: {
        display: 'flex',
        flexDirection: 'row',
        gap: 2,
        cursor: 'default',
        fontWeight: 700,
        padding: '0 12px',
        '& > .rating': {
            color: '#6987b9',
            fontWeight: 700,
            marginLeft: 4,
            '& > .required': {
                display: 'flex',
                flexDirection: 'row',
                gap: 4,
                alignItems: 'center',

                color: 'red',
            },
        },
    },
    '@media (max-width: 1280px)': {
        companyRating: {
            fontSize: pxToRem(11),
        },
    },
    tooltip: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        '& .tooltip-content-grid': {
            display: 'grid',
            gridTemplateColumns: 'auto auto',
            gap: 8,
            '& > div': {
                display: 'flex',
                flexDirection: 'row',
                gap: 8,
            },
            '& > div:nth-child(odd)': {
                fontWeight: 700,
            },
        },
        '& .tooltip-content': {
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'baseline',
            gap: 8,
        },
    },
});

const CompanyOverride = ({ classes, canEdit, companyID, show }) => {
    const dispatch = useDispatch();
    const msci = useSelector((state) => state.GridDataReducer.MSCIInfo.Data);

    const [{ data: companyInfo }, getCompanyRating, setCompanyRating] = useCompanyRatingOverride();

    const [rationale, setRationale] = useState(null);
    const [showConfirmPending, setShowConfirmPending] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [showRationaleEntry, setShowRationaleEntry] = useState(false);
    const [showReaffirm, setShowReaffirm] = useState(false);

    const ratingInfo = useMemo(() => {
        const details = msci?.Details != null && hasEntries(msci?.Details) ? msci?.Details[0] : {};
        return {
            abvRating: details?.ABCompanyRating ?? null,
            abvRatingDate: details?.ABCompanyRatingDate ?? null,
            abvRatingScheme: details?.ABCompanyRating != null ? 'ABV' : 'MSCI',
            anticipatedRating: details?.AnticipatedCompanyRating ?? null,
            anticipatedRatingDate: details?.RatingDate ?? null,
            companyOverrideByName: companyInfo?.overrideByName ?? null,
            companyOverrideDate: companyInfo?.overrideDate ?? null,
            companyOverrideRating: companyInfo?.overrideRating ?? null,
            companyOverrideRationale: companyInfo?.overrideRationale ?? null,
        };
    }, [companyInfo, msci]);

    const canReaffirm = useMemo(() => {
        const hasRating = !isNullOrEmpty(ratingInfo?.companyOverrideRating);
        const hasRationale = !isNullOrEmpty(ratingInfo?.companyOverrideRationale);
        const staleRationale = needsRationale(ratingInfo);
        return hasRating && hasRationale && !staleRationale;
    }, [ratingInfo]);

    const doSave = async (data) => {
        setShowConfirm(true);
        setShowConfirmPending(true);
        await setCompanyRating({ companyID, ...data });
        setShowConfirmPending(false);
    };
    const handleConfirmClose = () => {
        setShowConfirm(false);
        dispatch(getMsci(companyID));
    };
    const handleRationaleEntry = (ev) => {
        setRationale(ev.target.value);
    };
    const handleSaveRationaleEntry = () => {
        const key = ratingInfo?.abvRating != null ? 'ABV' : 'MSCI';
        const scheme = getScheme(key);
        doSave({
            rating: ratingInfo[scheme.dataKey],
            ratingScheme: key,
            rationale: rationale,
        });
        setShowRationaleEntry(false);
    };
    const handleSaveReaffirmRating = () => {
        doSave({ reaffirm: true });
        setShowReaffirm(false);
    };

    useEffect(() => {
        getCompanyRating({ companyID });
    }, [companyID, getCompanyRating]);
    useEffect(() => {
        setRationale(companyInfo?.overrideRationale);
    }, [companyInfo]);

    const rating = ratingInfo?.abvRating ?? ratingInfo?.anticipatedRating;

    return (
        show && (
            <div>
                <Tooltip
                    side="bottom"
                    trigger={
                        <div className={classes.companyRating}>
                            <span>AB Value Rating: </span>
                            <span className="rating">
                                {needsRationale(ratingInfo) ? (
                                    <span className="required">
                                        {ratingInfo?.companyOverrideRating ?? 'N/A'}
                                        <i className="fas fa-long-arrow-alt-right"></i>
                                        {rating}
                                    </span>
                                ) : (
                                    <span>{ratingInfo?.companyOverrideRating ?? 'N/A'}</span>
                                )}
                            </span>
                        </div>
                    }
                >
                    <div className={classes.tooltip} style={{ maxWidth: 400 }}>
                        {needsRationale(ratingInfo) ? (
                            <div className={classes.tooltip}>
                                <div className="tooltip-content">
                                    <span>This security needs to be affirmed. Please submit a rationale for the rating of this security.</span>
                                </div>
                                <div className="tooltip-content">
                                    <strong>ABV Rating:</strong>
                                    <span>{rating}</span>
                                </div>
                                <div className="tooltip-content">
                                    <strong>Affirmed Rating:</strong>
                                    <span>{ratingInfo?.companyOverrideRating ?? '--'}</span>
                                </div>
                                <div className="tooltip-content">
                                    <strong>Affirmed Rationale:</strong>
                                    <span>{ratingInfo?.companyOverrideRationale ?? '--'}</span>
                                </div>
                                {ratingInfo?.companyOverrideByName != null && (
                                    <div className="tooltip-content">
                                        <span>{ratingInfo?.companyOverrideByName}</span>
                                        <em>({formatDate(ratingInfo?.companyOverrideDate)})</em>
                                    </div>
                                )}
                            </div>
                        ) : ratingInfo?.companyOverrideRationale != null ? (
                            <div className="tooltip-content-grid">
                                <div>Rating:</div>
                                <div>{ratingInfo?.companyOverrideRating}</div>

                                <div>Rationale:</div>
                                <div>{ratingInfo?.companyOverrideRationale}</div>

                                <div>Last Updated:</div>
                                <div>
                                    <span>{ratingInfo?.companyOverrideByName}</span>
                                    <em>({formatDate(ratingInfo?.companyOverrideDate)})</em>
                                </div>
                            </div>
                        ) : (
                            <div>This security is not rated.</div>
                        )}
                    </div>
                </Tooltip>
                {canEdit && (
                    <>
                        <DropdownMenu
                            align="end"
                            side="bottom"
                            trigger={
                                <div className={classes.trigger} aria-label="Edit AB Value Rating">
                                    <i className={cn(classes.icon, 'fas fa-cog')}></i>
                                </div>
                            }
                        >
                            <DropdownItem disabled={!canReaffirm} onSelect={() => setShowReaffirm(true)}>
                                Re-Affirm Current Rating
                            </DropdownItem>
                            <DropdownItem onSelect={() => setShowRationaleEntry(true)}>Edit ABV Rating Rationale</DropdownItem>
                        </DropdownMenu>
                        <Dialog
                            onOpenChange={(open) => setShowReaffirm(open)}
                            open={showReaffirm}
                            className={classes.dialog}
                            title="Re-Affirm AB Value Rating"
                            description="Are you sure you wish to re-affirm the current AB Value rating for this security?"
                            actions={
                                <>
                                    <Button className="secondary" onClick={() => setShowReaffirm(false)}>
                                        No
                                    </Button>
                                    <Button onClick={handleSaveReaffirmRating}>Yes</Button>
                                </>
                            }
                        >
                            <div className={classes.dialogContainer}>
                                <div className={classes.dialogContent}>
                                    <strong>AB Value Rating: </strong>
                                    <span>{ratingInfo?.companyOverrideRating}</span>
                                    <em>({formatDate(ratingInfo?.companyOverrideDate)})</em>
                                </div>
                                <div className={cn(classes.dialogContent, 'stacked')}>
                                    <strong>AB Value Rationale: </strong>
                                    <div>{rationale}</div>
                                </div>
                            </div>
                            {ratingInfo?.companyOverrideDate != null && (
                                <div className={cn(classes.dialogContent, 'end', 'emphasis')}>
                                    <span>Last Updated:</span>
                                    <span>{ratingInfo?.companyOverrideByName}</span>
                                    <span>({formatDate(ratingInfo?.companyOverrideDate)})</span>
                                </div>
                            )}
                        </Dialog>
                        <Dialog
                            onOpenChange={setShowRationaleEntry}
                            open={showRationaleEntry}
                            className={classes.dialog}
                            title="AB Value Rating Rationale"
                            description="Enter the rationale for this security's AB Value rating."
                            actions={
                                <>
                                    <Button className="secondary" onClick={() => setShowRationaleEntry(false)}>
                                        Cancel
                                    </Button>
                                    <Button disabled={isNullOrEmpty(rationale)} onClick={handleSaveRationaleEntry}>
                                        Save
                                    </Button>
                                </>
                            }
                        >
                            <div className={classes.dialogContainer}>
                                {ratingInfo?.abvRating != null ? (
                                    <div className={classes.dialogContent}>
                                        <strong>Calculated AB Value Rating: </strong>
                                        <span>{ratingInfo?.abvRating}</span>
                                        <em>({formatDate(ratingInfo?.abvRatingDate)})</em>
                                    </div>
                                ) : (
                                    <div className={classes.dialogContent}>
                                        <strong>MSCI Anticipated Rating: </strong>
                                        <span>{ratingInfo?.anticipatedRating}</span>
                                        <em>({formatDate(ratingInfo?.anticipatedRatingDate)})</em>
                                    </div>
                                )}
                            </div>
                            <div className={cn(classes.dialogContent, 'stacked')}>
                                <strong>Rating Rationale: </strong>
                                <textarea style={{ minHeight: 150, width: '100%' }} onChange={handleRationaleEntry}>
                                    {rationale}
                                </textarea>
                            </div>
                            {ratingInfo?.companyOverrideDate != null && (
                                <div className={cn(classes.dialogContent, 'end', 'emphasis')}>
                                    <span>Rationale Updated By:</span>
                                    <span>{ratingInfo?.companyOverrideByName}</span>
                                    <span>({formatDate(ratingInfo?.companyOverrideDate)})</span>
                                </div>
                            )}
                        </Dialog>
                        <Dialog
                            onOpenChange={handleConfirmClose}
                            open={showConfirm}
                            className={classes.dialog}
                            title="Update Complete"
                            description="The update saved successfully."
                            actions={<Button onClick={() => handleConfirmClose(false)}>Close</Button>}
                        >
                            {showConfirmPending ? (
                                <LoadingSpinner />
                            ) : (
                                <div className={classes.dialogContainer}>
                                    <div className={classes.dialogContent}>
                                        <strong>AB Value Rating: </strong>
                                        <span>{ratingInfo?.companyOverrideRating}</span>
                                    </div>
                                    <div className={cn(classes.dialogContent, 'stacked')}>
                                        <strong>Rationale: </strong>
                                        <div>{ratingInfo?.companyOverrideRationale}</div>
                                    </div>
                                    <div className={classes.dialogContent}>
                                        <strong>Update By: </strong>
                                        <span>
                                            {ratingInfo?.companyOverrideByName} ({formatDate(ratingInfo?.companyOverrideDate)})
                                        </span>
                                    </div>
                                </div>
                            )}
                        </Dialog>
                    </>
                )}
            </div>
        )
    );
};

export default withStyles(styles)(CompanyOverride);
