import React, { Fragment } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Tooltip from '../../../componentlibrary/tooltip/Tooltip';
import { dateFormat, formatDate } from '../../../Utils/dateHelper';
import { isNullOrEmpty } from 'Utils/stringHelper';
import { getClimateTransitionAlignmentFrameworkScore } from 'store/GridDataModule';

import './CTAlignmentFrameworkGrid.css';

// Climate Transition Aligment Framework
const CTAlignmentFramework = ({ companyID }) => {
    const dispatch = useDispatch();
    const ctafData = useSelector((state) => state.GridDataReducer.ClimateTransitionAlignmentFrameworkScore);
    const score = ctafData.Data ?? {};

    const notes = useSelector((state) => state.CompanyReducer.CommentsInfo.Boxes);
    const matchingNote = notes.find((n) => n.NoteID === score.NoteID);
    const getNoteLink = (note) => (score.NoteID > 0 ? `${note.NoteTypeName}Input/${score.CompanyID}/${score.NoteID}` : '#');

    React.useEffect(() => {
        if (companyID != null) {
            dispatch(getClimateTransitionAlignmentFrameworkScore(companyID));
        }
    }, [dispatch, companyID]);

    return !score.ScoreID ? null : (
        <div className="ctaf-wrapper">
            <table className="ctaf-table">
                <thead>
                    <tr className="super-header">
                        <th colSpan="3">
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                                    <h4 className="score-title" style={{ margin: 0 }}>
                                        Climate Transition Alignment Framework
                                    </h4>
                                    <Tooltip trigger={<i style={{ color: '#6987B9' }} className={'fas fa-info-circle blue'}></i>} side="left">
                                        <InfoTable />
                                    </Tooltip>
                                </div>
                                {matchingNote && (
                                    <a href={getNoteLink(matchingNote)} style={{ marginRight: '1em' }}>
                                        View Note
                                    </a>
                                )}
                            </div>
                        </th>
                    </tr>

                    <tr className="ctaf-header">
                        <DisplayLevel isHeader={true} score={score} />
                        {matchingNote && (
                            <th colSpan="1" key="Analyst" className="grid-label">
                                Analyst
                            </th>
                        )}
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <DisplayLevel isHeader={false} score={score} />
                        {matchingNote && (
                            <th colSpan={1} key="Analyst" className="grid-value">
                                {matchingNote.AnalystUserName ?? '-'}
                            </th>
                        )}
                    </tr>
                </tbody>
                <tfoot></tfoot>
            </table>
        </div>
    );
};

export default CTAlignmentFramework;

const data = [
    { level: 0, title: 'Awareness', description: 'Issuer lacks sufficient climate disclosure' },
    { level: 1, title: 'Aspiring', description: 'Issuer has climate disclosure but has not made a Net Zero/1.5 degree/SBTi commitment' },
    { level: 2, title: 'Ambition', description: 'Issuer has climate disclosure AND has committed to align majority of material Scope 1, 2 and 3 emissions to Net Zero/1.5/SBTi' },
    { level: 3, title: 'Aligning', description: 'Issuer discloses material Scope 1, 2 and 3 emissions, has ST or MT* reduction targets, and quantifies plans to achieve targets' },
    { level: 4, title: 'Aligned', description: 'Issuer is performing against emissions reduction targets and has a capex plan that supports its commitment' },
    { level: 5, title: 'Achieved', description: 'Emissions and business strategy is achieving NZ/1.5/SBTi' },
];

const InfoTable = () => {
    return (
        <div className="score-info">
            <div className="score-top">Level Description</div>
            <div className="score-list">
                {data.map((row, index) => (
                    <Fragment key={row.level}>
                        <div>
                            <strong>{`Level ${row.level}: ${row.title.toUpperCase()}`}</strong>
                        </div>
                        <div>
                            <span>{row.description}</span>
                        </div>
                    </Fragment>
                ))}
            </div>
        </div>
    );
};

const DisplayZeroState = ({ showAsHeaders }) => {
    if (showAsHeaders)
        return (
            <>
                <th colSpan="1" key="ALIGNMENT" className="grid-label">
                    Alignment Level
                </th>
                <th colSpan="1" key="ESTIMATED" className="grid-label">
                    Estimated Level
                </th>
                <th colSpan="1" key="DATE" className="grid-label">
                    Date
                </th>
            </>
        );

    return (
        <>
            <th colSpan="1" className="grid-value">
                -
            </th>
            <th colSpan="1" className="grid-value">
                -
            </th>
            <th colSpan="1" className="grid-value">
                -
            </th>
        </>
    );
};

const DisplayLevel = ({ isHeader, score }) => {
    const isBlank = isNullOrEmpty(score['Date']) && isNullOrEmpty(score['ManuallyAssessedLevel']) && isNullOrEmpty(score['EstimatedAssignmentLevel']);
    if (isBlank) return <DisplayZeroState showAsHeaders={isHeader} />;

    if (isHeader)
        return (
            <>
                {score['ManuallyAssessedLevel'] && (
                    <th colSpan="1" key="ALIGNMENT" className="grid-label">
                        Alignment Level
                    </th>
                )}
                {!score['ManuallyAssessedLevel'] && (
                    <th colSpan="1" key="ESTIMATED" className="grid-label">
                        Estimated Level
                    </th>
                )}
                <th colSpan="1" key="DATE" className="grid-label">
                    Date
                </th>
            </>
        );

    return (
        <>
            {score['ManuallyAssessedLevel'] && (
                <th colSpan="1" className="grid-value">
                    {score['ManuallyAssessedLevel']}
                </th>
            )}
            {!score['ManuallyAssessedLevel'] && (
                <th colSpan="1" className="grid-value">
                    {score['EstimatedAssignmentLevel']}
                </th>
            )}
            <th colSpan="1" className="grid-value">
                {formatDate(score['Date'], dateFormat)}
            </th>
        </>
    );
};
