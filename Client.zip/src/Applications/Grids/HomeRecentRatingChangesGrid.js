import React from 'react';
import { withRouter } from 'react-router-dom';
import { CollectionView } from '@grapecity/wijmo';
import { FlexGrid, FlexGridColumn } from '@grapecity/wijmo.react.grid';

import { toLocalDateTime } from 'Utils/dateHelper';

const HomeRecentRatingChangesGrid = ({ RecentRatingChangesData, onCompanyNameClick }) => {
    const getRecentRatingChangesData = () => {
        let recentRatingChangesData = RecentRatingChangesData;
        //change the data type to Date else filter in the grid doesnt work.
        if (recentRatingChangesData != null) {
            recentRatingChangesData.forEach((item) => {
                item.RatingDate = toLocalDateTime(item.RatingDate).toJSDate();
            });
        }

        let collectionView = new CollectionView(recentRatingChangesData);
        collectionView.sortConverter = function (sd, item, value) {
            if (sd.property === 'MSCIRating') {
                value = item.MSCIRatingValueWithTrend;
            }
            return value;
        };

        return collectionView;
    };

    const handleCompanyNameClick = (event, id) => {
        event.preventDefault();
        event.stopPropagation();
        if (onCompanyNameClick != null) {
            onCompanyNameClick(id);
        }
    };

    const formatItem = (s, e) => {
        if (s.rows[e.row] == null) return;

        var panel = e.panel;
        if (panel === s.cells) {
            var item = s.rows[e.row].dataItem;
            switch (s.columns[e.col].binding) {
                case 'CompanyName':
                    var a = document.createElement('a');
                    a.innerText = item.CompanyName;
                    a.href = `/CompanyAnalysis/${item.CompanyID}`;
                    a.addEventListener('click', (event) => handleCompanyNameClick(event, item.CompanyID), { once: true });

                    e.cell.innerHTML = '';
                    e.cell.appendChild(a);
                    break;

                case 'MSCIRating':
                    e.cell.innerHTML = item.MSCIRating + ' ';
                    if (String(item.IsNewlyRated) === '1') {
                        e.cell.innerHTML += "<span style='color:#DE4D39;font-weight:700;font-size:9px!important;'>New</span>";
                    } else {
                        if (item.RatingTrend < 0) {
                            e.cell.innerHTML += "<i style='color:#DE4D39;font-weight:700;' class='fa fa-long-arrow-alt-down'></i>";
                        } else if (item.RatingTrend > 0) {
                            e.cell.innerHTML += "<i style='color:#00B252;font-weight:700;' class='fa fa-long-arrow-alt-up'></i>";
                        }
                    }
                    break;
                case 'MktCapUSDMM':
                    const cellValue = e.cell.innerText;
                    e.cell.innerText = cellValue != null && cellValue !== '' ? `$${cellValue}` : '';
                    e.cell.style.textAlign = 'right';
                    e.cell.style.paddingRight = '10px';
                    break;
                default:
                    break;
            }
        }
    };

    return (
        <div data-test="data-changes-msci">
            <FlexGrid formatItem={formatItem} itemsSource={getRecentRatingChangesData()} headersVisibility="1" alternatingRowStep={1}>
                <FlexGridColumn header="Company" binding="CompanyName" width="3*" />
                <FlexGridColumn header="MSCI ESG" binding="MSCIRating" width=".8*" align="center" />
                <FlexGridColumn header="Market Cap ($M)" binding="MktCapUSDMM" width="1.25*" align="center" />
                <FlexGridColumn header="Region" binding="Region" width="*" align="left" />
                <FlexGridColumn header="Rating Date" binding="RatingDate" width="*" align="left" dataType="Date" format="MMM dd, yyyy" />
                <FlexGridColumn header="MSCIRatingValueWithTrend" binding="MSCIRatingValueWithTrend" width="*" align="left" visible={false} />
            </FlexGrid>
        </div>
    );
};

export default withRouter(HomeRecentRatingChangesGrid);
