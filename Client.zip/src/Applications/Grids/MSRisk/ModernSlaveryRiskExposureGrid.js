import React, { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { getAuthor, reverseNameOrder } from '../../KnowledgeCenter/utilities';
import { isNullOrEmpty } from 'Utils/stringHelper';

import Dialog from 'UIComponents/MaterialUI/CommonDialog';
import Icon from 'componentlibrary/icons/Icon';
import Tooltip from 'componentlibrary/tooltip/Tooltip';

import ModernSlaveryRiskExposureDialog from './ModernSlaveryRiskExposureDialog';

import { INFO_TEXT, validateRating, RISK_OPTIONS, formatRatingFieldValue } from './utils';
import { getModernSlaveryRiskExposureRating, saveModernSlaveryRiskExposureRating } from 'store/GridDataModule';
import { useCurrentUser } from 'hooks';

import { TextArea } from 'semantic-ui-react';
import './ModernSlaveryRiskExposureGrid.css';

const ModernSlaveryRiskExposureGrid = ({ companyID }) => {
    const dispatch = useDispatch();
    const analysts = useSelector((state) => state.DimensionReducer.Analysts);
    const modernSlaveryRiskExposureRating = useSelector((state) => state.GridDataReducer.ModernSlaveryRiskExposureRating);
    const currentUser = useCurrentUser();

    const rating = useMemo(() => modernSlaveryRiskExposureRating?.Data ?? {}, [modernSlaveryRiskExposureRating?.Data]);

    const [isEditing, setIsEditing] = useState(false);
    const [formErrors, setFormErrors] = useState({});
    const [showingDialog, setShowingDialog] = useState(false);
    const [changes, setChanges] = useState({});

    const initial = React.useMemo(
        () => ({
            RatingID: rating?.RatingID,
            AnalystID: rating?.AnalystID,
            OperationsRisk: rating?.OperationsRisk,
            SupplyChainRisk: rating?.SupplyChainRisk,
            Comment: rating?.Comment,
        }),
        [rating]
    );

    useEffect(() => {
        dispatch(getModernSlaveryRiskExposureRating(companyID));
    }, [companyID, dispatch]);

    useEffect(() => {
        if (rating != null) {
            setChanges(initial);
        }
    }, [initial, rating]);

    const closeDialog = () => {
        setShowingDialog(false);
    };

    const canEdit = (field, userCanWrite) => {
        // Field must be editable & user must select edit mode
        return userCanWrite && ['OperationsRisk', 'SupplyChainRisk'].includes(field);
    };

    const Validation = ({ field, formErrors }) => <>{formErrors[field] && <Icon classNames="field-warning" iconName="WARNING" />}</>;

    const buildRiskColumns = (rating) => {
        return [
            {
                field: 'OperationsRisk',
                label: 'Operations',
                colSpan: 1,
                RenderCell: ({ field, changes, canEdit, isEditing, handleChange }) => (
                    <th colSpan={1} key={field} className="grid-value">
                        <RiskEditor
                            field={field}
                            isEditing={isEditing}
                            handleChange={(value) => handleChange(field, parseInt(value))}
                            canEdit={canEdit}
                            initialValue={changes[field] ?? rating[field]}
                        />
                    </th>
                ),
            },
            {
                field: 'SupplyChainRisk',
                label: 'Supply Chain',
                colSpan: 1,
                RenderCell: ({ field, changes, canEdit, isEditing, handleChange }) => (
                    <th colSpan={1} key={field} className="grid-value">
                        <RiskEditor
                            field={field}
                            isEditing={isEditing}
                            handleChange={(value) => handleChange(field, parseInt(value))}
                            canEdit={canEdit}
                            initialValue={changes[field] ?? rating[field]}
                        />
                    </th>
                ),
            },
        ];
    };

    const validateChanges = (changedRatingFields) => {
        const validation = validateRating(changedRatingFields);
        setFormErrors(validation.errorMessages);
        return validation.isValid;
    };

    const changeCount = ['OperationsRisk', 'SupplyChainRisk', 'Comment'].reduce((acc, s) => {
        if (!changes[s]) return acc;
        return rating[s] === changes[s] ? acc : acc + 1;
    }, 0);

    const handleRatingChange = (field, value) => {
        setChanges((changes) => ({ ...changes, [field]: value }));
    };

    const handleRationaleChange = (field, value) => setChanges((changes) => ({ ...changes, [field]: value }));

    const onSaveAndValidate = () => {
        if (changeCount === 0) return;
        setShowingDialog(validateChanges(changes));
    };

    const saveAndResetForm = (companyID, rating) => {
        dispatch(saveModernSlaveryRiskExposureRating(companyID, rating));
        resetChanges();
        setShowingDialog(false);
    };

    const getRatingToSubmit = (currentUser, rating, changes) => {
        // Apply defaults in necessary
        return {
            RatingID: rating?.RatingID ?? 0,
            AnalystID: currentUser.userInfo.UserID,
            OperationsRisk: changes.OperationsRisk ?? 1,
            SupplyChainRisk: changes.SupplyChainRisk ?? 1,
            Comment: changes.Comment ?? '',
        };
    };

    const submitRatings = () => {
        saveAndResetForm(companyID, getRatingToSubmit(currentUser, rating, changes));
    };

    const riskColumns = buildRiskColumns(rating);

    const resetChanges = () => {
        setChanges(initial);
        setFormErrors({});
        setIsEditing(false);
    };

    const handleChangeRationale = (evt) => handleRationaleChange('Comment', evt.currentTarget.value);

    const RiskEditor = ({ initialValue, handleChange, isEditing, field }) => {
        const options = Object.entries(RISK_OPTIONS).map(([id, { value }]) => ({
            id,
            label: formatRatingFieldValue(field, value),
            value,
        }));

        return (
            <div>
                {isEditing ? (
                    <select value={initialValue} onChange={(e) => handleChange(parseInt(e.currentTarget.value))}>
                        {options.map(({ id, label, value }) => (
                            <option key={id} value={value}>
                                {label}
                            </option>
                        ))}
                    </select>
                ) : (
                    <div className="display-rating">
                        <span>{isNullOrEmpty(initialValue) ? '' : formatRatingFieldValue(field, initialValue)}</span>
                    </div>
                )}
            </div>
        );
    };

    const SaveRatingButton = ({ handleClick }) => {
        const getClasses = (changeCount) => `${changeCount === 0 ? 'ratings-actions-disabled' : ''}`;
        return (
            <div className={getClasses(changeCount)} onMouseDown={() => handleClick()}>
                <span>Save</span>
                <Icon classNames="ratings-actions-icon" label="Save" iconName="SAVE" size="SMALL" />
            </div>
        );
    };

    const RatingsActions = ({ changeCount, isEditing }) => (
        <div className="ratings-actions">
            {isEditing ? (
                <>
                    {changeCount > 0 && <span>{changeCount} pending change(s)</span>}
                    <SaveRatingButton handleClick={onSaveAndValidate} />
                    <div onClick={() => resetChanges()}>
                        <span>Cancel</span>
                        <Icon classNames="ratings-actions-icon" label="Clear" iconName="CLOSE" size="SMALL" />
                    </div>
                </>
            ) : (
                <>
                    {currentUser.permissions.CanWrite && (
                        <div onClick={() => setIsEditing(true)}>
                            <span>Edit Ratings</span>
                            <Icon classNames="save-ratings-icon" label="Edit" iconName="EDIT" size="SMALL" />
                        </div>
                    )}
                </>
            )}
        </div>
    );

    const RatingValidationMessages = ({ formErrors }) => {
        const errorArr = Object.keys(formErrors);
        if (errorArr.length < 1) return null;

        return (
            <Tooltip
                side="left"
                trigger={
                    <div className="field-msg">
                        <span>{errorArr.length} error(s)</span>
                        <Icon classNames="warning-info" iconName="INFO" />
                    </div>
                }
            >
                <div className="error-list">
                    {errorArr.map((fieldKey) => (
                        <span key={fieldKey}>{formErrors[fieldKey]}</span>
                    ))}
                </div>{' '}
            </Tooltip>
        );
    };

    const RatingTitle = () => (
        <Tooltip
            trigger={
                <div className="rating-title">
                    <div className="rating-trigger">
                        <strong>AB Modern Slavery Risk Exposure Rating</strong>
                        <Icon iconName="INFO" />
                    </div>
                </div>
            }
        >
            <div className="rating-title">
                <div className="rating-info-text">
                    <header>
                        <strong>Risk Scoring:</strong>
                        <span>1 = Low, 2 = Medium, 3 = High</span>
                    </header>
                    <div>
                        <span>Modern Slavery Risk Exposure:</span>
                        <p>{INFO_TEXT.TITLE}</p>
                    </div>
                </div>
            </div>
        </Tooltip>
    );
    return (
        <div className="ms-data-wrapper">
            <table className="ms-data-table">
                <thead>
                    <tr className="super-header">
                        <th colSpan="6">
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: 8 }}>
                                <RatingTitle />
                                <div className="rating-validation-msg">
                                    <RatingValidationMessages formErrors={formErrors} />
                                </div>
                                <RatingsActions changeCount={changeCount} isEditing={isEditing} />
                            </div>
                        </th>
                    </tr>

                    <tr className="rating-header">
                        <th colSpan="2" key="Rationale" className="grid-label">
                            Rationale
                            <Validation formErrors={formErrors} field="Comment" />
                        </th>
                        {riskColumns.map(({ field, label, colSpan }) => (
                            <th colSpan={colSpan} key={label} className="grid-label">
                                {label}
                                <Validation formErrors={formErrors} field={field} />
                            </th>
                        ))}
                        {rating['AnalystID'] > 0 && (
                            <th colSpan="1" key="analyst" className="grid-label">
                                Analyst
                            </th>
                        )}
                        {rating['AnalystID'] === 0 && (
                            <th colSpan="1" key="analyst" className="grid-label">
                                Team
                            </th>
                        )}
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th colSpan={2} key={'Comment'} className="grid-value grid-value-comment-field">
                            {isEditing ? (
                                <div>
                                    <TextArea disabled={false} value={changes.Comment} onChange={handleChangeRationale} placeholder="Rationale (required)" />
                                </div>
                            ) : (
                                <div className="rationale-text">
                                    {changes.Comment?.substring(0, 99)}
                                    {changes.Comment?.length > 100 && (
                                        <Tooltip trigger={<strong>...(view all)</strong>}>
                                            <div className="rationale-tooltip">
                                                <header>Rationale: </header>
                                                <p>{changes.Comment}</p>
                                            </div>
                                        </Tooltip>
                                    )}
                                </div>
                            )}
                        </th>
                        {riskColumns.map(({ field, colSpan, isHidden, RenderCell }) => {
                            return (
                                <RenderCell
                                    key={field}
                                    field={field}
                                    formErrors={formErrors}
                                    canEdit={canEdit(field, currentUser.permissions.CanWrite)}
                                    changes={changes}
                                    colSpan={colSpan}
                                    handleChange={handleRatingChange}
                                    isEditing={isEditing}
                                />
                            );
                        })}
                        {rating['AnalystID'] > 0 && (
                            <th colSpan={1} key={'AnalystID'} className="grid-value">
                                {rating['AnalystID'] ? reverseNameOrder(getAuthor(parseInt(rating['AnalystID']), analysts)) : ''}
                            </th>
                        )}
                        {rating['AnalystID'] === 0 && (
                            <th colSpan={1} key={'Team'} className="grid-value">
                                {rating['Team'] ?? ''}
                            </th>
                        )}
                    </tr>
                </tbody>
                <tfoot></tfoot>
            </table>
            <Dialog title="Confirm Rating" open={showingDialog} showActions={true} onClose={closeDialog} onConfirm={submitRatings}>
                <ModernSlaveryRiskExposureDialog submittedChanges={getRatingToSubmit(currentUser, rating, changes)} rating={initial} />
            </Dialog>
        </div>
    );
};

export default ModernSlaveryRiskExposureGrid;
