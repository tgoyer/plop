import { isNullOrEmpty } from '../../../Utils/stringHelper';

export const validateRating = rating => {
    const fieldValidationRules = {
        Comment: {
            isFieldValid: value => !isNullOrEmpty(value),
            validationMessage: 'Rationale cannot be blank'
        }
    };

    const invalidFields = Object.entries(rating)
        .filter(([key, value]) => fieldValidationRules[key] && !fieldValidationRules[key].isFieldValid(value))
        .reduce((acc, [key, value]) => ({ ...acc, [key]: fieldValidationRules[key].validationMessage }), {});

    return {
        isValid: Object.keys(invalidFields).length === 0,
        errorMessages: invalidFields
    };
};

export const INFO_TEXT = {
    TITLE: 'To assess the modern slavery risk exposure, we focus on high risk-to-people factors, including: vulnerable populations (e.g., migrant workers, minorities, linguistically diverse backgrounds), high-risk geographies (e.g., history of abuses, conflict affected zones, limited or weak judiciary), high-risk products and services (e.g., raw materials, basic services, internal services, ‘sweat’ shops), and high-risk business models (e.g., outsourcing, fraudulent recruiters, seasonal demand peaks, franchises). How companies manage these risks, is not  incorporated in this exposure score. Risk management is incorporated in our best-practice scorecard for companies. Please see FAQ and Engagement guide for further details (posted on the “Best-Practice Guides” tab). '
};

export const RISK_OPTIONS = Object.freeze({
    1: { value: 1, label: 'Low' },
    2: { value: 2, label: 'Medium' },
    3: { value: 3, label: 'High' },
});

export const formatRatingFieldValue = (field, fieldValue) => {
    if (!['OperationsRisk', 'SupplyChainRisk'].includes(field)) return fieldValue; // Only format fields with fixed options / dropdowns
    return `${RISK_OPTIONS[fieldValue].value} - ${RISK_OPTIONS[fieldValue].label}`;
};
