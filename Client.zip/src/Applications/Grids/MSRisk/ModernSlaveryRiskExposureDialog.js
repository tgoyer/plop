import React from "react";
import { isNullOrEmpty } from "Utils/stringHelper";
import { formatRatingFieldValue } from './utils'


const ModernSlaveryRiskExposureDialog = ({ submittedChanges, rating }) => {
    const getFieldValueDelta = field => {
        if (isNullOrEmpty(rating[field])) return formatRatingFieldValue(field,submittedChanges[field]); // Changes hold the default or required minimum value

        const delta = submittedChanges[field] !== rating[field];
        const fieldValue = delta ? submittedChanges[field] : (rating[field] ?? submittedChanges[field]);

        return `${delta ? formatRatingFieldValue(field, fieldValue)
            : formatRatingFieldValue(field, fieldValue) + ' (No Change)'}`;
    };

    return <div className="ms-ratings-dialog-wrapper">
        <h3>The following rating will be saved:</h3>
        <div className="ms-ratings-changes">
            <div className="ms-ratings-changes-risk">
                <div className="risk-delta">
                    <h4>Operations Risk:</h4>
                    <p>{getFieldValueDelta('OperationsRisk')}</p>
                </div>
                <div className="risk-delta">
                    <h4>Supply Chain Risk:</h4>
                    <p>{getFieldValueDelta('SupplyChainRisk')}</p>
                </div>
            </div>
            <div className="ms-ratings-changes-comment">
                <h4>Rationale:</h4>
                <p>{getFieldValueDelta('Comment')}</p>
            </div>
        </div>
    </div>
};

export default ModernSlaveryRiskExposureDialog;