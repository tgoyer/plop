import React from 'react';
import { withRouter } from 'react-router-dom';

import { CollectionView } from '@grapecity/wijmo';
import { FlexGrid, FlexGridColumn } from '@grapecity/wijmo.react.grid';
import { FlexGridFilter } from '@grapecity/wijmo.react.grid.filter';

import { toDateTime } from '../../Utils/dateHelper';

const PortfolioActionsGrid = ({ PortfolioActionsData, onCompanyNameClick }) => {
    const getPortfolioActionsData = () => {
        let portfolioData = PortfolioActionsData;
        //change the data type to Date else filter in the grid doesnt work.
        if (portfolioData != null) {
            portfolioData.forEach((item) => {
                item.PortfolioActionDate = toDateTime(item.PortfolioActionDate).toJSDate();
            });
        }

        let collectionView = new CollectionView(portfolioData);
        return collectionView;
    };

    const itemsSourceChanged = (s, e) => {
        setTimeout(() => {
            var row = s.columnHeaders.rows[0];
            row.wordWrap = true;
            s.autoSizeRow(0, true);
        });
    };

    const handleCompanyNameClick = (event, id) => {
        event.preventDefault();
        event.stopPropagation();

        if (onCompanyNameClick != null) {
            onCompanyNameClick(id);
        }
    };

    const formatRow = (s, e) => {
        if (s.rows[e.row] == null) return;

        var panel = e.panel;
        if (panel === s.cells) {
            var item = s.rows[e.row].dataItem;
            switch (s.columns[e.col].binding) {
                case 'CompanyName':
                    var a = document.createElement('a');
                    a.innerText = item.CompanyName;
                    a.href = `/CompanyAnalysis/${item.CompanyID}`;
                    a.addEventListener('click', (event) => handleCompanyNameClick(event, item.CompanyID), { once: true });
                    e.cell.innerHTML = '';
                    e.cell.appendChild(a);
                    break;
                default:
                    break;
            }
        }
    };

    return (
        <div data-test="data-changes-portfolio-actions">
            <FlexGrid
                alternatingRowStep={1}
                autoGenerateColumns={false}
                formatItem={formatRow}
                height="350px"
                headersVisibility="1"
                itemsSource={getPortfolioActionsData()}
                itemsSourceChanged={itemsSourceChanged}
            >
                <FlexGridColumn header="Company Name" binding="CompanyName" width="1.25*" />
                <FlexGridColumn header="Portfolio Date" binding="PortfolioActionDate" width="0.75*" dataType="Date" format="MMM dd, yyyy" />
                <FlexGridColumn header="Portfolio Action" binding="PortfolioAction" width="0.75*" />
                <FlexGridColumn header="User" binding="User" width="*" />
                <FlexGridColumn header="Strategies" binding="Strategies" width="1.75*" />
                <FlexGridFilter />
            </FlexGrid>
        </div>
    );
};

export default withRouter(PortfolioActionsGrid);
