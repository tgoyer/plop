import React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/SwipeableDrawer';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';

import DatePicker from 'components/Form/DatePicker';
import CommentsLayout from './NoteCards/CommentsLayout';
import EsgInfoGrids from './Grids/EsgInfoGrids';
import SubHeader from '../Layout/Header/SubHeader';
import Tooltip from '../UIComponents/Tooltip';
import { GlobalFiltersDrawerSection, ToolDrawer } from '../UIComponents/ToolDrawer';
import DeleteDialog from '../UIComponents/MaterialUI/CommonDialog';

import { setLocalSetting } from '../store/AppSettingsModule';
import { selectCompanyByID } from '../store/CompanyModule';

import { dateFormat, formatDate } from '../Utils/dateHelper';
import { getClosestParent, pxToRem, triggerEvent } from '../Utils/layoutHelper';
import { getUserWatchlistCompanyInfo, saveUserGeneralFollowUpInfo, addWatchlistCompany, removeWatchlistCompany, getUserWatchlistData, deleteUserGeneralFollowUpInfo } from '../store/UserModule';

import { isNullOrEmpty } from 'Utils/stringHelper';

const drawerWidth = 400;
const styles = (theme) => ({
    checked: {},
    commentsListBox: {
        position: 'relative',
        height: 'calc(100vh - 285px)',
        maxHeight: 'calc(100vh - 285px)',
        marginTop: 10,
    },
    content: {
        display: 'flex',
        '& > div': {
            width: 'calc(50% - 6px)',
            flexGrow: 0,
            flexShrink: 0,
        },
        '& > div + div': {
            marginLeft: 12,
        },
    },
    contentDrawerOpen: {
        width: `calc(100% - ${drawerWidth + 4}px)`,
    },
    controlLabel: {
        height: '20px !important',
        fontSize: pxToRem(13),
        marginBottom: 0,
        '& > span': {
            padding: 0,
        },
    },
    drawer: {
        display: 'none',
        flexShrink: 0,
        opacity: 0,
        width: drawerWidth,
    },
    drawerOpen: {
        display: 'block',
        opacity: 1,
    },
    drawerPaper: {
        borderRadius: 4,
        boxShadow: '0px 1px 3px 0px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14)',
        height: 'auto',
        position: 'absolute',
        margin: '20px 0',
        width: drawerWidth,
        zIndex: 'auto',
    },
    error: {
        color: 'red',
        paddingLeft: 5,
        fontSize: pxToRem(12),
    },
    filterGroup: {
        backgroundColor: theme.palette.primary.main,
        borderRadius: 18,
        color: 'white',
        cursor: 'pointer',
        display: 'inline',
        fontSize: pxToRem(12),
        padding: '2px 4px',
        marginLeft: 4,
    },
    filterGroupZeroState: {
        color: '#999',
        padding: '0 2px',
    },
    filterLabel: {
        padding: '2px 2px 0px 2px',
        fontSize: pxToRem(12),
        fontWeight: 400,
    },
    filterValue: {
        padding: '0 5px',
    },
    formControl: {
        display: 'block',
    },
    formControlContainer: {
        backgroundColor: '#fff',
        borderRadius: 4,
        boxShadow: '1px 1px 1px #ccc',
    },
    iconExclaimation: {
        color: '#f08f50',
        display: 'none',
        fontSize: 16,
        padding: 8,
    },
    iconVisible: {
        display: 'initial',
    },
    root: {
        ...theme.mixins.gutters(),
        margin: 10,
        paddingTop: 8,
        paddingBottom: 5,
        paddingRight: 5,
        paddingLeft: 5,
        fontSize: pxToRem(12),
    },
    rootCheckBox: {
        ...theme.mixins.gutters(),
        fontSize: pxToRem(12),
        color: '#52BEAD',
        '&$checked': {
            color: '#52BEAD',
            height: '20px !important',
        },
    },
    rootRadioButton: {
        ...theme.mixins.gutters(),
        fontSize: pxToRem(12),
        color: '#52BEAD',
        '&$checked': {
            color: '#52BEAD',
            height: '20px !important',
        },
    },
    reminderContainer: {
        position: 'relative',
    },
    reminderPanel: {
        position: 'absolute',
        left: 0,
        top: 36,

        display: 'block',
        background: 'white',
        borderRadius: 4,
        boxShadow: '2px 2px 4px rgba(0, 0, 0, 0.35)',
        padding: 10,
        width: 350,

        zIndex: 1000,
    },
    reminderRowActions: {
        textAlign: 'right',
        justifyContent: 'center',
        paddingTop: 10,
    },
    reminderRow: {
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'flex-start',
    },
    reminderNoFrequency: {
        marginTop: 5,
        marginLeft: 8,
    },
    reminderNote: {
        display: 'flex',
        width: '96%',
    },
    searchBox: {
        padding: '1px 1px 1px 4px',
        width: 'calc(100% - 36px)',
        fontSize: pxToRem(14),
        fontWeight: 400,
    },
    searchButton: {
        height: 27,
        lineHeight: 1.7,
        margin: 0,
        width: 36,
    },
    subHeaderButton: {
        fontWeight: 700,
        '& i': {
            paddingRight: 8,
        },
    },
    followUpControl: {
        marginLeft: 8,
    },
    followUpFormControl: {
        marginLeft: 4,
        marginTop: 4,
        padding: '6px 0 1px 0',
    },
    followUpDatePicker: {
        fontSize: 12,
        padding: 0,
        margin: 0,
        width: 170,
        'label + &': {
            padding: 0,
            margin: 0,
        },
    },
    followUpTextField: {
        fontSize: 12,
        padding: 0,
        margin: 0,
        width: 350,
        height: 40,
        'label + &': {
            padding: 0,
            margin: 0,
        },
    },
    rightGroup: {
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'center',
        '& > a': {
            marginRight: '1.5em',
            fontWeight: '600',
        },
    },
    button: {
        backgroundColor: '#6987B9',
        //boxShadow: 'none'
    },
    '@media (max-width: 990px)': {
        commentsListBox: {
            height: 'calc(50vh - 160px)',
            maxHeight: 'calc(50vh - 160px)',
            '&:after': {
                boxShadow: '0px -2px 2px rgba(0, 0, 0, 0.25)',
                content: '""',
                display: 'block',
                height: 2,
                left: 0,
                position: 'absolute',
                bottom: -2,
                width: '100%',
            },
            '&:before': {
                boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                content: '""',
                display: 'block',
                height: 2,
                left: 0,
                position: 'absolute',
                top: -2,
                width: '100%',
            },
        },
        content: {
            flexDirection: 'column',
            '& > div': {
                width: '100%',
            },
            '& > div + div': {
                marginLeft: 0,
                marginTop: 12,
            },
        },
        infoGrids: {
            height: 'calc(50vh - 160px)',
            maxHeight: 'calc(50vh - 160px)',
            overflowY: 'scroll',
        },
        recentChangesFilter: {
            marginTop: 8,
        },
    },
});

class CompanyAnalysis extends React.Component {
    state = {
        companyID: null,
        noteTypeValue: '0',
        recentPostsValue: '',
        searchText: null,
        searchTextTemp: '',
        toolDrawerOpen: false,
        notesTeam: null,
        notesSearchDate: { Start: null, End: null },
        companyWatching: false,
        companyWatchingText: 'Add to Watchlist',
        followUpDate: null,
        followUpReason: '',
        showReminder: false,
        isNotificationFrequencySet: false,
        showNoNotificatonSetIcon: false,
        showReminderDeleteConfirmation: false,
        showDeleteReminderButton: false,
    };

    constructor(props) {
        super(props);
        this.reminderPanelRef = React.createRef();
    }

    static getDerivedStateFromProps = (nextProps, prevState) => {
        const { match } = nextProps;
        const companyID = match.params.companyID != null ? match.params.companyID : null;

        return companyID != null && companyID !== prevState.companyID ? { companyID: Number(companyID) } : null;
    };

    handleReminderMouseDown = (evt) => {
        const foundTarget = (this.reminderPanelRef.current != null && this.reminderPanelRef.current.contains(evt.target)) || getClosestParent(evt.target, "[class^='MuiModal']") != null;

        if (!foundTarget && this.state.showReminder === true) {
            this.toggleReminder();
        }
    };

    async componentDidMount() {
        const { companyID } = this.props.match.params;
        const {
            history,
            Filters,
            UserInfo: { UserID },
            Selected,
            fetchAndSelectCompanyDispatcher,
            getWatchlistDataDispatcher,
        } = this.props;

        const selectedId = !isNullOrEmpty(companyID) ? companyID : !isNullOrEmpty(Selected?.CompanyID) ? Selected?.CompanyID : null;

        this.setState({ notesTeam: Filters.Team });

        if (selectedId != null) {
            try {
                await fetchAndSelectCompanyDispatcher(selectedId);
                getWatchlistDataDispatcher(UserID).then(() => {
                    const { WatchlistData } = this.props;
                    const frequencySet = WatchlistData.NotificationFrequency != null && WatchlistData.NotificationFrequency !== '' ? true : false;

                    this.setState({ isNotificationFrequencySet: frequencySet }, () => {
                        if (selectedId != null) {
                            this.fetchAndSetWatchlistCompanyInfo(UserID, selectedId);
                        }
                    });
                });
            } catch {
                history.push('/CompanyAnalysis');
            }
        }
    }

    fetchAndSetWatchlistCompanyInfo = (userID, companyID) => {
        this.props.fetchUserWatchlistCompanyInfoDispatcher(userID, companyID).then((data) => this.setWatchlistCompanyInfo(data));
    };

    setWatchlistCompanyInfo = (data) => {
        if (data != null) {
            const { IsCompanyInWatchlist, FollowUpDate, FollowUpReason } = data;
            this.setState({
                companyWatching: IsCompanyInWatchlist,
                companyWatchingText: IsCompanyInWatchlist ? 'Watching company' : 'Add to Watchlist',
                followUpDate: FollowUpDate,
                followUpReason: FollowUpReason,
                showNoNotificatonSetIcon: IsCompanyInWatchlist && !this.state.isNotificationFrequencySet,
                showDeleteReminderButton: FollowUpDate != null && FollowUpReason != null && FollowUpReason.trim() !== '',
            });
        }
    };

    componentDidUpdate = (prevProps, prevState) => {
        const { companyID } = this.state;
        const {
            UserInfo: { UserID },
        } = this.props;

        if (companyID != null && prevState.companyID !== companyID) {
            this.setState(
                {
                    companyWatching: false,
                    companyWatchingText: '',
                    followUpDate: null,
                    followUpReason: '',
                },
                () => {
                    this.props.fetchAndSelectCompanyDispatcher(companyID);
                    this.fetchAndSetWatchlistCompanyInfo(UserID, companyID);
                }
            );

            this.setState({ showNoNotificatonSetIcon: false });
        }
    };

    handleClearFilter = (type) => (event) => {
        event.stopPropagation();
        event.preventDefault();

        if (type === 'date') {
            this.handleDataFilterSave([{ name: 'date', value: { Start: null, End: null } }]);
        } else if (type === 'team') {
            this.handleDataFilterSave([{ name: 'team', value: null }]);
        }
    };

    handleDataFilterSave = (filters) => {
        const date = filters.find((filter) => filter.name === 'date');
        const team = filters.find((filter) => filter.name === 'team');

        if (date != null) {
            this.setState({ notesSearchDate: date.value });
        }
        if (team != null) {
            this.setState({ notesTeam: team.value });
            this.props.setLocalSettingDispatcher({ Team: team.value });
        }
    };

    onRecentPostsChange = (event) => {
        this.setState({ recentPostsValue: event.target.value });
    };

    refreshCards = (event) => {
        this.setState({ noteTypeValue: event.target.value });
    };

    searchTextSubmit = (event) => {
        this.setState({ searchText: this.state.searchTextTemp });
    };

    searchTextChange = (event) => {
        this.setState({ searchTextTemp: event.target.value });
    };

    toggleReminder = (event) => {
        if (event !== undefined) this.setState({ showReminder: !this.state.showReminder });
    };

    toggleToolDrawer = (event) => {
        this.setState({ toolDrawerOpen: !this.state.toolDrawerOpen }, () => {
            //TODO: Super hacky patch for weird controversy, proxy vote, and MSCI grid rendering.  Should be better investigated later.
            const nodes = [
                ...Array.prototype.slice.apply(document.querySelectorAll('#controversyProxyGrids .wj-colheaders .wj-cell.wj-header')),
                ...Array.prototype.slice.apply(document.querySelectorAll('.wj-elem-collapse')),
            ];
            nodes.forEach((node) => {
                triggerEvent(node);
                triggerEvent(node, { ctrlKey: true });
            });
        });
    };

    saveGeneralFollowUp = (event) => {
        const { followUpDate, followUpReason } = this.state;
        const {
            Selected: { CompanyID },
            UserInfo: { UserID },
        } = this.props;

        this.props
            .saveUserGeneralFollowUpInfoDispatcher(UserID, {
                UserID,
                CompanyID,
                FollowUpDate: followUpDate,
                FollowUpReason: followUpReason,
            })
            .then(() => {
                this.fetchAndSetWatchlistCompanyInfo(UserID, CompanyID);
            });
    };

    deleteGeneralFollowUp = (event) => {
        const { companyID } = this.state;
        const {
            UserInfo: { UserID },
        } = this.props;

        this.props.deleteUserGeneralFollowUpInfoDispatcher(UserID, companyID).then(() => {
            this.fetchAndSetWatchlistCompanyInfo(UserID, companyID);
            this.setState({ followUpDate: null, followUpReason: '', showReminderDeleteConfirmation: false });
        });
    };

    closeGeneralFollowUpPopUp = (event) => {
        this.toggleReminder(event);
    };

    handleDateChange = (date) => {
        this.setState({ followUpDate: date });
    };

    handleCompanyWatchingChange = (event) => {
        const {
            addWatchlistCompanyDispatcher,
            removeWatchlistCompanyDispatcher,
            UserInfo: { UserID },
            Selected: { CompanyID },
        } = this.props;

        if (!this.state.companyWatching && !this.state.isNotificationFrequencySet) {
            this.setState({ showNoNotificatonSetIcon: true });
        } else {
            this.setState({ showNoNotificatonSetIcon: false });
        }

        const promise = this.state.companyWatching ? removeWatchlistCompanyDispatcher(UserID, CompanyID) : addWatchlistCompanyDispatcher(UserID, CompanyID);

        promise.then(() => this.fetchAndSetWatchlistCompanyInfo(UserID, CompanyID));
    };

    getAddNotificationFrequencyAlert = () => {
        if (!this.state.isNotificationFrequencySet) {
            return (
                <div>
                    <span>To receive reminders, go to User Preferences and set your notification frequency.</span>
                </div>
            );
        }

        return '';
    };

    render() {
        const { Filters, classes } = this.props;
        const filterEnabled = Filters.Team != null;

        return (
            <React.Fragment>
                <SubHeader
                    left={() => (
                        <div className={classes.reminderContainer}>
                            Reminders:{' '}
                            <Button color="primary" className={classes.subHeaderButton} onClick={this.toggleReminder}>
                                {this.state.followUpDate != null ? <span>{formatDate(this.state.followUpDate)}</span> : <span>Set Reminder</span>}
                            </Button>
                            {this.state.showReminder && (
                                <div className={classes.reminderPanel} ref={this.reminderPanelRef}>
                                    <div className={classes.reminderNoFrequency}>
                                        Follow-up notifications are sent out in advance. If you set a follow-up date for the current notification period, the reminder won't be included in your
                                        notifications.
                                    </div>
                                    <div className={classes.reminderNoFrequency}>{this.getAddNotificationFrequencyAlert()}</div>

                                    <div className={classes.reminderRow}>
                                        <DatePicker
                                            className={classes.followUpControl}
                                            label="Reminder Date"
                                            value={this.state.followUpDate}
                                            onChange={this.handleDateChange}
                                            InputLabelProps={{
                                                classes: { root: classes.followUpDatePicker },
                                                className: 'required asterisk',
                                            }}
                                            disablePast={true}
                                            minDateMessage="Date should not be before today's date"
                                            InputProps={{
                                                disabled: true,
                                                disableUnderline: false,
                                            }}
                                            disabled={this.state.showDeleteReminderButton}
                                        />
                                    </div>
                                    <div className={classes.reminderRow}>
                                        <TextField
                                            name="FollowupReason"
                                            label="Reason"
                                            multiline={true}
                                            className={classes.followUpControl}
                                            InputLabelProps={{
                                                classes: { root: classes.followUpTextField },
                                                className: 'required asterisk',
                                            }}
                                            inputProps={{
                                                maxLength: 255,
                                                style: { width: 310, maxHeight: 100, height: 50 },
                                                disabled: this.state.showDeleteReminderButton,
                                            }}
                                            onChange={(event) => this.setState({ followUpReason: event.target.value })}
                                            value={this.state.followUpReason || ''}
                                        />
                                    </div>
                                    <div className={classes.reminderRowActions}>
                                        {this.state.showDeleteReminderButton && (
                                            <Button
                                                variant="contained"
                                                color="primary"
                                                onClick={() => this.setState({ showReminderDeleteConfirmation: true })}
                                                className={cn(classes.subHeaderButton, classes.followUpControl)}
                                            >
                                                Delete
                                            </Button>
                                        )}
                                        <Button
                                            variant="contained"
                                            color="primary"
                                            onClick={this.saveGeneralFollowUp}
                                            className={cn(classes.subHeaderButton, classes.followUpControl)}
                                            disabled={
                                                this.state.followUpDate == null || this.state.followUpReason == null || this.state.followUpReason.trim() === '' || this.state.showDeleteReminderButton
                                            }
                                        >
                                            Save
                                        </Button>
                                        <Button variant="contained" color="primary" onClick={this.toggleReminder} className={cn(classes.subHeaderButton, classes.followUpControl)}>
                                            Close
                                        </Button>
                                    </div>
                                    <DeleteDialog
                                        showActions={true}
                                        title="Are you sure you wish to continue?"
                                        open={this.state.showReminderDeleteConfirmation}
                                        onClose={() => this.setState({ showReminderDeleteConfirmation: false })}
                                        onConfirm={this.deleteGeneralFollowUp}
                                    >
                                        Are you sure you wish to delete this reminder?
                                    </DeleteDialog>
                                </div>
                            )}
                        </div>
                    )}
                    center={() => (
                        <div>
                            <Checkbox color="primary" checked={this.state.companyWatching} onChange={this.handleCompanyWatchingChange} />
                            <span>{this.state.companyWatchingText}</span>
                            <i
                                data-tip
                                data-for="ShowNoNotificationSet_TT"
                                style={{ cursor: 'pointer' }}
                                className={cn('fas', 'fa-exclamation-triangle', classes.iconExclaimation, {
                                    [classes.iconVisible]: this.state.showNoNotificatonSetIcon,
                                })}
                            ></i>
                            {this.state.showNoNotificatonSetIcon && (
                                <Tooltip id="ShowNoNotificationSet_TT" place="left">
                                    To receive watchlist reminders, go to User Preferences and set your notification frequency.
                                </Tooltip>
                            )}
                        </div>
                    )}
                    right={() => (
                        <div className={classes.rightGroup}>
                            <a className="ri-email" href={`mailto:ESIGHT_RIteam_help@alliancebernstein.com`}>
                                Click Here to Request ESG Research Help
                            </a>
                            <Button data-tip data-for="FilterButton_TT" color="primary" className={classes.subHeaderButton} onClick={this.toggleToolDrawer}>
                                <i
                                    className={cn('fas', {
                                        'fa-arrow-right': !this.state.toolDrawerOpen,
                                        'fa-arrow-down': this.state.toolDrawerOpen,
                                    })}
                                ></i>
                                Adv Options
                                <i
                                    className={cn('fas', 'fa-exclamation-triangle', classes.iconExclaimation, {
                                        [classes.iconVisible]: filterEnabled,
                                    })}
                                ></i>
                            </Button>
                            {filterEnabled && (
                                <Tooltip id="FilterButton_TT" place="left">
                                    A global filter is enabled on this page that may affect search results.
                                </Tooltip>
                            )}
                        </div>
                    )}
                />
                {this.state.toolDrawerOpen && (
                    <Drawer
                        className={cn(classes.drawer, { [classes.drawerOpen]: this.state.toolDrawerOpen })}
                        variant="persistent"
                        anchor="right"
                        open={this.state.toolDrawerOpen}
                        onClose={this.toggleToolDrawer}
                        onOpen={this.toggleToolDrawer}
                        classes={{ paper: classes.drawerPaper }}
                    >
                        <ToolDrawer>
                            <GlobalFiltersDrawerSection
                                onSave={this.handleDataFilterSave}
                                filterDate={this.state.notesSearchDate}
                                filterTeam={this.state.notesTeam}
                                showDateSelection={true}
                                showTeamSelection={true}
                            />
                        </ToolDrawer>
                    </Drawer>
                )}
                <div className={cn(classes.content, { [classes.contentDrawerOpen]: this.state.toolDrawerOpen })}>
                    <div>
                        <div className={classes.formControlContainer}>
                            <FormControl className={cn(classes.formControl, 'FilterBar')} component="div">
                                <ActiveFilters classes={classes} team={this.state.notesTeam} date={this.state.notesSearchDate} onClearFilter={this.handleClearFilter} />
                            </FormControl>
                        </div>
                        <div className={classes.formControlContainer} style={{ marginTop: 10 }}>
                            <FormControl className={cn('FilterBar', classes.formControl)} component="div">
                                <div style={{ margin: '5px 0 8px 0', width: '100%' }}>
                                    <input
                                        type="text"
                                        id="txtSANoteSearch"
                                        placeholder="Search Notes..."
                                        key="btnSANoteSearch"
                                        value={this.state.searchTextTemp}
                                        className={classes.searchBox}
                                        onChange={this.searchTextChange}
                                    />
                                    <button onClick={this.searchTextSubmit} className={classes.searchButton}>
                                        <i className="fa fa-search"></i>
                                    </button>
                                </div>
                                <div style={{ display: 'inline-flex', width: '100%' }}>
                                    <RadioGroup row={true} style={{ paddingLeft: 20, display: 'inline-flex' }} value={this.state.noteTypeValue} onChange={this.refreshCards}>
                                        <FormControlLabel
                                            control={
                                                <Radio
                                                    classes={{
                                                        root: classes.rootRadioButton,
                                                        checked: classes.checked,
                                                    }}
                                                />
                                            }
                                            classes={{ root: classes.controlLabel }}
                                            label="All"
                                            value="0"
                                        />
                                        <FormControlLabel
                                            control={
                                                <Radio
                                                    classes={{
                                                        root: classes.rootRadioButton,
                                                        checked: classes.checked,
                                                    }}
                                                />
                                            }
                                            classes={{ root: classes.controlLabel }}
                                            label="Research"
                                            value="1"
                                        />
                                        <FormControlLabel
                                            control={
                                                <Radio
                                                    classes={{
                                                        root: classes.rootRadioButton,
                                                        checked: classes.checked,
                                                    }}
                                                />
                                            }
                                            classes={{ root: classes.controlLabel }}
                                            label="Engagement"
                                            value="2"
                                        />
                                    </RadioGroup>
                                </div>
                            </FormControl>
                        </div>
                        <div className={classes.commentsListBox}>
                            {this.props.Selected?.CompanyID && (
                                <CommentsLayout
                                    CompanyID={this.props.Selected.CompanyID}
                                    StartDate={this.state.notesSearchDate.Start}
                                    EndDate={this.state.notesSearchDate.End}
                                    NoteTypeID={this.state.noteTypeValue}
                                    SearchText={this.state.searchText}
                                    NoteID={null}
                                    Selected={this.props.Selected}
                                    ShowCompanyInfo={false}
                                    UserInfo={this.props.UserInfo}
                                />
                            )}
                        </div>
                    </div>
                    <div>
                        <EsgInfoGrids />
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

const ActiveFilters = ({ classes, team, date, onClearFilter }) => {
    const filters = {};

    if (team != null) {
        filters['Team'] = <TeamFilter key="team" classes={classes} team={team} onClearFilter={onClearFilter} />;
    }
    if (date.Start != null && date.End != null) {
        filters['Date Range'] = <DateFilter key="daterange" classes={classes} date={date} onClearFilter={onClearFilter} />;
    }

    return (
        <React.Fragment>
            <span className={cn(classes.controlLabel, classes.filterLabel)}>
                <strong>Filters: </strong>
            </span>
            {Object.keys(filters).length > 0 ? (
                <React.Fragment>{Object.keys(filters).map((key) => filters[key])}</React.Fragment>
            ) : (
                <span className={cn(classes.controlLabel, classes.filterLabel)}>
                    <span className={cn(classes.filterGroupZeroState)}>Click the 'Adv Options' button to filter this list.</span>
                </span>
            )}
        </React.Fragment>
    );
};

const DateFilter = ({ classes, date, onClearFilter }) => {
    const end = formatDate(date.End, dateFormat);
    const start = formatDate(date.Start, dateFormat);

    return start === end ? (
        <span onClick={onClearFilter('date')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{start}</span>
        </span>
    ) : (
        <span onClick={onClearFilter('date')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{start}</span>&mdash;
            <span className={classes.filterValue}>{end}</span>
        </span>
    );
};

const TeamFilter = ({ classes, team, onClearFilter }) => {
    return (
        <span onClick={onClearFilter('team')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{team.label}</span>
        </span>
    );
};

const mapStateToProps = (state) => {
    return {
        Filters: state.AppSettingsReducer.LocalSettings.Filters,
        Selected: state.CompanyReducer.Selected.Data,
        UserInfo: state.UserReducer.UserInfo.Data,
        UserWatchlistCompanyInfo: state.UserReducer.UserWatchlistCompanyInfo,
        WatchlistData: state.UserReducer.UserWatchlistData,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        setLocalSettingDispatcher: (value) => dispatch(setLocalSetting('Filters', value)),
        fetchAndSelectCompanyDispatcher: (companyID) => dispatch(selectCompanyByID(companyID)),
        fetchUserWatchlistCompanyInfoDispatcher: (userID, companyID) => dispatch(getUserWatchlistCompanyInfo(userID, companyID)),
        saveUserGeneralFollowUpInfoDispatcher: (userID, generalFollowUpInfo) => dispatch(saveUserGeneralFollowUpInfo(userID, generalFollowUpInfo)),
        deleteUserGeneralFollowUpInfoDispatcher: (userID, companyID) => dispatch(deleteUserGeneralFollowUpInfo(userID, companyID)),
        addWatchlistCompanyDispatcher: (userID, companyID) => dispatch(addWatchlistCompany(userID, companyID)),
        removeWatchlistCompanyDispatcher: (userID, companyID) => dispatch(removeWatchlistCompany(userID, companyID)),
        getWatchlistDataDispatcher: (userID) => dispatch(getUserWatchlistData(userID)),
    };
};

export default withStyles(styles, { withTheme: true })(connect(mapStateToProps, mapDispatchToProps)(withRouter(CompanyAnalysis)));
