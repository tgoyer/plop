import React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import Collapse from '@material-ui/core/Collapse';
import CardContent from '@material-ui/core/CardContent';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import CompanyLink from '../../UIComponents/CompanyLink';
import AttachmentsList from './AttachmentsList';
import { formatDate, toLocalDateTime, timeAgo, toServerDateTime } from '../../Utils/dateHelper';
import { pxToRem } from '../../Utils/layoutHelper';
import { deleteLike, insertComment, insertLike } from '../../store/CompanyModule';
import Downloader from 'componentlibrary/file/Downloader';

const styles = (theme) => ({
    actions: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: '4px 8px',
        '& > div': {
            display: 'flex',
            flexDirection: 'row',
            gap: 16,
        },
    },
    saveCommentButton: {
        backgroundColor: theme.palette.primary.main,
        fontSize: pxToRem(18),
        padding: 8,
        minWidth: 48,
        '&:disabled': {
            backgroundColor: 'rgba(105, 135, 185, 0.2)',
            color: 'white',
        },
    },
    updatedDate: {
        fontSize: pxToRem(12),
        fontStyle: 'italic',
        textAlign: 'right',
        margin: '0 20px 10px 0',
    },
});

class CommentBoxFooter extends React.Component {
    txtNewComment = React.createRef();
    state = {
        newCommentText: '',
        showCommentsPanel: false,
        showLikesPanel: false,
        commentValid: false,
    };

    componentDidMount = () => {
        this.setState({
            showCommentsPanel: this.props.CommentInfoList != null && this.props.CommentInfoList.length > 0,
        });
    };

    //====> COMMENTS <====//
    handleCommentChange = (event) =>
        this.setState({
            newCommentText: event.target.value,
            commentValid: event.target.value != null && String(event.target.value).trim().length > 0,
        });

    handleCommentSave = async () => {
        const newComment = {
            CommentID: new Date().getTime(),
            NoteID: this.props.NoteID,
            UserID: this.props.UserInfo.UserID,
            UserName: this.props.UserInfo.FullName,
            CommentDate: toServerDateTime(new Date()).toISO(),
            Comment: this.state.newCommentText,
        };

        await this.props.insertNoteCommentDispatcher(newComment);

        this.setState(
            {
                newCommentText: '',
                commentValid: false,
            },
            () => {
                this.txtNewComment.focus();
            }
        );
    };

    toggleShowComments = () => {
        const { showCommentsPanel } = this.state;

        this.setState(
            {
                showCommentsPanel: !showCommentsPanel,
                showLikesPanel: false,
            },
            () => {
                if (this.state.showCommentsPanel) {
                    this.txtNewComment.focus();
                }
            }
        );
    };
    //====> END COMMENTS <====//

    //====> LIKES <====//
    toggleLikeClick = () => {
        const { LikeInfoList, NoteID, UserInfo } = this.props;
        const like = LikeInfoList != null && Array.isArray(LikeInfoList) ? LikeInfoList.find((likeInfo) => likeInfo.NoteID === NoteID && likeInfo.UserID === UserInfo.UserID) : null;

        const newLike = {
            NoteID: NoteID,
            UserID: UserInfo.UserID,
            UserName: UserInfo.FullName,
            LikeDate: toServerDateTime(new Date()).toISO(),
        };

        if (like == null) {
            this.props.insertNoteLikeDispatcher(newLike);
        } else {
            this.props.deleteNoteLikeDispatcher(newLike);
        }
    };

    toggleShowLikes = () => {
        const { showLikesPanel } = this.state;

        this.setState({
            showCommentsPanel: false,
            showLikesPanel: !showLikesPanel,
        });
    };
    //====> END LIKES <====//

    render() {
        const { classes, NoteID, CompanyID, EditPage, UpdatedDate } = this.props;

        return (
            <>
                <AttachmentsList noteId={NoteID} />
                <div className={classes.updatedDate}>Last updated on {UpdatedDate}</div>
                <div className="CommentBoxFooter" data-test="input-note-card-footer">
                    <div className={this.props.className}>
                        <div className={classes.actions}>
                            <div>
                                <LikesIcon likes={this.props.LikeInfoList} onClickCount={this.toggleShowLikes} onClickIcon={this.toggleLikeClick} UserID={this.props.UserInfo.UserID} />
                                <CommentsIcon comments={this.props.CommentInfoList} onClick={this.toggleShowComments} UserID={this.props.UserInfo.UserID} />
                            </div>
                            <div>
                                <Downloader useApiResource={true} uri={`/notes/${NoteID}/print`}>
                                    <i className="fas fa-print" style={{ fontSize: pxToRem(18) }}></i>
                                </Downloader>
                                <CompanyLink to={`/${EditPage}/${CompanyID}/${NoteID}`} companyID={CompanyID}>
                                    <i style={{ fontSize: pxToRem(18) }} className="fas fa-external-link-alt"></i>
                                </CompanyLink>
                            </div>
                        </div>
                    </div>
                    <Collapse in={this.state.showCommentsPanel} timeout="auto" unmountOnExit style={{ width: '100%', backgroundColor: 'white', borderBottomLeftRadius: 4, borderBottomRightRadius: 4 }}>
                        <CardContent style={{ padding: 0 }}>
                            <CommentsList comments={this.props.CommentInfoList} />
                            <div className="CommentEntry">
                                <TextField
                                    label="Add New Comment"
                                    style={{ width: 'calc(100% - 56px)', margin: '0 8px 0 0' }}
                                    margin="normal"
                                    multiline={true}
                                    InputLabelProps={{ shrink: true }}
                                    inputRef={(node) => (this.txtNewComment = node)}
                                    inputProps={{ maxLength: 2048 }}
                                    onChange={this.handleCommentChange}
                                    value={this.state.newCommentText}
                                />
                                <Button variant="contained" color="primary" disabled={!this.state.commentValid} onClick={this.handleCommentSave} className={classes.saveCommentButton}>
                                    <i className="far fa-arrow-alt-circle-right"></i>
                                </Button>
                            </div>
                        </CardContent>
                    </Collapse>
                    <Collapse in={this.state.showLikesPanel && Array.isArray(this.props.LikeInfoList) && !!this.props.LikeInfoList.length} timeout="auto" unmountOnExit>
                        <CardContent>
                            <LikesList likes={this.props.LikeInfoList} />
                        </CardContent>
                    </Collapse>
                </div>
            </>
        );
    }
}

const mapStateToProps = (state) => ({});
const mapDispatchToProps = (dispatch) => ({
    deleteNoteLikeDispatcher: (like) => dispatch(deleteLike(like)),
    insertNoteCommentDispatcher: (comment) => dispatch(insertComment(comment)),
    insertNoteLikeDispatcher: (like) => dispatch(insertLike(like)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(CommentBoxFooter)));

const CommentsIcon = (props) => {
    const { comments, onClick, UserID } = props;
    const count = Array.isArray(comments) ? comments.length : 0;
    const userCommented = Array.isArray(comments) ? comments.find((l) => l.UserID === UserID) : null;

    const countStyle = {
        backgroundColor: '#6987b9',
        borderRadius: 4,
        color: '#fff',
        display: 'inline-block',
        fontFamily: 'sans-serif',
        fontSize: pxToRem(10),
        marginLeft: 5,
        padding: '2px 6px',
    };
    const iconFamily = userCommented != null ? 'fas' : 'far';
    const iconStyle = { display: 'inline-block', color: '#6987b9', paddingRight: 5 };

    return (
        <div>
            <div onClick={onClick} style={iconStyle}>
                <i className={cn(iconFamily, 'fa-comment-alt')} style={{ fontSize: pxToRem(14), marginTop: 2 }} /> Comment
            </div>
            {count > 0 ? (
                <div onClick={onClick} style={countStyle}>
                    {count}
                </div>
            ) : null}
        </div>
    );
};

const CommentsList = (props) => {
    const { comments } = props;
    const wrapStyle = {
        overflow: 'auto',
        borderBottom: '1px solid #cfcfcf',
        maxHeight: 150,
        padding: '8px 16px 0',
        boxShadow: 'inset 0px 0px 2px 0px rgba(0, 0, 0, 0.25)',
    };

    return (
        <div style={wrapStyle}>
            {Array.isArray(comments) &&
                comments.map((comment) => {
                    const commentDate = timeAgo(toLocalDateTime(comment.CommentDate));

                    return (
                        <div className="NoteComment" key={comment.CommentID}>
                            <div className="header">
                                <strong>{comment.UserName}</strong>
                                {` (${commentDate})`}
                            </div>
                            <blockquote>{comment.Comment}</blockquote>
                        </div>
                    );
                })}
        </div>
    );
};

const LikesIcon = (props) => {
    const { likes, onClickCount, onClickIcon, UserID } = props;
    const count = Array.isArray(likes) ? likes.length : 0;
    const userLike = Array.isArray(likes) ? likes.find((l) => l.UserID === UserID) : null;

    const iconFamily = userLike != null ? 'fas' : 'far';
    const iconLabel = userLike != null ? 'Unlike' : 'Like';
    const iconStyle = { cursor: 'pointer', color: '#6987b9', width: 60 };

    return (
        <div>
            <span style={iconStyle} onClick={onClickIcon}>
                <i className={cn(iconFamily, 'fa-thumbs-up')} style={{ fontSize: pxToRem(14) }} /> {iconLabel}
            </span>
            {count > 0 ? (
                <div
                    onClick={onClickCount}
                    style={{
                        backgroundColor: '#6987b9',
                        borderRadius: 4,
                        color: '#fff',
                        display: 'inline-block',
                        fontFamily: 'sans-serif',
                        fontSize: pxToRem(10),
                        marginLeft: 5,
                        padding: '2px 6px',
                    }}
                >
                    {count}
                </div>
            ) : null}
        </div>
    );
};

const LikesList = (props) => {
    const { likes } = props;

    return (
        Array.isArray(likes) &&
        likes.map((like) => {
            const likeDate = formatDate(toLocalDateTime(like.LikeDate));

            return (
                <div style={{ fontSize: pxToRem(12), whiteSpace: 'nowrap' }} key={`${like.NoteID}-${like.UserID}`}>
                    <span style={{ display: 'inline-block', textAlign: 'right', whiteSpace: 'nowrap' }}>{likeDate}</span>
                    <b style={{ marginLeft: 8, whiteSpace: 'nowrap' }}>{like.UserName}</b>
                </div>
            );
        })
    );
};
