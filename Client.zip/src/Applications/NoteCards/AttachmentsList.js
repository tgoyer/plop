import React from 'react';
import { useSelector } from 'react-redux';

import { getFileDefinitions } from 'store/FileModule';
import Downloader from 'componentlibrary/file/Downloader';

const AttachmentsList = ({ noteId }) => {
    const allFiles = useSelector((state) => state.FileReducer.Files.Data);
    const allAttachments = useSelector((state) => state.FileReducer.NoteAttachments.Data);

    const files = allAttachments != null && allAttachments[noteId] != null ? allAttachments[noteId] : [];
    const attachments = getFileDefinitions(files, allFiles);

    return !Array.isArray(attachments) || attachments.length === 0 ? null : (
        <div className="CommentBoxBody" data-test="input-note-card-attachments">
            <div className="row" style={{ padding: '8px 12px' }}>
                <div className="col-xs-12">
                    <strong>Attachments: </strong>
                    {attachments.map((a) => {
                        const { FileName, Id } = a;
                        return (
                            <div key={Id}>
                                <Downloader useApiResource={true} uri={`/files/${Id}`}>
                                    {`${FileName}`}
                                </Downloader>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default AttachmentsList;
