import React from 'react';
import PropTypes from 'prop-types';
import _debounce from 'lodash/debounce';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import CommentBox from './CommentBox';
import LoadingPanel from '../../UIComponents/LoadingPanel';
import ErrorPanel from '../../UIComponents/ErrorPanel';

import { getCompanyByID, getNotes, selectCompany } from '../../store/CompanyModule';
import { getFileDefinitions } from '../../store/FileModule';

import { pxToRem } from '../../Utils/layoutHelper';

const styles = (theme) => ({
    root: {
        ...theme.mixins.gutters(),
        marginBottom: 12,
        paddingTop: 0,
        paddingBottom: 0,
        paddingRight: '0 !important',
        paddingLeft: '0 !important',
        fontSize: pxToRem(13),
    },
    cssFocused: {},
    cssLabel: {
        '&$cssFocused': {
            color: '#52BEAD',
        },
    },
    cssUnderline: {
        '&:after': {
            borderBottomColor: '#52BEAD',
        },
    },
    header: {
        borderBottom: '1px solid #cfcfcf',
        backgroundColor: '#f0f0f0',
        padding: '7px 10px 5px',
    },
    infiniteScroll: {
        height: '100%',
        overflowX: 'hidden',
        overflowY: 'auto',
        padding: '0 2px',
    },
    textField: {
        ...theme.mixins.gutters(),
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        border: '1px solid yellow',
        height: '80px',
    },
});

class CommentsLayout extends React.Component {
    _isMounted = false;
    state = {
        teamId: null,
        noteTypeValue: 0, //Show All
        searchText: '',
        finishedLoading: false,
        pageSize: 5,
    };

    onScroll = () => {
        const scrollPanel = this.iScrollPanel.current;
        const panelScrollHeight = scrollPanel.offsetHeight + scrollPanel.scrollTop;
        const triggerHeight = scrollPanel.scrollHeight - 100;

        if (panelScrollHeight >= triggerHeight) {
            this.loadMoreItems();
        }
    };

    iScrollPanel = React.createRef();
    debouncedScroll = _debounce(this.onScroll, 250);

    componentDidMount = async () => {
        const scrollPanel = this.iScrollPanel.current;
        const { CompanyID, StartDate, EndDate } = this.props;

        scrollPanel.addEventListener('scroll', this.debouncedScroll);
        this._isMounted = true;

        await this.props.fetchNotesDispatcher(CompanyID, StartDate, EndDate, null, null, null, 1, this.getTeamIdFilterValue(this.props));

        if (this.state._isMounted) {
            this.setState({ finishedLoading: false });
        }
    };

    componentWillUnmount() {
        this._isMounted = false;
        const scrollPanel = this.iScrollPanel.current;
        scrollPanel.removeEventListener('scroll', this.debouncedScroll, false);
    }

    componentWillReceiveProps = async (nextProps) => {
        const {
            Filters: { Team: thisTeam },
            CompanyID: thisCompanyID,
            StartDate: thisStartDate,
            EndDate: thisEndDate,
            NoteTypeID: thisNoteTypeID,
            SearchText: thisSearchText,
        } = this.props;
        const {
            Filters: { Team: nextTeam },
            CompanyID: nextCompanyID,
            StartDate: nextStartDate,
            EndDate: nextEndDate,
            NoteTypeID: nextNoteTypeID,
            SearchText: nextSearchText,
        } = nextProps;

        const teamID = thisTeam != null ? thisTeam.value : null;
        const nextTeamID = nextTeam != null ? nextTeam.value : null;
        const dateFilterValid = (nextStartDate == null && nextEndDate == null) || (nextStartDate != null && nextEndDate != null);

        if (
            thisCompanyID !== nextCompanyID ||
            (dateFilterValid && thisStartDate !== nextStartDate) ||
            (dateFilterValid && thisEndDate !== nextEndDate) ||
            thisNoteTypeID !== nextNoteTypeID ||
            thisSearchText !== nextSearchText ||
            teamID !== nextTeamID
        ) {
            await this.props.fetchNotesDispatcher(nextCompanyID, nextStartDate, nextEndDate, nextNoteTypeID, nextSearchText, null, 1, this.getTeamIdFilterValue(nextProps));
            this.setState({ finishedLoading: false });
        }

        if (this.state._isMounted) {
            this.setState({ finishedLoading: false });
        }
    };

    getTeamIdFilterValue = (props) => {
        const { Team } = props.Filters;
        return Team != null && Team.value != null ? Team.value : null;
    };

    loadMoreItems = async () => {
        let pageNumber = 1;
        let noOfBoxesLoaded = 0;

        if (this.props.CommentsInfo && this.props.CommentsInfo.pageNumber) {
            pageNumber = this.props.CommentsInfo.pageNumber + 1;
        }

        if (this.props.CommentBoxes != null) {
            noOfBoxesLoaded = this.props.CommentBoxes.length;
        }

        if (!this.state.finishedLoading) {
            await this.props.fetchNotesDispatcher(
                this.props.CompanyID,
                this.props.StartDate,
                this.props.EndDate,
                this.props.NoteTypeID,
                this.props.SearchText,
                null,
                pageNumber,
                this.getTeamIdFilterValue(this.props)
            );
            this.setState({ finishedLoading: noOfBoxesLoaded === this.props.CommentBoxes.length });
        }
    };

    displayItems = (classes) => {
        const { CommentBoxes, Attachments, Files, PortfolioActionInfo } = this.props;

        return CommentBoxes.map((noteInfo, index) => {
            const noteID = noteInfo.NoteID;
            return (
                <Paper className={classes.root} elevation={1} key={noteID}>
                    <CommentBox
                        Note={noteInfo}
                        Attachments={getFileDefinitions(Attachments[noteID], Files)}
                        ShowCompanyInfo={this.props.ShowCompanyInfo}
                        Index={index}
                        UserInfo={this.props.UserInfo}
                        PortfolioActionInfo={PortfolioActionInfo.filter((pa) => pa.NoteID === noteID)}
                    />
                </Paper>
            );
        });
    };

    displayEmptyState = (props) => {
        return props.Fetching ? <LoadingPanel /> : <ZeroState {...props} />;
    };

    render() {
        const { classes, theme, CommentBoxes, CommentsInfo } = this.props;
        return (
            <div className={classes.infiniteScroll} ref={this.iScrollPanel}>
                {CommentBoxes.length === 0 ? this.displayEmptyState(this.props) : this.displayItems(classes, theme)}
                {CommentBoxes.length >= this.state.pageSize && CommentsInfo.canLoadMore ? (
                    <div style={{ marginBottom: 10 }}>
                        <LoadingPanel />
                    </div>
                ) : null}
            </div>
        );
    }
}

CommentsLayout.propTypes = {
    classes: PropTypes.object.isRequired,
    theme: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => {
    return {
        Fetching: state.ApiReducer.Fetching,
        CompanyList: state.CompanyReducer.Selected.Data,
        CommentsInfo: state.CompanyReducer.CommentsInfo,
        CommentBoxes: state.CompanyReducer.CommentsInfo.Boxes,
        Attachments: state.FileReducer.NoteAttachments.Data,
        Files: state.FileReducer.Files.Data,
        PortfolioActionInfo: state.CompanyReducer.CommentsInfo.PortfolioActions,
        Filters: state.AppSettingsReducer.LocalSettings.Filters,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        selectCompanyDispatcher: (company) => dispatch(selectCompany(company)),
        fetchCompanyByIdDispatcher: (companyID) => dispatch(getCompanyByID(companyID)),
        fetchNotesDispatcher: (companyID, startDate, endDate, noteTypeID, searchText, noteID, pageNumber, teamID) =>
            dispatch(getNotes(companyID, startDate, endDate, noteTypeID, searchText, noteID, pageNumber, teamID)),
    };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(withStyles(styles, { withTheme: true })(CommentsLayout)));

function ZeroState(props) {
    const { CompanyID, Selected } = props;
    const companyName = Selected != null ? Selected.CompanyName : '';
    const company = CompanyID == null ? '' : ` for ${companyName}`;

    return <ErrorPanel message={`No entries were found${company}.`} />;
}
