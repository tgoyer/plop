import React, { useMemo } from 'react';
import { withStyles } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';

import CommentBoxFooter from './CommentBoxFooter';
import EngagementCommentBody from './EngagementCommentBody';
import ResearchCommentBody from './ResearchCommentBody';
import Tooltip from 'componentlibrary/tooltip/Tooltip';

import { hasEntries } from '../../Utils/arrayHelpers';
import { formatDate, toLocalDateTime, isDate } from '../../Utils/dateHelper';
import { pxToRem } from '../../Utils/layoutHelper';

const styles = (theme) => ({
    header: {
        borderBottom: '1px solid #cfcfcf',
        backgroundColor: '#e6e6e6',
        padding: '7px 10px 5px',
    },
    cardCompany: {
        backgroundColor: '#dadada',
        borderTopLeftRadius: 4,
        borderTopRightRadius: 4,
        borderBottom: '1px solid #c7c7c7',
        color: '#002463',
        fontSize: 16,
        fontWeight: 700,
        textDecoration: 'none',
        padding: '7px 10px',
        '& a:hover': {
            color: theme.palette.primary.main,
            textDecoration: 'underline',
        },
    },
    commentBoxHeaderRow: {
        display: 'flex',
        flexDirection: 'space-between',
        fontSize: pxToRem(14),
        '& > div': {
            flexGrow: 1,
            flexShrink: 1,
            flexWrap: 'nowrap',
        },
    },
    commentBoxSubHeader: {
        paddingTop: 2,
        fontSize: pxToRem(13),
    },
    commentBoxHeaderActions: {
        alignItems: 'center',
        display: 'flex',
        flexBasis: 120,
        flexWrap: 'nowrap',
        justifyContent: 'center',
        '& > *': {
            margin: `0 ${pxToRem(5)}`,
        },
    },
    commentBoxHeaderDivider: {
        color: '#000000 !important',
        padding: '0 10px',
    },
    commentBoxHeaderNameDate: {
        flexBasis: 'calc(50% - 55px)',
        justifyContent: 'left',
        '& *': {
            fontWeight: 700,
        },
        '& span': {
            color: theme.palette.primary.main,
        },
    },
    commentBoxHeaderNoteType: {
        alignItems: 'center',
        display: 'flex',
        flexBasis: 'calc(50% - 55px)',
        flexDirection: 'row',
        flexWrap: 'nowrap',
        fontWeight: 700,
        justifyContent: 'flex-end',
        margin: `0 ${pxToRem(10)} 0 ${pxToRem(15)}`,
    },
    commentFooter: {
        backgroundColor: '#f0f0f0',
        borderTop: '1px solid #cfcfcf',
        borderBottomLeftRadius: 4,
        borderBottomRightRadius: 4,
        padding: '7px 10px 5px',
    },
    portfolioActionTable: {
        border: 0,
        '& tbody td': {
            padding: '2px 6px',
            verticalAlign: 'baseline',
        },
        '& tbody td:first-child': {
            fontWeight: 'bold',
            textAlign: 'right',
        },
    },
});

const CommentBox = ({ classes, Attachments, Note, PortfolioActionInfo, ShowCompanyInfo, UserInfo }) => {
    const id = Note.NoteID;
    const displayDate = isDate(Note.DisplayDate) ? formatDate(toLocalDateTime(Note.DisplayDate)) : '';
    const portfolioActionDate = isDate(Note.PortfolioActionDate) ? formatDate(toLocalDateTime(Note.PortfolioActionDate)) : '';
    const updatedDate = isDate(Note.UpdatedDate) ? formatDate(toLocalDateTime(Note.UpdatedDate)) : '';

    const portfolioActionNameCSV = useMemo(() => {
        return hasEntries(PortfolioActionInfo)
            ? PortfolioActionInfo.sort((a, b) => (a.ProductName > b.ProductName ? 1 : -1)).map((s, i) => (
                  <div key={i} style={{ whiteSpace: 'nowrap' }}>
                      {s.ProductName}
                  </div>
              ))
            : null;
    }, [PortfolioActionInfo]);

    const showHideCompanyName = () => {
        if (ShowCompanyInfo === true) {
            return (
                <div className={classes.cardCompany} data-test="input-note-card-header">
                    <Link to={`/CompanyAnalysis/${Note.CompanyID}`}>{Note.CompanyName}</Link>
                </div>
            );
        }
    };

    const getPortfolioClassName = (action) => {
        switch (String(action).toLowerCase()) {
            case 'buy':
                return 'ESGCommentHeaderBookIcon fas fa-arrow-up';
            case 'sell':
                return 'ESGCommentHeaderBookIcon fas fa-arrow-down';
            case 'no change':
                return 'ESGCommentHeaderBookIcon fas fa-minus';
            case 'research only':
                return 'ESGCommentHeaderBookIcon fas fa-book-open';
            default:
                return '';
        }
    };

    const getEffectClassName = (action) => {
        switch (String(action).toLowerCase()) {
            case 'negative':
                return 'ESGCommentHeaderEffectIcon fas fa-minus-square';
            case 'no change':
                return 'ESGCommentHeaderEffectIcon fas fa-check-square';
            case 'positive':
                return 'ESGCommentHeaderEffectIcon fas fa-plus-square';
            default:
                return '';
        }
    };

    return (
        <div className="ESGCommentBox" data-test="input-note-card">
            {showHideCompanyName()}
            <div className={classes.header}>
                <div className={classes.commentBoxHeaderRow} data-test="input-note-card-subheader">
                    <div className={classes.commentBoxHeaderNameDate}>
                        <div>{displayDate}</div>
                        <div className={classes.commentBoxSubHeader}>
                            <span>{Note.AnalystUserName}</span>
                            <span className={classes.commentBoxHeaderDivider}>|</span>
                            <span>{Note.TeamName}</span>
                        </div>
                    </div>
                    <div className={classes.commentBoxHeaderActions}>
                        {Note.PortfolioAction != null && (
                            <Tooltip trigger={<i className={getPortfolioClassName(Note.PortfolioAction)} />}>
                                <table className={classes.portfolioActionTable}>
                                    <tbody>
                                        <tr>
                                            <td>Portfolio Action:</td>
                                            <td>{Note.PortfolioAction}</td>
                                        </tr>
                                        <tr>
                                            <td>Portfolio Date:</td>
                                            <td>{portfolioActionDate}</td>
                                        </tr>
                                        <tr>
                                            <td>Strategies:</td>
                                            <td>{portfolioActionNameCSV}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </Tooltip>
                        )}
                        {Note.Effect != null && (
                            <Tooltip trigger={<i className={getEffectClassName(Note.Effect)} />}>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b>Effect on Investment Thesis:</b>
                                            </td>
                                            <td>&nbsp;{Note.Effect}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </Tooltip>
                        )}
                        {Note.MSCIConsensusRating != null && Note.MSCIConsensusRating.indexOf('N/A') === -1 && (
                            <Tooltip trigger={<span style={{ fontWeight: 700, color: '#6987b9', fontSize: pxToRem(14) }}>{Note.MSCIConsensusRating}</span>}>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b>MSCI ESG Rating Consensus:</b>
                                            </td>
                                            <td>&nbsp;{Note.MSCIConsensusRating}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </Tooltip>
                        )}
                    </div>
                    <div className={classes.commentBoxHeaderNoteType}>
                        {Note.IsOngoing ? 'Action ' : ''}
                        {Note.NoteTypeName}
                    </div>
                </div>
            </div>
            {Note.NoteTypeName === 'Research' ? <ResearchCommentBody Comments={Note.Comments} /> : <EngagementCommentBody Note={Note} />}
            <CommentBoxFooter
                attachmentClick={Note.attachmentClick}
                className={classes.commentFooter}
                Attachments={Attachments}
                NoteID={id}
                CompanyID={Note.CompanyID}
                LikeInfoList={Note.LikeInfoList}
                CommentInfoList={Note.CommentInfoList}
                EditPage={`${Note.NoteTypeName}Input`}
                UserInfo={UserInfo}
                key={'CBFooter' + id}
                AnalystUserName={Note.AnalystUserName}
                UpdatedDate={updatedDate}
            />
        </div>
    );
};

export default withStyles(styles)(CommentBox);
