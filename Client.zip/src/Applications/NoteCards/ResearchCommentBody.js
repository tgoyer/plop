import React from 'react';
import cn from 'classnames';
import Avatar from '@material-ui/core/Avatar';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from '../../UIComponents/Tooltip';
import { generateId, pxToRem, calculateContrastColorRgb, convertCssRgbToRgb, convertRgbaToCss } from '../../Utils/layoutHelper';
import { isNullOrEmpty } from '../../Utils/stringHelper';

const styles = (theme) => ({
    body: {
        padding: '0 10px',
    },
    avatar: {
        backgroundColor: '#52BEAD',
        borderRadius: 4,
        fontSize: pxToRem(25),
        fontWeight: 700,
        height: 36,
        width: 30,
    },
    avatarEnv: {
        backgroundColor: '#60ba53',
    },
    avatarSoc: {
        backgroundColor: '#1e98d7',
    },
    avatarGov: {
        backgroundColor: '#f08f50',
    },
    avatarColumn: {
        verticalAlign: 'top',
        display: 'inline-block',
        padding: '12px 10px 0',
        width: 36,
    },
    bodyTextColumn: {
        display: 'inline-block',
        padding: '12px 0 0 12px',
        width: 'calc(100% - 60px)',
    },
    esgCommentRating: {
        color: theme.palette.primary.main,
        float: 'right',
        margin: '0 0 10px 10px',
        width: pxToRem(30),
    },
    esgCommentRatingValue: {
        backgroundColor: '#f0f0f0',
        borderRadius: 4,
        color: '#666',
        display: 'inline-block',
        fontWeight: 700,
        margin: 0,
        padding: '4px !important',
        textAlign: 'center',
        minWidth: 40,
    },
    esgCommentRatingTitle: {
        paddingRight: 5,
    },
    esgCommentText: {
        fontSize: pxToRem(13),
        paddingTop: 4,
        marginBottom: 0,

        wordBreak: 'break-all',
        'word-break': 'break-word' /* Non standard for WebKit */,
        '-ms-word-break': 'break-all',
        '-webkit-hyphens': 'auto',
        '-moz-hyphens': 'auto',
        hyphens: 'auto',
    },
});

class ResearchCommentBody extends React.Component {
    getPillarClass(esgType, classes) {
        if (esgType === 'E') {
            return classes.avatarEnv;
        } else if (esgType === 'S') {
            return classes.avatarSoc;
        }
        return classes.avatarGov;
    }

    getRatingTypeDescription(comment) {
        const { RatingTypeDescription, RatingType } = comment;
        const type = RatingType != null ? RatingType : null;
        const description = RatingTypeDescription != null ? RatingTypeDescription.split('|').map((item, i) => <div key={generateId()}>{item}</div>) : RatingTypeDescription;

        return (
            <React.Fragment>
                {type != null && (
                    <div>
                        <strong>{type}</strong>
                    </div>
                )}
                {description != null && description.length > 0 && <div style={{ paddingLeft: 15 }}>{description}</div>}
            </React.Fragment>
        );
    }

    getFixed(value, precision = 2, defaultValue = '') {
        if (isNullOrEmpty(value)) return defaultValue;
        if (isNaN(value)) return value;

        const pow = 10 ** precision;
        return (Math.round(Number(value) * pow) / pow).toFixed(precision);
    }

    render() {
        const { classes, Comments, NoteID } = this.props;
        let tooltipId = `Tooltip_RatingDescription_${NoteID}`;

        return Array.isArray(Comments)
            ? Comments.map((comment, i) => {
                  const ratingRgb = comment.ColorCode != null ? convertCssRgbToRgb(comment.ColorCode) : null;
                  const bgColor = ratingRgb != null ? convertRgbaToCss({ ...ratingRgb, a: 0.75 }) : '#e6e6e6';
                  const ratingContractRgb = ratingRgb != null ? calculateContrastColorRgb(ratingRgb.r, ratingRgb.g, ratingRgb.b) : null;
                  const foreColor = ratingContractRgb != null ? convertRgbaToCss({ ...ratingContractRgb, a: 1 }) : 'auto';

                  return (
                      <div key={i} className="CommentBoxBody" data-test="input-note-card-body">
                          <div className={classes.avatarColumn}>
                              <Avatar aria-label="ESGIcon" className={cn(classes.avatar, this.getPillarClass(comment.ESGType, classes))}>
                                  {comment.ESGType}
                              </Avatar>
                          </div>
                          <div className={classes.bodyTextColumn}>
                              <span className="ESGCategoryList">
                                  <span className={classes.esgCommentRating}>
                                      <span className={classes.esgCommentRatingTitle}>Rating:</span>
                                      <span
                                          data-tip
                                          data-for={tooltipId}
                                          className={classes.esgCommentRatingValue}
                                          style={{
                                              borderColor: bgColor,
                                              color: foreColor,
                                              backgroundColor: bgColor,
                                          }}
                                      >
                                          {this.getFixed(comment.Rating)}
                                      </span>
                                  </span>
                                  <span className={classes.esgPillars}>{comment.KeyIssues}</span>
                              </span>
                              <span className={classes.esgCommentText}>
                                  {comment.Note == null
                                      ? ''
                                      : comment.Note.split(/(\r\n|\n|\r)/gm)
                                            .reduce((arr, n) => {
                                                if (!isNullOrEmpty(n)) {
                                                    arr.push(n);
                                                }
                                                return arr;
                                            }, [])
                                            .map((n, i) => <p key={i}>{n}</p>)}
                              </span>
                          </div>
                          <Tooltip id={tooltipId}>{this.getRatingTypeDescription(comment)}</Tooltip>
                      </div>
                  );
              })
            : null;
    }
}

export default withStyles(styles)(ResearchCommentBody);
