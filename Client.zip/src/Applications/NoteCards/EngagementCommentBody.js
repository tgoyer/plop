import React from 'react';
import cn from 'classnames';
import Avatar from '@material-ui/core/Avatar';
import { withStyles } from '@material-ui/core/styles';

import { hasEntries } from '../../Utils/arrayHelpers';
import { pxToRem } from '../../Utils/layoutHelper';
import { isNullOrEmpty } from '../../Utils/stringHelper';

const colors = {
    e: '#60ba53',
    s: '#1e98d7',
    g: '#f08f50',
};

const styles = (theme) => ({
    body: {
        padding: '0 10px',
    },

    avatar: {
        backgroundColor: '#52BEAD',
        borderRadius: 4,
        height: 36,
        width: 30,
        fontSize: pxToRem(25),
        fontWeight: 700,
    },

    avatarContainer: {
        display: 'flex',
        flexDirection: 'row',
        flexGrow: 1,
        margin: '0 10px 0 0',
    },

    avatarEnv: {
        backgroundColor: colors.e,
    },
    avatarSoc: {
        backgroundColor: colors.s,
    },
    avatarGov: {
        backgroundColor: colors.g,
    },
    esgCommentText: {
        fontSize: pxToRem(13),

        wordBreak: 'break-all',
        // eslint-disable-next-line
        wordBreak: 'break-word' /* Non standard for WebKit */,
        '-ms-word-break': 'break-all',
        '-webkit-hyphens': 'auto',
        '-moz-hyphens': 'auto',
        hyphens: 'auto',
    },
    keyIssue: {
        fontWeight: 700,
    },
    keyIssueColorE: {
        color: colors.e,
        '&:after': {
            content: '", "',
        },
        '&:last-child:after': {
            content: '""',
        },
    },
    keyIssueColorS: {
        color: colors.s,
        '&:after': {
            content: '", "',
        },
        '&:last-child:after': {
            content: '""',
        },
    },
    keyIssueColorG: {
        color: colors.g,
        '&:after': {
            content: '", "',
        },
        '&:last-child:after': {
            content: '""',
        },
    },
});

class EngagementCommentBody extends React.Component {
    getAvatar = (ESGCode) => {
        const { classes } = this.props;

        const code = /^[ESG]$/gi.test(ESGCode) ? ESGCode.toUpperCase() : null;

        return code != null ? (
            <Avatar key={code} aria-label="ESGIcon" className={cn(classes.avatar, this.getColorClass(code))}>
                {code}
            </Avatar>
        ) : null;
    };

    getColorClass = (code) => {
        const { classes } = this.props;

        switch (code) {
            case 'E':
                return classes.avatarEnv;
            case 'S':
                return classes.avatarSoc;
            case 'G':
                return classes.avatarGov;
            default:
                return null;
        }
    };

    getKeyIssues = (comment) => {
        const { classes } = this.props;
        const { KeyIssues } = comment;

        const keyIssues = KeyIssues != null && KeyIssues.length > 0 ? KeyIssues.split(',').map((i) => i.trim()) : null;

        return keyIssues != null
            ? keyIssues.map((ki, i) => (
                  <span key={i} className={cn(classes.keyIssue, classes[`keyIssueColor${comment.ESGType}`])}>
                      {ki}
                  </span>
              ))
            : null;
    };

    render() {
        const { classes, Note } = this.props;
        const objectiveParagraphs = Note.EngageObjective?.split(/(\r\n|\n|\r)/gm).reduce((arr, n) => {
            if (!isNullOrEmpty(n)) {
                arr.push(n);
            }
            return arr;
        }, []);

        return (
            <div className="CommentBoxBody" data-test="input-note-card-body">
                <div className="row" style={{ padding: '8px 12px' }}>
                    <div className="col-xs-12">
                        <div className={classes.avatarContainer}>
                            {hasEntries(Note.Comments) && Note.Comments.map((c) => this.getAvatar(c.ESGType))}
                            <div style={{ display: 'inline-block', lineHeight: '15px', paddingLeft: 10 }}>{Note.Comments && Note.Comments.map((c) => this.getKeyIssues(c))}</div>
                        </div>
                    </div>
                    <div className="col-xs-12" style={{ paddingTop: 10 }}>
                        <span className="ESGCommentText">
                            <strong>Objective: </strong>
                            {objectiveParagraphs.map((n, i) => (
                                <p key={i} className={classes.esgCommentText}>
                                    {n}
                                </p>
                            ))}
                        </span>
                    </div>
                </div>
            </div>
        );
    }
}

export default withStyles(styles)(EngagementCommentBody);
