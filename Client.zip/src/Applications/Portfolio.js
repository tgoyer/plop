import React, { Fragment } from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';

import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/SwipeableDrawer';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import Workbook from 'react-excel-workbook';

import CommonDialog from '../UIComponents/MaterialUI/CommonDialog';
import DataGrid from '../UIComponents/DataGrid/DataGrid';
import ErrorPanel from '../UIComponents/ErrorPanel';
import LoadingPanel from '../UIComponents/LoadingPanel';
import PortfolioOptionsToolDrawer from './Portfolio/PortfolioOptionsToolDrawer';
import PortfolioSearch from './Portfolio/PortfolioSearch';
import SubHeader from '../Layout/Header/SubHeader';
import Tooltip from '../componentlibrary/tooltip/Tooltip';
import { FilterPanel } from '../UIComponents/DataGrid/Filters/FilterPanel';

import { setLocalSetting } from '../store/AppSettingsModule';
import { consoleLog } from '../store/LayoutModule';
import { selectAccountById, selectPortfolioByAccount } from '../store/PortfolioModule';

import { dateFormat, formatDate } from '../Utils/dateHelper';
import { generateId, pxToRem } from '../Utils/layoutHelper';
import { findIndex } from '../Utils/listHelper';
import { getExcelColumnDefinitions, getExcelData } from './Portfolio/portfolioExcel.config';
import { getGridDefinition } from './Portfolio/portfolioGrid.config';
import { isNullOrEmpty } from 'Utils/stringHelper';

const bgColors = {
    green: '#DEFFDE',
    redDark: '#E57373',
    redLight: '#FFCDD2',
};
const drawerWidth = 400;
const styles = (theme) => ({
    checked: {},
    unchecked: {
        color: theme.palette.primary.main,
        '&$checked': {
            color: theme.palette.primary.main,
        },
    },
    divider: {
        width: 1,
        height: 28,
        margin: 4,
    },
    drawer: {
        display: 'none',
        flexShrink: 0,
        opacity: 0,
        width: drawerWidth,
    },
    drawerOpen: {
        display: 'block',
        opacity: 1,
    },
    drawerPaper: {
        position: 'absolute',
        borderRadius: 4,
        boxShadow: '0px 1px 3px 0px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14)',
        height: 'calc(100vh - 142px)',
        margin: '12px 0',
        width: drawerWidth,
        zIndex: 'auto',
    },
    filterGroup: {
        backgroundColor: theme.palette.primary.main,
        borderRadius: 18,
        color: 'white',
        cursor: 'pointer',
        display: 'inline',
        fontSize: pxToRem(13),
        padding: '2px 4px',
        marginLeft: 4,
        whiteSpace: 'nowrap',
    },
    filterLabel: {
        padding: '2px 2px 0px 2px',
        fontSize: pxToRem(13),
        fontWeight: 400,
    },
    filterValue: {
        padding: '0 5px',
    },
    gridDrawerOpen: {
        width: `calc(100% - ${drawerWidth + 4}px)`,
    },
    gridPaper: {
        padding: 20,
        height: 'calc(100vh - 155px)',
        maxHeight: 'calc(100vh - 160px)',
        maxWidth: 'calc(100vw - 145px)',
    },
    gridSubHeader: {
        backgroundColor: 'rgba(255, 255, 255) !important',
        borderLeft: '#f6f6f6',
        borderRight: '#f6f6f6',
        fontSize: pxToRem(14),
        fontWeight: 700,
    },
    gridSubHeaderDivider: {
        borderLeft: '1px solid #9f9f9f !important',
    },
    iconExclamation: {
        color: '#f08f50',
        display: 'none',
        fontSize: 16,
        padding: '0 8px',
    },
    iconVisible: {
        display: 'initial',
    },
    inputBlock: {
        padding: '2px 4px',
        display: 'flex',
        alignItems: 'center',
        width: 400,
    },
    label: {
        marginRight: 10,
    },
    paragraph: {
        marginLeft: pxToRem(25),
        textIndent: pxToRem(-25),
    },
    portfolioSearch: {
        display: 'inline-block',
        width: 'calc(100% - 150px)',
        '@media (max-width: 1040px)': {
            width: 'calc(100% - 35px)',
        },
    },
    searchLabel: {
        display: 'initial',
        '@media (max-width: 1040px)': {
            display: 'none',
        },
    },
    sectionBody: {
        fontSize: pxToRem(12),
        margin: 0,
    },
    sectionContainer: {
        marginBottom: 15,
    },
    sectionHeading: {
        backgroundColor: '#eee',
        color: theme.palette.primary.main,
        cursor: 'pointer',
        fontSize: pxToRem(14),
        fontWeight: 'bold',
        margin: 0,
        '& > *': {
            display: 'inline-block',
        },
        '& > i': {
            padding: '10px 10px 10px 15px',
        },
    },
    sectionHeadingIcon: {
        transform: 'rotate(0deg)',
    },
    sectionHeadingIconRotate: {
        transform: 'rotate(90deg)',
    },
    sectionHeadingLabel: {},
    sectionHidden: {
        height: 0,
        display: 'none',
        '& > i': {
            padding: '10px 15px 15px 15px',
        },
    },
    subHeaderButton: {
        fontWeight: 700,
        padding: 0,
        minHeight: 0,
        margin: '0 8px',
        '& i': {
            padding: '0 8px',
        },
    },
    subHeaderFilter: {
        backgroundColor: 'rgba(105, 135, 185, 0.08)',
        border: `1px solid ${theme.palette.primary.main}`,
        borderRadius: 4,
        color: theme.palette.primary.main,
        fontWeight: 700,
        margin: 4,
        minHeight: 36,
        minWidth: 64,
        padding: '3px 0 4px 6px',
        whiteSpace: 'nowrap',
        '& > i': {
            backgroundColor: theme.palette.primary.main,
            color: 'rgb(238, 241, 245)',
            display: 'inline-block',
            height: '100%',
            margin: '0 0 0 5px',
            padding: 5,
        },
    },
    textField: {
        borderBottom: '1px solid black',
        margin: theme.spacing(0, 1),
        padding: theme.spacing(0, 1),
    },
    statsGrid: {
        display: 'grid',
        gridTemplateColumns: 'repeat(5, 1fr)',
        width: 'max-content',
        marginBottom: 24,
        borderTop: '1px solid #e5e5e5',
        borderLeft: '1px solid #e5e5e5',
    },
    statsGridABV: {
        gridTemplateColumns: 'repeat(6, 1fr)',
    },
    statsGridCell: {
        padding: 8,
        width: '100%',
        borderRight: '1px solid #e5e5e5',
        borderBottom: '1px solid #e5e5e5',
    },
    statsGridCellCenter: {
        textAlign: 'center',
    },
    statsGridColHeader: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: bgColors.redLight,
        fontWeight: 'bold',
    },
    statsGridRowHeader: {
        fontWeight: 'bold',
    },
});
const initialState = {
    dialog: {
        title: null,
        message: null,
        show: false,
        showButtons: false,
    },
    notesTeam: null,
    notesSearchDate: { Start: null, End: null },
    selectedRow: null,
    toolDrawerOpen: false,
};

class Portfolio extends React.PureComponent {
    animationSpeed = 500;
    tableRef = React.createRef();
    state = {
        ...initialState,
    };

    componentDidMount = () => {
        const { Filters, LocalSettings, match } = this.props;
        const accountId = match.params.accountId;
        const localSettingAccountId = LocalSettings.accountId;

        this.setState({ notesTeam: Filters.Team });
        //this.props.setLocalSettingDispatcher('Portfolio', { gridSettings: [] });

        if (accountId != null) {
            this.loadPortfolio(accountId);
        } else if (localSettingAccountId != null) {
            this.loadPortfolio(localSettingAccountId);
        }
    };

    componentDidUpdate = (prevProps) => {
        const { Portfolio } = this.props;
        const portfolioDataChanged =
            Portfolio.Data !== prevProps.Portfolio.Data || (prevProps.Portfolio.Data != null && Portfolio.Data != null && prevProps.Portfolio.Data.length !== Portfolio.Data.length);

        if (portfolioDataChanged) {
            this.props.setLocalSettingDispatcher('Portfolio', { gridFiltered: [] });
        }
    };

    loadPortfolio = async (accountId) => {
        const { Account, IsLoading, history, selectAccountByIdDispatcher, selectPortfolioDispatcher } = this.props;
        const { notesSearchDate, notesTeam } = this.state;
        accountId = accountId != null ? accountId : Account.Data != null ? Account.Data.AccountID : null;

        const teamID = notesTeam != null ? notesTeam.value : null;

        const endDate = notesSearchDate != null ? notesSearchDate.End : null;

        const startDate = notesSearchDate != null ? notesSearchDate.Start : null;

        if (!IsLoading && accountId != null) {
            this.setState({ accountId });
            history.push(`/portfolio/${accountId}`);
            await Promise.all([selectAccountByIdDispatcher(accountId), selectPortfolioDispatcher(accountId, teamID, startDate, endDate)]);
        }
    };

    getColumnDefs = () => {
        const { classes, LocalSettings, Portfolio } = this.props;
        return getGridDefinition(Portfolio.Data, [...LocalSettings.gridSettings], classes, this.onColumnExpandClick);
    };

    handleClearFilter = (type) => (event) => {
        event.stopPropagation();
        event.preventDefault();

        if (type === 'date') {
            this.onGlobalFilterSave([{ name: 'date', value: { Start: null, End: null } }]);
        } else if (type === 'team') {
            this.onGlobalFilterSave([{ name: 'team', value: null }]);
        }
    };

    handleClearOneFilter = (id, hideMenu) => () => {
        const filters = this.props.LocalSettings.gridFiltered;
        const filterList = filters.filter((filter) => filter.id !== id);

        if (filterList.length === 0) {
            hideMenu();
        }

        this.props.setLocalSettingDispatcher('Portfolio', { gridFiltered: filterList });
    };

    handleClearAllFilters = () => {
        this.props.setLocalSettingDispatcher('Portfolio', { gridFiltered: [] });
    };

    handleOnToggleFavorite = (key) => (evt) => {
        this.onToggleFavorite(key);
    };

    onAccountSearch = (account) => {
        const accountId = account.AccountID;

        this.props.setLocalSettingDispatcher('Portfolio', { accountId });
        this.loadPortfolio(accountId);
    };

    onColumnApply = (sections) => {
        const dialog = {
            title: 'Are you sure?',
            message: (
                <div>
                    <p>This configuration will be applied to the current grid view. Are you sure you want to continue?</p>
                </div>
            ),
            show: true,
            onConfirm: async () => {
                const settings = this.getColumnDefs();
                const gridSettings = sections.map((section) => {
                    const oldSetting = settings.find((s) => section.id === s.id);
                    return {
                        ...oldSetting,
                        ...section,
                        columns: section.columns.map((column) => {
                            const oldColumn = oldSetting.columns.find((c) => c.id === column.id);
                            return {
                                ...oldColumn,
                                ...column,
                            };
                        }),
                    };
                });
                await this.saveGridSettings(gridSettings);
                await this.props.setLocalSettingDispatcher('Portfolio', { loadedConfigKey: null });
                this.onDialogClose();
            },
        };

        this.setState({ dialog });
    };

    onColumnExpandClick = (sectionName) => () => {
        const gridSettings = this.getColumnDefs();

        const idx = findIndex(gridSettings, (setting) => setting.id === sectionName);
        const section = gridSettings[idx];

        const expanded = !section.expanded;
        const columns = section['columns'] != null ? section['columns'] : [];
        const hasStaticColumn = columns.findIndex((c) => c.collapsable === false) >= 0;
        section.expanded = expanded;
        section['columns'] = columns.map((column, idx) => {
            column.show = column.collapsable === false || (!hasStaticColumn && idx === 0) || expanded;
            return column;
        });
        gridSettings.splice(idx, 1, section);
        this.saveGridSettings(gridSettings);
    };

    onColumnReset = () => {
        const dialog = {
            title: 'Are you sure?',
            message: (
                <div>
                    <p>This will reset the current view to the default layout. Any unsaved customizations will be lost. Are you sure you want to continue?</p>
                    <p>Note: This will NOT effect any saved layouts.</p>
                </div>
            ),
            show: true,
            onConfirm: async () => {
                await this.props.setLocalSettingDispatcher('Portfolio', {
                    loadedConfigKey: null,
                    gridFiltered: [],
                    gridResized: [],
                    gridSort: [],
                    gridSettings: [],
                });
                this.onDialogClose();
                this.setState({ toolDrawerOpen: false });
            },
        };

        this.setState({ dialog });
    };

    onColumnResize = (resized) => {
        this.props.setLocalSettingDispatcher('Portfolio', { gridResized: resized });
    };

    onColumnSave = async (name, sections) => {
        const settings = this.getColumnDefs();
        const gridSettings = sections.map((section) => {
            const oldSetting = settings.find((s) => section.id === s.id);
            return {
                ...oldSetting,
                ...section,
                columns: section.columns.map((column) => {
                    const oldColumn = oldSetting.columns.find((c) => c.id === column.id);
                    return {
                        ...oldColumn,
                        ...column,
                    };
                }),
            };
        });

        await this.saveGridConfiguration(name, gridSettings);
        await this.saveGridSettings(gridSettings);
    };

    onColumnSort = (sorted) => {
        this.props.setLocalSettingDispatcher('Portfolio', { gridSort: sorted });
    };

    onDeleteSavedConfig = async (configKey) => {
        const { LocalSettings, setLocalSettingDispatcher } = this.props;
        const gridConfigurations = LocalSettings.gridConfigurations;

        delete gridConfigurations[configKey];
        await setLocalSettingDispatcher('Portfolio', { gridConfigurations });
    };

    onDialogClose = () => {
        this.setState(
            {
                dialog: {
                    ...this.state.dialog,
                    show: false,
                },
            },
            () => {
                setTimeout(() => {
                    this.setState({
                        dialog: {
                            ...initialState.dialog,
                            onConfirm: () => null,
                        },
                    });
                }, this.animationSpeed);
            }
        );
    };

    onToggleFavorite = async (favoriteAccount) => {
        const { Account, LocalSettings, setLocalSettingDispatcher } = this.props;
        const favoritePortfolios = LocalSettings.favoritePortfolios;
        const accountId = favoriteAccount != null ? favoriteAccount : Account.Data != null ? Account.Data.AccountID : null;

        const favorite = favoritePortfolios != null && Object.keys(favoritePortfolios).length > 0 ? favoritePortfolios[accountId] : null;

        if (favorite == null) {
            await setLocalSettingDispatcher('Portfolio', {
                favoritePortfolios: {
                    ...favoritePortfolios,
                    [accountId]: `${Account.Data.Subaccount == null ? '' : '(' + Account.Data.Subaccount + ') '} ${Account.Data.AccountName}`,
                },
            });
        } else {
            delete favoritePortfolios[accountId];
            await setLocalSettingDispatcher('Portfolio', { favoritePortfolios });
        }
    };

    onFiltered = async (filtered) => {
        await this.props.setLocalSettingDispatcher('Portfolio', {
            gridFiltered: filtered.filter((filter) => filter.value != null && filter.value.clearFilter !== true),
        });
        document.querySelector('.rt-table').scrollTop = 0;
    };

    onGlobalFilterSave = (filters) => {
        const date = filters.find((filter) => filter.name === 'date');
        const team = filters.find((filter) => filter.name === 'team');
        const doLoad = () => {
            this.setState(
                {
                    dialog: {
                        title: 'One Moment...',
                        message: 'Applying your changes.',
                        show: true,
                        showButtons: false,
                    },
                },
                () => {
                    setTimeout(async () => {
                        this.loadPortfolio();
                        this.onDialogClose();
                    }, this.animationSpeed);
                }
            );
        };

        if (date != null) {
            this.setState({ notesSearchDate: date.value });
        }
        if (team != null) {
            this.setState({ notesTeam: team.value });
            this.props.setLocalSettingDispatcher('Filters', { Team: team.value });
        }

        if (date != null) {
            if ((date.value.Start != null && date.value.End != null) || (date.value.Start == null && date.value.End == null)) {
                doLoad();
            }
        } else {
            doLoad();
        }
    };

    onLoadFavorite = (accountId) => {
        this.loadPortfolio(accountId);
    };

    onLoadSavedConfig = (key) => {
        const { LocalSettings } = this.props;
        const config = LocalSettings.gridConfigurations[key];
        const loadedConfigKey = key;
        if (config != null) {
            this.setState(
                {
                    dialog: {
                        title: 'One Moment...',
                        message: 'Applying your changes.',
                        show: true,
                        showButtons: false,
                    },
                },
                () => {
                    setTimeout(async () => {
                        const gridSettings = config.settings;
                        const table = document.querySelector('.rt-table');
                        await this.props.setLocalSettingDispatcher('Portfolio', { gridSettings, loadedConfigKey });

                        if (table != null) {
                            table.scrollTop = 0;
                        }

                        this.onDialogClose();
                    }, this.animationSpeed);
                }
            );
        }
    };

    onToolDrawerToggle = () => {
        const isOpen = !this.state.toolDrawerOpen;
        this.setState({ toolDrawerOpen: isOpen }, () => this.props.consoleLogDispatcher(this.state));
    };

    saveGridConfiguration = (name, settings) => {
        const { gridConfigurations } = this.props.LocalSettings;
        let existingKey = null;
        for (const key in gridConfigurations) {
            if (gridConfigurations[key] != null && gridConfigurations[key].name === name) {
                existingKey = key;
                break;
            }
        }
        const key = existingKey != null ? existingKey : generateId();

        return this.props.setLocalSettingDispatcher('Portfolio', {
            loadedConfigKey: key,
            gridConfigurations: {
                ...gridConfigurations,
                [key]: {
                    name: name,
                    settings: settings,
                },
            },
        });
    };

    saveGridSettings = (groups) => {
        const gridSettings =
            groups == null
                ? []
                : groups.map((g) => ({
                      id: g.id,
                      expanded: g.expanded,
                      columns:
                          g.columns == null
                              ? []
                              : g.columns.map((c) => ({
                                    id: c.id,
                                    collapsable: c.collapsable,
                                    show: c.show,
                                    hidden: c.hidden,
                                })),
                  }));

        return this.props.setLocalSettingDispatcher('Portfolio', { gridSettings });
    };

    getAccountName = (account) => {
        const sanitizedName = String(account.Data.AccountName).replace(/[/\\:*"?<>|;[\]]/g, '');
        return sanitizedName;
    };

    render() {
        const { Account, Filters, LocalSettings, Portfolio, classes } = this.props;
        const { favoritePortfolios, gridConfigurations, loadedConfigKey } = LocalSettings;
        const columnSections = this.getColumnDefs();
        const accountId = Account.Data != null ? Account.Data.AccountID : null;
        const isFavorite = favoritePortfolios[accountId] != null;
        const filterEnabled = Filters.Team != null;

        return (
            <div className="row">
                <div className={cn('col-xs-12', { [classes.gridDrawerOpen]: this.state.toolDrawerOpen })}>
                    {Portfolio.isLoading === true ? (
                        <LoadingPanel />
                    ) : Portfolio.Data === null ? (
                        <ErrorPanel message="Search for an account above." />
                    ) : Portfolio.Data.length === 0 ? (
                        <ErrorPanel message="No portfolio records were located for that account." />
                    ) : (
                        <Paper className={classes.gridPaper}>
                            <div
                                style={{
                                    height: 'calc(100% - 145px)',
                                }}
                            >
                                <ComplianceStats classes={classes} portfolio={Portfolio} />
                                <DataGrid
                                    innerRef={this.tableRef}
                                    className="-striped -highlight"
                                    columns={columnSections}
                                    defaultPageSize={Portfolio.Data.length < 20 ? 20 : Portfolio.Data.length}
                                    data={Portfolio.Data}
                                    filterable={true}
                                    getTdProps={(state, rowInfo) => {
                                        return rowInfo && rowInfo.row
                                            ? {
                                                  onClick: () => {
                                                      const idx = rowInfo.index !== this.state.selectedRow ? rowInfo.index : null;
                                                      this.setState({ selectedRow: idx });
                                                  },
                                                  style: rowInfo.index === this.state.selectedRow ? { backgroundColor: '#f9f0d2' } : {},
                                              }
                                            : {};
                                    }}
                                    onFilteredChange={this.onFiltered}
                                    onResizedChange={this.onColumnResize}
                                    onSortedChange={this.onColumnSort}
                                    filtered={LocalSettings.gridFiltered}
                                    resized={LocalSettings.gridResized}
                                    showPagination={false}
                                    sorted={LocalSettings.gridSort}
                                />
                            </div>
                        </Paper>
                    )}
                </div>
                {this.state.toolDrawerOpen && (
                    <Drawer
                        className={cn(classes.drawer, { [classes.drawerOpen]: this.state.toolDrawerOpen })}
                        variant="persistent"
                        anchor="right"
                        open={this.state.toolDrawerOpen}
                        onClose={this.onToolDrawerToggle}
                        onOpen={this.onToolDrawerToggle}
                        classes={{ paper: classes.drawerPaper }}
                    >
                        <PortfolioOptionsToolDrawer
                            columnSections={columnSections}
                            favoritePortfolios={favoritePortfolios}
                            filterDate={this.state.notesSearchDate}
                            filterTeam={this.state.notesTeam}
                            gridConfigurations={gridConfigurations}
                            loadedConfigKey={loadedConfigKey}
                            onColumnApply={this.onColumnApply}
                            onColumnReset={this.onColumnReset}
                            onColumnSave={this.onColumnSave}
                            onClose={this.onToolDrawerToggle}
                            onDeleteSavedConfig={this.onDeleteSavedConfig}
                            onExpandClick={this.onColumnExpandClick}
                            onGlobalFilterSave={this.onGlobalFilterSave}
                            onLoadFavorite={this.onLoadFavorite}
                            onLoadSavedConfig={this.onLoadSavedConfig}
                            onToggleFavorite={this.onToggleFavorite}
                            showDateSelection={true}
                            showTeamSelection={true}
                        />
                    </Drawer>
                )}
                <SubHeader
                    left={() => (
                        <div>
                            <span className={classes.searchLabel}>Search Accounts: </span>
                            <div className={classes.portfolioSearch}>
                                <PortfolioSearch account={Account.Data} isFavorite={isFavorite} onFavoriteClick={this.handleOnToggleFavorite(accountId)} onSearch={this.onAccountSearch} />
                            </div>
                        </div>
                    )}
                    center={() => (
                        <React.Fragment>
                            <FilterList filters={LocalSettings.gridFiltered} sections={columnSections} onClearOneFilter={this.handleClearOneFilter} onClearAllFilters={this.handleClearAllFilters} />
                            <ActiveFilters classes={classes} team={this.state.notesTeam} date={this.state.notesSearchDate} onClearFilter={this.handleClearFilter} />
                        </React.Fragment>
                    )}
                    right={() => (
                        <div>
                            {Account.Data === null || Portfolio.Data === null || Portfolio.Data.length === 0 ? (
                                <Button disabled={true} color="primary" className={classes.subHeaderButton}>
                                    <i className="far fa-file-excel"></i> Excel Export
                                </Button>
                            ) : (
                                <Workbook
                                    filename={`${this.getAccountName(Account)} Portfolio Export.xlsx`}
                                    element={
                                        <Button color="primary" className={classes.subHeaderButton}>
                                            <i className="far fa-file-excel"></i> Excel Export
                                        </Button>
                                    }
                                >
                                    <Workbook.Sheet
                                        data={getExcelData(this.tableRef, columnSections)}
                                        name={this.getAccountName(Account).length < 31 ? this.getAccountName(Account) : this.getAccountName(Account).substring(0, 30)}
                                    >
                                        {getExcelColumnDefinitions(columnSections).map((d) => (
                                            <Workbook.Column key={d.value} value={d.key} label={d.value} cellFormat={d.key === 'LastRsrchNoteDate' ? 'mm-dd-yyyy' : null} />
                                        ))}
                                    </Workbook.Sheet>
                                </Workbook>
                            )}
                            {filterEnabled ? (
                                <Tooltip
                                    show="left"
                                    trigger={
                                        <Button color="primary" className={classes.subHeaderButton} onClick={this.onToolDrawerToggle}>
                                            <i className={`fas ${this.state.toolDrawerOpen ? 'fa-arrow-down' : 'fa-arrow-right'}`}></i>
                                            Adv Options
                                            <i className="fas fa-exclamation-triangle"></i>
                                        </Button>
                                    }
                                >
                                    A global filter is enabled on this page that may affect search results.
                                </Tooltip>
                            ) : (
                                <Button color="primary" className={classes.subHeaderButton} onClick={this.onToolDrawerToggle}>
                                    <i className={`fas ${this.state.toolDrawerOpen ? 'fa-arrow-down' : 'fa-arrow-right'}`}></i>
                                    Adv Options
                                </Button>
                            )}
                        </div>
                    )}
                />
                <CommonDialog showActions={true} title={this.state.dialog.title} open={this.state.dialog.show} onClose={this.onDialogClose} onConfirm={this.state.dialog.onConfirm}>
                    {this.state.dialog.message}
                </CommonDialog>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        Account: state.PortfolioReducer.Account,
        Console: state.LayoutReducer.Console,
        Filters: state.AppSettingsReducer.LocalSettings.Filters,
        LocalSettings: state.AppSettingsReducer.LocalSettings.Portfolio,
        Portfolio: state.PortfolioReducer.Portfolio,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        consoleLogDispatcher: (message) => dispatch(consoleLog(message)),
        setLocalSettingDispatcher: (key, value) => dispatch(setLocalSetting(key, value)),
        selectPortfolioDispatcher: (accountId, teamID, startDate, endDate) => dispatch(selectPortfolioByAccount(accountId, teamID, startDate, endDate)),
        selectAccountByIdDispatcher: (accountId) => dispatch(selectAccountById(accountId)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles, { withTheme: true })(Portfolio));

const getColumn = (id, sections) => {
    for (let x = 0; x < sections.length; x++) {
        const section = sections[x];
        for (let y = 0; y < section.columns.length; y++) {
            const column = section.columns[y];
            if (column.id === id) {
                return {
                    ...column,
                    section: section.label,
                };
            }
        }
    }
    return null;
};

const paddedNumber = new Intl.NumberFormat('en-US', { minimumFractionDigits: 1 });

const ComplianceStats = ({ classes, portfolio }) => {
    if (isNullOrEmpty(portfolio?.Stats)) return null;

    const isAbvBB = portfolio?.Stats?.some((stat) => stat?.StaleEngagementBB != null);
    const stats = portfolio?.Stats?.map((stat) => {
        Object.keys(stat).forEach((key) => {
            if (stat == null || stat[key] == null || isNaN(stat[key])) return;
            stat[key] = paddedNumber.format(stat[key]);
        });
        return stat;
    });

    const rowHeaderClass = cn(classes.statsGridRowHeader, classes.statsGridCell);
    const colHeaderClass = cn(classes.statsGridCell, classes.statsGridCellCenter, classes.statsGridColHeader);
    const dataCellClass = cn(classes.statsGridCell, classes.statsGridCellCenter);

    return (
        <div className={cn(classes.statsGrid, { [classes.statsGridABV]: isAbvBB })}>
            <div className={colHeaderClass}>
                Compliance
                <br />
                Summary
            </div>
            <Tooltip trigger={<div className={colHeaderClass}>CCC</div>}>This is an aggregation of the CCC scored positions using the published MSCI score.</Tooltip>
            <div className={colHeaderClass}>GOV &lt;= 2</div>
            <div className={colHeaderClass}>UNGC Violator</div>
            <div className={colHeaderClass}>Stale Engagement</div>
            {isAbvBB && (
                <Tooltip
                    trigger={
                        <div className={colHeaderClass}>
                            Stale Engagement
                            <br />
                            &lt;= BB
                        </div>
                    }
                >
                    This is the aggregation of positions that are BB, B, or CCC and have stale engagements.
                </Tooltip>
            )}
            {stats.map((s, i) => (
                <Fragment key={s.SummaryID}>
                    <div className={rowHeaderClass}>{s.SummaryName}</div>
                    <div className={dataCellClass}>{s.CCC}</div>
                    <div className={dataCellClass}>{s.GovLT3}</div>
                    <div className={dataCellClass}>{s.UNGCViolator}</div>
                    <div className={dataCellClass}>{s.StaleEngagement}</div>
                    {isAbvBB && <div className={dataCellClass}>{s.StaleEngagementBB}</div>}
                </Fragment>
            ))}
        </div>
    );
};
const ActiveFilters = ({ classes, team, date, onClearFilter }) => {
    const filters = {};

    if (team != null) {
        filters['Team'] = <TeamFilter key="team" classes={classes} team={team} onClearFilter={onClearFilter} />;
    }
    if (date.Start != null && date.End != null) {
        filters['Date Range'] = <DateFilter key="daterange" classes={classes} date={date} onClearFilter={onClearFilter} />;
    }

    return Object.keys(filters).map((key) => filters[key]);
};

const DateFilter = ({ classes, date, onClearFilter }) => {
    const end = formatDate(date.End, dateFormat);
    const start = formatDate(date.Start, dateFormat);

    return start === end ? (
        <span onClick={onClearFilter('date')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{start}</span>
        </span>
    ) : (
        <span onClick={onClearFilter('date')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{start}</span>&mdash;
            <span className={classes.filterValue}>{end}</span>
        </span>
    );
};

const TeamFilter = ({ classes, team, onClearFilter }) => {
    return (
        <span onClick={onClearFilter('team')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{team.label}</span>
        </span>
    );
};

const filterListStyles = (theme) => ({
    container: {
        display: 'inline-block',
        justifySelf: 'center',
        margin: '0 5px',
        '& button': {
            minHeight: 0,
            padding: 0,
        },
    },
    filterButton: {
        display: 'inline-block',
    },
    filterListItem: {
        padding: '8px 12px',
        '& > i': {
            color: theme.palette.primary.main,
            marginRight: 8,
            paddingRight: 4,
        },
    },
});

const FilterListBase = ({ classes, filters, sections, onClearOneFilter, onClearAllFilters }) => {
    const columns = filters != null ? filters.map((filter) => getColumn(filter.id, sections)) : [];

    return sections.length !== 0 ? (
        <div className={classes.container}>
            <FilterPanel label={'Column Filters (' + columns.length + ')'} show={columns.length > 0} subheader="Click a filter to remove" onClear={onClearAllFilters}>
                {(hideMenu) =>
                    columns.map((column) => {
                        return (
                            <MenuItem key={column.accessor} className={classes.filterListItem} onClick={onClearOneFilter(column.id, hideMenu)}>
                                <i className="far fa-trash-alt"></i>
                                {`${column.section}: ${column.label}`}
                            </MenuItem>
                        );
                    })
                }
            </FilterPanel>
        </div>
    ) : null;
};
const FilterList = withStyles(filterListStyles, { withTheme: true })(FilterListBase);
