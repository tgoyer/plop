import React from 'react';
import Paper from '@material-ui/core/Paper';
import cn from 'classnames';
import { connect } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import { pxToRem } from '../Utils/layoutHelper';
import { sort } from '../Utils/listHelper';

const styles = (theme) => ({
    cell: {
        padding: 8,
    },
    email: {
        marginLeft: 8,
    },
    gray: {
        backgroundColor: '#f3f3f3',
    },
    grid: {
        border: 'none',
        borderCollapse: 'collapse',
        margin: 0,
        padding: 0,
        width: '100%',
    },
    header: {
        borderRadius: '4px 4px 0 0',
        fontSize: pxToRem(16),
        fontWeight: 700,
        height: 'auto',
        letterSpacing: 1,
        margin: 0,
        padding: '8px 16px',
        backgroundColor: theme.palette.primary.main,
        width: '100%',
    },
    headerRow: {
        backgroundColor: '#ffffff',
        borderBottom: '2px solid #bdd7ff',
        fontSize: pxToRem(16),
        fontWeight: 700,
        margin: 0,
        padding: 0,
    },
    paper: {
        ...theme.mixins.gutters(),
        padding: '0 !important',
        margin: 10,
        fontSize: pxToRem(12),
    },
    tbody: {
        margin: 0,
    },
});

const Contacts = (props) => {
    const { Contacts, classes } = props;
    const contacts = Contacts != null ? Contacts.sort(sort('team')) : [];

    return (
        <div className="row">
            <div className="col-xs-12 col-lg-6">
                <Paper className={classes.paper} elevation={1}>
                    <legend className={classes.header}>Team Contacts</legend>
                    <div className={classes.grid}>
                        <div className={cn('row', classes.headerRow)}>
                            <div className={cn('col-xs-6', classes.cell)}>Team</div>
                            <div className={cn('col-xs-6', classes.cell)}>Contact</div>
                        </div>
                        {contacts.map((contact, idx) => (
                            <div key={idx} className={cn('row', classes.tbody, { [classes.gray]: idx % 2 === 0 })}>
                                <div className={cn('col-xs-6', classes.cell)}>{contact.team}</div>
                                <div className={cn('col-xs-6', classes.cell)}>
                                    {contact.contacts != null &&
                                        contact.contacts.map((user, i) => [
                                            i > 0 && ', ',
                                            <a key={i} className={classes.email} href={`mailto:${user.email}`}>
                                                {user.user}
                                            </a>,
                                        ])}
                                </div>
                            </div>
                        ))}
                    </div>
                </Paper>
            </div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        Contacts: state.ContactsReducer.Contacts.Data,
    };
};

export default connect(mapStateToProps)(withStyles(styles, { withTheme: true })(Contacts));
