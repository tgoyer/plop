import React from 'react';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    horizontalSections: { 
        float: 'left',
        margin: '0 10px',
        width: 'calc(50% - 30px)', 
    },
    paper: {
        padding: 10,
        marginBottom: 10
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '5px 0px 5px 20px',
        padding: 5,
        width: '33%'
    },
    sectionHeaderLabel: {
        cursor: 'pointer',
    },
});

const Preferences = (props) => {
    const { classes } = props;
    
    return (
        <React.Fragment>
            <div className={classes.horizontalSections}>
                <Paper elevation={1} className={classes.paper}>
                    <div className={classes.sectionHeader}>
                        <span className={classes.sectionHeaderLabel}>Another Setting Block</span>
                    </div>
                    <div>
                        <ul>
                            <li>Option 1</li>
                            <li>Option 2</li>
                            <li>Option 3</li>
                        </ul>                        
                    </div>
                </Paper>
                <Paper elevation={1} className={classes.paper}>
                    <div className={classes.sectionHeader}>
                        <span className={classes.sectionHeaderLabel}>Another Setting Block</span>
                    </div>
                    <div>
                        <ul>
                            <li>Option 1</li>
                            <li>Option 2</li>
                            <li>Option 3</li>
                        </ul>                        
                    </div>
                </Paper>
            </div>
        </React.Fragment>
    )
}

export default withStyles(styles)(Preferences);


