import React from 'react';
import { useParams } from 'react-router-dom';

import Survey from './CalendarSurvey/Survey';
import SurveyList from './CalendarSurvey/SurveyList';

const CalendarSurvey = () => {
    const { moduleID } = useParams();

    return moduleID != null ? <Survey surveyID={moduleID} /> : <SurveyList />;
};

export default CalendarSurvey;
