import React from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import { Card, Icon } from 'semantic-ui-react';

import { getUserSurveys } from 'store/UserModule';

import { formatDateTime } from 'Utils/dateHelper';

const styles = (theme) => ({
    card: {
        maxWidth: 1000,
    },
    table: {
        border: 0,
        borderCollapse: 'collapse',
        '& th': {
            padding: 4,
        },
        '& td': {
            padding: 5,
        },
        '& thead': {
            display: 'table',
            width: 'calc(100% - 16px)',
            tableLayout: 'fixed',
        },
        '& tbody': {
            maxHeight: 200,
            display: 'block',
            overflowY: 'scroll',
        },
        '& thead tr': {
            backgroundColor: '#f7f7f7',
            borderBottom: '1px solid #bdd7ff',
            fontWeight: 700,
            width: '100%',
            '& th:nth-child(1)': {
                textAlign: 'center',
                width: 65,
            },
            '& th:nth-child(2)': {
                width: '100%',
            },
            '& th:nth-child(3)': {
                textAlign: 'center',
                width: 100,
            },
            '& th:nth-child(4)': {
                width: 175,
            },
            '& th:nth-child(5)': {
                width: 175,
            },
        },
        '& tbody tr': {
            width: '100%',
            tableLayout: 'fixed',
            borderBottom: '1px solid #eee',
            display: 'table',
            '& td i': {
                fontSize: 16,
                color: '#6987B9',
                '&.fa-link': {
                    fontSize: 14,
                    paddingLeft: 8,
                },
            },
            '& td': {
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
            },
            '& td:nth-child(1)': {
                textAlign: 'center',
                width: 65,
            },
            '& td:nth-child(2)': {
                width: '100%',
            },
            '& td:nth-child(3)': {
                textAlign: 'center',
                width: 100,
            },
            '& td:nth-child(4)': {
                width: 175,
            },
            '& td:nth-child(5)': {
                width: 175,
            },
            '&:last-child': {
                borderBottom: 'none',
            },
        },
    },
    zeroStateContainer: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        margin: '75px 0',
        '& svg': {
            margin: 20,
        },
        '& h4': {
            fontWeight: 700,
            paddingTop: 30,
            paddingBottom: 10,
        },
    },
});

const SurveyList = ({ classes }) => {
    const dispatch = useDispatch();
    const surveys = useSelector((state) => state.UserReducer.Surveys?.Data);
    const isLoaded = useSelector((state) => state.UserReducer.Surveys?.isLoaded);

    React.useEffect(() => {
        dispatch(getUserSurveys('me'));
    }, [dispatch]);

    return !isLoaded ? null : (
        <div className={classes.card}>
            <Card fluid={true} raised={true}>
                {isLoaded && surveys.length === 0 ? (
                    <div className={classes.zeroStateContainer}>
                        <Icon color="blue" name="check circle" size="massive" />
                        <h4>You Have No Surveys</h4>
                        <div>There are no company meeting surveys for you to complete at this time.</div>
                    </div>
                ) : (
                    <>
                        <Card.Content>
                            <Card.Header>Assigned Meeting Surveys</Card.Header>
                        </Card.Content>
                        <Card.Content>
                            <table className={classes.table}>
                                <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>Company Name</th>
                                        <th>Is Host</th>
                                        <th>Meeting Date</th>
                                        <th>Completed Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {surveys.map((survey) => (
                                        <tr key={survey.SurveyID}>
                                            <td>
                                                {survey.CompletedDate != null ? (
                                                    <Icon color="green" name="check circle outline" />
                                                ) : (
                                                    <Icon color="red" name="arrow alternate circle right outline" />
                                                )}
                                            </td>
                                            <td>
                                                <Link to={`/Preferences/CalendarSurvey/${survey.SurveyID}`}>{survey.CompanyName}</Link>
                                            </td>
                                            <td>{survey.IsHost === true && <Icon color="green" name="checkmark" />}</td>
                                            <td>{formatDateTime(new Date(survey.MeetingDate))}</td>
                                            <td>{survey.CompletedDate == null ? null : formatDateTime(new Date(survey.CompletedDate))}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </Card.Content>
                    </>
                )}
            </Card>
        </div>
    );
};

export default withStyles(styles)(SurveyList);
