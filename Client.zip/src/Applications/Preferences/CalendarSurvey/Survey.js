import React from 'react';
import { useHistory, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import { Button, Card, Checkbox, Form, Header, Icon, Menu, Modal, Popup, Radio, TextArea } from 'semantic-ui-react';

import { pxToRem } from 'Utils/layoutHelper';

import { getCompanySurvey, saveCompanySurvey } from 'store/CompanyModule';
import { formatDate } from 'Utils/dateHelper';
import { sortList } from 'Utils/listHelper';

const styles = (theme) => ({
    card: {
        maxWidth: 1000,
    },
    dropdown: {
        margin: '0px !important',
        '& .divider': {
            margin: '4px !important',
        },
    },
    errors: {
        display: 'inline-flex',
        flexDirection: 'column',
        background: '#ffe5e5',
        border: '2px solid #900',
        color: '#900',
        margin: 10,
        padding: 10,
        '& ul': {
            margin: 0,
            padding: 0,
        },
        '& li': {
            margin: '0 20px',
            padding: 0,
        },
        '& li + li': {
            marginTop: 10,
        },
    },
    errorTitle: {
        fontSize: pxToRem(14),
        fontWeight: 700,
    },
    formField: {
        marginLeft: 20,
        '& div.radio, & div.checkbox': {
            margin: '0px !important',
            marginTop: '3px !important',
        },
        '& div.checkbox': {
            '& input~label:before': {
                borderColor: '#2185d0 !important',
            },
            '& input:checked~label:before': {
                background: '#2185d0 !important',
                borderColor: '#2185d0 !important',
            },
            '& input:checked~label:after': {
                color: '#ffffff !important',
            },
        },
        '& div.radio': {
            '& input~label:before': {
                borderColor: '#2185d0 !important',
            },
            '& input:checked~label:before': {
                backgroundColor: '#2185d0 !important',
                borderColor: '#2185d0 !important',
            },
            '& input:checked~label:after': {
                backgroundColor: '#ffffff !important',
                color: '#ffffff !important',
            },
        },
    },
    groups: {
        padding: 10,
        '& div.fields + div.fields': {
            marginTop: '20px !important',
        },
    },
    header: {
        display: 'inline-block',
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 4,
        '& .subheader': {
            display: 'inline-block',
            color: '#767676',
            fontSize: 12,
            fontWeight: 700,
            marginLeft: 8,
        },
    },
    model: {
        bottom: 'auto',
        left: 'auto',
        right: 'auto',
        top: 'auto',
        fontWeight: 700,
    },
    zeroStateContainer: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        margin: '75px 0',
        '& svg': {
            margin: 20,
        },
        '& h4': {
            fontWeight: 700,
            paddingTop: 30,
            paddingBottom: 10,
        },
    },
});

const DeclineReasons = {
    DidNotAttend: 'Did Not Attend',
    MeetingCanceled: 'Meeting Canceled',
    Duplicate: 'Duplicate Meeting Survey',
    Other: 'Other',
};
const StatusCodes = {
    DECLINED: 'D',
    INITIAL: 'I',
    UPDATED: 'U',
};

const Survey = ({ classes, surveyID }) => {
    const dispatch = useDispatch();
    const history = useHistory();

    const [survey, setSurvey] = React.useState(null);
    const [errors, setErrors] = React.useState([]);

    const [isSaving, setIsSaving] = React.useState(false);
    const [showAlert, setShowAlert] = React.useState(false);
    const [useDeclinedForm, setUseDeclinedForm] = React.useState(false);
    const [useEsgForm, setUseEsgForm] = React.useState(false);

    const analysts = useSelector((state) => state.DimensionReducer.Analysts);
    const surveyData = useSelector((state) => state.CompanyReducer.Survey.Data);
    const userID = useSelector((state) => state.UserReducer?.UserInfo?.Data?.UserID);

    const handleCheckboxChange = (e, { name, checked }) => {
        updateSurvey(name, checked);
    };
    const handleDeclineReasonChange = (e, { value }) => {
        const found = Object.keys(DeclineReasons).some((key) => key === value);

        updateSurvey('IsEnvironmental', false);
        updateSurvey('IsSocial', false);
        updateSurvey('IsGovernance', false);
        updateSurvey('IsSubstantive', false);
        updateSurvey('Status', 'D');
        updateSurvey('DeclineReasonKey', value);
        updateSurvey('StatusMessage', found && value !== 'Other' ? DeclineReasons[value] : '');
    };
    const handleDelegateClick = (id) => () => {
        updateSurvey('DelegatedAnalystID', id);
    };
    const handleEnableEsg = (value) => () => {
        setErrors([]);
        setUseEsgForm(value === 'yes');
        setUseDeclinedForm(value === 'declined');

        updateSurvey('DeclineReasonKey', null);
        updateSurvey('IsEnvironmental', false);
        updateSurvey('IsSocial', false);
        updateSurvey('IsGovernance', false);
        updateSurvey('IsSubstantive', false);
        updateSurvey('DelegatedAnalystID', userID === survey.HostID ? survey.HostID : survey.DelegatedAnalystID);
        updateSurvey('Status', 'U');
        updateSurvey('StatusMessage', '');
    };
    const handleIsSubstantiveChange = (value) => () => {
        updateSurvey('IsSubstantive', value);
        if (!value) {
            updateSurvey('DelegatedAnalystID', userID === survey.HostID ? survey.HostID : survey.DelegatedAnalystID);
        }
    };
    const handleOtherReasonChange = (evt) => {
        updateSurvey('StatusMessage', evt.target.value);
    };
    const handleShowAlertClose = () => {
        setShowAlert(false);
        if (isHost && survey?.IsSubstantive && userID === survey?.DelegatedAnalystID && survey?.NoteID == null) {
            history.push({
                pathname: `/EngagementInput/${survey.CompanyID}`,
                search: `?meetingID=${survey.CalendarMeetingID}`,
                state: { redirect: '/Preferences/CalendarSurvey' },
            });
        } else {
            history.push(`/Preferences/CalendarSurvey`);
        }
    };
    const handleSubmit = () => {
        const data = { ...survey };

        data.Status = useDeclinedForm ? StatusCodes.DECLINED : StatusCodes.UPDATED;

        if (validate()) {
            setIsSaving(true);
            dispatch(saveCompanySurvey(survey))
                .then(() => {
                    setIsSaving(false);
                    setShowAlert(true);
                })
                .catch(() => setIsSaving(false));
        }
    };
    const updateSurvey = (key, value) => {
        setSurvey((survey) => ({
            ...survey,
            [key]: value,
        }));
    };
    const validate = () => {
        const errors = [];

        if (useDeclinedForm) {
            if (survey?.StatusMessage == null || survey?.StatusMessage === '') {
                errors['StatusMessage'] = 'A reason must be entered for why this survey is not applicable.';
            }
        }

        if (useEsgForm && !hasEsg) {
            errors['ESG'] = 'If yes is selected, you must pick one or more ESG categories.';
        }

        setErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const attendees = React.useMemo(() => {
        var list = surveyData?.Attendees?.reduce((acc, attendee) => {
            const analyst = analysts.find((a) => attendee.AnalystID === a.UserID);
            if (analyst != null && analyst.Permissions?.CanWrite) {
                acc.push(analyst);
            }
            return acc;
        }, []);

        return sortList(list, 'FullName');
    }, [surveyData, analysts]);

    const delegateAttendee = React.useMemo(() => {
        return Array.isArray(analysts) && survey?.DelegatedAnalystID != null ? analysts.find((analyst) => analyst.UserID === survey?.DelegatedAnalystID) : null;
    }, [survey, analysts]);
    const meetingDate = React.useMemo(() => (surveyData?.Survey?.MeetingDate != null ? formatDate(new Date(surveyData?.Survey.MeetingDate)) : null), [
        surveyData,
    ]);
    const hasEsg = React.useMemo(() => {
        return Boolean(survey?.IsEnvironmental) || Boolean(survey?.IsSocial) || Boolean(survey?.IsGovernance);
    }, [survey]);
    const isHost = React.useMemo(() => {
        return userID === survey?.HostID;
    }, [survey, userID]);
    const enabledOther = React.useMemo(() => {
        return survey?.DeclineReasonKey === 'Other';
    }, [survey]);
    const otherReason = React.useMemo(() => {
        return enabledOther ? survey?.StatusMessage : '';
    }, [survey, enabledOther]);

    React.useEffect(() => {
        dispatch(getCompanySurvey(surveyID));
    }, [dispatch, surveyID]);
    React.useEffect(() => {
        const data = surveyData?.Survey;
        const msg = data?.StatusMessage == null ? '' : data?.StatusMessage;
        const declineReasonKey = Object.keys(DeclineReasons).find((key) => DeclineReasons[key] === msg);

        setSurvey((survey) => ({ ...survey, ...data }));
        setUseEsgForm(Boolean(data?.IsEnvironmental) || Boolean(data?.IsSocial) || Boolean(data?.IsGovernance));
        setUseDeclinedForm(data?.Status === 'D');
        updateSurvey('DeclineReasonKey', declineReasonKey != null ? declineReasonKey : msg !== '' ? 'Other' : '');
    }, [surveyData]);

    const isFound = survey?.SurveyID != null;

    return (
        <div className={classes.card}>
            <Card raised={true} fluid={true}>
                {!isFound ? (
                    <div className={classes.zeroStateContainer}>
                        <Icon color="blue" name="dont" size="massive" />
                        <h4>Survey Not Found</h4>
                        <div>
                            There is no survey for you at this link. Go <Link to="/Preferences/CalendarSurvey">back to your list</Link> and try again.
                        </div>
                    </div>
                ) : (
                    <>
                        {Object.keys(errors).length > 0 && (
                            <Card.Content>
                                <div className={classes.errors}>
                                    <span className={classes.errorTitle}>Errors:</span>
                                    <ul>
                                        {Object.keys(errors).map((key, idx) => (
                                            <li key={idx}>{errors[key]}</li>
                                        ))}
                                    </ul>
                                </div>
                            </Card.Content>
                        )}
                        <Card.Content>
                            <Link to={'/Preferences/CalendarSurvey'} style={{ float: 'right' }}>
                                <span style={{ paddingRight: 4 }}>Back to Surveys List</span>
                                <Icon name="reply" />
                            </Link>
                            <Card.Header>{survey.CompanyName}</Card.Header>
                            <Card.Description>{meetingDate}</Card.Description>
                        </Card.Content>
                        <Card.Content>
                            <div className={classes.groups}>
                                <Form.Group disabled={isSaving}>
                                    <div className={classes.header}>Did your meeting include an ESG discussion?</div>
                                    <div style={{ marginLeft: 20 }}>
                                        <Button.Group>
                                            <Button disabled={isSaving} basic={useEsgForm || useDeclinedForm} color="blue" onClick={handleEnableEsg('no')}>
                                                No
                                            </Button>
                                            <Button disabled={isSaving} basic={!useEsgForm} color="blue" onClick={handleEnableEsg('yes')}>
                                                Yes
                                            </Button>
                                            <Button disabled={isSaving} basic={!useDeclinedForm} color="blue" onClick={handleEnableEsg('declined')}>
                                                N/A
                                            </Button>
                                        </Button.Group>
                                    </div>
                                </Form.Group>
                                {useDeclinedForm ? (
                                    <>
                                        <Form.Group
                                            style={{
                                                color: errors?.StatusMessage != null ? '#900' : 'inherit',
                                            }}
                                            disabled={isSaving}
                                        >
                                            <div className={classes.header}>
                                                Reason for N/A <div className="subheader">(required)</div>
                                            </div>
                                            {Object.keys(DeclineReasons).map((key) => (
                                                <Form.Field key={key}>
                                                    <div className={classes.formField}>
                                                        <Radio
                                                            className={classes.checkbox}
                                                            disabled={isSaving}
                                                            label={DeclineReasons[key]}
                                                            checked={survey?.DeclineReasonKey === key}
                                                            value={key}
                                                            onChange={handleDeclineReasonChange}
                                                        />
                                                    </div>
                                                </Form.Field>
                                            ))}
                                        </Form.Group>
                                        <Form.Group
                                            style={{
                                                color: errors?.StatusMessage != null ? '#900' : 'inherit',
                                            }}
                                            disabled={!enabledOther || isSaving}
                                        >
                                            <div style={{ marginLeft: 20, width: 300 }}>
                                                <TextArea
                                                    disabled={!enabledOther || isSaving}
                                                    onChange={handleOtherReasonChange}
                                                    placeholder={enabledOther ? 'Enter other reason.' : ''}
                                                    maxLength={500}
                                                    style={{
                                                        borderColor: errors?.StatusMessage != null ? '#900' : 'inherit',
                                                        color: errors?.StatusMessage != null ? '#900' : 'inherit',
                                                    }}
                                                    value={otherReason}
                                                />
                                            </div>
                                        </Form.Group>
                                    </>
                                ) : (
                                    useEsgForm && (
                                        <>
                                            <Form.Group
                                                style={{
                                                    color: errors?.ESG != null ? '#900' : 'inherit',
                                                }}
                                                disabled={!useEsgForm || isSaving}
                                            >
                                                <div className={classes.header}>
                                                    What was discussed? <div className="subheader">(required)</div>
                                                </div>
                                                <Form.Field>
                                                    <div className={classes.formField}>
                                                        <Checkbox
                                                            disabled={!useEsgForm || isSaving}
                                                            checked={Boolean(survey?.IsEnvironmental)}
                                                            className={classes.checkbox}
                                                            label="Environmental"
                                                            name="IsEnvironmental"
                                                            onChange={handleCheckboxChange}
                                                        />
                                                    </div>
                                                </Form.Field>
                                                <Form.Field>
                                                    <div className={classes.formField}>
                                                        <Checkbox
                                                            disabled={!useEsgForm || isSaving}
                                                            checked={Boolean(survey?.IsSocial)}
                                                            className={classes.checkbox}
                                                            label="Social"
                                                            name="IsSocial"
                                                            onChange={handleCheckboxChange}
                                                        />
                                                    </div>
                                                </Form.Field>
                                                <Form.Field>
                                                    <div className={classes.formField}>
                                                        <Checkbox
                                                            disabled={!useEsgForm || isSaving}
                                                            checked={Boolean(survey?.IsGovernance)}
                                                            className={classes.checkbox}
                                                            label="Governance"
                                                            name="IsGovernance"
                                                            onChange={handleCheckboxChange}
                                                        />
                                                    </div>
                                                </Form.Field>
                                            </Form.Group>
                                            {hasEsg && isHost && (
                                                <>
                                                    <Form.Group disabled={!hasEsg || isSaving}>
                                                        <div className={classes.header}>
                                                            Was the ESG discussion substantive? <div className="subheader">(required)</div>
                                                        </div>
                                                        <div style={{ marginLeft: 20, width: 300 }}>
                                                            <Button.Group>
                                                                <Button
                                                                    disabled={!hasEsg || isSaving}
                                                                    basic={Boolean(survey?.IsSubstantive)}
                                                                    color="blue"
                                                                    onClick={handleIsSubstantiveChange(false)}
                                                                >
                                                                    No
                                                                </Button>
                                                                <Button
                                                                    disabled={!hasEsg || isSaving}
                                                                    basic={!Boolean(survey?.IsSubstantive)}
                                                                    color="blue"
                                                                    onClick={handleIsSubstantiveChange(true)}
                                                                >
                                                                    Yes
                                                                </Button>
                                                            </Button.Group>
                                                        </div>
                                                    </Form.Group>
                                                    {survey?.IsSubstantive && (
                                                        <Form.Group disabled={!hasEsg || !Boolean(survey?.IsSubstantive) || isSaving}>
                                                            <div className={classes.header}>Select the analyst who should enter the engagement entry.</div>
                                                            <div style={{ marginLeft: 20 }}>
                                                                <Popup
                                                                    on="click"
                                                                    positionFixed={true}
                                                                    trigger={
                                                                        <Button disabled={isSaving} labelPosition="left" icon={true} color="blue">
                                                                            <Icon name="pencil" />
                                                                            {delegateAttendee?.FullName}
                                                                        </Button>
                                                                    }
                                                                >
                                                                    <Popup.Content>
                                                                        <Menu vertical={true}>
                                                                            {attendees?.map((attendee) => (
                                                                                <Menu.Item
                                                                                    key={attendee.UserID}
                                                                                    active={attendee.UserID === delegateAttendee?.UserID}
                                                                                    onClick={handleDelegateClick(attendee.UserID)}
                                                                                >
                                                                                    {attendee?.FullName}
                                                                                    {attendee.UserID === delegateAttendee?.UserID && (
                                                                                        <Icon color="green" name="check" />
                                                                                    )}
                                                                                </Menu.Item>
                                                                            ))}
                                                                        </Menu>
                                                                    </Popup.Content>
                                                                </Popup>
                                                            </div>
                                                        </Form.Group>
                                                    )}
                                                </>
                                            )}
                                        </>
                                    )
                                )}
                            </div>
                        </Card.Content>
                    </>
                )}
            </Card>
            {isFound && (
                <div style={{ width: 180, padding: 12 }}>
                    {isSaving ? (
                        <Button loading={true} primary={true}>
                            Saving...
                        </Button>
                    ) : (
                        <Button fluid={true} labelPosition="left" icon={true} color="blue" loading={isSaving} onClick={handleSubmit}>
                            <Icon name="save" />
                            Save Survey
                        </Button>
                    )}
                </div>
            )}
            <Modal className={classes.model} open={showAlert} onClose={handleShowAlertClose} size="small" dimmer="blurring">
                <Header icon>
                    <Icon color="green" name="check circle outline" />
                    Survey Complete!
                </Header>
                <Modal.Content>
                    <p>Thank you for your feedback! Your survey answers have been saved.</p>
                    {survey?.NoteID == null && hasEsg === true && isHost === false && (
                        <p>
                            <span>We encourage you to enter an </span>
                            <Link
                                to={{
                                    pathname: `/EngagementInput/${survey.CompanyID}`,
                                    search: `?meetingID=${survey.CalendarMeetingID}`,
                                    state: { redirect: '/Preferences/CalendarSurvey' },
                                }}
                            >
                                engagement entry
                            </Link>
                            <span> for this meeting.</span>
                        </p>
                    )}
                    {survey?.NoteID == null && isHost === true && survey?.IsSubstantive && userID === survey?.DelegatedAnalystID && (
                        <p>You will now be directed to the Engagement Input screen to enter your engagement meeting entry.</p>
                    )}

                    {survey?.NoteID != null && hasEsg === true && isHost === false && (
                        <p>
                            <span>An </span>
                            <Link
                                to={{
                                    pathname: `/EngagementInput/${survey.CompanyID}/${survey.NoteID}`,
                                    state: { redirect: '/Preferences/CalendarSurvey' },
                                }}
                            >
                                engagement entry
                            </Link>
                            <span> was found for this survey. There is no need to add another.</span>
                        </p>
                    )}
                    {survey?.NoteID != null && isHost === true && survey?.IsSubstantive && userID === survey?.DelegatedAnalystID && (
                        <p>
                            An <Link to={`/EngagementInput/${survey.CompanyID}/${survey.NoteID}`}>engagement note has been entered</Link> for this meeting.
                            There is no need to add another entry.
                        </p>
                    )}
                </Modal.Content>
                <Modal.Actions>
                    <Button color="blue" onClick={() => handleShowAlertClose(false)}>
                        Close
                    </Button>
                </Modal.Actions>
            </Modal>
        </div>
    );
};

export default withStyles(styles)(Survey);
