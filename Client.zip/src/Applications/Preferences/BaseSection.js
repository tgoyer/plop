import React from 'react';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    formControl: {
        margin: 10,
    },
    paper: {
        padding: 10,
        marginBottom: 10
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: 5,
        padding: 5
    },
});

const BaseSection = (props) => {
    const { classes, title, children, style, flat = false } = props;
    
    return flat === true
        ? (
            <React.Fragment>
                <div className={classes.sectionHeader}>
                    <span className={classes.sectionHeaderLabel}>{title}</span>
                </div>
                <div className={classes.formControl} style={style}>{ children }</div>
            </React.Fragment>
        ) : (
            <Paper elevation={1} className={classes.paper}>
                <div className={classes.sectionHeader}>
                    <span className={classes.sectionHeaderLabel}>{title}</span>
                </div>
                <div className={classes.formControl} style={style}>{ children }</div>
            </Paper>
        )
}

export default withStyles(styles)(BaseSection);


