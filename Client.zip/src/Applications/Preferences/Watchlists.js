import React from 'react';
import { connect } from 'react-redux';
import cn from 'classnames';

import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Paper from '@material-ui/core/Paper';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import { withStyles } from '@material-ui/core/styles';

import BaseSection from './BaseSection';
import NewWatchList, { WatchlistCategories } from './WatchLists/NewWatchList';
import { pxToRem } from '../../Utils/layoutHelper';
import { sort } from '../../Utils/listHelper';
import { getUserWatchlistData, deleteUserWatchlistItem, saveWatchlist, deleteUserGeneralFollowUpInfo } from '../../store/UserModule';
import DeleteDialog from '../../UIComponents/MaterialUI/CommonDialog';
import { dateFormat, formatDate } from '../../Utils/dateHelper';

const styles = (theme) => ({
    container: {
        display: 'flex',
        justifyContent: 'space-around',
        '@media (max-width: 1199px)': {
            flexWrap: 'wrap',
        },
    },
    formControl: {
        margin: '10px 0 10px 20px',
    },
    sections: {
        display: 'flex',
        flexBasis: '50%',
        flexDirection: 'column',
        margin: '0 5px',
        '&:first-child': {
            marginLeft: 0,
        },
        '&:last-child': {
            marginRight: 0,
        },
        '@media (max-width: 1199px)': {
            flexBasis: '100%',
        },
    },
    paper: {
        padding: 10,
        marginBottom: 10,
    },
    radio: {
        padding: '0 4px 0 16px',
        '& svg': {
            fontSize: 22,
        },
    },
    watchlistItem: {
        '& > i': {
            padding: '2px 8px 2px 0',
        },
    },
    zeroState: {
        align: 'centre',
        color: 'black',
        cursor: 'not-allowed',
        backgroundColor: '#fff',
        fontSize: pxToRem(12),
    },
    hidden: {
        display: 'none',
    },
    resultsTable: {
        border: 0,
        borderCollapse: 'collapse',
        fontSize: 12,
        width: '100%',
        '& tr.hide': {
            display: 'none',
        },
        '& thead th': {
            backgroundColor: '#F5F5F5', //'#6987B9',
            color: 'black',
            fontWeight: 700,
            padding: '4px 8px',
            textAlign: 'center',
            border: '1px solid #eee',
        },
        '& tbody tr': {
            backgroundColor: '#fff',
        },
        '& tbody td': {
            border: '1px solid #eee',
            color: '#000000',
            fontWeight: 400,
            margin: 2,
            padding: '4px 8px',
        },
        '& .fa-trash-alt': {
            cursor: 'pointer',
        },
    },
    resultsTableDisabled: {
        '& .fa-trash-alt': {
            cursor: 'auto !important',
        },
    },
});

const NotificationFrequencies = {
    None: 'None',
    Weekly: 'Weekly',
    Monthly: 'Monthly',
};

const Watchlists = (props) => {
    const {
        classes,
        UserInfo,
        WatchlistData,
        deleteWatchlistItemDispatcher,
        getWatchlistDataDispatcher,
        saveWatchlistDispatcher,
        deleteUserGeneralFollowUpInfoDispatcher,
    } = props;
    const [useAnalystSecurityMap, setUseAnalystSecurityMap] = React.useState(false);
    const [showAnalystSecurityMapUrl, setShowAnalystSecurityMapUrl] = React.useState('none');
    const [myAnalystSecurityMapUrl, setMyAnalystSecurityMapUrl] = React.useState('');
    const [useProxyAlert, setUseProxyAlert] = React.useState(false);
    const [notificationFrequency, setNotificationFrequency] = React.useState(NotificationFrequencies.None);
    const [previousNotificationFrequency, setPreviousNotificationFrequency] = React.useState(NotificationFrequencies.None);
    const [showDeleteConfirmation, setShowDeleteConfirmation] = React.useState(false);
    const [selectedWatchlistDetailID, setSelectedWatchlistDetailID] = React.useState(0);
    const [showNoNotificationConfirmation, setShowNoNotificationConfirmation] = React.useState(false);
    const [showReminderDeleteConfirmation, setShowReminderDeleteConfirmation] = React.useState(false);
    const [selectedCompanyID, setSelectedCompanyID] = React.useState(0);

    const getWatchList = React.useCallback(() => {
        getWatchlistDataDispatcher(UserInfo.UserID);
    }, [UserInfo.UserID, getWatchlistDataDispatcher]);

    React.useEffect(() => {
        getWatchList();
    }, [getWatchList]);

    React.useEffect(() => {
        const frequency =
            WatchlistData.NotificationFrequency != null && WatchlistData.NotificationFrequency !== '' ? WatchlistData.NotificationFrequency : 'None';
        const showASMUrl = WatchlistData.MyAnalystToSecurityMappingUrl != null && WatchlistData.MyAnalystToSecurityMappingUrl !== '' ? 'block' : 'none';

        setShowNoNotificationConfirmation(false);
        setNotificationFrequency(NotificationFrequencies[frequency]);
        setShowAnalystSecurityMapUrl(showASMUrl);
        setUseAnalystSecurityMap(WatchlistData.UseMyAnalystToSecurityMapping || false);
        setUseProxyAlert(WatchlistData.ReceiveProxyDataChangesAlert || false);
        setMyAnalystSecurityMapUrl(WatchlistData.MyAnalystToSecurityMappingUrl);
    }, [WatchlistData]);

    const deleteWatchlistItem = () => {
        deleteWatchlistItemDispatcher(UserInfo.UserID, selectedWatchlistDetailID).then(() => {
            setShowDeleteConfirmation(false);
            setShowNoNotificationConfirmation(false);
            getWatchList();
        });
    };

    const handleAnalystMapChange = () => {
        saveWatchlistDispatcher(UserInfo.UserID, {
            EntityType: null,
            EntityValue: null,
            UserID: UserInfo.UserID,
            WatchlistID: WatchlistData.WatchlistID,
            NotificationFrequencyType: notificationFrequency,
            AnalystToSecurity: !useAnalystSecurityMap,
            ProxyData: useProxyAlert,
        }).then(getWatchList);
    };

    const handleProxyAlertChange = () => {
        saveWatchlistDispatcher(UserInfo.UserID, {
            EntityType: null,
            EntityValue: null,
            UserID: UserInfo.UserID,
            WatchlistID: WatchlistData.WatchlistID,
            NotificationFrequencyType: notificationFrequency,
            AnalystToSecurity: useAnalystSecurityMap,
            ProxyData: !useProxyAlert,
        }).then(getWatchList);
    };

    const handleCreate = (selectedEntityInfo) => {
        saveWatchlistDispatcher(UserInfo.UserID, {
            ...selectedEntityInfo,
            UserID: UserInfo.UserID,
            WatchlistID: WatchlistData.WatchlistID,
            NotificationFrequencyType: notificationFrequency,
            AnalystToSecurity: useAnalystSecurityMap,
            ProxyData: useProxyAlert,
        }).then(getWatchList);
    };

    const handleDelete = (watchlistDetailID) => {
        if (notificationFrequency !== 'None') {
            setSelectedWatchlistDetailID(watchlistDetailID);
            setShowDeleteConfirmation(true);
        }
    };

    const handleNotificationFrequencyChange = (previousFrequency, frequency) => {
        setPreviousNotificationFrequency(previousFrequency);

        if (WatchlistData.WatchlistID !== null && frequency === 'None') {
            setShowNoNotificationConfirmation(true);
            setNotificationFrequency(frequency);
        } else {
            setNewNotificationFrequency(frequency);
        }
    };

    const setNewNotificationFrequency = (frequency) => {
        setNotificationFrequency(frequency);
        saveWatchlistDispatcher(UserInfo.UserID, {
            EntityType: null,
            EntityValue: null,
            UserID: UserInfo.UserID,
            WatchlistID: WatchlistData.WatchlistID,
            NotificationFrequencyType: frequency,
            AnalystToSecurity: useAnalystSecurityMap,
            ProxyData: useProxyAlert,
        }).then(() => {
            getWatchList();
        });
    };

    const getWatchedTableHeaderDisplay = (entityType) => WatchlistData[entityType] == null || WatchlistData[entityType].length === 0;

    const handleDeleteReminder = (companyID) => {
        if (notificationFrequency !== 'None') {
            setSelectedCompanyID(companyID);
            setShowReminderDeleteConfirmation(true);
        }
    };

    const deleteReminderItem = () => {
        deleteUserGeneralFollowUpInfoDispatcher(UserInfo.UserID, selectedCompanyID).then(() => {
            setShowReminderDeleteConfirmation(false);
            getWatchList();
        });
    };

    const isDisabled = notificationFrequency === 'None';

    return (
        <div className={classes.container}>
            <div className={classes.sections}>
                <NewWatchList onCreate={handleCreate} notificationFrequency={notificationFrequency} />
            </div>
            <div className={classes.sections}>
                <BaseSection title="Notification Frequency">
                    <RadioGroup
                        row={true}
                        aria-label="Watchlist Categories"
                        name="watchlistCategory"
                        className={classes.group}
                        value={notificationFrequency}
                        onChange={(event) => handleNotificationFrequencyChange(notificationFrequency, event.target.value)}
                    >
                        {Object.keys(NotificationFrequencies).map((key) => (
                            <FormControlLabel
                                key={key}
                                value={NotificationFrequencies[key]}
                                control={<Radio className={classes.radio} />}
                                label={NotificationFrequencies[key]}
                            />
                        ))}
                    </RadioGroup>
                </BaseSection>

                <Paper elevation={1} className={classes.paper}>
                    <BaseSection title="Research Wire" flat={true}>
                        <Checkbox
                            color="primary"
                            checked={useAnalystSecurityMap}
                            onChange={handleAnalystMapChange}
                            style={{ textAlign: 'right', padding: 4 }}
                            disabled={isDisabled}
                        />
                        Use my Analyst to Security mapping.{' '}
                        <span key="RWUrl" className={cn({ [classes.hidden]: showAnalystSecurityMapUrl === 'none' })}>
                            Go to{' '}
                            <a href={myAnalystSecurityMapUrl} target="_blank" rel="noopener noreferrer">
                                Research Wire.
                            </a>
                        </span>
                    </BaseSection>

                    <BaseSection title="Proxy Data Changes" flat={true}>
                        <Checkbox
                            color="primary"
                            checked={useProxyAlert}
                            onChange={handleProxyAlertChange}
                            style={{ textAlign: 'right', padding: 4 }}
                            disabled={isDisabled}
                        />
                        Receive Proxy Data changes Alert
                    </BaseSection>
                    <BaseSection title="Watched Analysts" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Analyst) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Analyst] != null && WatchlistData[WatchlistCategories.Analyst].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Analyst].sort(sort('Name')).map((analyst) => (
                                        <tr key={analyst.WatchlistDetailID}>
                                            <td align="left">{analyst.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(analyst.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any analysts. Use the form to the left to start watching your favorite analyst!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Teams" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Team) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Team] != null && WatchlistData[WatchlistCategories.Team].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Team].sort(sort('Name')).map((team) => (
                                        <tr key={team.WatchlistDetailID}>
                                            <td align="left">{team.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(team.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any teams. Use the form to the left to start watching your favorite team!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Accounts" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Account) })}>
                                    <th style={{ textAlign: 'left', width: '65%' }}>Name</th>
                                    <th style={{ textAlign: 'left', width: '25%' }}>Account Number</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Account] != null && WatchlistData[WatchlistCategories.Account].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Account].sort(sort('Name')).map((account) => (
                                        <tr key={account.WatchlistDetailID}>
                                            <td align="left">{account.Name}</td>
                                            <td align="left">{account.AccountNumber}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(account.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="3">
                                            <span className={classes.zeroState}>
                                                You are not watching any accounts. Use the form to the left to start watching your favorite account!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Benchmarks" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Benchmark) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Benchmark] != null && WatchlistData[WatchlistCategories.Benchmark].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Benchmark].sort(sort('Name')).map((benchmark) => (
                                        <tr key={benchmark.WatchlistDetailID}>
                                            <td align="left">{benchmark.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(benchmark.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any benchmarks. Use the form to the left to start watching your favorite benchmark!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Companies" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Company) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Company] != null && WatchlistData[WatchlistCategories.Company].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Company].sort(sort('Name')).map((company) => (
                                        <tr key={company.WatchlistDetailID}>
                                            <td align="left">{company.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(company.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any companies. Use the form to the left to start watching your favorite company!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Products" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Product) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Product] != null && WatchlistData[WatchlistCategories.Product].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Product].sort(sort('Name')).map((product) => (
                                        <tr key={product.WatchlistDetailID}>
                                            <td align="left">{product.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(product.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any products. Use the form to the left to start watching your favorite product!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Sectors" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Sector) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Sector] != null && WatchlistData[WatchlistCategories.Sector].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Sector].sort(sort('Name')).map((sector) => (
                                        <tr key={sector.WatchlistDetailID}>
                                            <td align="left">{sector.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(sector.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any sectors. Use the form to the left to start watching your favorite sector!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Industries" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Industry) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Industry] != null && WatchlistData[WatchlistCategories.Industry].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Industry].sort(sort('Name')).map((industry) => (
                                        <tr key={industry.WatchlistDetailID}>
                                            <td align="left">{industry.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(industry.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any industries. Use the form to the left to start watching your favorite industry!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Watched Subindustries" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.Subindustry) })}>
                                    <th style={{ textAlign: 'left', width: '90%' }}>Name</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.Subindustry] != null && WatchlistData[WatchlistCategories.Subindustry].length > 0 ? (
                                    WatchlistData[WatchlistCategories.Subindustry].sort(sort('Name')).map((subindustry) => (
                                        <tr key={subindustry.WatchlistDetailID}>
                                            <td align="left">{subindustry.Name}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDelete(subindustry.WatchlistDetailID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="2">
                                            <span className={classes.zeroState}>
                                                You are not watching any subindustries. Use the form to the left to start watching your favorite subindustry!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                    <BaseSection title="Follow-up Reminders" flat={true}>
                        <table className={cn(classes.resultsTable, { [classes.resultsTableDisabled]: isDisabled })}>
                            <thead>
                                <tr className={cn({ hide: getWatchedTableHeaderDisplay(WatchlistCategories.GeneralFollowUpInfo) })}>
                                    <th style={{ textAlign: 'left', width: '30%' }}>Company Name</th>
                                    <th style={{ textAlign: 'left', width: '20%' }}>Follow-Up Date</th>
                                    <th style={{ textAlign: 'left', width: '40%' }}>Follow-Up Reason</th>
                                    <th style={{ width: '10%' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {WatchlistData[WatchlistCategories.GeneralFollowUpInfo] != null &&
                                WatchlistData[WatchlistCategories.GeneralFollowUpInfo].length > 0 ? (
                                    WatchlistData[WatchlistCategories.GeneralFollowUpInfo].sort(sort('Name')).map((followUp) => (
                                        <tr key={followUp.CompanyID}>
                                            <td align="left">{followUp.CompanyName}</td>
                                            <td align="left">{formatDate(followUp.FollowUpDate, dateFormat)}</td>
                                            <td align="left">{followUp.FollowUpReason}</td>
                                            <td align="center" style={{ fontSize: 14 }}>
                                                <i className="far fa-trash-alt" onClick={() => handleDeleteReminder(followUp.CompanyID)}></i>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="4">
                                            <span className={classes.zeroState}>
                                                You have not set any reminders. Navigate to CompanyAnalysis screen to add reminders for your favorite company!
                                            </span>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </BaseSection>
                </Paper>
            </div>
            <DeleteDialog
                showActions={true}
                title="Are you sure you wish to continue?"
                open={showDeleteConfirmation}
                onClose={() => setShowDeleteConfirmation(false)}
                onConfirm={deleteWatchlistItem}
            >
                Are you sure you wish to delete this watchlist item?
            </DeleteDialog>
            <DeleteDialog
                showActions={true}
                title="Are you sure you wish to continue?"
                open={showNoNotificationConfirmation}
                onClose={() => {
                    setShowNoNotificationConfirmation(false);
                    setNotificationFrequency(previousNotificationFrequency);
                }}
                onConfirm={(event) => {
                    setNewNotificationFrequency(notificationFrequency);
                }}
            >
                You will not be able to receive watchlist notifications if you do this. Are you sure you wish to continue?
            </DeleteDialog>
            <DeleteDialog
                showActions={true}
                title="Are you sure you wish to continue?"
                open={showReminderDeleteConfirmation}
                onClose={() => setShowReminderDeleteConfirmation(false)}
                onConfirm={deleteReminderItem}
            >
                Are you sure you wish to delete this reminder?
            </DeleteDialog>
        </div>
    );
};

const mapDispatchToProps = (dispatch) => ({
    getWatchlistDataDispatcher: (userID) => dispatch(getUserWatchlistData(userID)),
    deleteWatchlistItemDispatcher: (userID, watchlistDetailID) => dispatch(deleteUserWatchlistItem(userID, watchlistDetailID)),
    saveWatchlistDispatcher: (userID, watchlistData) => dispatch(saveWatchlist(userID, watchlistData)),
    deleteUserGeneralFollowUpInfoDispatcher: (userID, companyID) => dispatch(deleteUserGeneralFollowUpInfo(userID, companyID)),
});

const mapStateToProps = (state) => ({
    UserInfo: state.UserReducer.UserInfo.Data,
    WatchlistData: state.UserReducer.UserWatchlistData,
});

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(Watchlists));
