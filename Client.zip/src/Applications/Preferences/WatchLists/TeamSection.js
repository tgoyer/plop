import React from 'react';
import { connect } from 'react-redux';

import BaseWatchlistSection from './BaseWatchlistSection';
import SearchableDropdown from '../../../UIComponents/MaterialUI/SearchableDropdown';
import { toOptionsList, toSingleOption } from '../../../Utils/selectHelper';

const TeamSection = ({ DefaultTeam, notificationFrequency, Teams, WatchlistData, onCreate }) => {
    const [team, setTeam] = React.useState(null);
    const [teams, setTeams] = React.useState([]);
    const [enabled, setEnabled] = React.useState(false);

    const getDefaultTeam = React.useCallback(() => {
        const watchlistTeam = WatchlistData.Teams.filter(team => team.TeamID === DefaultTeam.value);
        return watchlistTeam.length === 0 ? DefaultTeam : null;
    }, [WatchlistData.Teams, DefaultTeam]);

    React.useEffect(() => {
        setTeam(getDefaultTeam());
    }, [getDefaultTeam])

    React.useEffect(() => {
        const list = Array.isArray(Teams)
            ? Teams.filter(team => WatchlistData.Teams.find(t => team.value === t.TeamID) == null)
            : [];

        setTeams(list);
    }, [WatchlistData.Teams, Teams])

    const handleCreate = (event) => {
        if (team != null && onCreate != null) {
            onCreate({ "EntityType": "Team", "EntityValue": team.value.toString() }, event);
            setTeam(null);
        }
    }

    const handleReset = () => {
        let team = getDefaultTeam();
        setTeam(team);
    }

    const handleSelect = (setDirty) => (value) => {
        setDirty(true);
        setTeam(value);
    }

    React.useEffect(() => {
        setEnabled(team != null);
    }, [team]);

    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} title="Team Watchlist" enabled={enabled}>
            {(setDirty) => ((notificationFrequency !== "None") &&
                <SearchableDropdown
                    id="Teams"
                    dropdownItems={teams}
                    defaultValue={team}
                    onChange={handleSelect(setDirty)}
                />
            )}
        </BaseWatchlistSection>
    )
}

const mapDispatchToProps = (dispatch) => ({})
const mapStateToProps = (state) => {
    return {
        DefaultTeam: toSingleOption(state.DimensionReducer.DefaultTeam, 'TeamName', 'TeamID'),
        Teams: toOptionsList(state.DimensionReducer.Teams, 'TeamName', 'TeamID'),
        UserInfo: state.UserReducer.UserInfo.Data,
        WatchlistData: state.UserReducer.UserWatchlistData
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(TeamSection);