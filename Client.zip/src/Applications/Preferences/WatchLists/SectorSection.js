import React from 'react';
import { connect } from 'react-redux';

import BaseWatchlistSection from './BaseWatchlistSection';
import SearchableDropdown from '../../../UIComponents/MaterialUI/SearchableDropdown';
import { toOptionsList } from '../../../Utils/selectHelper';
import { getSectorsForWatchlist, getIndustriesForWatchlist, getSubindustriesForWatchlist } from '../../../store/DimensionModule';

const SectorSection = ({
    notificationFrequency,
    UserInfo: { UserID },
    DimensionIndustries,
    DimensionSectors,
    DimensionSubIndustries,
    WatchlistIndustries,
    WatchlistSectors,
    WatchlistSubindustries,
    onCreate,
    getIndustriesForWatchlistDispatcher,
    getSectorsForWatchlistDispatcher,
    getSubindustriesForWatchlistDispatcher,
}) => {
    const [selectedSector, setSelectedSector] = React.useState(null);
    const [selectedIndustry, setSelectedIndustry] = React.useState(null);
    const [selectedSubIndustry, setSelectedSubIndustry] = React.useState(null);

    React.useEffect(() => {
        const getSectors = (userID) => getSectorsForWatchlistDispatcher(userID);
        getSectors(UserID);
    }, [getSectorsForWatchlistDispatcher, WatchlistSectors, UserID]);

    React.useEffect(() => {
        const getSectorIndustry = (sector, userID) => {
            getIndustriesForWatchlistDispatcher(sector != null ? JSON.stringify([selectedSector.value]) : '[]', userID);
        };
        getSectorIndustry(selectedSector, UserID);
    }, [getIndustriesForWatchlistDispatcher, WatchlistIndustries, selectedSector, UserID]);

    React.useEffect(() => {
        const getSubIndustries = (industry, userID) => {
            getSubindustriesForWatchlistDispatcher(industry != null ? JSON.stringify([selectedIndustry.value]) : '[]', '[]', userID);
        };
        getSubIndustries(selectedIndustry, UserID);
    }, [getSubindustriesForWatchlistDispatcher, WatchlistSubindustries, selectedIndustry, UserID]);

    const handleReset = () => {
        setSelectedSector(null);
        setSelectedIndustry(null);
        setSelectedSubIndustry(null);
    };

    const handleCreate = (event) => {
        let entityInfo = null;

        if (selectedSubIndustry != null) {
            entityInfo = { EntityType: 'Sub-Industry', EntityValue: JSON.stringify([selectedSubIndustry.value]) };
            setSelectedSubIndustry(null);
        } else if (selectedIndustry != null) {
            entityInfo = { EntityType: 'Industry', EntityValue: JSON.stringify([selectedIndustry.value]) };
            setSelectedIndustry(null);
        } else if (selectedSector != null) {
            entityInfo = { EntityType: 'Sector', EntityValue: JSON.stringify([selectedSector.value]) };
            setSelectedSector(null);
        }
        onCreate(entityInfo, event);
    };

    const handleSectorSelect = (setDirty) => (option) => {
        setSelectedSector(option);
        setSelectedIndustry(null);
        setSelectedSubIndustry(null);
        setDirty(true);
    };

    const handleIndustrySelect = (setDirty) => (option) => {
        setSelectedIndustry(option);
        setSelectedSubIndustry(null);
        setDirty(true);
    };

    const handleSubIndustrySelect = (setDirty) => (option) => {
        setSelectedSubIndustry(option);
        setDirty(true);
    };

    const validate = () => {
        return selectedSector != null || selectedIndustry != null || selectedSubIndustry != null;
    };

    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} enabled={validate()} title="Sector Watchlist">
            {(setDirty) =>
                notificationFrequency !== 'None' && (
                    <React.Fragment>
                        <SearchableDropdown
                            id="sectors"
                            dropdownItems={DimensionSectors}
                            defaultValue={selectedSector}
                            onChange={handleSectorSelect(setDirty)}
                            dropdownName="Sector"
                        />
                        <br></br>
                        <SearchableDropdown
                            id="industries"
                            dropdownItems={DimensionIndustries}
                            defaultValue={selectedIndustry}
                            onChange={handleIndustrySelect(setDirty)}
                            dropdownName="Industry"
                        />
                        <br></br>
                        <SearchableDropdown
                            id="subindustries"
                            dropdownItems={DimensionSubIndustries}
                            defaultValue={selectedSubIndustry}
                            onChange={handleSubIndustrySelect(setDirty)}
                            dropdownName="Sub-industry"
                        />
                    </React.Fragment>
                )
            }
        </BaseWatchlistSection>
    );
};

const mapDispatchToProps = (dispatch) => ({
    getSectorsForWatchlistDispatcher: (userID) => dispatch(getSectorsForWatchlist(userID)),
    getIndustriesForWatchlistDispatcher: (sectorsJson, userID) => dispatch(getIndustriesForWatchlist(sectorsJson, userID)),
    getSubindustriesForWatchlistDispatcher: (industriesJson, sectorsJson, userID) =>
        dispatch(getSubindustriesForWatchlist(industriesJson, sectorsJson, userID)),
});
const mapStateToProps = (state) => {
    return {
        DimensionSectors: toOptionsList(state.DimensionReducer.WatchlistSectors, 'SectorName', 'SectorID'),
        DimensionIndustries: toOptionsList(state.DimensionReducer.WatchlistIndustries, 'IndustryName', 'IndustryID'),
        DimensionSubIndustries: toOptionsList(state.DimensionReducer.WatchlistSubindustries, 'SubindustryName', 'SubindustryID'),
        UserInfo: state.UserReducer.UserInfo.Data,
        WatchlistSectors: state.UserReducer.UserWatchlistData.Sectors,
        WatchlistIndustries: state.UserReducer.UserWatchlistData.Industries,
        WatchlistSubindustries: state.UserReducer.UserWatchlistData.SubIndustries,
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(SectorSection);
