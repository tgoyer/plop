import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import Actions from './Actions';
import BaseSection from '../BaseSection';

const styles = theme => ({});

const BaseWatchListSection = ({ enabled = false, onCreate, onReset, title, children }) => {
    const [dirty, setDirty] = React.useState(false);

    const handleReset = (options) => {
        onReset(options);
        setDirty(false);
    }

    const handleCreate = (event) => {
        onCreate(event);
        setDirty(false);
    }

    const actionsDisabled = !dirty && !enabled;

    return (
        <React.Fragment>
            <BaseSection title={title}>
                {children != null && children(setDirty)}
            </BaseSection>
            <Actions onCreate={handleCreate} onReset={handleReset} disabled={actionsDisabled} />
        </React.Fragment>
    )
}

export default withStyles(styles)(BaseWatchListSection);


