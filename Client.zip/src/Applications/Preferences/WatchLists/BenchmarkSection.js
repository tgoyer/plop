import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import BaseWatchlistSection from './BaseWatchlistSection';
import BenchmarkSearch from '../../../components/Search/BenchmarkSearch';

const styles = theme => ({
    formControl: {
        margin: '10px 0 10px 40px',
    },
    paper: {
        padding: 10,
        marginBottom: 10
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '5px 0px 5px 20px',
        padding: 5,
        width: '33%'
    },
    sectionHeaderLabel: {
        cursor: 'pointer',
    },
});

const BenchmarkSection = ({  onCreate, notificationFrequency  }) => {
    const [ benchmark, setBenchmark ] = React.useState(null);

    const handleCreate = (event) => {
        if (benchmark != null && onCreate != null) {
            onCreate({'EntityType': 'Benchmark', 'EntityValue': benchmark.BenchmarkID.toString()}, event);
            setBenchmark(null);
        }
    }

    const handleReset = () => {
        setBenchmark(null);
    }
    
    const handleSelect = (setDirty) => (value) => {
        if (value != null) {
            setBenchmark(value);
            setDirty(true);
        }
    }
    
    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} title="Benchmark Watchlist">
        {(setDirty) => ((notificationFrequency !== 'None') &&
            <BenchmarkSearch selected={benchmark} onSearch={handleSelect(setDirty)} />
        )}
        </BaseWatchlistSection>
    )
}

export default withStyles(styles)(BenchmarkSection);


