import React from 'react';
import cn from 'classnames';

import FormControlLabel from '@material-ui/core/FormControlLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from "../../../UIComponents/Tooltip";

import BaseSection from '../BaseSection';
import AccountSection from './AccountSection';
import AnalystSection from './AnalystSection';
import BenchmarkSection from './BenchmarkSection';
import ProductsSection from './ProductsSection';
import SecuritiesSection from './SecuritiesSection';
import TeamSection from './TeamSection';
import SectorSection from './SectorSection';

const styles = theme => ({
    icon: {
        color: theme.palette.primary.main,
        margin: '0 8px',
        cursor: 'help',
    },
    radio: {
        padding: '0 4px 0 16px',
        '& svg': {
            fontSize: 22
        }
    },
});

export const WatchlistCategories = Object.freeze({
    Analyst: 'Analysts',
    Team: 'Teams',
    Account: 'Accounts',
    Benchmark: 'Benchmarks',
    Company: 'Companies',
    Product: 'Products',
    Sector: 'Sectors',
    Industry: 'Industries',
    Subindustry: 'SubIndustries',
    GeneralFollowUpInfo:'GeneralFollowUpInfo',
});

const CreateWatchList = ({ classes, onCreate, notificationFrequency }) => {
    const [ watchlistCategory, setWatchlistCategory ] = React.useState(WatchlistCategories.Analyst);

    const handleWatchlistCategoryChange = (event) => {
        setWatchlistCategory(event.target.value);
    }

    const handleCreate = (selectedEntityInfo, event) => {
        if (onCreate != null) {
            onCreate(selectedEntityInfo, event);
        }
    }
    
    return (
        <React.Fragment>
            <BaseSection title={
                    <React.Fragment>
                        <span>Watchlist Categories</span>
                        <i data-tip data-for="Watchlist_Categories_TT" className={cn("fas fa-info-circle", classes.icon)}></i>
                        <Tooltip id="Watchlist_Categories_TT">Companies for which you've entered notes are automatically on your watchlist. Select categories below to add to your watchlist.</Tooltip>
                    </React.Fragment>
                }>
                <RadioGroup
                    row={true}
                    aria-label="Watchlist Categories"
                    name="watchlistCategpry"
                    value={watchlistCategory}
                    onChange={handleWatchlistCategoryChange}
                    
                >
                    { Object.keys(WatchlistCategories).filter(key => !['Industry','Subindustry', 'GeneralFollowUpInfo'].includes(key)).map(key => (
                        <FormControlLabel key={key} value={WatchlistCategories[key]} disabled={notificationFrequency === "None"}
                        control={<Radio className={classes.radio}/>} label={WatchlistCategories[key]} />
                    ))}
                </RadioGroup>
            </BaseSection>
            { watchlistCategory === WatchlistCategories.Analyst && <AnalystSection onCreate={handleCreate} notificationFrequency={notificationFrequency} />}
            { watchlistCategory === WatchlistCategories.Team && <TeamSection onCreate={handleCreate}  notificationFrequency={notificationFrequency} />}
            { watchlistCategory === WatchlistCategories.Account && <AccountSection onCreate={handleCreate} notificationFrequency={notificationFrequency} />}
            { watchlistCategory === WatchlistCategories.Benchmark && <BenchmarkSection onCreate={handleCreate} notificationFrequency={notificationFrequency} />}
            { watchlistCategory === WatchlistCategories.Company && <SecuritiesSection onCreate={handleCreate}  notificationFrequency={notificationFrequency} />}
            { watchlistCategory === WatchlistCategories.Product && <ProductsSection onCreate={handleCreate} notificationFrequency={notificationFrequency} />} 
            { watchlistCategory === WatchlistCategories.Sector && <SectorSection onCreate={handleCreate} notificationFrequency={notificationFrequency} />} 
        </React.Fragment>
    )
}

export default withStyles(styles)(CreateWatchList);


