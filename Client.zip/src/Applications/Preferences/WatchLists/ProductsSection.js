import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import BaseWatchlistSection from './BaseWatchlistSection';
import ProductSearch from '../../../components/Search/ProductSearch';

const styles = theme => ({
    formControl: {
        margin: '10px 0 10px 40px',
    },
    paper: {
        padding: 10,
        marginBottom: 10
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '5px 0px 5px 20px',
        padding: 5,
        width: '33%'
    },
    sectionHeaderLabel: {
        cursor: 'pointer',
    },
});

const ProductsSection = (props) => {
    const { onCreate, notificationFrequency } = props;
    const [ product, setProduct ] = React.useState(null);

    const handleReset = () => {
        setProduct(null);
    }

    const handleCreate = (event) => {
        if (product != null && onCreate != null) {
            onCreate({ 'EntityType': 'Product', 'EntityValue': product.ProductID.toString() }, event);
            setProduct(null);
        }
    }

    const handleSelect = (setDirty) => (value) => {
        if (value != null) {
            setProduct(value);
            setDirty(true);
        }
    }
    
    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} title="Product Watchlist">
        {(setDirty) => ((notificationFrequency !== 'None') &&
            <ProductSearch selected={product} onSearch={handleSelect(setDirty)} />
        )}
        </BaseWatchlistSection>
    )
}

export default withStyles(styles)(ProductsSection);
