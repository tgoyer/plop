import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import BaseWatchlistSection from './BaseWatchlistSection';
import PortfolioSearch from '../../../components/Search/PortfolioSearch';

const styles = theme => ({
    formControl: {
        margin: '10px 0 10px 40px',
    },
    paper: {
        padding: 10,
        marginBottom: 10
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '5px 0px 5px 20px',
        padding: 5,
        width: '33%'
    },
    sectionHeaderLabel: {
        cursor: 'pointer',
    },
});

const AccountSection = ({ onCreate, notificationFrequency }) => {
    const [ account, setAccount ] = React.useState(null);

    const handleReset = () => {
        setAccount(null);
    }

    const handleCreate = (event) => {
        if (account != null && onCreate != null) {
            onCreate({ 'EntityType': 'Account', 'EntityValue': account.AccountID.toString() }, event);
            setAccount(null);
        }
    }
    
    const handleSelect = (setDirty) => (value) => {
        setAccount(value);
        setDirty(true);
    }
        
    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} title="Account Watchlist">
        {(setDirty) => ((notificationFrequency !== 'None') &&
            <PortfolioSearch selected={account} onSearch={handleSelect(setDirty)} />
        )}
        </BaseWatchlistSection>
    )
}

export default withStyles(styles)(AccountSection);


