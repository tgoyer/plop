import React from 'react';

import BaseWatchlistSection from './BaseWatchlistSection';
import SecuritySearch from '../../../components/Search/CompanySearch';

const SecuritiesSection = (props) => {
    const { onCreate, notificationFrequency} = props;
    const [ company, setCompany ] = React.useState(null);
    
    const handleCreate = (event) => {
        if (company != null && onCreate != null) {
            onCreate({ 'EntityType': 'Company', 'EntityValue': company.CompanyID.toString()}, event);
            setCompany(null);
        }
    }
    
    const handleReset = () => {
        setCompany(null);
    }

    const handleSelect = (setDirty) => (value) => {
        setCompany(value);
        setDirty(true);
    }

    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} title="Company Watchlist">
        {(setDirty) => ((notificationFrequency !== "None") &&
            <SecuritySearch selected={company} onSearch={handleSelect(setDirty)} />
        )}
        </BaseWatchlistSection>
    )
}

export default SecuritiesSection;