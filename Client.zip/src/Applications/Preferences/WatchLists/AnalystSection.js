import React from 'react';
import { connect } from 'react-redux';

import BaseWatchlistSection from './BaseWatchlistSection';
import SearchableDropdown from '../../../UIComponents/MaterialUI/SearchableDropdown';
import { toOptionsList } from '../../../Utils/selectHelper';

const AnalystSection = ({ Analysts, onCreate, notificationFrequency, WatchlistData }) => {
    const [analyst, setAnalyst] = React.useState(null);
    const [analysts, setAnalysts] = React.useState([]);

    React.useEffect(() => {
        const list =
            Array.isArray(Analysts) && Array.isArray(WatchlistData.Analysts)
                ? Analysts.filter((analyst) => WatchlistData.Analysts.find((a) => analyst.value === a.AnalystUserID) == null)
                : [];

        setAnalysts(list);
    }, [WatchlistData.Analysts, Analysts]);

    const handleCreate = (event) => {
        if (analyst != null && onCreate != null) {
            onCreate({ EntityType: 'Analyst', EntityValue: analyst?.value.toString() }, event);
            setAnalyst(null);
        }
    };

    const handleReset = () => {
        setAnalyst(null);
    };

    const handleSelect = (setDirty) => (value) => {
        setAnalyst(value);
        setDirty(true);
    };

    return (
        <BaseWatchlistSection onCreate={handleCreate} onReset={handleReset} title="Analyst Watchlist">
            {(setDirty) =>
                notificationFrequency !== 'None' && (
                    <SearchableDropdown id="Analysts" dropdownItems={analysts} defaultValue={analyst} onChange={handleSelect(setDirty)} />
                )
            }
        </BaseWatchlistSection>
    );
};

const mapDispatchToProps = (dispatch) => ({});
const mapStateToProps = (state) => ({
    Analysts: toOptionsList(state.DimensionReducer.Analysts, 'FullName', 'UserID'),
    UserInfo: state.UserReducer.UserInfo.Data,
    WatchlistData: state.UserReducer.UserWatchlistData,
});

export default connect(mapStateToProps, mapDispatchToProps)(AnalystSection);
