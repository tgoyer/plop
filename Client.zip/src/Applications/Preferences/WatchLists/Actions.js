import React from 'react';

import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import ConfirmDialog from '../../../UIComponents/MaterialUI/CommonDialog';

const styles = theme => ({
    button: {
        margin: 5,
    },
    buttons: {
        padding: 10,
        marginBottom: 10,
        textAlign: 'right'
    },
});

const Actions = (props) => {
    const { classes, disabled, onReset, onCreate } = props;
    const [showConfirm, setShowConfirm] = React.useState(false);

    const handleReset = (event) => {
        if (onReset != null) {
            setTimeout(() => {
                onReset(event);
                setShowConfirm(false);
            }, 150);
        } else {
            setShowConfirm(false);
        }
    }

    const saveWatchlist = (event) => {
        if (onCreate != null) {
            onCreate(event);
        }
    }

    return (
        <React.Fragment>
            <div className={classes.buttons}>
                <Button color="primary" disabled={disabled} className={classes.button} onClick={() => setShowConfirm(!disabled)}>Reset</Button>
                <Button variant="contained" color="primary" disabled={disabled} className={classes.button} onClick={saveWatchlist}>Add to Watchlist</Button>
            </div>
            <ConfirmDialog
                showActions={true}
                title="Reset Form"
                open={showConfirm}
                onClose={() => setShowConfirm(false)}
                onConfirm={handleReset}
            >
                This will reset the form.  You will lose any changes.  Are you sure you wish to continue?
            </ConfirmDialog>
        </React.Fragment>
    )
}

export default withStyles(styles)(Actions);


