import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import cn from 'classnames';

import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/SwipeableDrawer';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import { withStyles } from '@material-ui/core/styles';

import CommentsLayout from 'Applications/NoteCards/CommentsLayout';
import HomeRecentRatingChangesSection from 'Applications/Home/HomeRecentRatingChangesSection';
import PortfolioActionsSection from 'Applications/Home/PortfolioActionsSection';
import SubHeader from 'Layout/Header/SubHeader';
import Tooltip from 'UIComponents/Tooltip';
import { GlobalFiltersDrawerSection, ToolDrawer } from 'UIComponents/ToolDrawer';

import { selectCompanyByID } from '../store/CompanyModule';
import { setLocalSetting } from '../store/AppSettingsModule';
import { getContent } from '../store/ContentModule';

import { dateFormat, formatDate } from 'Utils/dateHelper';
import { pxToRem } from 'Utils/layoutHelper';

const drawerWidth = 400;
const styles = (theme) => ({
    content: {
        display: 'flex',
        '& > div': {
            width: 'calc(50% - 6px)',
            flexGrow: 0,
            flexShrink: 0,
        },
        '& > div + div': {
            marginLeft: 12,
        },
    },
    contentBox: {
        position: 'relative',
        height: 'calc(100vh - 190px)',
        maxHeight: 'calc(100vh - 190px)',
        marginTop: 10,
    },
    contentDrawerOpen: {
        width: `calc(100% - ${drawerWidth + 4}px)`,
    },
    controlLabel: {
        height: '20px !important',
        fontSize: pxToRem(13),
        marginBottom: 0,
    },
    drawer: {
        display: 'none',
        flexShrink: 0,
        opacity: 0,
        width: drawerWidth,
    },
    drawerOpen: {
        display: 'block',
        opacity: 1,
    },
    drawerPaper: {
        borderRadius: 4,
        boxShadow: '0px 1px 3px 0px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14)',
        height: 'calc(100vh - 142px)',
        margin: '12px 0',
        position: 'absolute',
        width: drawerWidth,
        zIndex: 'auto',
    },
    filterBar: {
        background: '#ffffff',
        padding: 8,
    },
    filterGroup: {
        backgroundColor: theme.palette.primary.main,
        borderRadius: 18,
        color: 'white',
        cursor: 'pointer',
        display: 'inline',
        fontSize: pxToRem(13),
        padding: '2px 4px',
        marginLeft: 4,
    },
    filterGroupZeroState: {
        color: '#999',
        padding: '0 2px',
    },
    filterLabel: {
        padding: '2px 2px 0px 2px',
        fontSize: pxToRem(13),
        fontWeight: 400,
    },
    filterValue: {
        padding: '0 5px',
    },
    formControl: {
        alignItems: 'flex-start',
        boxShadow: '1px 1px 1px #ccc',
        borderRadius: 4,
        display: 'flex',
        flex: '1 0 auto',
        flexDirection: 'row !important',
        minHeight: 'initial',
    },
    iconClearFilter: {
        fontSize: 12,
        padding: 5,
    },
    iconExclaimation: {
        color: '#f08f50',
        display: 'none',
        fontSize: 16,
        padding: 8,
    },
    iconFilter: {
        color: theme.palette.primary.main,
        padding: '0 5px',
        fontSize: 12,
    },
    iconVisible: {
        display: 'initial',
    },
    root: {
        ...theme.mixins.gutters(),
        margin: 10,
        paddingTop: 8,
        paddingBottom: 8,
        paddingRight: '5px !important',
        paddingLeft: '5px !important',
        fontSize: pxToRem(12),
    },
    rootRadioButton: {
        fontSize: pxToRem(12),
    },
    subHeaderButton: {
        fontWeight: 700,
        '& i': {
            paddingRight: 8,
        },
    },
    '@media (max-width: 990px)': {
        content: {
            flexDirection: 'column',
            '& > div': {
                width: '100%',
            },
            '& > div + div': {
                marginLeft: 0,
                marginTop: 12,
            },
        },
        contentBox: {
            height: 'calc(50vh - 125px)',
            maxHeight: 'calc(50vh - 125px)',
            '&:after': {
                content: '""',
                display: 'block',
                height: 2,
                left: 0,
                position: 'absolute',
                bottom: -2,
                width: '100%',
            },
            '&:before': {
                content: '""',
                display: 'block',
                height: 2,
                left: 0,
                position: 'absolute',
                top: -2,
                width: '100%',
            },
        },
    },
});

const Home = ({ classes, history }) => {
    const dispatch = useDispatch();
    const filters = useSelector((state) => state.AppSettingsReducer.LocalSettings.Filters);
    const user = useSelector((state) => state.UserReducer.UserInfo.Data);

    const [globalFilterEnabled, setGlobalFilterEnabled] = React.useState(false);
    const [notesSearchDate, setNotesSearchDate] = React.useState({ Start: null, End: null });
    const [notesTeam, setNotesTeam] = React.useState(null);
    const [entryType, setEntryType] = React.useState(null);
    const [recentRatingsValue, setRecentRatingsValue] = React.useState(180);
    const [toolDrawerOpen, setToolDrawerOpen] = React.useState(false);

    React.useEffect(() => {
        dispatch(getContent());
        setNotesTeam(filters.Team);
        setGlobalFilterEnabled(filters.Team != null);
    }, [filters]);

    const handleClearFilter = (type) => (event) => {
        event.stopPropagation();
        event.preventDefault();

        handleDataFilterSave([
            {
                name: type,
                value: type === 'date' ? { Start: null, End: null } : null,
            },
        ]);
    };

    const handleCompanyNameClick = async (id) => {
        if (id != null) {
            await dispatch(selectCompanyByID(id));
            history.push(`/CompanyAnalysis/${id}`);
        }
    };

    const handleDataFilterSave = (filters) => {
        const date = filters.find((filter) => filter.name === 'date');
        const entry = filters.find((filter) => filter.name === 'entry');
        const team = filters.find((filter) => filter.name === 'team');

        if (date != null) {
            setNotesSearchDate(date.value);
        }

        if (entry != null) {
            setEntryType(entry.value);
        }

        if (team != null) {
            setNotesTeam(team.value);
            setGlobalFilterEnabled(team.value != null);
            updateLocalSettings({ team: team.value });
        }
    };

    const refreshRecentRatingChanges = (event) => setRecentRatingsValue(Number(event.target.value));
    const toggleToolDrawer = () => setToolDrawerOpen(!toolDrawerOpen);
    const updateLocalSettings = async ({ team }) => await dispatch(setLocalSetting('Filters', { Team: team }));

    return (
        <React.Fragment>
            <SubHeader
                right={() => (
                    <div>
                        <Button data-tip data-for="FilterButton_TT" color="primary" className={classes.subHeaderButton} onClick={toggleToolDrawer}>
                            <i className={cn('fas', { 'fa-arrow-right': !toolDrawerOpen, 'fa-arrow-down': toolDrawerOpen })}></i>
                            Adv Options
                            <i className={cn('fas', 'fa-exclamation-triangle', classes.iconExclaimation, { [classes.iconVisible]: globalFilterEnabled })}></i>
                        </Button>
                        {globalFilterEnabled && (
                            <Tooltip id="FilterButton_TT" place="left">
                                A global filter is enabled on this page that may affect search results.
                            </Tooltip>
                        )}
                    </div>
                )}
            />
            {toolDrawerOpen && (
                <Drawer
                    className={cn(classes.drawer, { [classes.drawerOpen]: toolDrawerOpen })}
                    variant="persistent"
                    anchor="right"
                    open={toolDrawerOpen}
                    onClose={toggleToolDrawer}
                    onOpen={toggleToolDrawer}
                    classes={{ paper: classes.drawerPaper }}
                >
                    <ToolDrawer>
                        <GlobalFiltersDrawerSection
                            onSave={handleDataFilterSave}
                            filterDate={notesSearchDate}
                            filterTeam={notesTeam}
                            showDateSelection={true}
                            showTeamSelection={true}
                            showEntryTypeSelection={true}
                            filterEntryType={entryType}
                        />
                    </ToolDrawer>
                </Drawer>
            )}
            <div className={cn(classes.content, { [classes.contentDrawerOpen]: toolDrawerOpen })}>
                <div>
                    <FormControl className={cn(classes.formControl, classes.filterBar)} component="div">
                        <ActiveFilters classes={classes} date={notesSearchDate} entryType={entryType} team={notesTeam} onClearFilter={handleClearFilter} />
                    </FormControl>
                    <div className={classes.contentBox}>
                        <CommentsLayout
                            CompanyID={null}
                            NoteID={null}
                            NoteTypeID={entryType}
                            StartDate={notesSearchDate.Start}
                            EndDate={notesSearchDate.End}
                            SearchText={null}
                            ShowCompanyInfo={true}
                            Team={notesTeam}
                            UserInfo={user}
                        />
                    </div>
                </div>
                <div data-test="data-changes-container">
                    <FormControl className={cn(classes.formControl, classes.filterBar)} component="div">
                        <span className={cn(classes.controlLabel, classes.filterLabel)}>Recent Changes: </span>
                        <RadioGroup row value={recentRatingsValue.toString()} style={{ paddingLeft: 20 }} onChange={refreshRecentRatingChanges}>
                            <FormControlLabel
                                label="Week"
                                classes={{ root: classes.controlLabel }}
                                value="7"
                                control={<Radio classes={{ root: classes.rootRadioButton, checked: classes.checked }} />}
                            />
                            <FormControlLabel
                                label="Month"
                                classes={{ root: classes.controlLabel }}
                                value="30"
                                control={<Radio classes={{ root: classes.rootRadioButton, checked: classes.checked }} />}
                            />
                            <FormControlLabel
                                label="6 Months"
                                classes={{ root: classes.controlLabel }}
                                value="180"
                                control={<Radio classes={{ root: classes.rootRadioButton, checked: classes.checked }} />}
                            />
                        </RadioGroup>
                    </FormControl>
                    <div className={classes.contentBox}>
                        <HomeRecentRatingChangesSection onCompanyNameClick={handleCompanyNameClick} PastDays={recentRatingsValue} />
                        <PortfolioActionsSection onCompanyNameClick={handleCompanyNameClick} PastDays={recentRatingsValue} />
                    </div>
                </div>
            </div>
        </React.Fragment>
    );
};

const ActiveFilters = ({ classes, date, entryType, team, onClearFilter }) => {
    const filters = {};

    if (team != null) {
        filters['Team'] = <TeamFilter key="team" classes={classes} team={team} onClearFilter={onClearFilter} />;
    }
    if (entryType != null) {
        filters['Entry'] = <EntryTypeFilter key="entryType" classes={classes} entryType={entryType} onClearFilter={onClearFilter} />;
    }
    if (date.Start != null && date.End != null) {
        filters['Date Range'] = <DateFilter key="daterange" classes={classes} date={date} onClearFilter={onClearFilter} />;
    }

    return (
        <React.Fragment>
            <span className={cn(classes.controlLabel, classes.filterLabel)}>
                <strong>Filters: </strong>
            </span>
            {Object.keys(filters).length > 0 ? (
                <React.Fragment>{Object.keys(filters).map((key) => filters[key])}</React.Fragment>
            ) : (
                <span className={cn(classes.controlLabel, classes.filterLabel)}>
                    <span className={cn(classes.filterGroupZeroState)}>Click the 'Adv Options' button to filter this list.</span>
                </span>
            )}
        </React.Fragment>
    );
};

const DateFilter = ({ classes, date, onClearFilter }) => {
    const end = formatDate(date.End, dateFormat);
    const start = formatDate(date.Start, dateFormat);

    return start === end ? (
        <span onClick={onClearFilter('date')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{start}</span>
        </span>
    ) : (
        <span onClick={onClearFilter('date')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{start}</span>&mdash;<span className={classes.filterValue}>{end}</span>
        </span>
    );
};

const EntryTypeFilter = ({ classes, entryType, onClearFilter }) => {
    const label = entryType === 1 ? 'Research Entries' : entryType === 2 ? 'Engagement Entries' : null;

    return (
        <span onClick={onClearFilter('entry')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{label}</span>
        </span>
    );
};

const TeamFilter = ({ classes, team, onClearFilter }) => {
    return (
        <span onClick={onClearFilter('team')} className={classes.filterGroup}>
            <span className={classes.filterValue}>{team.label}</span>
        </span>
    );
};

export default withStyles(styles, { withTheme: true })(Home);
