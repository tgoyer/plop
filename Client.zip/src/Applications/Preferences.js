import React from 'react';
import { useHistory, useParams } from 'react-router-dom';

import { Tab, TabSubHeader } from 'Layout/Header';

import Watchlists from 'Applications/Preferences/Watchlists';
import CalendarSurvey from 'Applications/Preferences/CalendarSurvey';

const Preferences = () => {
    const history = useHistory();
    const [tabIndex, setTabIndex] = React.useState(0);
    const { module } = useParams();

    React.useEffect(() => {
        const route = module == null ? null : String(module).toLowerCase();
        const index = Object.keys(ROUTES).findIndex((key) => {
            return ROUTES[key] == null ? null : ROUTES[key].toLowerCase() === route;
        });
        setTabIndex(index > 0 ? index : 0);
    }, [module]);

    const handleTabIndexChange = (tab) => {
        history.push(tab === 0 ? `/Preferences` : `/Preferences/${ROUTES[tab]}`);
    };

    return (
        <React.Fragment>
            <TabSubHeader onTabChange={handleTabIndexChange} activeTab={tabIndex}>
                <Tab label="Watchlists" />
                <Tab label="Company Surveys" />
            </TabSubHeader>
            {tabIndex === TABS.WATCHLISTS && <Watchlists />}
            {tabIndex === TABS.SURVEYS && <CalendarSurvey />}
        </React.Fragment>
    );
};

export default Preferences;

const TABS = {
    WATCHLISTS: 0,
    SURVEYS: 1,
};

const ROUTES = {
    [TABS.WATCHLISTS]: null,
    [TABS.SURVEYS]: 'CalendarSurvey',
};
