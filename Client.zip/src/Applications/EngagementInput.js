﻿import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import { withRouter } from 'react-router-dom';

import { Button, FormControlLabel, InputLabel, Paper, Radio, RadioGroup, TextField as MuiTextField } from '@material-ui/core';
import { RadioButtonUnchecked as RadioButtonUncheckedIcon, RadioButtonChecked as RadioButtonCheckedIcon } from '@material-ui/icons';

import DatePicker from 'components/Form/DatePicker';
import ErrorDialog from 'UIComponents/MaterialUI/CommonErrorDialog';
import LoadingOverlay from 'UIComponents/LoadingOverlay';
import MultiSelect from 'UIComponents/MaterialUI/MultiSelectDropdown';
import SearchableDropdown from 'UIComponents/MaterialUI/SearchableDropdown';
import Tooltip from 'UIComponents/Tooltip';
import { hasEntries } from 'Utils/arrayHelpers';
import { toLocalDateTime, toDateTime, toServerDate } from 'Utils/dateHelper';
import { pxToRem } from 'Utils/layoutHelper';
import { toOptionsList } from 'Utils/selectHelper';

import Actions from 'Applications/NoteInput/Actions';
import ActionTracking from 'Applications/NoteInput/ActionTracking';
import Attachments from 'Applications/NoteInput/Attachments';
import Drawer from 'Applications/NoteInput/Drawer';
import Guides from 'Applications/NoteInput/Guides';
import KeyIssues from 'Applications/NoteInput/KeyIssues';
import MeetingDateInput from 'Applications/NoteInput/MeetingDateInput';
import SubHeader from 'Applications/NoteInput/SubHeader';
import { InputTypes, PillarTypes } from 'Applications/NoteInput/_constants';

import { uploadFile } from 'Applications/KnowledgeCenter/FileManager/utilities';
import { subdomains } from 'Applications/KnowledgeCenter/utilities';
import Downloader from 'componentlibrary/file/Downloader';

const drawerWidth = 575;
const minimumHorizontalWidth = 1600;
const inputType = 'EngagementInput';

const styles = (theme) => ({
    root: {
        ...theme.mixins.gutters(),
        padding: '10px 16px !important',
        margin: '0 0 16px 0',
    },
    actions: {
        display: 'flex',
        flexDirection: 'row',
    },
    analystTeamSection: {
        display: 'flex',
        flexDirection: 'row',
        '& > div': {
            maxWidth: 400,
            width: '50%',
        },
        '& > div + div': {
            marginLeft: 12,
        },
    },
    button: {
        margin: theme.spacing(1),
        '&:disabled': {
            backgroundColor: '#cccccc',
            boxShadow: 'none',
        },
    },
    checkBox: {
        borderRadius: 2,
        color: 'white',
        '&:checked': {
            color: 'white',
        },
        fontSize: pxToRem(20),
        height: 22,
        padding: 0,
        width: 22,
    },
    content: {
        flexGrow: 1,
        marginRight: 0,
    },
    contentShift: {
        width: `calc(100% - ${drawerWidth}px)`,
    },
    controlLabel: {
        height: '20px !important',
        fontSize: pxToRem(14),
        marginBotton: '5px',
        paddingRight: '10px',
    },
    drawerOpen: {
        display: 'block',
        opacity: 1,
    },
    followupLabel: {
        color: 'rgba(0, 0, 0, 0.54)',
        fontSize: 10,
        fontWeight: 700,
        paddingRight: 20,
    },
    followupRadioGroup: {
        marginLeft: 20,
        marginTop: 10,
    },
    formSections: {
        '& > .formSection + .formSection': {
            marginTop: 24,
        },
        '& .formSection': {
            '& .formSubSection': {
                marginTop: 8,
                marginLeft: 24,
            },
            '& .formSubSection + .formSubSection': {
                marginTop: 16,
            },
        },
    },
    dataForm: {
        display: 'flex',
        flexDirection: 'row',
        paddingTop: 8,
        '& > div': {
            width: '50%',
        },
        '& > div + div': {
            marginLeft: 24,
        },
    },
    msciRatingPill: {
        fontSize: pxToRem(16),
        color: '#fff',
        backgroundColor: '#8fa5cb',
        borderRadius: 14,
        padding: '2px 10px',
        margin: '0 14px',
        textShadow: '1px 1px rgba(0,0,0,0.4)',
        verticalAlign: 'middle',
    },
    radioButton: {
        '&:checked': {
            color: theme.palette.primary.main + ' !important',
        },
        '& svg': {
            color: theme.palette.primary.main + ' !important',
        },
        padding: '0px',
    },
    reminderNote: {
        display: 'flex',
        color: 'black',
        width: '96%',
    },
    textField: {
        width: '100%',
    },
    textFieldOptionalInsight: {
        width: '100%',
    },
    textFieldPortfolioActionNote: {
        width: '100%',
    },
    '@media (max-width: 1400px)': {
        dataFormSmall: {
            flexDirection: 'column',
            '& > div': {
                width: '100%',
            },
            '& > div + div': {
                marginLeft: 0,
                marginTop: 24,
            },
        },
    },
    '@media (max-width: 1023px)': {
        analystTeamSectionSmall: {
            flexDirection: 'column',
            '& > div': {
                width: '100%',
                maxWidth: '100%',
            },
            '& > div + div': {
                marginLeft: 0,
                marginTop: 8,
            },
        },
        dataForm: {
            flexDirection: 'column',
            '& > div': {
                width: '100%',
            },
            '& > div + div': {
                marginLeft: 0,
                marginTop: 24,
            },
        },
    },
});

class EngagementInput extends React.Component {
    state = {
        IsLoading: true,
        NoteID: null,
        SelectedAnalyst: [],
        SelectedTeam: [],

        Pillars: {
            hasActions: null,
            [PillarTypes.ENV.ID]: {
                checked: false,
                keyIssues: null,
                other: '',
            },
            [PillarTypes.SOC.ID]: {
                checked: false,
                keyIssues: null,
                other: '',
            },
            [PillarTypes.GOV.ID]: {
                checked: false,
                keyIssues: null,
                other: '',
            },
        },

        Objective: '',
        Background: '',
        ScopeAndProcess: '',
        Outcomes: '',

        SelectedConsensusRating: [],
        MSCIConsensusInsight: '',
        SelectedPortfolioAction: [],
        SelectedPortfolioActionNote: null,
        SelectedPortfolioActionDate: null,
        SelectedPortfolioProducts: [],

        SelectedEffect: [],
        EffectInsight: '',
        When: null,
        What: '',
        SelectedInternalAttendees: [],
        ExternalAttendees: '',

        FollowUpRequired: false,

        IsEditable: true,
        IsPortfolioActionEditable: true,

        ErrorMessages: [],
        SelectedEngagementDate: null,
        CalendarMeetingID: null,

        files: {},
        horizontalWidth: 0,
        isRightDrawerOpen: false,
        isNotificationFrequencySet: false,
        uploadCount: null,
    };

    componentDidMount = async () => {
        const { MSCIPinned, getWatchlistDataDispatcher, UserDetails } = this.props;

        this.setState({ isRightDrawerOpen: MSCIPinned === true });
        await this.initializeData();

        getWatchlistDataDispatcher(UserDetails.UserID).then(() => {
            const { WatchlistData } = this.props;
            const frequencySet = WatchlistData.NotificationFrequency != null && WatchlistData.NotificationFrequency !== '' ? true : false;

            this.setState({ isNotificationFrequencySet: frequencySet });
        });

        this.loadStateData();

        window.addEventListener('resize', this.handleWindowResize);
        this.handleWindowResize();
    };

    componentWillUnmount = async () => {
        window.removeEventListener('resize', this.handleWindowResize);
    };

    initializeData = () => {
        const { Selected } = this.props;
        const { companyID, noteID } = this.props.match.params;
        const promises = [];
        const selectedID = Selected != null ? Selected.CompanyID : null;

        if (companyID != null) {
            promises.push(this.props.fetchEngagementInputDispatcher(companyID, noteID));
            if (parseInt(companyID, 10) !== selectedID) {
                promises.push(this.props.fetchAndSelectCompanyDispatcher(companyID));
            }
            // if (noteID != null) {
            //     promises.push(this.props.fetchAttendeesDispatcher(noteID));
            //}
        } else if (selectedID != null) {
            promises.push(this.props.fetchEngagementInputDispatcher(selectedID, noteID));
        } else {
            promises.push(this.props.fetchEngagementInputDispatcher(selectedID, null));
        }

        return Promise.all(promises);
    };

    updateFileDetails = (fileDetails) => {
        this.setState({ FileDetails: fileDetails });
    };

    getIndex = (value, arr, prop) => {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i][prop] === value) {
                return i;
            }
        }
        return -1; //to handle the case where the value doesn't exist
    };

    setDefaultAnalyst = () => {
        const { Selected, UserDetails } = this.props;

        this.setState({
            SelectedAnalyst: {
                value: UserDetails?.UserID,
                label: UserDetails?.LastName + ', ' + UserDetails?.FirstName,
            },
        });

        this.props.getMeetingsDispatcher(Selected?.CompanyID, UserDetails?.UserID);
        this.props.fetchAnalystTeamsDispatcher(UserDetails?.UserID, null).then(() => {
            const { DefaultTeam } = this.props;
            if (DefaultTeam != null) {
                this.setState({ SelectedTeam: DefaultTeam });
                this.props.fetchPortfolioProductsDispatcher(DefaultTeam.value);
            }
        });
    };

    handleActionsChange = (pillars) => {
        this.setState({
            Pillars: {
                ...this.state.Pillars,
                ...pillars,
            },
        });
    };

    handleDateChange = (date) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        // if (!this.state.IsEditable) return;

        this.props.setDirtyFlagDispatcher(true);
        this.setState({ SelectedPortfolioActionDate: date });
    };

    handleDrawerToggle = (isOpen) => {
        const value = isOpen == null ? true : isOpen;
        this.setState({ isRightDrawerOpen: value }, this.handleWindowResize);
    };

    handleWindowResize = () => {
        const horizontalWidth = Math.max(document.documentElement.clientWidth, document.documentElement.offsetWidth);

        this.setState({ horizontalWidth });
    };

    findProductsByID = (productIds) => {
        let sourceArray = this.props.PortfolioProducts;
        if (productIds != null && productIds.length > 0 && sourceArray != null && sourceArray.length > 0) {
            let selectedItems = [];

            for (var k = 0; k < productIds.length; k++) {
                for (var i = 0; i < sourceArray.length; i++) {
                    if (sourceArray[i].value === productIds[k].ProductID) {
                        selectedItems.push(sourceArray[i]);
                    }
                }
            }
            if (selectedItems.length > 0) {
                this.setState({ SelectedPortfolioProducts: selectedItems });
            }
        }
    };

    getKeyIssuesForPillar = (pillar, keyIssues) => {
        return hasEntries(keyIssues) ? keyIssues.filter((i) => i.PillarName === pillar.ID && i.KeyIssueName.toLowerCase() !== `total ${pillar.LABEL}`) : [];
    };

    //Setting Default values when page landing
    loadStateData = async () => {
        const addActionObjectToKeyIssues = (noteID, keyIssues) => {
            keyIssues = keyIssues.map((ki) => {
                return {
                    ...ki,
                    Action:
                        ki.Action !== null
                            ? { ...ki.Action, EngagementType: 'Action' }
                            : {
                                  Action: '',
                                  Comment: '',
                                  EscalationPathOther: '',
                                  EscalationPathID: null,
                                  NoteID: noteID,
                                  ParentID: null,
                                  Result: null,
                                  Status: null,
                                  FollowUpDate: null,
                                  IsDeleted: false,
                                  WasDiscussed: null,
                                  IsNew: true,
                                  EngagementType: 'Insight',
                                  ActionTypeID: null,
                                  TargetEndDate: null,
                              },
                };
            });

            return keyIssues;
        };

        const { noteID } = this.props.match.params;

        if (noteID != null) {
            await this.props.fetchAttendeesDispatcher(noteID);
        }

        const { NoteData, NoteKeyIssues, Selected, UserDetails } = this.props;

        let actionKeyIssues = NoteData?.ActionKeyIssues;
        let akiWithParentEngageDate = actionKeyIssues?.filter((aki) => aki.ParentNoteEngageDate !== null);
        let parentNoteEngageDate =
            akiWithParentEngageDate !== undefined && akiWithParentEngageDate !== null && akiWithParentEngageDate.length > 0 ? akiWithParentEngageDate[0].ParentNoteEngageDate : null;
        let eIssues = this.getKeyIssuesForPillar(PillarTypes.ENV, NoteKeyIssues);
        let gIssues = this.getKeyIssuesForPillar(PillarTypes.GOV, NoteKeyIssues);
        let sIssues = this.getKeyIssuesForPillar(PillarTypes.SOC, NoteKeyIssues);

        eIssues = addActionObjectToKeyIssues(NoteData?.NoteID, eIssues);
        gIssues = addActionObjectToKeyIssues(NoteData?.NoteID, gIssues);
        sIssues = addActionObjectToKeyIssues(NoteData?.NoteID, sIssues);

        if (NoteData != null && NoteData.length !== 0) {
            const selectedAnalystIndex = this.getIndex(NoteData.AnalystUserID, this.props.Analysts, 'value');
            const selectedMSCIRatingIndex = this.getIndex(NoteData.MSCIConsensusRating, this.props.Consensus, 'value');
            const selectedEffectIndex = this.getIndex(NoteData.EffectID, this.props.Effects, 'value');
            const selectedPortfolioActionIndex = this.getIndex(NoteData.PortfolioActionID, this.props.PortfolioActions, 'value');

            let selectedTeamIndex = -1;
            let selectedTeam = null;

            await this.props.getMeetingsDispatcher(Selected.CompanyID, NoteData.AnalystUserID);
            await this.props.fetchAnalystTeamsDispatcher(NoteData.AnalystUserID, NoteData.NoteID);
            selectedTeamIndex = this.getIndex(NoteData.TeamID, this.props.UserTeams, 'value');
            selectedTeam = this.props.UserTeams[selectedTeamIndex];

            if (selectedTeam != null) {
                await this.props.fetchPortfolioProductsDispatcher(selectedTeam.value); // Load this.props.PortfolioProducts based on the selected team.
                this.findProductsByID(NoteData.PortfolioActionProducts);

                const PortfolioActionDate = NoteData.PortfolioActionDate != null ? toLocalDateTime(NoteData.PortfolioActionDate) : null;
                const EngageFollowupDate = NoteData.EngageFollowupDate != null ? toLocalDateTime(NoteData.EngageFollowupDate) : null;
                const EngageDate = NoteData.EngageDate != null ? toLocalDateTime(NoteData.EngageDate) : null;

                this.setState({
                    NoteID: NoteData.NoteID,
                    IsLoading: false,
                    Pillars: {
                        ...this.state.Pillars,
                        //hasActions: NoteKeyIssues.some((i) => i.Action != null && Boolean(i.IsSelected)),
                        hasActions: true,
                        [PillarTypes.ENV.ID]: {
                            checked: Boolean(NoteData.E),
                            keyIssues: eIssues,
                            other: NoteData.EOther == null ? '' : NoteData.EOther,
                        },
                        [PillarTypes.SOC.ID]: {
                            checked: Boolean(NoteData.S),
                            keyIssues: sIssues,
                            other: NoteData.SOther == null ? '' : NoteData.SOther,
                        },
                        [PillarTypes.GOV.ID]: {
                            checked: Boolean(NoteData.G),
                            keyIssues: gIssues,
                            other: NoteData.GOther == null ? '' : NoteData.GOther,
                        },
                        ParentNoteEngageDate: parentNoteEngageDate,
                    },

                    CalendarMeetingID: NoteData.CalendarMeetingID,

                    SelectedAnalyst: this.props.Analysts[selectedAnalystIndex],
                    SelectedConsensusRating: this.props.Consensus[selectedMSCIRatingIndex],
                    SelectedPortfolioAction: this.props.PortfolioActions[selectedPortfolioActionIndex],
                    SelectedPortfolioActionNote: NoteData.PortfolioActionNote,
                    SelectedPortfolioActionDate: PortfolioActionDate,
                    SelectedTeam: selectedTeam,
                    SelectedEffect: this.props.Effects[selectedEffectIndex],

                    SelectedEngagementDate: EngageDate,
                    Objective: NoteData.EngageObjective == null ? '' : NoteData.EngageObjective,
                    Background: NoteData.EngageBackground == null ? '' : NoteData.EngageBackground,
                    ScopeAndProcess: NoteData.EngageScope == null ? '' : NoteData.EngageScope,
                    Outcomes: NoteData.EngageOutcome == null ? '' : NoteData.EngageOutcome,
                    When: EngageFollowupDate,
                    What: NoteData.EngageFollowupNote == null ? '' : NoteData.EngageFollowupNote,
                    EffectInsight: NoteData.EffectInsight == null ? '' : NoteData.EffectInsight,
                    MSCIConsensusInsight: NoteData.MSCIConsensusInsight == null ? '' : NoteData.MSCIConsensusInsight,
                    SelectedInternalAttendees: toOptionsList(NoteData.InternalAttendees, 'AttendeesName', 'AttendeesUserID'),
                    ExternalAttendees: NoteData.ExternalAttendees == null ? '' : NoteData.ExternalAttendees,
                    FollowUpRequired: NoteData.EngageFollowupDate != null || (NoteData.EngageFollowupNote != null && NoteData.EngageFollowupNote !== ''),
                    IsEditable: UserDetails.Permissions.CanWrite && !!NoteData.IsEditable,
                    IsPortfolioActionEditable: !!NoteData.IsPortfolioActionEditable,
                });
            }
        } else {
            const { Consensus, Effects, PortfolioActions } = this.props;

            this.setDefaultAnalyst();
            this.setState({
                IsEditable: UserDetails.Permissions.CanWrite,
                NoteKeyIssues: NoteKeyIssues != null && NoteKeyIssues.length > 0 ? NoteKeyIssues : [],
                SelectedConsensusRating: Consensus != null && Consensus.length > 0 ? Consensus[0] : [],
                SelectedPortfolioAction: PortfolioActions != null && PortfolioActions.length > 0 ? PortfolioActions[0] : [],
                SelectedEffect: Effects != null && Effects.length > 0 ? Effects[0] : [],
                IsLoading: false,
                Pillars: {
                    ...this.state.Pillars,
                    [PillarTypes.ENV.ID]: {
                        checked: false,
                        keyIssues: eIssues,
                        other: '',
                    },
                    [PillarTypes.SOC.ID]: {
                        checked: false,
                        keyIssues: sIssues,
                        other: '',
                    },
                    [PillarTypes.GOV.ID]: {
                        checked: false,
                        keyIssues: gIssues,
                        other: '',
                    },
                },
            });
        }
    };

    handleChangeNoteKeyIssues = (keyItems, noteKeyType) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        //if (!this.state.IsEditable) return;

        const isCheckedLabel = noteKeyType === 'Environment' ? 'IsCheckedE' : noteKeyType === 'Social' ? 'IsCheckedS' : 'IsCheckedG';

        const otherType = noteKeyType === 'Environment' ? 'EnvironmentOther' : noteKeyType === 'Social' ? 'SocialOther' : 'GovernanceOther';

        const items = this.updateNoteKeyIssues(keyItems);
        const otherCheckbox = items.find((item) => item.KeyIssueName === 'Other' && item.PillarName === noteKeyType);
        const otherText = otherCheckbox != null && Boolean(otherCheckbox.IsSelected) === true ? this.state[otherType] : '';

        const keyTypeChecked = !!this.state[isCheckedLabel] || this.isKeyItemSelected(items, noteKeyType);
        this.props.setDirtyFlagDispatcher(true);

        if (!keyTypeChecked) {
            this.setState({
                [isCheckedLabel]: keyTypeChecked,
                NoteKeyIssues: items,
            });
        } else {
            this.setState({
                [isCheckedLabel]: keyTypeChecked,
                [otherType]: otherText,
                NoteKeyIssues: items,
            });
        }
    };

    isKeyItemSelected = (items, noteKeyType) => {
        return items.some((i) => i.PillarName === noteKeyType && !!i.IsSelected);
    };

    updateNoteKeyIssues = (items) => {
        const keyIssues = [...this.state.NoteKeyIssues];
        if (items != null) {
            items.forEach((i) => {
                const keyIssue = keyIssues.find((nki) => i.KeyIssueID === nki.KeyIssueID);
                keyIssue.IsSelected = i.IsSelected;
            });
        }
        return keyIssues;
    };

    resetTeam = (item) => {
        const { Selected, getMeetingsDispatcher, fetchAnalystTeamsDispatcher } = this.props;

        getMeetingsDispatcher(Selected.CompanyID, item?.value);
        return fetchAnalystTeamsDispatcher(item?.value, null).then(() => {
            this.setState({ SelectedTeam: this.props.DefaultTeam });
        });
    };

    handleAttachmentChange = (newFiles) => {
        const files = Array.isArray(newFiles)
            ? newFiles.reduce((acc, fileData) => {
                  acc[fileData.label] = fileData;
                  return acc;
              }, {})
            : {};

        this.setState({ files });
    };

    handleAttachmentDelete = (id) => {
        const { deleteFileDispatcher } = this.props;
        const noteId = this.state.NoteID;
        deleteFileDispatcher(noteId, id);
    };

    handleKeyIssuesChange = (data) => {
        //console.log('this.state.Pillars', this.state.Pillars);
        //console.log('data', data);
        let selectedKeyIssueIDs = [];

        Object.keys(this.state.Pillars).map((key) => {
            if (key !== 'hasActions' && key !== 'ParentNoteEngageDate') {
                let skis = this.state.Pillars[key]?.keyIssues?.filter((ki) => ki.IsSelected === true);
                let skiids = skis !== undefined && skis !== null ? skis.map((ki) => ki.KeyIssueID) : [];

                selectedKeyIssueIDs = [...selectedKeyIssueIDs, ...skiids];
            }
        });

        Object.keys(data).map((key) => {
            if (key !== 'hasActions' && key !== 'ParentNoteEngageDate') {
                let skis = data[key].keyIssues?.filter((ki) => ki.IsSelected === false && selectedKeyIssueIDs.includes(ki.KeyIssueID));
                skis.map((ki) => (ki.Action.IsDeleted = true));
            }
        });

        //console.log('data', data);
        this.setState({ Pillars: { ...this.state.Pillars, ...data } });
    };

    handleInputOnChange = (controlName) => (event) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        //   if (!this.state.IsEditable) return;

        let inputValue = event.target.value;
        this.props.setDirtyFlagDispatcher(true);
        switch (controlName) {
            case 'environmentother':
                this.setState({ EnvironmentOther: inputValue });
                break;
            case 'socialother':
                this.setState({ SocialOther: inputValue });
                break;
            case 'governanceother':
                this.setState({ GovernanceOther: inputValue });
                break;
            case 'objective':
                this.setState({ Objective: inputValue });
                break;
            case 'background':
                this.setState({ Background: inputValue });
                break;
            case 'scopeandprocess':
                this.setState({ ScopeAndProcess: inputValue });
                break;
            case 'outcomes':
                this.setState({ Outcomes: inputValue });
                break;
            case 'when':
                this.setState({ When: inputValue });
                break;
            case 'what':
                this.setState({ What: inputValue });
                break;
            case 'portfolioactiondate':
                this.setState({ SelectedPortfolioActionDate: inputValue });
                break;
            case 'externalattendees':
                this.setState({ ExternalAttendees: inputValue });
                break;
            case 'effectinsight':
                this.setState({ EffectInsight: inputValue });
                break;
            default:
                break;
        }
    };

    inputDateChange = (controlName) => (date) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        // if (!this.state.IsEditable) return;

        this.props.setDirtyFlagDispatcher(true);
        switch (controlName) {
            case 'when':
                this.setState({ When: date });
                break;
            case 'portfolioactiondate':
                this.setState({ SelectedPortfolioActionDate: date });
                break;
            case 'engagementdate':
                this.setState({ SelectedEngagementDate: date });
                break;
            default:
                break;
        }
    };

    dropdownOnChange = (name) => (value) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        // if (!this.state.IsEditable) return;

        this.props.setDirtyFlagDispatcher(true);
        switch (name) {
            case 'Analyst':
                if (value == null) {
                    this.props.getMeetingsDispatcher(null, null);
                    this.props.fetchAnalystTeamsDispatcher(null, null).then(() => {
                        this.props.fetchPortfolioProductsDispatcher(null).then(() => {
                            this.setState({
                                SelectedAnalyst: value,
                                SelectedTeam: value,
                                SelectedPortfolioActionDate: null,
                                SelectedPortfolioActioNote: null,
                                SelectedPortfolioProducts: null,
                            });
                        });
                    });
                } else {
                    this.resetTeam(value).then(() => {
                        this.setState({ SelectedAnalyst: value }, () => {
                            const selectedTeam = this.state.SelectedTeam?.value;
                            if (selectedTeam != null) {
                                this.props.fetchPortfolioProductsDispatcher(selectedTeam);
                            }
                            this.setState({
                                SelectedPortfolioProducts: [],
                                SelectedPortfolioActioNote: null,
                                SelectedPortfolioActionDate: null,
                            });
                        });
                    });
                }
                break;
            case 'Team':
                this.setState({ SelectedTeam: value }, () => {
                    const selectedTeam = this.state.SelectedTeam?.value;
                    this.props.fetchPortfolioProductsDispatcher(selectedTeam);
                    this.setState({
                        SelectedPortfolioProducts: null,
                        SelectedPortfolioActioNote: null,
                        SelectedPortfolioActionDate: null,
                    });
                });
                break;
            case 'PortfolioAction':
                if (this.state.SelectedTeam?.value != null) {
                    this.setState({ SelectedPortfolioAction: value }, () => {
                        this.setState({
                            SelectedPortfolioProducts: null,
                            SelectedPortfolioActioNote: null,
                            SelectedPortfolioActionDate: null,
                        });
                    });
                }
                break;
            case 'Consensus':
                this.setState({
                    SelectedConsensusRating: value,
                    MSCIConsensusInsight: '',
                });
                break;
            case 'Effect':
                this.setState({ SelectedEffect: value });
                break;
            case 'PortfolioActionProducts':
                this.setState({ SelectedPortfolioProducts: value });
                break;
            case 'Followup':
                this.setState({ FollowUpRequired: value });
                break;
            case 'InternalAttendees':
                this.setState({ SelectedInternalAttendees: value });
                break;
            default:
                break;
        }
    };

    getAddNotificationFrequencyAlert = () => {
        if (this.state.FollowUpRequired && !this.state.isNotificationFrequencySet) {
            return '(To receive reminders, go to User Preferences and set your notification frequency.)';
        }

        return '';
    };

    handleChange = (event) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        //if (!this.state.IsEditable) return;

        let value = event.target.value === 'true' ? true : false;
        if (!value) {
            this.setState({ When: null, What: '' });
        }
        this.setState({ FollowUpRequired: value });
        this.props.setDirtyFlagDispatcher(true);
    };

    handleMeetingDataChange = ({ engagementDate, meeting }) => {
        this.setState({
            SelectedInternalAttendees: meeting != null ? toOptionsList(meeting.Attendees, 'DisplayName', 'AnalystID') : null,
            CalendarMeetingID: meeting?.CalendarMeetingID,
            SelectedEngagementDate: meeting == null ? engagementDate : toDateTime(meeting?.MeetingDate),
        });
    };

    validate = () => {
        const { PortfolioProducts } = this.props;
        const {
            FollowUpRequired,
            Objective,
            When,
            What,
            SelectedEffect,
            SelectedEngagementDate,
            SelectedPortfolioAction,
            SelectedPortfolioActionDate,
            SelectedPortfolioProducts,
            Pillars,
            SelectedTeam,
            SelectedAnalyst,
        } = this.state;
        const errorMessages = [];

        let actionKeyIssues = [];

        Object.keys(this.state.Pillars).map((key) => {
            if (key !== 'hasActions' && key !== 'ParentNoteEngageDate') {
                let keyIssues = this.state.Pillars[key]?.keyIssues?.filter(
                    (ki) => ki.Action !== null && ki.Action.EngagementType === 'Action' && ki.Action.Status === true && new Date(ki.Action.FollowUpDate) < new Date()
                );
                actionKeyIssues = [...actionKeyIssues, ...keyIssues];
            }
        });

        if (actionKeyIssues !== null && actionKeyIssues.length > 0) {
            errorMessages.push('Update action key issues so all follow up dates are later than today.');
        }

        if (SelectedAnalyst == null || SelectedAnalyst.length === 0) {
            errorMessages.push('Select an analyst.');
        }

        if (SelectedTeam == null || SelectedTeam.length === 0) {
            errorMessages.push('Select a team.');
        }

        const keyIssues = [...Pillars[PillarTypes.ENV.ID].keyIssues, ...Pillars[PillarTypes.GOV.ID].keyIssues, ...Pillars[PillarTypes.SOC.ID].keyIssues];
        if (!keyIssues.some((ki) => ki.IsSelected === true)) {
            errorMessages.push('Select at least one key issue.');
        }

        if (SelectedEngagementDate == null) {
            errorMessages.push('Enter the engagement date.');
        }

        if (Objective === '') {
            errorMessages.push('Enter an engagement objective.');
        }

        if (SelectedPortfolioAction != null && SelectedPortfolioAction.value > 0 && ['Buy', 'Sell'].indexOf(SelectedPortfolioAction.label) >= 0) {
            if (SelectedPortfolioActionDate === null) {
                errorMessages.push('Enter the portfolio action date.');
            }
            if (SelectedPortfolioProducts == null || SelectedPortfolioProducts.length === 0) {
                if (PortfolioProducts != null && PortfolioProducts.length > 0) {
                    errorMessages.push('Select one or more portfolio action products.');
                } else {
                    errorMessages.push('Select a team with products; then select products.');
                }
            }
        }

        if (SelectedEffect.value === 0) {
            errorMessages.push('Select the Effect on Investment Thesis');
        }

        if (FollowUpRequired && When === null) {
            errorMessages.push('Select a follow-up reminder date');
        }

        if (FollowUpRequired && What === '') {
            errorMessages.push('Enter the follow-up what');
        }

        if (this.state.ExternalAttendees != null) {
            const allNames = String(this.state.ExternalAttendees)
                .toLowerCase()
                .split(';')
                .map((i) => i.trim());

            const isLengthExceeded = allNames.reduce((acc, name) => {
                return acc || name.length > 1000;
            }, false);

            if (isLengthExceeded === true) {
                errorMessages.push('An external attendee name should not be more than 1000 characters');
            }
        }

        if (errorMessages.length > 0) {
            this.setState({ ErrorMessages: errorMessages, DisplayDialog: true });
        }

        return errorMessages.length === 0;
    };

    onSubmit = async (event) => {
        const NoteID = this.state.NoteID == null ? null : parseInt(this.state.NoteID, 10);
        const NoteTypeID = 2;

        const PortfolioActionProducts =
            this.state.SelectedPortfolioProducts != null
                ? this.state.SelectedPortfolioProducts.map((product) => ({
                      ProductID: product.value,
                      ProductName: product.label,
                  }))
                : [];

        const SelectedInternalAttendees = this.state.SelectedInternalAttendees != null ? this.state.SelectedInternalAttendees.map((user) => user.value) : [];

        const PortfolioActionDate =
            this.state.SelectedPortfolioActionDate != null && this.state.SelectedPortfolioActionDate !== '' ? toServerDate(this.state.SelectedPortfolioActionDate).toISO() : null;

        const SelectedEngagementDate = this.state.SelectedEngagementDate != null && this.state.SelectedEngagementDate !== '' ? toServerDate(this.state.SelectedEngagementDate).toISO() : null;

        const EngageFollowupDate = this.state.When != null && this.state.When !== '' ? toServerDate(this.state.When).toISO() : null;

        const envData = this.state.Pillars[PillarTypes.ENV.ID];
        const govData = this.state.Pillars[PillarTypes.GOV.ID];
        const socData = this.state.Pillars[PillarTypes.SOC.ID];

        const selectedEnvKIs = Array.isArray(envData.keyIssues) ? envData.keyIssues.filter((ki) => Boolean(ki.IsSelected || Boolean(ki.Action?.IsDeleted))) : [];
        const selectedGovKIs = Array.isArray(govData.keyIssues) ? govData.keyIssues.filter((ki) => Boolean(ki.IsSelected || Boolean(ki.Action?.IsDeleted))) : [];
        const selectedSocKIs = Array.isArray(socData.keyIssues) ? socData.keyIssues.filter((ki) => Boolean(ki.IsSelected) || Boolean(ki.Action?.IsDeleted)) : [];

        const deletedEKeyIssues = selectedEnvKIs.filter((ki) => !Boolean(ki.IsSelected) && Boolean(ki.Action?.IsDeleted));
        const deletedGKeyIssues = selectedGovKIs.filter((ki) => !Boolean(ki.IsSelected) && Boolean(ki.Action?.IsDeleted));
        const deletedSKeyIssues = selectedSocKIs.filter((ki) => !Boolean(ki.IsSelected) && Boolean(ki.Action?.IsDeleted));

        const selectedKeyIssues = [...selectedEnvKIs, ...selectedGovKIs, ...selectedSocKIs];

        //console.log('Submit-selectedKeyIssues', selectedKeyIssues);

        let json = {
            NoteID: NoteID,
            CompanyID: parseInt(this.props.Selected.CompanyID, 10),
            CalendarMeetingID: this.state.CalendarMeetingID,
            NoteTypeID: NoteTypeID,
            AnalystUserID: this.state.SelectedAnalyst == null ? null : parseInt(this.state.SelectedAnalyst.value, 10),
            UpdatedByUserID: parseInt(this.props.UserDetails.UserID, 10),
            TeamID: this.state.SelectedTeam == null ? null : parseInt(this.state.SelectedTeam?.value, 10),
            // E: envData.checked || selectedEnvKIs.length > 0,
            // G: govData.checked || selectedGovKIs.length > 0,
            // S: socData.checked || selectedSocKIs.length > 0,
            E: deletedEKeyIssues.length !== selectedEnvKIs.length,
            G: deletedGKeyIssues.length !== selectedGovKIs.length,
            S: deletedSKeyIssues.length !== selectedSocKIs.length,
            EOther: envData.other,
            GOther: govData.other,
            SOther: socData.other,
            KeyIssues: selectedKeyIssues,
            MSCIRating: this.props.MSCIRating.MSCIRating,
            MSCIConsensusRating: this.state.SelectedConsensusRating == null ? null : this.state.SelectedConsensusRating.value,
            MSCIConsensusInsight: this.state.MSCIConsensusInsight === '' ? null : this.state.MSCIConsensusInsight,
            EngageObjective: this.state.Objective,
            EngageBackground: this.state.Background,
            EngageScope: this.state.ScopeAndProcess,
            EngageOutCome: this.state.Outcomes,
            EngageFollowupDate: EngageFollowupDate,
            EngageFollowupNote: this.state.What,
            PortfolioActionID: this.state.SelectedPortfolioAction == null ? null : parseInt(this.state.SelectedPortfolioAction.value, 10),
            PortfolioActionDate: PortfolioActionDate,
            PortfolioActionNote: this.state.SelectedPortfolioActionNote,
            PortfolioActionProducts: PortfolioActionProducts,
            EffectID: this.state.SelectedEffect == null ? null : parseInt(this.state.SelectedEffect.value, 10),
            EffectInsight: this.state.EffectInsight,
            InternalAttendees: SelectedInternalAttendees,
            ExternalAttendees: this.state.ExternalAttendees == null ? '' : this.state.ExternalAttendees,
            EngageDate: SelectedEngagementDate,
        };

        await this.props.setDirtyFlagDispatcher(false);

        const note = await this.props.saveNoteDispatcher(json);
        const noteId = note.NoteID;
        const files = this.state.files;

        const fileKeys = files != null ? Object.keys(files) : [];
        const formData = {
            subdomain: subdomains.Attachments,
            noteId,
        };

        json.NoteID = noteId;
        this.setState({ uploadCount: fileKeys > 0 ? 0 : null });

        if (fileKeys.length !== 0) {
            await Promise.all(
                fileKeys.map((key, idx) => {
                    const item = files[key];
                    this.setState({ uploadCount: idx + 1 });
                    return uploadFile(item, formData, null, null, null, this.props.getPublisherDispatcher);
                })
            );
        }
        await this.props.generateNotePdfDispatcher(json.NoteID);
        this.props.history.push(this.props.location.state?.redirect || `/CompanyAnalysis/${this.props.Selected.CompanyID}`);
        this.setState({ uploadCount: null });
    };

    onCancel = () => {
        this.props.setDirtyFlagDispatcher(false).then(() => {
            this.props.history.push(this.props.location.state?.redirect || `/CompanyAnalysis/${this.props.Selected.CompanyID}`);
        });
    };

    onCloseDialog = () => {
        this.setState({ ErrorMessages: [] });
    };

    onDelete = () => {
        this.props
            .deleteNoteDataDispatcher(this.state.NoteID)
            .then(() => this.props.setDirtyFlagDispatcher(false))
            .then(() => this.props.history.replace(`/CompanyAnalysis/${this.props.Selected.CompanyID}`));
    };

    // getParentNoteID = (pillars) => {
    //     Object.keys(pillars).map((key) => {
    //         let actions = pillars[key].Actions.filter((a) => a.ParentID !== null);
    //         parentID = actions !== undefined && actions !== null ? action[0].ParentID : null;
    //         if (parentID !== null) return parentID;
    //     });

    //     return null;
    // };

    render() {
        const { classes, UserDetails, MSCIRating, Selected } = this.props;
        const { horizontalWidth, isRightDrawerOpen, Pillars, IsLoading } = this.state;
        const companyID = Selected != null && Selected.CompanyID != null ? Selected.CompanyID : null;
        const sectorGuide = MSCIRating != null ? MSCIRating.SectorGuide : null;

        let isDisabled = !this.state.IsEditable;
        let isPortfolioActionDisabled = true; //disabled
        const isVertical = horizontalWidth < minimumHorizontalWidth && isRightDrawerOpen;
        let parentNoteEngageDate = Pillars?.ParentNoteEngageDate;

        //console.log('Pillars', Pillars);
        //console.log('ParentEngagementDate', parentNoteEngageDate);

        if (UserDetails.Permissions.CanWrite) {
            if (this.state.IsEditable) {
                isPortfolioActionDisabled = false; //enabled
            } else if (this.state.IsPortfolioActionEditable) {
                isPortfolioActionDisabled = false; //enabled
            }
        }

        const { hasActions } = Pillars;

        return IsLoading === true ? null : (
            <div className={cn(classes.content, { [classes.contentShift]: isRightDrawerOpen })}>
                <Drawer open={isRightDrawerOpen} onToggle={this.handleDrawerToggle} />
                <SubHeader inputType={inputType} open={isRightDrawerOpen} onToggleDrawer={this.handleDrawerToggle} onPinDrawer={this.handleDrawerToggle} />
                {hasActions == null ? (
                    <ActionTracking pillars={Pillars} readOnly={isDisabled} onChange={this.handleActionsChange} />
                ) : (
                    <>
                        <Guides sectorGuide={sectorGuide} />
                        <Paper
                            className={cn(classes.root, classes.analystTeamSection, {
                                [classes.analystTeamSectionSmall]: isRightDrawerOpen,
                            })}
                            elevation={1}
                        >
                            <div>
                                <SearchableDropdown
                                    id="Analysts"
                                    dropdownName={'Analyst'}
                                    dropdownItems={this.props.Analysts}
                                    placeholder={'Select Analyst'}
                                    defaultValue={this.state.SelectedAnalyst}
                                    InputLabelProps={{
                                        className: cn({
                                            'required asterisk': this.state.IsEditable,
                                        }),
                                        shrink: true,
                                    }}
                                    onChange={this.dropdownOnChange('Analyst')}
                                    isDisabled={isDisabled}
                                />
                            </div>
                            <div>
                                <SearchableDropdown
                                    id="Teams"
                                    dropdownName={'Team'}
                                    dropdownItems={this.props.UserTeams}
                                    placeholder={'Select Team'}
                                    defaultValue={this.state.SelectedTeam}
                                    InputLabelProps={{
                                        className: cn({
                                            'required asterisk': this.state.IsEditable,
                                        }),
                                        shrink: true,
                                    }}
                                    onChange={this.dropdownOnChange('Team')}
                                    isDisabled={isDisabled}
                                />
                            </div>
                        </Paper>
                        <KeyIssues data={Pillars} inputType={InputTypes.ENGAGEMENT} readOnly={isDisabled} vertical={isVertical} onChange={this.handleKeyIssuesChange} />
                        {hasActions === true && <ActionTracking pillars={Pillars} readOnly={isDisabled} onChange={this.handleActionsChange} isRightDrawerOpen={isRightDrawerOpen} />}
                        <Paper
                            className={cn(classes.dataForm, classes.root, {
                                [classes.dataFormSmall]: isRightDrawerOpen,
                            })}
                            elevation={1}
                        >
                            <div className={classes.formSections}>
                                <MeetingDateInput
                                    disabled={isDisabled}
                                    editable={this.state.IsEditable}
                                    onChange={this.handleMeetingDataChange}
                                    engagementDate={this.state.SelectedEngagementDate}
                                    meetingID={this.state.CalendarMeetingID}
                                    parentEngageDate={parentNoteEngageDate}
                                />
                                <div className="formSection">
                                    <TextField
                                        id="standard"
                                        label="Objective"
                                        placeholder="Enter objective"
                                        fullWidth
                                        multiline
                                        InputLabelProps={{
                                            className: cn({
                                                'required asterisk': this.state.IsEditable,
                                            }),
                                            shrink: true,
                                        }}
                                        onChange={this.handleInputOnChange('objective')}
                                        inputProps={{ maxLength: 2048 }}
                                        value={this.state.Objective}
                                        data-tip
                                        data-for="Tooltip_Objective"
                                        disabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_Objective">Reason for having the engagement meeting with the company</Tooltip>
                                </div>
                                <div className="formSection">
                                    <TextField
                                        id="background"
                                        label="Background"
                                        placeholder="Enter Background"
                                        fullWidth
                                        multiline
                                        InputLabelProps={{ shrink: true }}
                                        onChange={this.handleInputOnChange('background')}
                                        value={this.state.Background}
                                        data-tip
                                        data-for="Tooltip_Background"
                                        disabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_Background">
                                        <p>Contextual information of what's driving the noted ESG concern in the objective</p>
                                        <p>(ex: one sentence describing the company’s business and the details of the key concern(s) noted in the objective).</p>
                                    </Tooltip>
                                </div>
                                <div className="formSection">
                                    <TextField
                                        id="scopeProcess"
                                        label="Scope of the Engagement"
                                        placeholder="Enter Scope of the Engagement"
                                        fullWidth
                                        multiline
                                        InputLabelProps={{ shrink: true }}
                                        onChange={this.handleInputOnChange('scopeandprocess')}
                                        value={this.state.ScopeAndProcess}
                                        data-tip
                                        data-for="Tooltip_ScopeProcess"
                                        disabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_ScopeProcess">Describe any policies or process that the company has in place at present in its efforts to address the concern.</Tooltip>
                                </div>
                                <div className="formSection">
                                    <TextField
                                        id="outcomes"
                                        label="Outcomes"
                                        placeholder="Enter Outcomes"
                                        fullWidth
                                        multiline
                                        InputLabelProps={{ shrink: true }}
                                        onChange={this.handleInputOnChange('outcomes')}
                                        value={this.state.Outcomes}
                                        data-tip
                                        data-for="Tooltip_Outcomes"
                                        disabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_Outcomes">State how the company has responded and what progress the analysts expects to see on the company going forward.</Tooltip>
                                </div>
                                <div className="formSection">
                                    <Attachments
                                        files={this.props.Attachments}
                                        metadata={{
                                            companyId: companyID,
                                            noteId: this.state.NoteID == null ? this.props.match.params.noteID : this.state.NoteID,
                                            userId: this.props.UserDetails.UserID,
                                        }}
                                        editable={this.state.IsEditable}
                                        onChange={this.handleAttachmentChange}
                                        onDelete={this.handleAttachmentDelete}
                                        uploadCount={this.state.uploadCount}
                                    />
                                </div>
                            </div>
                            <div className={classes.formSections}>
                                <div className="formSection">
                                    <InputLabel style={{ fontSize: pxToRem(12), width: '100%' }}>
                                        <span data-tip data-for="Tooltip_RatingConsensus" style={{ verticalAlign: 'middle' }}>
                                            MSCI ESG Rating Consensus
                                        </span>
                                        {this.props.MSCIRating && this.props.MSCIRating.MSCIRating && <span className={classes.msciRatingPill}>{this.props.MSCIRating.MSCIRating}</span>}
                                        <div style={{ display: 'inline-block', width: '100px', verticalAlign: 'middle' }}>
                                            <SearchableDropdown
                                                id="Consensus"
                                                dropdownItems={this.props.Consensus}
                                                placeholder={'Select'}
                                                defaultValue={this.state.SelectedConsensusRating}
                                                onChange={this.dropdownOnChange('Consensus')}
                                                isDisabled={isDisabled}
                                            />
                                        </div>
                                    </InputLabel>
                                    <Tooltip id="Tooltip_RatingConsensus">
                                        <p>Analyst's view of the company's ESG performance relative to MSCI's ESG rating</p>
                                        <p>+ Better than MSCI's</p>
                                        <p>- Worse than MSCI's Rating</p>
                                        <p>= Neutral/Agrees with MSCI</p>
                                    </Tooltip>
                                </div>
                                {this.state.SelectedConsensusRating != null && this.state.SelectedConsensusRating.value !== 'N/A' && (
                                    <div className="formSection">
                                        <TextField
                                            id="MSCIRatingInsight"
                                            label="MSCI Consensus Rating Insight"
                                            placeholder="Enter MSCI consensus insight"
                                            multiline
                                            InputLabelProps={{ shrink: true }}
                                            className={classes.textFieldOptionalInsight}
                                            value={this.state.MSCIConsensusInsight}
                                            inputProps={{ maxLength: 1024 }}
                                            onChange={(e) => this.setState({ MSCIConsensusInsight: e.target.value })}
                                            disabled={isDisabled}
                                        />
                                    </div>
                                )}
                                <div className="formSection">
                                    <SearchableDropdown
                                        data-tip
                                        data-for="Tooltip_PortfolioActions"
                                        id="PortfolioAction"
                                        dropdownName={'Portfolio Actions'}
                                        dropdownItems={this.props.PortfolioActions}
                                        placeholder={'Select'}
                                        defaultValue={this.state.SelectedPortfolioAction}
                                        onChange={this.dropdownOnChange('PortfolioAction')}
                                        isDisabled={isPortfolioActionDisabled}
                                    />
                                    <Tooltip id="Tooltip_PortfolioActions">
                                        <p>
                                            PM’s decision to buy or sell the stock based on the company engagement meeting (in-person or call) or research on the company’s ESG performance. Defaulted
                                            at N/A as an optional input field.
                                        </p>
                                        <p>
                                            <em>
                                                Research Only option is to be selected if the engagement meeting was simply a part of the company’s ESG research without an intention to directly
                                                incorporate the findings into investment process at the time of submitting the post.
                                            </em>
                                        </p>
                                    </Tooltip>
                                    {this.state.SelectedPortfolioAction != null && this.state.SelectedPortfolioAction.value > 0 && (
                                        <>
                                            <div className="formSubSection">
                                                <DatePicker
                                                    label="Portfolio Action Date"
                                                    value={this.state.SelectedPortfolioActionDate}
                                                    onChange={this.inputDateChange('portfolioactiondate')}
                                                    animateYearScrolling={false}
                                                    InputLabelProps={{
                                                        className: cn({
                                                            'required asterisk':
                                                                !isPortfolioActionDisabled &&
                                                                this.state.SelectedPortfolioAction != null &&
                                                                ['Buy', 'Sell'].indexOf(this.state.SelectedPortfolioAction.label) >= 0,
                                                        }),
                                                        shrink: true,
                                                    }}
                                                    disabled={isPortfolioActionDisabled}
                                                />
                                            </div>
                                            <div className="formSubSection">
                                                <MultiSelect
                                                    id="PortfolioActionProducts"
                                                    dropdownName={'Portfolio Action Products'}
                                                    dropdownItems={this.props.PortfolioProducts}
                                                    placeholder={'Select Products'}
                                                    defaultValue={this.state.SelectedPortfolioProducts}
                                                    onChange={this.dropdownOnChange('PortfolioActionProducts')}
                                                    InputLabelProps={{
                                                        className: cn({
                                                            'required asterisk':
                                                                !isPortfolioActionDisabled &&
                                                                this.state.SelectedPortfolioAction != null &&
                                                                ['Buy', 'Sell'].indexOf(this.state.SelectedPortfolioAction.label) >= 0,
                                                        }),
                                                    }}
                                                    isDisabled={isPortfolioActionDisabled}
                                                />
                                            </div>
                                            <div className="formSubSection">
                                                <TextField
                                                    id="PortfolioActionNote"
                                                    label="Portfolio Action Note"
                                                    placeholder="Enter a note about this action"
                                                    multiline
                                                    InputLabelProps={{ shrink: true }}
                                                    className={classes.textFieldPortfolioActionNote}
                                                    value={this.state.SelectedPortfolioActionNote}
                                                    inputProps={{ maxLength: 2048 }}
                                                    onChange={(e) =>
                                                        this.setState({
                                                            SelectedPortfolioActionNote: e.target.value,
                                                        })
                                                    }
                                                    disabled={isPortfolioActionDisabled}
                                                />
                                            </div>
                                        </>
                                    )}
                                </div>
                                <div className="formSection">
                                    <SearchableDropdown
                                        data-tip
                                        data-for="Tooltip_InvestmentThesis"
                                        id="InvestmentThesis"
                                        dropdownName={'Effect on Investment Thesis'}
                                        dropdownItems={this.props.Effects}
                                        InputLabelProps={{
                                            className: cn({
                                                'required asterisk': this.state.IsEditable,
                                            }),
                                        }}
                                        placeholder={'Select'}
                                        defaultValue={this.state.SelectedEffect}
                                        onChange={this.dropdownOnChange('Effect')}
                                        isDisabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_InvestmentThesis">
                                        <p>
                                            Any change on the investment thesis based on the company engagement meeting (in-person or call) or research on the company's ESG performance. Defaulted at
                                            N/A as an optional input field. Optional insight field can be entered to explain any background reasons for making such change on the investment thesis.
                                        </p>
                                    </Tooltip>
                                    {this.state.SelectedEffect !== undefined && this.state.SelectedEffect.value > 0 && (
                                        <div className="formSubSection">
                                            <TextField
                                                id="effectInsight"
                                                label="Optional Insight"
                                                placeholder="Enter optional insight"
                                                multiline
                                                className={classes.textFieldOptionalInsight}
                                                value={this.state.EffectInsight}
                                                name="EffectInsight"
                                                onChange={this.handleInputOnChange('effectinsight')}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 1024 }}
                                                disabled={isDisabled}
                                            />
                                        </div>
                                    )}
                                </div>
                                <div className="formSection">
                                    <span className={classes.followupLabel}>Follow-up required {this.getAddNotificationFrequencyAlert()}</span>
                                    <RadioGroup className={classes.followupRadioGroup} row value={this.state.FollowUpRequired.toString()} onChange={this.handleChange}>
                                        <FormControlLabel
                                            label="Yes"
                                            classes={{
                                                root: cn(classes.controlLabel, classes.radioButton, 'RadioButton'),
                                            }}
                                            value="true"
                                            control={
                                                <Radio
                                                    className={classes.radioButton}
                                                    checked={this.state.FollowUpRequired}
                                                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                                                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                                                    disabled={isDisabled}
                                                />
                                            }
                                        />
                                        <FormControlLabel
                                            label="No"
                                            classes={{
                                                root: cn(classes.controlLabel, classes.radioButton, 'RadioButton'),
                                            }}
                                            value="false"
                                            control={
                                                <Radio
                                                    className={classes.radioButton}
                                                    checked={!this.state.FollowUpRequired}
                                                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                                                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                                                    disabled={isDisabled}
                                                />
                                            }
                                        />
                                    </RadioGroup>
                                    <Tooltip id="Tooltip_FollowUpRequired">
                                        <p>
                                            If selected yes, the analyst who submits the post (NOT including the internal/external attendees listed in the post) will be reminded via email. Will be
                                            available for V2 of the tool.
                                        </p>
                                    </Tooltip>
                                    {this.state.FollowUpRequired && (
                                        <>
                                            <div className={cn('formSubSection', classes.reminderNote)}>
                                                Follow-up notifications are sent out in advance. If you set a follow-up date for the current notification period, the reminder won't be included in your
                                                notifications.
                                            </div>
                                            <div className="formSubSection">
                                                <DatePicker
                                                    label="Reminder Date"
                                                    value={this.state.When}
                                                    onChange={this.inputDateChange('when')}
                                                    animateYearScrolling={false}
                                                    InputLabelProps={{
                                                        className: cn({
                                                            'required asterisk': this.state.IsEditable,
                                                        }),
                                                        shrink: true,
                                                    }}
                                                    disabled={isDisabled}
                                                />
                                            </div>
                                            <div className="formSubSection">
                                                <TextField
                                                    id="what"
                                                    label="What"
                                                    placeholder="Enter What"
                                                    fullWidth
                                                    multiline
                                                    InputLabelProps={{
                                                        className: cn({
                                                            'required asterisk': this.state.IsEditable,
                                                        }),
                                                        shrink: true,
                                                    }}
                                                    onChange={this.handleInputOnChange('what')}
                                                    value={this.state.What}
                                                    inputProps={{ maxLength: 1024 }}
                                                    disabled={isDisabled}
                                                />
                                            </div>
                                        </>
                                    )}
                                </div>
                                <div className="formSection">
                                    <MultiSelect
                                        data-tip
                                        data-for="Tooltip_InternalAttendees"
                                        id="internalAttendees"
                                        dropdownName={'Internal Attendees'}
                                        dropdownItems={this.props.Analysts}
                                        placeholder={'Select attendees'}
                                        defaultValue={this.state.SelectedInternalAttendees}
                                        onChange={this.dropdownOnChange('InternalAttendees')}
                                        isDisabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_InternalAttendees">
                                        <p>Attendees from AB.</p>
                                    </Tooltip>
                                </div>
                                <div className="formSection">
                                    <TextField
                                        id="attendees"
                                        label="External Attendees ( Please enter the names separated by ; )"
                                        placeholder="Enter external attendees"
                                        fullWidth
                                        multiline
                                        InputLabelProps={{ shrink: true }}
                                        onChange={this.handleInputOnChange('externalattendees')}
                                        value={this.state.ExternalAttendees}
                                        inputProps={{ maxLength: 2048 }}
                                        data-tip
                                        data-for="Tooltip_ExternalAttendees"
                                        disabled={isDisabled}
                                    />
                                    <Tooltip id="Tooltip_ExternalAttendees">
                                        <p>Attendees from a company outside of AB.</p>
                                    </Tooltip>
                                </div>
                            </div>
                        </Paper>
                        {(this.state.IsEditable || !isPortfolioActionDisabled) && (
                            <div className="small required message">
                                Fields marked with <span className="required asterisk"></span> are required.
                            </div>
                        )}
                        <div className={classes.actions}>
                            <Actions
                                onSubmit={this.onSubmit}
                                onCancel={this.onCancel}
                                canDelete={this.state.NoteID != null && this.state.IsEditable}
                                canEdit={(this.state.IsEditable || this.state.IsPortfolioActionEditable) && UserDetails.Permissions.CanWrite}
                                onDelete={this.onDelete}
                                validator={this.validate}
                            />

                            {this.state.NoteID != null && (
                                <Downloader useApiResource={true} uri={`/notes/${this.state.NoteID}/print`}>
                                    <Button variant="contained" color="primary" className={classes.button}>
                                        Print
                                    </Button>
                                </Downloader>
                            )}
                        </div>
                    </>
                )}
                <ErrorDialog onClose={this.onCloseDialog} messages={this.state.ErrorMessages} />
                {!!this.props.Fetching && <LoadingOverlay />}
            </div>
        );
    }
}

EngagementInput.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withRouter(withStyles(styles)(EngagementInput));

const TextField = (props) => {
    const { onChange, value, ...rest } = props;

    const [text, setText] = React.useState('');
    const handleBlur = (evt) => {
        if (onChange) onChange(evt);
    };
    const handleChange = (evt) => {
        setText(evt.target.value);
    };

    React.useEffect(() => {
        if (value != null) {
            setText(value);
        }
    }, [value]);

    return <MuiTextField {...rest} value={text} onBlur={handleBlur} onChange={handleChange} />;
};
