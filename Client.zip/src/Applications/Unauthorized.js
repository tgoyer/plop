import React from 'react';

import cn from 'classnames';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import { pxToRem } from '../Utils/layoutHelper';

const styles = (theme) => ({
    root: {
        ...theme.mixins.gutters(),
        paddingTop: 10,
        paddingBottom: 10,
    },
    actionContent: {
        margin: 10,
        display: 'flex',
        alignItems: 'center',
    },
    actionIcon: {
        color: '#c33',
        fontSize: pxToRem(35),
        float: 'left',
        padding: '0 20px',
    },
});

const Unauthorized = ({ classes }) => {
    return (
        <div style={{ padding: '0 25px' }}>
            <div className="row">
                <div className="col-xs-10 col-md-8 col-lg-6">
                    <Paper className={classes.root} elevation={1}>
                        <div className={classes.actionContent}>
                            <i className={cn('fas', 'fa-exclamation-triangle', classes.actionIcon)} aria-hidden="true"></i>
                            <span>
                                You are not authorized to view this screen. To request access, please submit an{' '}
                                <a href="http://erequest.acml.com/" rel="noopener noreferrer" target="_blank">
                                    eRequest
                                </a>{' '}
                                for ESIGHT.
                            </span>
                        </div>
                    </Paper>
                </div>
            </div>
        </div>
    );
};

export default withStyles(styles)(Unauthorized);
