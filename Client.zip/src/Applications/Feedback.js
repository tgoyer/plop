import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';

import Dialog from 'UIComponents/MaterialUI/CommonDialog';
import SearchableDropdown from 'UIComponents/MaterialUI/SearchableDropdown';

import { saveFeedback } from 'store/FeedbackModule';

import { isNullOrEmpty } from 'Utils/stringHelper';

const CATEGORIES = {
    Home: 'Home',
    'Research Input': 'Research Input',
    'Engagement Input': 'Engagement Input',
    'Company Analysis': 'Company Analysis',
    'Portfolio View': 'Portfolio',
    'Knowledge Center': 'Knowledge Center',
    'Team Contacts': 'Team Contacts',
    Feedback: 'Feedback',
    'User Preferences': 'User Preferences',
};

const categoryOptions = Object.keys(CATEGORIES).map((key) => ({
    value: key,
    label: CATEGORIES[key],
}));

const styles = (theme) => ({
    root: {
        ...theme.mixins.gutters(),
        padding: '12px 16px',
        margin: theme.spacing(1),
        maxWidth: 500,
        width: '100%',
    },
    button: {
        ...theme.mixins.gutters(),
        padding: '12px 16px',
        margin: theme.spacing(1),
        maxWidth: 100,
        width: '100%',
    },
    textField: {
        width: '100%',
    },
});

const Feedback = ({ classes }) => {
    const dispatch = useDispatch();
    const user = useSelector((state) => state.UserReducer.UserInfo.Data);

    const [category, setCategory] = React.useState('');
    const [comment, setComment] = React.useState('');
    const [displayDialog, setDisplayDialog] = React.useState(false);

    const disableButton = () => isNullOrEmpty(category) || isNullOrEmpty(comment);
    const handleCategoryChange = (value) => setCategory(isNullOrEmpty(value) ? '' : value);
    const handleCommentChange = (event) => setComment(isNullOrEmpty(event?.target?.value) ? '' : event.target.value);

    const handleReset = () => {
        setCategory('');
        setComment('');
        setDisplayDialog(false);
    };

    const handleSubmitFeedback = async (event) => {
        const UserID = user.UserID;
        await dispatch(
            saveFeedback({
                UserID,
                Comment: String(comment).trim(),
                Category: category.value,
            })
        );

        setDisplayDialog(true);
    };

    return (
        <>
            <Paper className={classes.root} elevation={1}>
                <SearchableDropdown
                    id="categoryList"
                    dropdownName={'Category'}
                    dropdownItems={categoryOptions}
                    defaultValue={category}
                    onChange={handleCategoryChange}
                />
                <TextField
                    id="commentField"
                    label="Feedback Comments"
                    placeholder="Enter Feedback Comments"
                    className={classes.textField}
                    multiline
                    margin="normal"
                    value={comment}
                    onChange={handleCommentChange}
                    inputProps={{ maxLength: 2048 }}
                    InputLabelProps={{
                        className: 'required asterisk',
                        shrink: true,
                    }}
                />
            </Paper>
            <Button className={classes.button} onClick={handleSubmitFeedback} disabled={disableButton()} variant="contained" color="primary">
                Submit
            </Button>
            <Dialog title="Thank you!" open={displayDialog} showActions={true} onClose={handleReset} isInformation={true}>
                Thank you for your feedback. This information will help us provide the best experience possible!
            </Dialog>
        </>
    );
};

export default withStyles(styles)(Feedback);
