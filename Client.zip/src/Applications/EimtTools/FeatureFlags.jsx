import React, { Fragment, useEffect, useMemo, useState } from 'react';
import cn from 'classnames';
import { useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import Button from 'componentlibrary/buttons/Button';
import Toggle from 'componentlibrary/toggle/Toggle';
import Tooltip from 'componentlibrary/tooltip/Tooltip';
import { Select, toOptionList } from 'components/Form';

import useFeatureFlags from 'hooks/data/useFeatureFlags';
import { hasEntries } from 'Utils/arrayHelpers';
import { useDebug } from '@spiffdog/spiffy-hooks';

const styles = (theme) => ({
    paper: {
        display: 'grid',
        gridTemplateColumns: 'minmax(250px, auto) 1fr',

        backgroundColor: '#fff',
        border: '1px solid #ccc',
        height: '100%',
        overflow: 'hidden',
    },
    addNew: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        padding: 8,
        background: '#f0f0f0',
        border: 'none',
        borderRadius: 4,
    },
    grid: {
        display: 'grid',
        gridTemplateColumns: 'minmax(250px, auto) 1fr',
        gap: 12,

        alignItems: 'center',
        justifyContent: 'center',
        '& .actions': {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-end',
            alignItems: 'center',
            gap: 12,

            height: '100%',
            padding: 4,
        },
        '& .title': {
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',

            padding: 4,
            fontWeight: 700,
            height: '100%',
        },
        '& .contents': {
            display: 'contents',
            '&:hover > div': {
                backgroundColor: '#f9f9f9',
            },
        },
    },
    list: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,

        background: '#fff',
        borderRight: '1px solid #ccc',
        padding: 8,

        '& .flag': {
            width: '100%',
        },
    },
    detail: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        padding: 8,

        background: '#f9f9f9',
        border: 'none',
        borderRadius: 4,
    },
    actionButton: {
        background: 'transparent',
        border: 0,
        cursor: 'pointer',
        padding: 12,
        width: '100%',

        '&:hover,&.active': {
            background: '#dfdfdf',
        },
    },
});

const getOptions = (all, filtered, field) => {
    const ids = filtered?.map((t) => t[field]) ?? [];
    return all?.filter((t) => !ids?.includes(t[field])) ?? [];
};

const FeatureFlags = ({ classes }) => {
    const { flags, users, teams, deleteTeam, deleteUser, saveFlag, saveTeams, saveUsers } = useFeatureFlags();

    const [selectedFlag, setSelectedFlag] = useState(null);
    const [filteredTeams, setFilteredTeams] = useState([]);
    const [filteredUsers, setFilteredUsers] = useState([]);

    const allAnalysts = useSelector((state) => state.DimensionReducer.Analysts);
    const allTeams = useSelector((state) => state.DimensionReducer.Teams);

    const handleFlagEnableChange = () => {
        setSelectedFlag((f) => ({
            ...f,
            IsEnabled: !f.IsEnabled,
        }));
        //saveFlag(updated);
    };

    const handleTeamEnableChange = (team) => (evt) => {
        const updated = {
            ...team,
            IsEnabled: evt.target.checked,
        };
        const teams = filteredTeams.map((t) => (t.TeamFlagID === team.TeamFlagID ? updated : t));
        setFilteredTeams(teams);
        //saveTeam(updated);
    };
    const handleTeamSelectChange = (id) => {
        const found = allTeams.find((t) => t.TeamID === id);
        setFilteredTeams([
            ...filteredTeams,
            {
                TeamFlagID: null,
                FeatureFlagID: selectedFlag.FeatureFlagID,
                TeamID: found.TeamID,
                Name: found.TeamName,
                IsEnabled: false,
            },
        ]);
    };

    const handleFlagSelection = (flag) => {
        setSelectedFlag(flag);
    };

    useEffect(() => {
        const flagID = selectedFlag?.FeatureFlagID;
        setFilteredTeams(teams?.filter((t) => t.FeatureFlagID === flagID));
        setFilteredUsers(users?.filter((u) => u.FeatureFlagID === flagID));
    }, [selectedFlag, teams, users]);

    const teamOptions = useMemo(() => toOptionList(getOptions(allTeams, filteredTeams, 'TeamID'), 'TeamID', 'TeamName'), [allTeams, filteredTeams]);

    useDebug(teamOptions, 'options');

    return flags === null ? null : (
        <div className={classes.paper}>
            <div className={classes.list}>
                {hasEntries(flags) &&
                    flags.map((flag) => {
                        return (
                            <Button key={flag.FeatureFlagID} className={cn('flag', { secondary: flag.FeatureFlagID !== selectedFlag?.FeatureFlagID })} onClick={() => handleFlagSelection(flag)}>
                                {flag.Name}
                            </Button>
                        );
                    })}
            </div>
            <div className={classes.detail}>
                {selectedFlag != null && (
                    <>
                        <CollapsablePanel defaultOpen={true} title="Global Settings" actions={<Button onClick={() => saveFlag(selectedFlag)}>Save</Button>}>
                            <div className={classes.grid}>
                                <div className="title">Enabled</div>
                                <div className="actions">
                                    <Tooltip
                                        trigger={
                                            <div>
                                                <Toggle checked={selectedFlag.IsEnabled} onChange={handleFlagEnableChange} />
                                            </div>
                                        }
                                    >
                                        <div>Enable or disable the feature flag.</div>
                                        <div>This value can be overridden by team flag or user flag value.</div>
                                    </Tooltip>
                                </div>
                            </div>
                        </CollapsablePanel>
                        <CollapsablePanel defaultOpen={true} title="Teams" actions={<Button onClick={() => saveTeams(filteredTeams)}>Save</Button>}>
                            {hasEntries(filteredTeams) && (
                                <>
                                    <div className={classes.grid}>
                                        {filteredTeams.map((t) => {
                                            return (
                                                <div key={t.TeamFlagID} className="contents">
                                                    <div className="title">{t.Name}</div>
                                                    <div className="actions">
                                                        <Toggle checked={t.IsEnabled} onChange={handleTeamEnableChange(t)} />
                                                        <Button className="alert">
                                                            <i className="fas fa-2x fa-trash-alt"></i>
                                                        </Button>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                        <div className="title">
                                            <Select onChange={(option) => handleTeamSelectChange(option.value)} options={teamOptions} />
                                        </div>
                                        <div className="actions">
                                            <Button className="secondary">
                                                <i className="fas fa-2x fa-arrow-alt-circle-right"></i>
                                            </Button>
                                        </div>
                                    </div>
                                </>
                            )}
                        </CollapsablePanel>
                        <CollapsablePanel defaultOpen={true} title="Users">
                            {hasEntries(filteredUsers) && (
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Enabled</th>
                                            <th>Name</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredUsers.map((u) => {
                                            return (
                                                <tr>
                                                    <td>
                                                        <i className={cn('far', { 'fa-check-square': u.IsEnabled, 'fa-square': !u.IsEnabled })}></i>
                                                    </td>
                                                    <td>
                                                        <div>{u.Name}</div>
                                                    </td>
                                                    <td>
                                                        <i className="far fa-trash-alt"></i>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            )}
                        </CollapsablePanel>
                    </>
                )}
            </div>
        </div>
    );
};

export default withStyles(styles)(FeatureFlags);

const panelStyles = (theme) => ({
    panel: {
        border: `1px solid #ccc`,
        borderRadius: 4,
        '& > summary': {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',

            background: '#efefef',
            cursor: 'pointer',
            fontSize: '1.2rem',
            fontWeight: 700,
            padding: 8,
        },
        '&[open] > summary': {
            borderBottom: `1px solid #ccc`,
        },
        '& > div.content': {
            background: '#fff',
            padding: 8,
        },
    },
});
const CollapsablePanelBase = ({ classes, children, actions, defaultOpen = false, title = 'Header' }) => {
    return (
        <details className={classes.panel} open={defaultOpen}>
            <summary>
                {title != null && <div className="title">{title}</div>}
                {actions != null && <div className="actions">{actions}</div>}
            </summary>
            <div className="content">{children}</div>
        </details>
    );
};
const CollapsablePanel = withStyles(panelStyles)(CollapsablePanelBase);
