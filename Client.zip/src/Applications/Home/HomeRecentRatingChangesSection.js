import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getMsciRatingChanges } from '../../store/GridDataModule';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import HomeRecentRatingChangesGrid from '../Grids/HomeRecentRatingChangesGrid';
import { pxToRem } from '../../Utils/layoutHelper';

const styles = (theme) => ({
    header: {
        borderRadius: '4px 4px 0 0',
        color: '#ffffff',
        fontSize: pxToRem(16),
        fontWeight: 700,
        height: 'auto',
        letterSpacing: 1,
        margin: 0,
        padding: '8px 16px',
        backgroundColor: theme.palette.primary.main,
        width: '100%',
    },
    paper: {
        fontSize: pxToRem(12),
    },
    grid: {
        '& .wj-flexgrid': {
            height: 'calc(50vh - 145px)',
            maxHeight: 'calc(50vh - 145px)',
        },
    },
    '@media (max-width: 990px)': {
        header: {
            fontSize: pxToRem(14),
            padding: '8px 8px',
        },
        grid: {
            '& .wj-flexgrid': {
                height: 'calc(25vh - 105px)',
                maxHeight: 'calc(25vh - 105px)',
            },
        },
    },
});

class HomeRecentRatingChangesSection extends React.Component {
    componentWillReceiveProps(nextProps) {
        if (this.props.MSCIRecentRatingsInfo == null || this.props.PastDays !== nextProps.PastDays) {
            this.props.fetchMSCIRecentRatingsDataDispatcher(parseInt(nextProps.PastDays, 10));
        }
    }

    render() {
        const { classes } = this.props;
        let recentRatingChangesData = this.props.MSCIRecentRatingsInfo;

        return (
            <Paper className={classes.paper} elevation={1}>
                <legend className={classes.header}>MSCI Rating Changes</legend>
                <div className={classes.grid}>
                    <HomeRecentRatingChangesGrid onCompanyNameClick={this.props.onCompanyNameClick} RecentRatingChangesData={recentRatingChangesData} />
                </div>
            </Paper>
        );
    }
}

HomeRecentRatingChangesSection.propTypes = {
    classes: PropTypes.object.isRequired,
    theme: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
    MSCIRecentRatingsInfo: state.GridDataReducer.MSCIRecentRatingsInfo.Data,
});

const mapDispatchToProps = (dispatch) => ({
    fetchMSCIRecentRatingsDataDispatcher: (pastDays) => dispatch(getMsciRatingChanges(pastDays)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles, { withTheme: true })(HomeRecentRatingChangesSection));
