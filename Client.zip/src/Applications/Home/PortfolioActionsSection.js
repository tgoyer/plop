import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getPortfolioActions } from '../../store/GridDataModule';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import PortfolioActionsGrid from '../Grids/PortfolioActionsGrid';
import LoadingPanel from '../../UIComponents/LoadingPanel';
import { pxToRem } from '../../Utils/layoutHelper';

const styles = (theme) => ({
    header: {
        borderRadius: '4px 4px 0 0',
        color: '#ffffff',
        fontSize: pxToRem(16),
        fontWeight: 700,
        height: 'auto',
        letterSpacing: 1,
        margin: 0,
        padding: '8px 16px',
        backgroundColor: theme.palette.primary.main,
        width: '100%',
    },
    paper: {
        fontSize: pxToRem(12),
        marginTop: 10,
    },
    grid: {
        '& .wj-flexgrid': {
            height: 'calc(50vh - 145px)',
            maxHeight: 'calc(50vh - 145px)',
        },
    },
    '@media (max-width: 990px)': {
        header: {
            fontSize: pxToRem(14),
            padding: '8px 8px',
        },
        grid: {
            '& .wj-flexgrid': {
                height: 'calc(25vh - 105px)',
                maxHeight: 'calc(25vh - 105px)',
            },
        },
    },
});

const PortfolioActionsSection = (props) => {
    const { PastDays, PortfolioActionsInfo, classes, fetchPortfolioActionsDataDispatcher, onCompanyNameClick } = props;

    const fetchPortfolioActions = React.useCallback(
        (days) => {
            fetchPortfolioActionsDataDispatcher(days);
        },
        [fetchPortfolioActionsDataDispatcher]
    );
    React.useEffect(() => {
        fetchPortfolioActions(parseInt(PastDays, 10));
    }, [fetchPortfolioActions, PastDays]);

    return (
        <Paper className={classes.paper} elevation={1}>
            <legend className={classes.header}>Portfolio Action Changes</legend>
            <div className={classes.grid}>
                {PortfolioActionsInfo.isLoading || PortfolioActionsInfo.Data === null ? (
                    <LoadingPanel />
                ) : (
                    <PortfolioActionsGrid onCompanyNameClick={onCompanyNameClick} PortfolioActionsData={PortfolioActionsInfo.Data} />
                )}
            </div>
        </Paper>
    );
};

PortfolioActionsSection.propTypes = {
    classes: PropTypes.object.isRequired,
    theme: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => {
    return {
        PortfolioActionsInfo: state.GridDataReducer.PortfolioActionsInfo,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchPortfolioActionsDataDispatcher: (pastDays) => dispatch(getPortfolioActions(pastDays)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles, { withTheme: true })(PortfolioActionsSection));
