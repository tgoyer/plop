import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import InputLabel from '@material-ui/core/InputLabel';
import Paper from '@material-ui/core/Paper';
import MuiTextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';

import DatePicker from 'components/Form/DatePicker';
import ErrorDialog from '../UIComponents/MaterialUI/CommonErrorDialog';
import LoadingOverlay from '../UIComponents/LoadingOverlay';
import MultiSelect from '../UIComponents/MaterialUI/MultiSelectDropdown';
import SearchableDropdown from '../UIComponents/MaterialUI/SearchableDropdown';
import Tooltip from '../UIComponents/Tooltip';
import { toLocalDateTime, toServerDate } from '../Utils/dateHelper';
import { pxToRem } from '../Utils/layoutHelper';

import Actions from './NoteInput/Actions';
import Attachments from './NoteInput/Attachments';
import KeyIssues from './NoteInput/KeyIssues';
import Drawer from './NoteInput/Drawer';
import Guides from './NoteInput/Guides';
import SubHeader from './NoteInput/SubHeader';
import { InputTypes, PillarTypes } from './NoteInput/_constants';

import { uploadFile } from './KnowledgeCenter/FileManager/utilities';
import { subdomains } from './KnowledgeCenter/utilities';
import Downloader from 'componentlibrary/file/Downloader';

const drawerWidth = 575;
const minimumHorizontalWidth = 1600;
const inputType = 'ResearchInput';
const esgColors = {
    environment: '#60ba53',
    social: '#1e98d7',
    governance: '#f08f50',
};

const styles = (theme) => ({
    root: {
        ...theme.mixins.gutters(),
        padding: '10px 16px !important',
        margin: '0 0 16px 0',
    },
    actions: {
        display: 'flex',
        flexDirection: 'row',
    },
    analystTeamSection: {
        display: 'flex',
        flexDirection: 'row',
        '& > div': {
            width: '33.33%',
            maxWidth: 400,
        },
        '& > div + div': {
            marginLeft: 12,
        },
    },
    card: {
        display: 'flex',
        flexGrow: 1,
        alignSelf: 'stretch',
        alignItems: 'stretch',
    },
    cardContent: {
        display: 'flex',
        flexGrow: 1,
        alignSelf: 'stretch',
        padding: '0 8px !important',
        margin: '8px',
        flexDirection: 'column',
        justifyContent: 'space-between',
    },
    cardHeaderDropdown: {
        borderTopRightRadius: 4,
        fontWeight: 700,
        margin: '0 10px',
        padding: 0,
        width: 95,
    },
    cardHeaderName: {
        width: 'calc(100% - 215px)',
    },
    cardHeaderRating: {
        textAlign: 'right',
        width: 100,
    },
    cardHeaderTitle: {
        backgroundColor: 'transparent',
        padding: '6px',
        textShadow: '1px 1px rgba(0,0,0,0.4)',
    },
    cardSet: {
        display: 'flex',
        alignItems: 'stretch',
    },
    container: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'end',
        margin: 0,
        width: '100%',
    },
    control: {
        minWidth: 'calc(50% - 32px)',
    },
    header: {
        borderRadius: '4px 4px 0 0',
        color: '#fff',
        display: 'flex',
        flex: '0 0 44px',
        fontSize: pxToRem(16),
        fontWeight: 700,
        height: 'auto',
        margin: 0,
        padding: '4px 0px 4px 12px',
        width: '100%',
    },
    headerRow: {
        width: '100%',
        margin: 0,
    },
    headerEnv: {
        backgroundColor: esgColors.environment,
    },
    headerGov: {
        backgroundColor: esgColors.governance,
    },
    headerSoc: {
        backgroundColor: esgColors.social,
    },
    msciRatingPill: {
        fontSize: pxToRem(16),
        color: '#fff',
        backgroundColor: '#8fa5cb',
        borderRadius: 14,
        padding: '2px 10px',
        margin: '0 14px',
        textShadow: '1px 1px rgba(0,0,0,0.4)',
        verticalAlign: 'middle',
    },
    section: {
        display: 'flex',
        flexDirection: 'row',
        '& > div': {
            width: '50%',
        },
        '& > div + div': {
            marginLeft: 32,
        },
    },
    sectionHeader: {
        display: 'flex',
        flex: '0 0 100%',
        flexDirection: 'row',
        padding: 0,
    },
    sectionSmall: {
        flexDirection: 'column',
        '& > div': {
            width: '100%',
        },
        '& > div + div': {
            marginLeft: 0,
            marginTop: 16,
        },
    },
    textField: {
        marginBottom: 0,
        marginTop: 4,
        width: '100%',
        '& input': {
            padding: '8px 0',
        },
    },
    textFieldPortfolioActionNote: {
        width: '100%',
    },
    textFieldOptionalInsight: {
        width: '100%',
    },
    button: {
        margin: theme.spacing(1),
        '&:disabled': {
            backgroundColor: '#cccccc',
            boxShadow: 'none',
        },
    },
    '@media (max-width: 1023px)': {
        card: {
            display: 'block',
            padding: '10px 0',
        },
        cardSet: {
            display: 'block',
            '& > div:first-child': {
                padding: 0,
            },
            '& > div:last-child': {
                padding: 0,
            },
        },
        sectionHeader: {
            display: 'block',
        },
    },
    '@media (max-width: 1280px)': {
        analystTeamSectionSmall: {
            flexDirection: 'column',
            '& > div': {
                width: '100%',
                maxWidth: '100%',
            },
            '& > div + div': {
                marginLeft: 0,
                marginTop: 8,
            },
        },
    },
    '@media (max-width: 1540px)': {
        attachmentsSmall: {
            marginTop: 8,
        },
        cardSetWithGrid: {
            display: 'block',
            '& > div:first-child': {
                padding: '0 0 16px 0',
            },
            '& > div:last-child': {
                padding: '0 0 16px 0',
            },
        },
        sectionWithGrid: {
            '& > div': {
                padding: '0 0 16px 0',
            },
        },
    },
    drawerOpen: {
        display: 'block',
        opacity: 1,
    },
    content: {
        flexGrow: 1,
        marginRight: 0,
    },
    contentShift: {
        width: `calc(100% - ${drawerWidth}px)`,
    },
});

const getIndex = (value, arr, prop) => {
    const val = value != null ? value : 'N/A';
    return Array.isArray(arr) ? arr.findIndex((item) => item[prop] === val) : 0;
};

const getKeyIssuesForPillar = (pillar, keyIssues) => {
    return !Array.isArray(keyIssues)
        ? []
        : pillar === PillarTypes.ENV.ID
        ? keyIssues.filter((i) => i.PillarName === PillarTypes.ENV.ID && i.KeyIssueName.toLowerCase() !== 'total environment')
        : pillar === PillarTypes.SOC.ID
        ? keyIssues.filter((i) => i.PillarName === PillarTypes.SOC.ID && i.KeyIssueName.toLowerCase() !== 'total social')
        : pillar === PillarTypes.GOV.ID
        ? keyIssues.filter((i) => i.PillarName === PillarTypes.GOV.ID && i.KeyIssueName.toLowerCase() !== 'total governance')
        : [];
};

const getTeamRatings = (ratings, pillar, selectedTeam, noteData) => {
    const teamsWithRatings = [3, 13, 9]; //Core Equities; Global Thematic & Sustainable; Fixed Income.
    const teamUsesRatings = selectedTeam != null && teamsWithRatings.indexOf(selectedTeam) >= 0;
    const noteHasRatings = noteData != null && (noteData.ERating !== 'N/A' || noteData.SRating !== 'N/A' || noteData.GRating !== 'N/A');

    return teamUsesRatings || noteHasRatings ? ratings.filter((item) => item.pillar === pillar) : [{ label: 'N/A', value: 'N/A', colorCode: null, pillar, ratingType: null }];
};

const findProductsByID = (products, portfolioProducts) => {
    if (Array.isArray(products) && Array.isArray(portfolioProducts)) {
        return portfolioProducts.filter((pp) => {
            return products.find((product) => pp.value === product.ProductID) != null;
        });
    }
    return [];
};

class ResearchInput extends React.Component {
    state = {
        NoteID: null,

        Pillars: {
            [PillarTypes.ENV.ID]: {
                keyIssues: null,
                checked: false,
                ratings: [],
                rating: null,
                comment: '',
                other: '',
            },
            [PillarTypes.SOC.ID]: {
                keyIssues: null,
                checked: false,
                ratings: [],
                rating: null,
                comment: '',
                other: '',
            },
            [PillarTypes.GOV.ID]: {
                keyIssues: null,
                checked: false,
                ratings: [],
                rating: null,
                comment: '',
                other: '',
            },
        },

        SelectedAnalyst: null,
        SelectedTeam: null,
        SelectedPortfolioAction: null,
        SelectedConsensus: null,
        SelectedEffect: null,
        SelectedResearchDate: null,
        SelectedTeamRatingTypeName: '',
        SelectedPortfolioProducts: [],
        SelectedPortfolioActionNote: null,
        SelectedPortfolioActionDate: null,

        EffectInsight: '',
        MSCIConsensusInsight: '',

        ErrorMessages: [],
        FileDetails: null,
        IsEditable: true,
        IsPortfolioActionEditable: true,

        horizontalWidth: 0,
        isRightDrawerOpen: false,
        files: {},
        uploadCount: null,
    };

    componentDidMount = async () => {
        const { MSCIPinned } = this.props;

        this.setState({ isRightDrawerOpen: MSCIPinned === true });

        await this.initializeData();
        this.loadStateData();

        window.addEventListener('resize', this.handleWindowResize);
        this.handleWindowResize();
    };

    componentWillUnmount = async () => {
        window.removeEventListener('resize', this.handleWindowResize);
    };

    fetchTeamRatings = (selectedTeam, isEdit) => {
        this.props.fetchTeamRatingsDispatcher(selectedTeam).then(() => {
            const { NoteData, TeamRatings } = this.props;

            if (TeamRatings != null) {
                // We should probably do the Pillar filtering in the Ratings reducer.  That way we
                // only need to do this once and then we can cache/memoize the result.
                const teamERatings = getTeamRatings(TeamRatings, 'Environment', selectedTeam, NoteData);
                const teamGRatings = getTeamRatings(TeamRatings, 'Governance', selectedTeam, NoteData);
                const teamSRatings = getTeamRatings(TeamRatings, 'Social', selectedTeam, NoteData);

                const selectedERatingIndex = isEdit ? getIndex(NoteData.ERating, teamERatings, 'value') : 0;
                const selectedSRatingIndex = isEdit ? getIndex(NoteData.SRating, teamSRatings, 'value') : 0;
                const selectedGRatingIndex = isEdit ? getIndex(NoteData.GRating, teamGRatings, 'value') : 0;

                // If the team has ratings, use the 4th option to find the Rating Type because the first
                // three ratings are the "N/A" options and don't have the rating type.
                // This isn't great, but I'll leave it until I get a chance to refactor this entire messy component.
                const teamRatingTypeName = teamERatings.length > 1 || teamGRatings.length > 1 || teamSRatings.length > 1 ? TeamRatings[3].ratingType : 'N/A';

                this.setState({
                    SelectedTeamRatingTypeName: teamRatingTypeName,
                    Pillars: {
                        [PillarTypes.ENV.ID]: {
                            ...this.state.Pillars[PillarTypes.ENV.ID],
                            ratings: teamERatings,
                            rating: teamERatings[selectedERatingIndex]?.value,
                        },
                        [PillarTypes.GOV.ID]: {
                            ...this.state.Pillars[PillarTypes.GOV.ID],
                            ratings: teamGRatings,
                            rating: teamGRatings[selectedGRatingIndex]?.value,
                        },
                        [PillarTypes.SOC.ID]: {
                            ...this.state.Pillars[PillarTypes.SOC.ID],
                            ratings: teamSRatings,
                            rating: teamSRatings[selectedSRatingIndex]?.value,
                        },
                    },
                });
            }
        });
    };

    handleAttachmentChange = (newFiles) => {
        const files = Array.isArray(newFiles)
            ? newFiles.reduce((acc, fileData) => {
                  acc[fileData.label] = fileData;
                  return acc;
              }, {})
            : {};

        this.setState({ files });
    };

    handleAttachmentDelete = (id) => {
        const { deleteFileDispatcher } = this.props;
        const noteId = this.state.NoteID;
        deleteFileDispatcher(noteId, id);
    };

    handleCancel = () => {
        this.props.setDirtyFlagDispatcher(false).then(() => {
            this.props.history != null && this.props.history.action !== 'POP' ? this.props.history.go(-1) : this.props.history.push('/');
        });
    };

    handleCloseDialog = () => this.setState({ ErrorMessages: [] });

    handleDateChange = (date) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        // if (!this.state.IsEditable) return;

        if (this.props.IsDirty === false) this.props.setDirtyFlagDispatcher(true);

        this.setState({ SelectedPortfolioActionDate: date });
    };

    handleResearchDateChange = (date) => {
        if (this.props.IsDirty === false) this.props.setDirtyFlagDispatcher(true);
        this.setState({ SelectedResearchDate: date });
    };

    handleDelete = () => {
        this.props
            .deleteNoteDataDispatcher(this.state.NoteID)
            .then(() => this.props.setDirtyFlagDispatcher(false))
            .then(() => this.props.history.replace(`/CompanyAnalysis/${this.props.Selected.CompanyID}`));
    };

    handleDrawerToggle = (isOpen) => {
        const value = isOpen == null ? true : isOpen;
        this.setState({ isRightDrawerOpen: value }, this.handleWindowResize);
    };

    handleDropdownChange = (name) => async (value) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        // if (!this.state.IsEditable) return;

        if (this.props.IsDirty === false) this.props.setDirtyFlagDispatcher(true);

        switch (name) {
            case 'Analyst':
                await this.resetTeam(value);
                this.setState({ SelectedAnalyst: value }, async () => {
                    const selectedTeam = this.state.SelectedTeam?.value;
                    if (selectedTeam != null) {
                        this.props.fetchPortfolioProductsDispatcher(selectedTeam);
                        await this.fetchTeamRatings(selectedTeam, false);
                    }
                    this.setState({ SelectedPortfolioProducts: [], SelectedPortfolioActionNote: null, SelectedPortfolioActionDate: null });
                });
                break;
            case 'Team':
                this.setState({ SelectedTeam: value }, () => {
                    const selectedTeam = this.state.SelectedTeam?.value;
                    this.props.fetchPortfolioProductsDispatcher(selectedTeam);
                    this.fetchTeamRatings(selectedTeam, false);
                    this.setState({ SelectedPortfolioProducts: null, SelectedPortfolioActionNote: null, SelectedPortfolioActionDate: null });
                });
                break;
            case 'PortfolioAction':
                const selectedTeam = this.state.SelectedTeam?.value;
                if (selectedTeam != null) {
                    this.setState({ SelectedPortfolioAction: value }, () => {
                        this.setState({ SelectedPortfolioProducts: null, SelectedPortfolioActionNote: null, SelectedPortfolioActionDate: null });
                    });
                }
                break;
            case 'Consensus':
                this.setState({
                    SelectedConsensus: value,
                    MSCIConsensusInsight: '',
                });
                break;
            case 'Effect':
                this.setState({ SelectedEffect: value });
                break;
            case 'EnvironmentRating':
                this.setState({ SelectedEnvironmentRating: value });
                break;
            case 'SocialRating':
                this.setState({ SelectedSocialRating: value });
                break;
            case 'GovernanceRating':
                this.setState({ SelectedGovernanceRating: value });
                break;
            case 'PortfolioActionProducts':
                this.setState({ SelectedPortfolioProducts: value || [] });
                break;
            default:
                break;
        }
    };

    handleKeyIssueChange = (data) => {
        if (this.props.IsDirty === false) this.props.setDirtyFlagDispatcher(true);
        this.setState({ Pillars: data });
    };

    handleInputChange = (event) => {
        // Early abort if note cannot be edited or using does not have write permmisions.
        // if (!this.state.IsEditable) return;

        if (this.props.IsDirty === false) this.props.setDirtyFlagDispatcher(true);

        this.setState({
            [event.target.name]: event.target.value,
        });
    };

    handleSubmit = async (event) => {
        if (this.validate()) {
            const {
                history,
                Selected,
                MSCIRating,
                UserDetails,

                saveNoteDispatcher,
                setDirtyFlagDispatcher,
                generateNotePdfDispatcher,
                getPublisherDispatcher,
            } = this.props;
            const {
                files,
                NoteID,
                Pillars,
                EffectInsight,
                MSCIConsensusInsight,
                SelectedAnalyst,
                SelectedConsensus,
                SelectedEffect,
                SelectedPortfolioProducts,
                SelectedPortfolioAction,
                SelectedPortfolioActionDate,
                SelectedPortfolioActionNote,
                SelectedResearchDate,
                SelectedTeam,
            } = this.state;

            const e = Pillars[PillarTypes.ENV.ID];
            const g = Pillars[PillarTypes.GOV.ID];
            const s = Pillars[PillarTypes.SOC.ID];

            const selectedProducts = SelectedPortfolioProducts != null ? SelectedPortfolioProducts.map((product) => ({ ProductID: product.value, ProductName: product.label })) : null;

            const portfolioActionDate = SelectedPortfolioActionDate != null && SelectedPortfolioActionDate !== '' ? toServerDate(this.state.SelectedPortfolioActionDate).toISO() : null;

            const hasE = (e.rating != null && e.rating !== 'N/A') || e.keyIssues.some((i) => Boolean(i.IsSelected) === true);
            const hasG = (g.rating != null && g.rating !== 'N/A') || g.keyIssues.some((i) => Boolean(i.IsSelected) === true);
            const hasS = (s.rating != null && s.rating !== 'N/A') || s.keyIssues.some((i) => Boolean(i.IsSelected) === true);

            const envData = this.state.Pillars[PillarTypes.ENV.ID];
            const govData = this.state.Pillars[PillarTypes.GOV.ID];
            const socData = this.state.Pillars[PillarTypes.SOC.ID];

            const selectedEnvKIs = Array.isArray(envData.keyIssues) ? envData.keyIssues.filter((ki) => Boolean(ki.IsSelected)) : [];
            const selectedGovKIs = Array.isArray(govData.keyIssues) ? govData.keyIssues.filter((ki) => Boolean(ki.IsSelected)) : [];
            const selectedSocKIs = Array.isArray(socData.keyIssues) ? socData.keyIssues.filter((ki) => Boolean(ki.IsSelected)) : [];

            const selectedKeyIssues = [...selectedEnvKIs, ...selectedGovKIs, ...selectedSocKIs];

            let JsonData = {
                NoteID: NoteID,
                NoteTypeID: 1,
                E: hasE,
                ENote: e.comment,
                EOther: e.other,
                ERating: e.rating,
                G: hasG,
                GNote: g.comment,
                GOther: g.other,
                GRating: g.rating,
                S: hasS,
                SNote: s.comment,
                SOther: s.other,
                SRating: s.rating,
                AnalystUserID: SelectedAnalyst == null ? null : parseInt(SelectedAnalyst.value, 10),
                CompanyID: Selected.CompanyID,
                EffectID: SelectedEffect == null ? null : parseInt(SelectedEffect.value, 10),
                EffectInsight: EffectInsight,
                KeyIssues: selectedKeyIssues,
                MSCIConsensusRating: SelectedConsensus == null ? null : SelectedConsensus.value,
                MSCIConsensusInsight: MSCIConsensusInsight === '' ? null : MSCIConsensusInsight,
                MSCIRating: MSCIRating.MSCIRating,
                PortfolioActionDate: portfolioActionDate,
                PortfolioActionID: SelectedPortfolioAction == null ? null : parseInt(SelectedPortfolioAction.value, 10),
                PortfolioActionProducts: selectedProducts,
                PortfolioActionNote: SelectedPortfolioActionNote,
                TeamID: SelectedTeam?.value,
                UpdatedByUserID: UserDetails.UserID,
                ResearchDate: SelectedResearchDate, // Display label becomes "Research Date"
            };

            setDirtyFlagDispatcher(false)
                .then(() => saveNoteDispatcher(JsonData))
                .then((note) => {
                    const noteId = note.NoteID;
                    const fileKeys = files != null ? Object.keys(files) : [];
                    const formData = {
                        subdomain: subdomains.Attachments,
                        noteId,
                    };

                    JsonData.NoteID = noteId;
                    this.setState({ uploadCount: fileKeys > 0 ? 0 : null });
                    return fileKeys.length === 0
                        ? Promise.resolve()
                        : Promise.all(
                              fileKeys.map((key, idx) => {
                                  const item = files[key];
                                  this.setState({ uploadCount: idx + 1 });
                                  return uploadFile(item, formData, null, null, null, getPublisherDispatcher);
                              })
                          );
                })
                .then(() => {
                    generateNotePdfDispatcher(JsonData.NoteID);
                    history.push(`/CompanyAnalysis/${Selected.CompanyID}`);
                    this.setState({ uploadCount: null });
                });
        }
    };

    handleWindowResize = () => {
        const horizontalWidth = Math.max(document.documentElement.clientWidth, document.documentElement.offsetWidth);

        this.setState({ horizontalWidth });
    };

    initializeData = async () => {
        const { Selected, match } = this.props;
        const { companyID, noteID } = match.params;
        const selectedCompanyID = Selected != null && Selected.CompanyID ? Selected.CompanyID : null;

        if (companyID != null && parseInt(companyID, 10) !== selectedCompanyID) {
            await this.props.fetchAndSelectCompanyDispatcher(companyID);
        }
        await this.props.fetchResearchInputDispatcher(companyID || selectedCompanyID, noteID);

        this.setState({ NoteID: noteID != null ? noteID : null });
    };

    // Setting Default values when view loads
    // This process (including initializeData) is a mess and needs to be refactored and moved into a reducer.
    loadStateData = async () => {
        const { NoteData, NoteKeyIssues, UserDetails } = this.props;

        const eIssues = getKeyIssuesForPillar(PillarTypes.ENV.ID, NoteKeyIssues);
        const gIssues = getKeyIssuesForPillar(PillarTypes.GOV.ID, NoteKeyIssues);
        const sIssues = getKeyIssuesForPillar(PillarTypes.SOC.ID, NoteKeyIssues);

        if (NoteData != null && NoteData.length !== 0) {
            const selectedAnalystIndex = getIndex(NoteData.AnalystUserID, this.props.Analysts, 'value');
            const selectedMSCIRatingIndex = getIndex(NoteData.MSCIConsensusRating, this.props.Consensus, 'value');
            const selectedEffectIndex = getIndex(NoteData.EffectID, this.props.Effects, 'value');
            const selectedPortfolioActionIndex = getIndex(NoteData.PortfolioActionID, this.props.PortfolioActions, 'value');

            let selectedTeamIndex = -1;
            let selectedTeam = null;

            await this.props.fetchAnalystTeamsDispatcher(NoteData.AnalystUserID, NoteData.NoteID);
            selectedTeamIndex = getIndex(NoteData.TeamID, this.props.UserTeams, 'value');
            selectedTeam = this.props.UserTeams[selectedTeamIndex];

            if (selectedTeam != null) {
                await Promise.all([
                    this.props.fetchPortfolioProductsDispatcher(selectedTeam.value), // Load this.props.PortfolioProducts based on the selected team.
                    this.fetchTeamRatings(selectedTeam.value, true),
                ]);

                // get the selected products from the loaded products.
                this.setState({
                    SelectedPortfolioProducts: findProductsByID(NoteData.PortfolioActionProducts, this.props.PortfolioProducts),
                });

                const PortfolioActionDate = NoteData.PortfolioActionDate != null ? toLocalDateTime(NoteData.PortfolioActionDate) : null;

                this.setState({
                    NoteID: NoteData.NoteID,

                    Pillars: {
                        [PillarTypes.ENV.ID]: {
                            ...this.state.Pillars[PillarTypes.ENV.ID],
                            keyIssues: eIssues,
                            comment: NoteData.ENote == null ? '' : NoteData.ENote,
                            other: NoteData.EOther == null ? '' : NoteData.EOther,
                            rating: NoteData.ERating == null ? 'N/A' : NoteData.ERating,
                        },
                        [PillarTypes.GOV.ID]: {
                            ...this.state.Pillars[PillarTypes.GOV.ID],
                            keyIssues: gIssues,
                            comment: NoteData.GNote == null ? '' : NoteData.GNote,
                            other: NoteData.GOther == null ? '' : NoteData.GOther,
                            rating: NoteData.GRating == null ? 'N/A' : NoteData.GRating,
                        },
                        [PillarTypes.SOC.ID]: {
                            ...this.state.Pillars[PillarTypes.SOC.ID],
                            keyIssues: sIssues,
                            comment: NoteData.SNote == null ? '' : NoteData.SNote,
                            other: NoteData.SOther == null ? '' : NoteData.SOther,
                            rating: NoteData.SRating == null ? 'N/A' : NoteData.SRating,
                        },
                    },

                    SelectedAnalyst: this.props.Analysts[selectedAnalystIndex],
                    SelectedConsensus: this.props.Consensus[selectedMSCIRatingIndex],
                    SelectedEffect: this.props.Effects[selectedEffectIndex],
                    SelectedPortfolioAction: this.props.PortfolioActions[selectedPortfolioActionIndex],
                    SelectedPortfolioActionDate: PortfolioActionDate,
                    SelectedPortfolioActionNote: NoteData.PortfolioActionNote,
                    SelectedResearchDate: NoteData.ResearchDate,
                    SelectedTeam: selectedTeam,

                    EffectInsight: NoteData.EffectInsight == null ? '' : NoteData.EffectInsight,
                    MSCIConsensusInsight: NoteData.MSCIConsensusInsight == null ? '' : NoteData.MSCIConsensusInsight,
                    IsEditable: !!NoteData.IsEditable && UserDetails.Permissions.CanWrite,
                    IsPortfolioActionEditable: !!NoteData.IsPortfolioActionEditable,
                });
            }
        } else {
            let newState = {};
            const { Consensus, DefaultTeam, Effects, PortfolioActions, UserDetails } = this.props;

            this.setDefaultAnalyst();

            newState['IsEditable'] = UserDetails.Permissions.CanWrite;

            if (DefaultTeam != null && this.state.SelectedTeam?.value == null) {
                newState['SelectedTeam'] = DefaultTeam;
            }

            if (Consensus != null && Consensus.length > 0) {
                newState['SelectedConsensus'] = Consensus[0];
            }

            if (PortfolioActions != null && PortfolioActions.length > 0) {
                newState['SelectedPortfolioAction'] = PortfolioActions[0];
            }

            if (Effects != null && Effects.length > 0) {
                newState['SelectedEffect'] = Effects[0];
            }

            newState['Pillars'] = {
                [PillarTypes.ENV.ID]: {
                    keyIssues: eIssues,
                    comment: '',
                    other: '',
                    rating: 'N/A',
                },
                [PillarTypes.SOC.ID]: {
                    keyIssues: sIssues,
                    comment: '',
                    other: '',
                    rating: 'N/A',
                },
                [PillarTypes.GOV.ID]: {
                    keyIssues: gIssues,
                    comment: '',
                    other: '',
                    rating: 'N/A',
                },
            };

            this.setState({ ...newState });
        }
    };

    resetTeam = (item) => {
        return this.props.fetchAnalystTeamsDispatcher(item?.value, null).then(() => this.setState({ SelectedTeam: this.props.DefaultTeam }));
    };

    setDefaultAnalyst = () => {
        const { UserDetails } = this.props;

        this.setState({
            SelectedAnalyst: {
                value: UserDetails.UserID,
                label: `${UserDetails.LastName}, ${UserDetails.FirstName}`,
            },
        });

        this.props.fetchAnalystTeamsDispatcher(UserDetails.UserID, null).then(() => {
            const { DefaultTeam } = this.props;
            if (DefaultTeam != null) {
                this.setState({ SelectedTeam: DefaultTeam });
                this.props.fetchPortfolioProductsDispatcher(DefaultTeam.value);
                this.fetchTeamRatings(DefaultTeam.value, false);
            }
        });
    };

    updateNoteKeyIssues = (items) => {
        const keyIssues = [...this.state.NoteKeyIssues];
        if (items != null) {
            items.forEach((i) => {
                const keyIssue = keyIssues.find((nki) => i.KeyIssueID === nki.KeyIssueID);
                keyIssue.IsSelected = i.IsSelected;
            });
        }
        return keyIssues;
    };

    validate = () => {
        const errorMessages = [];
        const { PortfolioProducts } = this.props;
        const { Pillars, SelectedPortfolioAction, SelectedPortfolioActionDate, SelectedPortfolioProducts, SelectedTeam, SelectedAnalyst, SelectedEffect } = this.state;

        const e = Pillars[PillarTypes.ENV.ID];
        const g = Pillars[PillarTypes.GOV.ID];
        const s = Pillars[PillarTypes.SOC.ID];

        const eIssues = e.keyIssues.filter((i) => Boolean(i.IsSelected) === true);
        const gIssues = g.keyIssues.filter((i) => Boolean(i.IsSelected) === true);
        const sIssues = s.keyIssues.filter((i) => Boolean(i.IsSelected) === true);

        if (SelectedAnalyst == null || SelectedAnalyst.length === 0) {
            errorMessages.push('Select an analyst.');
        }

        if (SelectedTeam == null || SelectedTeam.length === 0) {
            errorMessages.push('Select a team.');
        }

        if (eIssues.length === 0 && sIssues.length === 0 && gIssues.length === 0) {
            errorMessages.push('Select at least one key issue.');
        }

        if (eIssues.length === 0 && e.comment !== '') {
            errorMessages.push('If you enter an environmental research conclusion, you must select an environmental key issue.');
        }

        if (eIssues.length > 0 && e.comment === '') {
            errorMessages.push('If you select an environmental key issue, you must enter an environmental research conclusion.');
        }

        if (sIssues.length === 0 && s.comment !== '') {
            errorMessages.push('If you enter a social research conclusion, you must select a social key issue.');
        }

        if (sIssues.length > 0 && s.comment === '') {
            errorMessages.push('If you select a social key issue, you must enter a social research conclusion.');
        }

        if (gIssues.length === 0 && g.comment !== '') {
            errorMessages.push('If you enter a governance research conclusion, you must select a governance key issue.');
        }

        if (gIssues.length > 0 && g.comment === '') {
            errorMessages.push('If you select a governance key issue, you must enter a governance research conclusion.');
        }

        // if(SelectedEffect.value === 0){
        //     errorMessages.push('Select the Effect on Investment Thesis');
        // }

        if (SelectedPortfolioAction != null && SelectedPortfolioAction.value > 0 && ['Buy', 'Sell'].indexOf(SelectedPortfolioAction.label) >= 0) {
            if (SelectedPortfolioActionDate == null) {
                errorMessages.push('Enter the portfolio action date.');
            }
            if (SelectedPortfolioProducts == null || SelectedPortfolioProducts.length === 0) {
                if (PortfolioProducts != null && PortfolioProducts.length > 0) {
                    errorMessages.push('Select one or more portfolio action products.');
                } else {
                    errorMessages.push('Select a team with products; then select products.');
                }
            }
        }

        this.setState({ ErrorMessages: errorMessages });

        return errorMessages.length === 0;
    };

    render() {
        const { classes, MSCIRating, Selected, UserDetails } = this.props;
        const { horizontalWidth, isRightDrawerOpen, IsEditable, IsPortfolioActionEditable } = this.state;
        const companyID = Selected != null && Selected.CompanyID != null ? Selected.CompanyID : null;
        const sectorGuide = MSCIRating != null ? MSCIRating.SectorGuide : null;

        const isDisabled = !this.state.IsEditable;
        const isVertical = horizontalWidth < minimumHorizontalWidth && isRightDrawerOpen;

        let isPortfolioActionDisabled = true; //disabled
        if (IsEditable && UserDetails.Permissions.CanWrite) {
            isPortfolioActionDisabled = false; //enabled
        } else if (IsPortfolioActionEditable && UserDetails.Permissions.CanWrite) {
            isPortfolioActionDisabled = false; //enabled
        }

        return (
            <div className={cn(classes.content, { [classes.contentShift]: isRightDrawerOpen })}>
                <Drawer open={isRightDrawerOpen} onToggle={this.handleDrawerToggle} />
                <SubHeader inputType={inputType} open={isRightDrawerOpen} onToggleDrawer={this.handleDrawerToggle} onPinDrawer={this.handleDrawerToggle} />
                <Guides sectorGuide={sectorGuide} />

                <Paper className={cn(classes.root, classes.analystTeamSection, { [classes.analystTeamSectionSmall]: isRightDrawerOpen })} elevation={1}>
                    <div>
                        <SearchableDropdown
                            id="Analysts"
                            dropdownName={'Analyst'}
                            dropdownItems={this.props.Analysts}
                            placeholder={'Select Analyst'}
                            defaultValue={this.state.SelectedAnalyst}
                            InputLabelProps={{
                                className: cn({
                                    'required asterisk': this.state.IsEditable,
                                }),
                                shrink: true,
                            }}
                            onChange={this.handleDropdownChange('Analyst')}
                            isDisabled={isDisabled}
                        />
                    </div>
                    <div>
                        <SearchableDropdown
                            id="Teams"
                            dropdownName={'Team'}
                            dropdownItems={this.props.UserTeams}
                            placeholder={'Select Team'}
                            defaultValue={this.state.SelectedTeam}
                            InputLabelProps={{
                                className: cn({
                                    'required asterisk': this.state.IsEditable,
                                }),
                                shrink: true,
                            }}
                            onChange={this.handleDropdownChange('Team')}
                            isDisabled={isDisabled}
                        />
                    </div>
                    <div>
                        <TextField
                            id="ratingTypeName"
                            label="Rating Type"
                            className={classes.textField}
                            margin="normal"
                            value={this.state.SelectedTeamRatingTypeName}
                            disabled
                            inputProps={{ maxLength: 2048 }}
                            InputLabelProps={{
                                shrink: true,
                            }}
                        />
                    </div>
                </Paper>
                <KeyIssues data={this.state.Pillars} inputType={InputTypes.RESEARCH} readOnly={isDisabled} vertical={isVertical} onChange={this.handleKeyIssueChange} />
                <Paper className={classes.root} elevation={3}>
                    <div className={cn(classes.section, { [classes.sectionSmall]: isRightDrawerOpen })}>
                        <div>
                            <div className={classes.container}>
                                <div className={classes.control} style={{ display: 'flex' }}>
                                    <InputLabel style={{ fontSize: pxToRem(12), width: '100%', padding: `0 ${pxToRem(12)} 0px 0px` }}>
                                        <span data-tip data-for="Tooltip_RatingConsensus" style={{ verticalAlign: 'middle' }}>
                                            MSCI ESG Rating Consensus
                                        </span>
                                        {this.props.MSCIRating && this.props.MSCIRating.MSCIRating && <span className={classes.msciRatingPill}>{this.props.MSCIRating.MSCIRating}</span>}
                                        <div style={{ display: 'inline-block', width: '100%', verticalAlign: 'middle' }}>
                                            <SearchableDropdown
                                                id="Consensus"
                                                dropdownItems={this.props.Consensus}
                                                placeholder={'Select'}
                                                defaultValue={this.state.SelectedConsensus}
                                                onChange={this.handleDropdownChange('Consensus')}
                                                isDisabled={isDisabled}
                                            />
                                        </div>
                                    </InputLabel>
                                </div>

                                <Tooltip id="Tooltip_ResearchDate">
                                    <p>Specific date of the last research update</p>
                                </Tooltip>
                                <DatePicker
                                    label="Enter a research date"
                                    value={this.state.SelectedResearchDate}
                                    onChange={this.handleResearchDateChange}
                                    animateYearScrolling={false}
                                    style={{ width: '100%' }}
                                    disableFuture={true}
                                    maxDateMessage="Date should not be after today's date"
                                    data-tip
                                    data-for="Tooltip_ResearchDate"
                                    disabled={isDisabled}
                                />
                                <Tooltip id="Tooltip_RatingConsensus">
                                    <p>Analyst's view of the company's ESG performance relative to MSCI's ESG rating</p>
                                    <p>+ Better than MSCI's</p>
                                    <p>- Worse than MSCI's Rating</p>
                                    <p>= Neutral/Agrees with MSCI</p>
                                </Tooltip>
                            </div>

                            {this.state.SelectedConsensus != null && this.state.SelectedConsensus.value !== 'N/A' && (
                                <div style={{ paddingLeft: '35px' }}>
                                    <TextField
                                        id="MSCIRatingInsight"
                                        label="MSCI Consensus Rating Insight"
                                        placeholder="Enter MSCI consensus insight"
                                        margin="normal"
                                        multiline
                                        InputLabelProps={{ shrink: true }}
                                        inputProps={{ maxLength: 1024 }}
                                        className={classes.textFieldOptionalInsight}
                                        value={this.state.MSCIConsensusInsight}
                                        name="MSCIConsensusInsight"
                                        onChange={this.handleInputChange}
                                        disabled={isDisabled}
                                    />
                                    <br />
                                </div>
                            )}
                            <br />
                            <br />
                            <div data-tip data-for="Tooltip_PortfolioActions">
                                <SearchableDropdown
                                    id="PortfolioAction"
                                    dropdownName={'Portfolio Actions'}
                                    dropdownItems={this.props.PortfolioActions}
                                    placeholder={'Select'}
                                    defaultValue={this.state.SelectedPortfolioAction}
                                    onChange={this.handleDropdownChange('PortfolioAction')}
                                    isDisabled={isPortfolioActionDisabled}
                                />
                            </div>
                            <Tooltip id="Tooltip_PortfolioActions">
                                <p>
                                    PM’s decision to buy or sell the stock based on the company engagement meeting (in-person or call) or research on the company’s ESG performance. Defaulted at N/A as
                                    an optional input field.
                                </p>
                                <p>
                                    <em>Research Only option is to be selected if the research did not have any intention of making an immediate portfolio action at the time.</em>
                                </p>
                            </Tooltip>
                            {this.state.SelectedPortfolioAction != null && this.state.SelectedPortfolioAction.value > 0 && (
                                <div style={{ paddingLeft: 25, paddingTop: 5 }}>
                                    <DatePicker
                                        label="Portfolio Action Date"
                                        value={this.state.SelectedPortfolioActionDate}
                                        onChange={this.handleDateChange}
                                        animateYearScrolling={false}
                                        InputLabelProps={{
                                            className: cn({
                                                'required asterisk':
                                                    !isPortfolioActionDisabled && this.state.SelectedPortfolioAction != null && ['Buy', 'Sell'].indexOf(this.state.SelectedPortfolioAction.label) >= 0,
                                            }),
                                            shrink: true,
                                        }}
                                        disabled={isPortfolioActionDisabled}
                                    />
                                    <br />
                                    <br />
                                    <MultiSelect
                                        id="PortfolioActionProducts"
                                        dropdownName={'Portfolio Action Products'}
                                        dropdownItems={this.props.PortfolioProducts}
                                        placeholder={'Select Products'}
                                        defaultValue={this.state.SelectedPortfolioProducts}
                                        onChange={this.handleDropdownChange('PortfolioActionProducts')}
                                        InputLabelProps={{
                                            className: cn({
                                                'required asterisk':
                                                    !isPortfolioActionDisabled && this.state.SelectedPortfolioAction != null && ['Buy', 'Sell'].indexOf(this.state.SelectedPortfolioAction.label) >= 0,
                                            }),
                                        }}
                                        isDisabled={isPortfolioActionDisabled}
                                    />
                                    <br />
                                    <br />
                                    <TextField
                                        id="PortfolioActionNote"
                                        label="Portfolio Action Note"
                                        placeholder="Enter a note about this action"
                                        multiline
                                        InputLabelProps={{ shrink: true }}
                                        className={classes.textFieldPortfolioActionNote}
                                        value={this.state.SelectedPortfolioActionNote}
                                        inputProps={{ maxLength: 1024 }}
                                        onChange={(e) => this.setState({ SelectedPortfolioActionNote: e.target.value })}
                                        disabled={isPortfolioActionDisabled}
                                    />
                                </div>
                            )}
                            <br />
                            <br />
                            <div data-tip data-for="Tooltip_InvestmentThesis">
                                <SearchableDropdown
                                    id="InvestmentThesis"
                                    dropdownName={'Effect on Investment Thesis'}
                                    dropdownItems={this.props.Effects}
                                    placeholder={'Select'}
                                    defaultValue={this.state.SelectedEffect}
                                    onChange={this.handleDropdownChange('Effect')}
                                    isDisabled={isDisabled}
                                    // InputLabelProps={{
                                    //     className: cn('required asterisk'),
                                    // }}
                                />
                            </div>
                            <Tooltip id="Tooltip_InvestmentThesis">
                                <p>
                                    Any change on the investment thesis based on the company engagement meeting (in-person or call) or research on the company's ESG performance. Defaulted at N/A as an
                                    optional input field. Optional insight field can be entered to explain any background reasons for making such change on the investment thesis.
                                </p>
                            </Tooltip>
                            {this.state.SelectedEffect != null && this.state.SelectedEffect.value > 0 && (
                                <div style={{ paddingLeft: '25px' }}>
                                    <TextField
                                        id="effectInsight"
                                        label="Optional Insight"
                                        placeholder="Enter optional insight"
                                        margin="normal"
                                        multiline
                                        className={classes.textFieldOptionalInsight}
                                        value={this.state.EffectInsight}
                                        name="EffectInsight"
                                        onChange={this.handleInputChange}
                                        InputLabelProps={{ shrink: true }}
                                        inputProps={{ maxLength: 1024 }}
                                        disabled={isDisabled}
                                    />
                                </div>
                            )}
                        </div>
                        <div>
                            <Attachments
                                files={this.props.Attachments}
                                metadata={{
                                    companyId: companyID,
                                    noteId: this.state.NoteID == null ? this.props.match.params.noteID : this.state.NoteID,
                                    userId: this.props.UserDetails.UserID,
                                }}
                                editable={this.state.IsEditable}
                                onChange={this.handleAttachmentChange}
                                onDelete={this.handleAttachmentDelete}
                                uploadCount={this.state.uploadCount}
                            />
                        </div>
                    </div>
                </Paper>
                {(this.state.IsEditable || !isPortfolioActionDisabled) && (
                    <div className="row">
                        <div className="col-xs-12">
                            <div className="small required message">
                                Fields marked with <span className="required asterisk"></span> are required.
                            </div>
                        </div>
                    </div>
                )}
                <div className={classes.actions}>
                    <Actions
                        onSubmit={this.handleSubmit}
                        onCancel={this.handleCancel}
                        canDelete={this.state.NoteID != null && this.state.IsEditable}
                        canEdit={(this.state.IsEditable || this.state.IsPortfolioActionEditable) && UserDetails.Permissions.CanWrite}
                        onDelete={this.handleDelete}
                        validator={this.validate}
                    />

                    {this.state.NoteID !== null && (
                        <Downloader useApiResource={true} uri={`/notes/${this.state.NoteID}/print`}>
                            <Button variant="contained" color="primary" className={classes.button}>
                                Print
                            </Button>
                        </Downloader>
                    )}
                </div>
                <ErrorDialog onClose={this.handleCloseDialog} messages={this.state.ErrorMessages} />
                {!!this.props.Fetching && <LoadingOverlay />}
            </div>
        );
    }
}
ResearchInput.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(ResearchInput);

const TextField = (props) => {
    const { onChange, value, ...rest } = props;

    const [text, setText] = React.useState('');
    const handleBlur = (evt) => {
        if (onChange) onChange(evt);
    };
    const handleChange = (evt) => {
        setText(evt.target.value);
    };

    React.useEffect(() => {
        if (value != null) {
            setText(value);
        }
    }, [value]);

    return <MuiTextField {...rest} value={text} onBlur={handleBlur} onChange={handleChange} />;
};
