import React from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';

import { Tab, TabSubHeader } from 'Layout/Header';

import FeatureFlags from 'Applications/EimtTools/FeatureFlags';

const styles = (theme) => ({});

const EimTools = ({ classes }) => {
    const history = useHistory();
    const [tabIndex, setTabIndex] = React.useState(0);
    const { setting } = useParams();

    React.useEffect(() => {
        const route = setting == null ? null : String(setting).toLowerCase();
        const index = Object.keys(ROUTES).findIndex((key) => {
            return ROUTES[key] == null ? null : ROUTES[key].toLowerCase() === route;
        });
        setTabIndex(index > 0 ? index : 0);
    }, [setting]);

    const handleTabIndexChange = (tab) => {
        history.push(tab === 0 ? `/AppTools` : `/AppTools/${ROUTES[tab]}`);
    };

    return (
        <>
            <TabSubHeader onTabChange={handleTabIndexChange} activeTab={tabIndex}>
                <Tab label="Feature Flags" />
            </TabSubHeader>
            {tabIndex === TABS.FEATUREFLAGS && <FeatureFlags />}
        </>
    );
};

const TABS = {
    FEATUREFLAGS: 0,
};

const ROUTES = {
    [TABS.FEATUREFLAGS]: null,
};

export default withStyles(styles)(EimTools);
