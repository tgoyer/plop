import React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';

import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import SubHeader from '../../Layout/Header/SubHeader';
import { setLocalSetting } from '../../store/AppSettingsModule';
import { getMsci } from '../../store/GridDataModule';

const styles = (theme) => ({
    subHeaderButton: {
        fontWeight: 700,
        '& i': {
            paddingRight: 8,
        },
    },
    pinButton: {
        minWidth: 45,
    },
    toggleMsciLink: {
        padding: 5,
    },
});

const NoteSubHeader = ({ classes, inputType, open, LocalSettings, Selected, onToggleDrawer, onPinDrawer, setLocalSettingDispatcher, getMsciDispatcher }) => {
    const pinned = LocalSettings[inputType] != null ? LocalSettings[inputType].msciPinned : false;
    const companyID = Selected != null ? Selected.CompanyID : null;

    const handlePinClick = async () => {
        const msciPinned = !LocalSettings[inputType].msciPinned;

        setLocalSettingDispatcher(inputType, { msciPinned });

        if (msciPinned) {
            await getMsciDispatcher(companyID);
        }

        if (onPinDrawer) {
            onPinDrawer(msciPinned);
        }
    };

    const handleDrawerLinkClick = async (event) => {
        if (event != null) {
            event.stopPropagation();
            event.preventDefault();
        }
        const isOpen = !open;
        const msciPinned = LocalSettings[inputType].msciPinned;

        if (isOpen) {
            await getMsciDispatcher(companyID);
        }

        if (!isOpen && msciPinned) {
            setLocalSettingDispatcher(inputType, { msciPinned: isOpen });
        }

        if (onToggleDrawer) {
            onToggleDrawer(isOpen);
        }
    };

    return (
        <SubHeader
            right={() => (
                <div>
                    <DrawerLink isOpen={open} onClick={handleDrawerLinkClick} classes={classes} />
                    <PinDrawerLink isPinned={pinned} onClick={handlePinClick} classes={classes} />
                </div>
            )}
        />
    );
};

const DrawerLink = ({ isOpen, onClick, classes }) => {
    return isOpen ? (
        <Button color="primary" className={cn(classes.toggleMsciLink, classes.subHeaderButton)} onClick={onClick}>
            <i className="fas fa-arrow-down" style={{ margin: '0 4px' }}></i> Hide Materiality Maps
        </Button>
    ) : (
        <Button color="primary" className={cn(classes.toggleMsciLink, classes.subHeaderButton)} onClick={onClick}>
            <i className="fas fa-arrow-right" style={{ margin: '0 4px' }}></i> View Materiality Maps
        </Button>
    );
};

const PinDrawerLink = ({ isPinned, onClick, classes }) => (
    <Button className={classes.pinButton} color="primary" onClick={onClick} title="Pin the MSCI data panel so it will remain open.">
        <i className={cn('fas fa-thumbtack', { 'fa-rotate-270': !isPinned })} style={{ marginLeft: 5 }}></i>
    </Button>
);

const mapStateToProps = (state) => {
    return {
        Selected: state.CompanyReducer.Selected.Data,
        LocalSettings: state.AppSettingsReducer.LocalSettings,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        getMsciDispatcher: (companyID) => dispatch(getMsci(companyID)),
        setLocalSettingDispatcher: (inputType, value) => dispatch(setLocalSetting(inputType, value)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(NoteSubHeader));
