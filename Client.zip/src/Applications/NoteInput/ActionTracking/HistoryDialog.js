import React, { useState, useCallback } from 'react';
import cn from 'classnames';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import Tree from 'react-d3-tree';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from 'UIComponents/Tooltip';
import { Button, ButtonTypes } from 'components/Form';
import { Popover, DialogSizes } from 'components/Dialogs';

import ActionTable from 'Applications/NoteInput/ActionTracking/ActionTable';
import { graphify } from 'Applications/NoteInput/ActionTracking/actionHelper';

import { getNoteHistory } from 'store/NoteModule';

import { hasEntries } from 'Utils/arrayHelpers';

const styles = () => ({
    root: {
        height: '100%',
        width: '100%',
    },
    cardContainer: {
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        backgroundColor: '#6987B9',
        border: '1px solid black',
        color: 'white',
        flexDirection: 'column',
        fontWeight: 700,
        padding: 4,
        margin: 12,
        '&.active': {
            boxShadow: '0px 0px 8px 0px #900',
        },
        '& > div + div': {
            marginTop: 4,
        },
        '& .header': {
            display: 'flex',
            flexDirection: 'row',
            fontSize: 16,
            justifyContent: 'space-between',
            padding: '0 4px',
            width: '100%',
            '& i + a': {
                marginLeft: 6,
            },
            '& a': {
                color: 'white',
            },
        },
        '& .data': {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            backgroundColor: 'white',
            color: 'black',
            height: '100%',
            width: '100%',
            padding: 4,
        },
    },
});

export const useCenteredTree = () => {
    const [translate, setTranslate] = useState({ x: 0, y: 0 });
    const containerRef = useCallback((containerElem) => {
        if (containerElem !== null) {
            const { width } = containerElem.getBoundingClientRect();
            setTranslate({ x: width / 2, y: 40 });
        }
    }, []);
    return [translate, containerRef];
};

const ActionTrackingHistoryDialog = ({ classes, show, onClose }) => {
    const dispatch = useDispatch();
    const keyIssueHistory = useSelector((state) => state.NoteReducer.NoteHistory);
    const { noteID } = useParams();
    const [viewActions, setViewActions] = useState(null);

    const historyGraph = React.useMemo(() => {
        return graphify(keyIssueHistory, 'NoteID', 'ParentID');
    }, [keyIssueHistory]);

    const detailsList = React.useMemo(() => {
        return hasEntries(viewActions) ? viewActions.map((kih) => ({ ...kih, Action: { ...kih } })) : [];
    }, [viewActions]);

    React.useEffect(() => {
        if (show === true) {
            dispatch(getNoteHistory(noteID));
        }
    }, [dispatch, noteID, show]);

    const handleNavigateClick = (noteID) => {
        console.log(noteID);
    };
    const handleViewDetailsClick = (actions) => {
        setViewActions(actions);
    };

    const [translate, containerRef] = useCenteredTree();
    const nodeSize = { x: 250, y: 200 };
    const cardProps = { width: nodeSize.x, height: nodeSize.y, x: -(nodeSize.x / 2), y: -30 };

    return (
        <Popover
            show={show}
            title="Action History"
            size={DialogSizes.LARGE}
            lockHeight={true}
            onClose={onClose}
            actions={
                <>
                    <Button type={ButtonTypes.MINIMAL} onClick={onClose}>
                        Close
                    </Button>
                </>
            }
        >
            <div className={classes.root} ref={containerRef}>
                <Tree
                    data={historyGraph || {}}
                    orientation="vertical"
                    pathFunc="step"
                    nodeSize={nodeSize}
                    renderCustomNodeElement={(rd3tProps) => {
                        return <CustomNodeElement classes={classes} cardProps={cardProps} onViewDetails={handleViewDetailsClick} onNavigate={handleNavigateClick} {...rd3tProps} />;
                    }}
                    translate={translate}
                />
            </div>
            <Popover
                show={hasEntries(viewActions)}
                title="Action Details"
                size={DialogSizes.MEDIUM}
                lockHeight={true}
                style={{ width: '75%', height: '50%', left: '25%' }}
                onClose={() => setViewActions(null)}
                actions={
                    <>
                        <Button type={ButtonTypes.MINIMAL} onClick={() => setViewActions(null)}>
                            Close
                        </Button>
                    </>
                }
            >
                <ActionTable issues={detailsList} />
            </Popover>
        </Popover>
    );
};

export default React.memo(withStyles(styles)(ActionTrackingHistoryDialog));

const CustomNodeElement = ({ classes, nodeDatum = {}, cardProps = {}, onViewDetails }) => {
    const { noteID, companyID } = useParams();

    /* <foreignObject /> is an SVG xml tag for rendering non-SVG elements inside a SVG image */
    return (
        <foreignObject {...cardProps}>
            <div className={cn(classes.cardContainer, { active: Number(nodeDatum.id) === Number(noteID) })}>
                <div className="header">
                    <div>{nodeDatum.name}</div>
                    <div>
                        <i className="far fa-eye" data-tip data-for={`view_details_tip_${nodeDatum.id}`} onClick={() => onViewDetails(nodeDatum.attributes.actions)}></i>
                        {Number(noteID) !== Number(nodeDatum.id) && (
                            <a href={`/EngagementInput/${companyID}/${nodeDatum.id}`}>
                                <i className="fas fa-share" data-tip data-for={`go_to_note_tip_${nodeDatum.id}`}></i>
                            </a>
                        )}
                        <Tooltip place="left" id={`view_details_tip_${nodeDatum.id}`}>
                            View Action Details
                        </Tooltip>
                        <Tooltip place="left" id={`go_to_note_tip_${nodeDatum.id}`}>
                            Go to entry screen
                        </Tooltip>
                    </div>
                </div>
                <div className="data">
                    {nodeDatum.attributes && (
                        <>
                            <div></div>
                            {Object.keys(nodeDatum.attributes).map((labelKey, i) => {
                                const actions = nodeDatum.attributes[labelKey];
                                return actions.map((action, i) => {
                                    return (
                                        <div key={`${labelKey}-${action.NoteID}-${action.KeyIssueID}`}>
                                            <span>{action.KeyIssueName}</span>
                                        </div>
                                    );
                                });
                            })}
                        </>
                    )}
                </div>
            </div>
        </foreignObject>
    );
};

//{labelKey}: {JSON.stringify(nodeDatum.attributes[labelKey], null, 4)}
