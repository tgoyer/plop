import { hasEntries } from 'Utils/arrayHelpers';
import { formatDate } from 'Utils/dateHelper';
import { isNullOrEmpty } from 'Utils/stringHelper';

export const createInitialActions = (keyIssues, parentID = null) => {
    //var filtered = hasEntries(keyIssues) ? keyIssues.filter((issue) => issue.IsSelected === true) : [];
    var actions = keyIssues.map((issue) => createInitialAction(keyIssues, issue, parentID, true));
    return actions;
};

export const createInitialAction = (keyIssues, keyIssue, parentID = null, isNew) => {
    const issue = hasEntries(keyIssues) ? keyIssues.find((ki) => keyIssue.KeyIssueID === ki?.KeyIssueID) : null;

    return {
        ...keyIssue,
        isDeleted: false,
        Action: initialAction(issue?.Action, parentID, isNew),
    };
};

const initialAction = (action, parentID, isNew) => {
    return {
        Action: action?.Action ?? '',
        Comment: action?.Comment ?? '',
        EscalationPathOther: action?.EscalationPathOther ?? '',
        EscalationPathID: action?.EscalationPathID ?? null,
        NoteID: null,
        ParentID: action?.NoteID ?? parentID,
        Result: action?.Result ?? null,
        Status: action?.Status ?? null,
        FollowUpDate: action?.FollowUpDate ?? null,
        IsDeleted: action?.IsDeleted ?? false,
        WasDiscussed: action?.WasDiscussed ?? null,
        IsNew: isNew === true,
        EngagementType: isNullOrEmpty(action?.WasDiscussed) ? 'Insight' : 'Action',
        ActionTypeID: action?.ActionTypeID ?? null,
        TargetEndDate: action?.TargetEndDate ?? null,
    };
};

export const graphify = (dataset = [], id, parentId) => {
    const dataTree = [];
    const hashTable = Object.create(null);

    if (hasEntries(dataset)) {
        dataset.forEach((data) => {
            hashTable[data[id]] = {
                id: data[id],
                parentId: data[parentId],
                name: formatDate(data.EngagementDate),
                attributes: {
                    ...(hashTable[data[id]]?.attributes ?? []),
                    actions: [...(hashTable[data[id]]?.attributes?.actions ?? []), data],
                },
                children: [],
            };
        });

        dataset.forEach((data) => {
            const did = data[id];
            const pid = data[parentId];
            const isTop = pid == null;
            const isFound = dataTree.some((d) => d.id === did);

            if (!isTop) {
                const item = hashTable[did];
                const filtered = hashTable[pid].children.filter((child) => child.id !== did);
                hashTable[pid].children = [...filtered, item];
            } else if (!isFound) {
                dataTree.push(hashTable[did]);
            }
        });
    } else {
        return {};
    }

    return hasEntries(dataTree) ? dataTree[0] : {};
};
