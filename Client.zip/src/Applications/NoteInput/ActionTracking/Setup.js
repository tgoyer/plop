import React, { useState } from 'react';
import cn from 'classnames';
import { useParams } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import Avatar from '@material-ui/core/Avatar';

import { Button, ButtonTypes } from 'components/Form';
import SearchableDropdown from 'UIComponents/MaterialUI/SearchableDropdown';

import { getNotes, getNoteKeyIssues } from 'store/NoteModule';
import { hasEntries } from 'Utils/arrayHelpers';
import { formatDate } from 'Utils/dateHelper';
import { toOptionsList } from 'Utils/selectHelper';
import { isNullOrUndefined } from 'Utils/objectHelpers';

const styles = () => ({
    workflow: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        '& .step': {
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            fontWeight: 'bold',
            minWidth: 200,
            // justifyContent: 'space-between',
            gap: '12px',
            '&.right': {
                justifyContent: 'flex-end',
            },
            '&.vertical': {
                flexDirection: 'column',
                alignItems: 'baseline',
            },
            '& .actions': {
                display: 'flex',
                flexDirection: 'row',
                gap: 8,
                '&.date-select': {
                    width: 800,
                },
                '&.full-width': {
                    flex: '1',
                    width: '100%',
                },
            },
            '& .noteCard': {
                display: 'flex',
                flexDirection: 'column',
                backgroundColor: '#fafafa',
                border: '1px solid #cccccc',
                borderRadius: 4,
                padding: 12,
                margin: '6px 0',
                width: '100%',
                '& .data': {
                    display: 'flex',
                    flexDirection: 'column',
                    marginTop: 8,
                    '& .title': {
                        fontWeight: 700,
                        fontSize: '1.1rem',
                        color: '#6987B9',
                    },
                    '& .value': {
                        fontSize: '1rem',
                        fontWeight: 400,
                        marginLeft: 12,
                    },
                },
                '& .data + & .data': {
                    marginTop: 8,
                },
                '& .header': {
                    display: 'flex',
                    flexDirection: 'row',
                    '& .actionTag span': {
                        backgroundColor: '#999999',
                        padding: '4px 8px',
                        color: '#ffffff',
                        borderRadius: 12,
                    },
                    '& .avatars': {
                        display: 'flex',
                        flexDirection: 'row',
                        flexGrow: 1,
                        flexShrink: 1,
                        margin: '0 10px 0 0',
                        '& .avatar': {
                            backgroundColor: '#52BEAD',
                            height: 36,
                            borderRadius: 0,
                            width: 30,
                            fontSize: '25px',
                            fontWeight: 700,
                            '&:first-child': {
                                borderTopLeftRadius: 4,
                                borderBottomLeftRadius: 4,
                            },
                            '&:last-child': {
                                borderTopRightRadius: 4,
                                borderBottomRightRadius: 4,
                            },
                            '&.E': {
                                backgroundColor: colors.e,
                            },
                            '&.S': {
                                backgroundColor: colors.s,
                            },
                            '&.G': {
                                backgroundColor: colors.g,
                            },
                        },
                    },
                    '& .keyIssues': {
                        width: '100%',
                        '& .keyIssue': {
                            fontWeight: 700,
                            '&:after': {
                                content: '", "',
                            },
                            '&:last-child:after': {
                                content: '""',
                            },
                            '&.E': {
                                color: colors.e,
                            },
                            '&.S': {
                                color: colors.s,
                            },
                            '&.G': {
                                color: colors.g,
                            },
                        },
                        '& i.actionTag': {
                            backgroundColor: '#999999 !important',
                            //padding: '4px 8px',
                            color: '#ffffff !important',
                            borderRadius: 2,
                            //right: '8%',
                            fontSize: '9pt',
                        },
                    },
                },
            },
            '& .title': {
                fontWeight: 'bold',
                flexWrap: 'nowrap',
                whiteSpace: 'nowrap',
                marginLeft: 4,
            },
        },
    },
});

const colors = {
    e: '#60ba53',
    s: '#1e98d7',
    g: '#f08f50',
};

const ActionTracking = ({ classes, onComplete }) => {
    const [config, setConfig] = React.useState(null);
    //const { companyID } = useParams();
    //const [parentKeyIssues] = useAxios(`companies/${companyID}/notes/${config?.noteID == null ? 0 : config?.noteID}/key_issues`);

    const parentKeyIssues = useSelector((state) => state.NoteReducer.NoteKeyIssues);
    // const handleIsOngoingStep = (value) => {
    //     setConfig({ isOngoing: value });
    // };

    const handleIsContinuationStep = (value) => {
        setConfig((config) => ({
            isOngoing: true, //Boolean(value), //config?.isOngoing,
            isContinuation: Boolean(value),
            isComplete: !Boolean(value),
            noteID: null,
        }));

        //if (!value) handleCompleteStep();
    };

    const handleParentEngagement = (otherText, noteID, engageDate) => {
        setConfig((config) => ({
            ...config,
            noteID,
            otherText,
            engageDate,
        }));
    };

    React.useEffect(() => {
        if (config?.isOngoing === true && config?.isContinuation === false && config?.isComplete === true && isNullOrUndefined(config?.noteID)) handleCompleteStep();
    }, [config]);

    const handleCompleteStep = () => {
        const c = {
            ...config,
            isComplete: true,
        };
        setConfig(c);
        onComplete(c);
    };

    React.useEffect(() => {
        const issues = hasEntries(parentKeyIssues)
            ? parentKeyIssues /*.map((pki) => {
                  const newKI = {
                      ...pki,
                      IsSelected: pki?.Action?.Status === false ? false : pki?.IsSelected, // Status: true === followup; false === closed.
                      Action: pki?.Action?.Status === false ? null : pki?.Action, // Status: true === followup; false === closed.
                  };
                  return newKI;
              })*/
            : [];

        setConfig((config) => ({
            ...config,
            isOngoing: true,
            parentKeyIssues: config?.noteID == null ? null : issues,
        }));

        // if (triggerUseEffect && config?.isComplete === true) {
        //     let a = 1;
        //     a = 2;
        //     onComplete({
        //         ...config,
        //         isOngoing: true,
        //         parentKeyIssues: config?.noteID == null ? null : issues,
        //     });
        // }
    }, [parentKeyIssues]); //[parentKeyIssues, triggerUseEffect]);

    return (
        <>
            <div className={classes.workflow}>
                {/* <IsOngoingStep classes={classes} isOngoing={config?.isOngoing} onComplete={handleIsOngoingStep} /> */}
                {/* {config?.isOngoing === true && <IsContinuationStep classes={classes} isContinuation={config?.isContinuation} onComplete={handleIsContinuationStep} />} */}
                {<IsContinuationStep classes={classes} isContinuation={config?.isContinuation} onComplete={handleIsContinuationStep} />}
                {config?.isOngoing === true && config?.isContinuation === true && <PreviousEngagementPickerStep classes={classes} onComplete={handleParentEngagement} />}
                {(config?.isOngoing === false || (config?.isContinuation != null && !isNullOrUndefined(config?.noteID))) && <IsCompleteStep onComplete={handleCompleteStep} />}
            </div>
        </>
    );
};

export default React.memo(withStyles(styles)(ActionTracking));

// const IsOngoingStep = ({ isOngoing, onComplete }) => {
//     const handleClick = (value) => () => onComplete(value);
//     return (
//         <div className="step">
//             <div className="title">Will this entry be part of an ongoing, outcome-based engagement?</div>
//             <div className="actions">
//                 <Button compact={true} type={isOngoing === false ? ButtonTypes.SECONDARY : ButtonTypes.MINIMAL} onClick={handleClick(false)}>
//                     <span>NO</span>
//                 </Button>
//                 <Button compact={true} type={isOngoing === true ? ButtonTypes.SECONDARY : ButtonTypes.MINIMAL} onClick={handleClick(true)}>
//                     <span>YES</span>
//                 </Button>
//             </div>
//         </div>
//     );
// };

const IsContinuationStep = ({ isContinuation, onComplete }) => {
    const handleClick = (value) => () => onComplete(value);

    return (
        <div className="step">
            <div className="title">Is this entry a continuation from a previous engagement discussion?</div>
            <div className="actions">
                <Button compact="true" type={isContinuation === false ? ButtonTypes.SECONDARY : ButtonTypes.MINIMAL} onClick={handleClick(false)}>
                    <span>NO</span>
                </Button>
                <Button compact="true" type={isContinuation === true ? ButtonTypes.SECONDARY : ButtonTypes.MINIMAL} onClick={handleClick(true)}>
                    <span>YES</span>
                </Button>
            </div>
        </div>
    );
};

const PreviousEngagementPickerStep = ({ onComplete }) => {
    const dispatch = useDispatch();
    const { companyID } = useParams();
    const list = useSelector((state) => state.NoteReducer.NoteList?.Boxes);
    let actionKeyIssueList = useSelector((state) => state.NoteReducer.NoteList?.ActionKeyIssues);
    const [selectedIndex, setSelectedIndex] = useState(null);

    const [otherText, setOtherText] = React.useState({});

    React.useEffect(() => {
        let theOtherText = {
            Environment: '',
            Social: '',
            Governance: '',
        };

        let selectedList = list.filter((l) => l.NoteID === engagement?.NoteID);
        if (!isNullOrUndefined(selectedList) && selectedList.length > 0) {
            let listComments = selectedList[0].Comments?.filter((c) => c.KeyIssues.includes('Other ('));
            //console.log('listComments', listComments);
            listComments.map((lc) => {
                let { KeyIssues, ESGType } = lc;
                KeyIssues = KeyIssues.replace(', Other (', '^^ Other (');
                let splits = KeyIssues.split('^^');
                let otherText = splits.filter((s) => s.includes('Other ('))[0];

                theOtherText[ESGType === 'E' ? 'Environment' : ESGType === 'S' ? 'Social' : 'Governance'] = otherText.substring(otherText.indexOf('(') + 1, otherText.indexOf(')')).trim();
            });
        }

        //console.log('theOtherText', theOtherText);
        setOtherText(theOtherText);

        if (engagement?.NoteID !== null) onComplete(theOtherText, engagement?.NoteID, engagement?.EngageDate);
    }, [selectedIndex]);

    const selectOptions = React.useMemo(() => {
        //console.log('list', list);
        return toOptionsList(list, (item) => `${formatDate(item.DisplayDate)} | ${item.AnalystUserName} | ${item.TeamName}`, 'NoteID');
    }, [list]);

    let engagement = React.useMemo(() => {
        if (selectedIndex == null) return null;

        const option = selectOptions[selectedIndex];
        return list.find((note) => note.NoteID === option.value);
    }, [list, selectedIndex, selectOptions]);

    const getKeyIssues = (comment, noteID) => {
        if (isNullOrUndefined(comment)) return null;

        //console.log('actionKeyIssueList', actionKeyIssueList);
        const noteActionKeyIssues = actionKeyIssueList?.filter((aki) => aki.NoteID === noteID);
        let { KeyIssues } = comment;
        let otherText = KeyIssues.substring(KeyIssues.indexOf('Other ('), KeyIssues.indexOf(')') + 1);
        let updatedOtherText = otherText.replace(',', '^');
        KeyIssues = KeyIssues.replace(otherText, updatedOtherText);
        const keyIssues = KeyIssues != null && KeyIssues.length > 0 ? KeyIssues.split(',').map((i) => i.trim()) : null;

        return keyIssues != null
            ? keyIssues.map((ki, i) => {
                  let pillarID = comment.ESGType === 'E' ? 1 : comment.ESGType === 'S' ? 2 : 3;
                  let kiName = ki.startsWith('Other (') ? 'Other' : ki.trim();
                  return (
                      <React.Fragment key={'WizardKIRoot' + comment.ESGType + noteID.toString() + i.toString()}>
                          <span className={cn('keyIssue', comment.ESGType)}>
                              {ki.trim().replace('^', ',')}{' '}
                              {noteActionKeyIssues?.some((aki) => aki.PillarID === pillarID && aki.KeyIssueName?.trim() === kiName) ? <i className="actionTag">Action</i> : ''}
                          </span>
                          &nbsp;
                      </React.Fragment>
                  );
              })
            : null;
    };

    const handleDateButtonClick = (dir) => () => {
        let sidx = selectedIndex == null ? -1 : selectedIndex;
        let idx = 0;
        switch (dir) {
            case 'prev':
                idx = sidx <= 0 ? 0 : sidx - 1;
                break;
            case 'next':
                idx = sidx >= selectOptions.length - 1 ? sidx : sidx + 1;
                break;
            default:
                break;
        }
        const value = selectOptions[idx].value;
        dispatch(getNoteKeyIssues(companyID, value));
        setSelectedIndex(idx);
        //onComplete(parseInt(value));
    };

    const handleDateChange = (value) => {
        const idx = list.findIndex((item) => item.NoteID === value);
        dispatch(getNoteKeyIssues(companyID, value));
        setSelectedIndex(idx);
        //onComplete(parseInt(value));
    };

    React.useEffect(() => {
        dispatch(getNotes(companyID, null, null, 2, null, null, -1));
    }, [dispatch, companyID]);

    // React.useEffect(() => {
    //     const option = selectOptions[selectedIndex];
    //     if (!isNullOrUndefined(option)) dispatch(getNoteKeyIssues(companyID, option.value));
    //     //setPKeyIssues(parentKeyIssues);
    // }, [companyID, selectedIndex, dispatch]);

    return (
        <>
            <div className="step vertical">
                {hasEntries(selectOptions) === true ? (
                    <>
                        <div className="title">When did the previous engagement occur:</div>

                        <div className="actions date-select">
                            <Button compact="true" disabled={selectedIndex === 0 || selectedIndex == null} type={ButtonTypes.SECONDARY} onClick={handleDateButtonClick('prev')}>
                                <i className="fas fa-chevron-left"></i> Prev
                            </Button>
                            <SearchableDropdown
                                dropdownItems={selectOptions}
                                defaultValue={selectOptions[selectedIndex]}
                                placeholder="Select a date"
                                onChange={(option) => handleDateChange(option.value)}
                            />
                            <Button compact="true" disabled={selectedIndex === selectOptions.length - 1} type={ButtonTypes.SECONDARY} onClick={handleDateButtonClick('next')}>
                                Next <i className="fas fa-chevron-right"></i>
                            </Button>
                        </div>
                    </>
                ) : (
                    <div className="title" style={{ color: 'red' }}>
                        There are no previous engagements for this company. Click NO to create new engagement note.
                    </div>
                )}
            </div>
            {engagement != null && (
                <div className="step vertical">
                    {/* <div className="title">Is this the correct engagement?</div> */}
                    <div className="noteCard">
                        <div className="header">
                            <div className="avatars">
                                {hasEntries(engagement?.Comments) &&
                                    engagement?.Comments.map((c, i) => {
                                        return (
                                            <Avatar key={i} className={cn('avatar', c.ESGType)}>
                                                {c.ESGType}
                                            </Avatar>
                                        );
                                    })}
                            </div>
                            <div className="keyIssues">{engagement?.Comments && engagement?.Comments.map((c) => getKeyIssues(c, engagement?.NoteID))}</div>
                            {/* {engagement.IsOngoing === true ? (
                                <div className="actionTag">
                                    <span>Action</span>
                                </div>
                            ) : (
                                <div className="actionTag">
                                    <span>Insight</span>
                                </div>
                            )} */}
                        </div>
                        <div className="data">
                            <div className="title">Analyst</div>
                            <div className="value">{engagement?.AnalystUserName}</div>
                        </div>
                        <div className="data">
                            <div className="title">Engagement Date</div>
                            <div className="value">{formatDate(engagement?.DisplayDate)}</div>
                        </div>
                        <div className="data">
                            <div className="title">Objective</div>
                            <div className="value">{engagement?.EngageObjective}</div>
                        </div>
                        {engagement?.EngageBackground != null && (
                            <div className="data">
                                <div className="title">Background</div>
                                <div className="value">{engagement?.EngageBackground}</div>
                            </div>
                        )}
                        {engagement?.EngageScope != null && (
                            <div className="data">
                                <div className="title">Scope</div>
                                <div className="value">{engagement?.EngageScope}</div>
                            </div>
                        )}
                        {engagement?.EngageOutcome != null && (
                            <div className="data">
                                <div className="title">Outcome</div>
                                <div className="value">{engagement?.EngageOutcome}</div>
                            </div>
                        )}
                        <div className="data">
                            <div className="title">Last Updated</div>
                            <div className="value">{formatDate(engagement?.UpdatedDate)}</div>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

const IsCompleteStep = ({ onComplete }) => {
    return (
        <div className="step right">
            <div className="actions">
                <Button type={ButtonTypes.PRIMARY} onClick={onComplete}>
                    <span>Continue</span>
                </Button>
            </div>
        </div>
    );
};
