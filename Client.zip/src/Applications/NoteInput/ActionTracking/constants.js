export const StatusCodes = Object.freeze([
    { label: 'Closed', value: false },
    { label: 'Follow-Up', value: true },
]);

export const ResultCodes = Object.freeze([
    { label: 'Successful', value: 'S' },
    { label: 'Partial', value: 'P' },
    { label: 'Unsuccessful', value: 'U' },
]);
