import React from 'react';
import cn from 'classnames';
import { useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import { StatusCodes, ResultCodes } from 'Applications/NoteInput/ActionTracking/constants';

import { hasEntries } from 'Utils/arrayHelpers';
import { formatDate } from 'Utils/dateHelper';
import { isNullOrEmpty } from 'Utils/stringHelper';

const styles = (theme) => ({
    table: {
        width: '100%',
        //tableLayout: 'auto',
        borderCollapse: 'collapse',
        '& thead th': {
            background: '#6987B9',
            color: '#ffffff',
            padding: '4px 8px',
        },
        '& tbody tr:nth-child(odd) td': {
            background: '#f2f2f2',
        },
        '& tbody td, & thead th': {
            fontWeight: 400,
            padding: '4px 8px',
            '&.header': {
                fontWeight: 700,
            },
            '&.column': {
                height: '1.5rem',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                transition: 'height 150ms ease-in-out',
                verticalAlign: 'baseline',
                '&.keyIssue': {
                    fontWeight: 700,
                    // '&.deleted': {
                    //     textDecoration: 'line-through',
                    // },
                    cursor: 'pointer',
                    maxWidth: 200,
                },

                '&.engagementType': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 75,
                    //width: '20px',
                },
                '&.buttons': {
                    textAlign: 'center',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 40,
                    '& i.fa-exclamation': {
                        color: '#e00!important',
                        fontSize: 12,
                    },
                    '& i': {
                        cursor: 'pointer',
                        fontSize: 16,
                        padding: '4px 8px',
                        transition: 'transform 150ms ease-in-out',
                        '&.rotate90': {
                            transform: 'rotate(90deg)',
                        },
                        '&.invalid': {
                            background: '#e00!important',
                            color: 'white',
                            borderRadius: 16,
                            padding: '4px 8px',
                        },
                    },
                },
                '&.action': {
                    padding: '8px 12px',
                    width: '250px!important',
                    maxWidth: '250px!important',
                },
                '&.date': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 120,
                    '& i.fa-exclamation': {
                        background: '#e00!important',
                        borderRadius: 16,
                        fontSize: 12,
                        padding: '4px 8px',
                        color: 'white',
                    },
                },
                '&.actionType': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 175,
                    //width: '30px',
                },
                '&.escalationPath': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 150,
                },
                '&.comment': {
                    padding: '8px 12px',
                    width: '250px!important',
                    maxWidth: '250px!important',
                },
                '&.discussed': {
                    width: 75,
                },
                '&.result': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 100,
                },
                '&.status': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    width: 75,
                },
                '&.scrollable': {
                    height: 150,
                    '& > div': {
                        display: 'block',
                        width: '230px',
                        height: '100%',
                        margin: 0,
                        overflow: 'auto',
                        whiteSpace: 'normal',
                    },
                },
                '&.truncate': {
                    height: '1.5rem',
                    //width: 300,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    '& > div': {
                        display: 'inline',
                        '& p': {
                            display: 'inline',
                        },
                    },
                },
            },
            '&.e': {
                color: '#429c35',
            },
            '&.s': {
                color: '#007ab9',
            },
            '&.g': {
                color: '#d27132',
            },
            '& > div > a': {
                color: 'inherit',
                '&:hover': {
                    color: 'red!important',
                },
            },
        },
        '& tbody td + td': {
            borderLeft: '4px solid white',
        },
    },
});

// Format large text blocks for action summary table.
// Break text line-feeds into <p> blocks.
const formatText = (text) => {
    const textBits = isNullOrEmpty(text) ? [] : text.split('\n').filter((t) => t.length > 0);
    return hasEntries(textBits) ? textBits.map((t, i) => <p key={i}>{t}&nbsp;</p>) : <p>&nbsp;</p>;
};

const getOptionLabel = (options, value, searchKey, valueKey) => {
    const option = hasEntries(options) ? options.find((o) => String(o[searchKey]) === String(value)) : null;
    return option != null ? option[valueKey] : null;
};

const ActionTable = ({ classes, issues = [], pillars, onKeyIssueClick, isRightDrawerOpen }) => {
    const [expandedRows, setExpandedRows] = React.useState({});
    const escalationPaths = useSelector((state) => state.DimensionReducer.EscalationPaths);
    const actionTypes = useSelector((state) => state.DimensionReducer.ActionTypes);
    const drawerWidth = 575;

    const handleExpand = (id) => () => {
        setExpandedRows((rows) => ({
            ...rows,
            [id]: rows[id] == null ? true : !rows[id],
        }));
    };

    const getActionTableRootWidth = () => {
        let width = document.documentElement.clientWidth - 152;
        //console.log('document.documentElement.clientWidth', document.documentElement.clientWidth);
        if (isRightDrawerOpen) {
            width = width - drawerWidth;
        }

        return width;
    };
    return (
        // <div className={classes.tableContainer}>
        <div style={{ overflowX: 'auto', width: getActionTableRootWidth() }}>
            <table className={classes.table}>
                <thead>
                    <tr>
                        <th className="column header buttons"></th>
                        <th className="column header keyIssue">Key Issue</th>
                        <th className="column header engagementType">Type</th>
                        <th className="column header action">Requested Action</th>
                        <th className="column header actionType">Action Type</th>
                        <th className="column header date">Target End Date</th>
                        <th className="column header escalationPath">Escalation Path</th>
                        <th className="column header comment">Details</th>
                        <th className="column header discussed">Discussed</th>
                        <th className="column header result">Result</th>
                        <th className="column header status">Status</th>
                        <th className="column header date">Follow Up Date</th>
                    </tr>
                </thead>
                <tbody>
                    {issues
                        .filter((ki) => ki.Action != null && !ki.Action?.IsDeleted)
                        .map((issue) => {
                            const { Action } = issue;
                            const isExpandedRow = expandedRows[issue?.KeyIssueID] === true;
                            const other = issue.KeyIssueName === 'Other' && pillars != null ? pillars[issue.PillarName].other : '';
                            const kiName = isNullOrEmpty(other) ? issue.KeyIssueName : `${issue.KeyIssueName}: ${other}`;
                            return (
                                <tr key={issue?.KeyIssueID}>
                                    <td className="column buttons">
                                        <i
                                            className={cn('fas fa-chevron-right', {
                                                rotate90: isExpandedRow,
                                                invalid: Action?.EngagementType === 'Action' && Action?.FollowUpDate && new Date(Action?.FollowUpDate) < new Date(),
                                            })}
                                            onClick={handleExpand(issue?.KeyIssueID)}
                                        ></i>
                                        {/* {Action?.EngagementType === 'Action' && Action?.FollowUpDate && new Date(Action?.FollowUpDate) < new Date() ? <i className="fas fa-exclamation"></i> : ''} */}
                                    </td>
                                    <td
                                        className={cn('column keyIssue truncate', {
                                            e: issue?.PillarID === 1,
                                            s: issue?.PillarID === 2,
                                            g: issue?.PillarID === 3,
                                            //deleted: Action?.IsDeleted === true,
                                            scrollable: isExpandedRow,
                                            truncate: !isExpandedRow,
                                        })}
                                    >
                                        <div>
                                            <a
                                                onClick={(e) => {
                                                    onKeyIssueClick(issue);
                                                    e.stopPropagation();
                                                }}
                                            >
                                                {kiName}
                                            </a>
                                        </div>
                                    </td>
                                    <td className="column engagementType">
                                        <div>{Action?.EngagementType === 'Action' ? 'Action' : 'Insight'}</div>
                                    </td>
                                    <td
                                        className={cn('column action', {
                                            scrollable: isExpandedRow,
                                            truncate: !isExpandedRow,
                                        })}
                                    >
                                        {/* <div>{Action.IsDeleted === true ? 'Will be removed' : formatText(Action?.Action)}</div> */}
                                        <div>{formatText(Action?.Action)}</div>
                                    </td>
                                    <td className="column actionType">{getOptionLabel(actionTypes, Action?.ActionTypeID, 'ID', 'Name')}</td>
                                    <td className="column date">{formatDate(Action?.TargetEndDate)}</td>
                                    <td className="column escalationPath">{getOptionLabel(escalationPaths, Action?.EscalationPathID, 'ID', 'Name')}</td>
                                    <td
                                        className={cn('column comment', {
                                            scrollable: isExpandedRow,
                                            truncate: !isExpandedRow,
                                        })}
                                    >
                                        <div>{formatText(Action?.Comment)}</div>
                                    </td>
                                    <td className="column discussed">{Action?.WasDiscussed !== null ? (Action?.WasDiscussed === true ? 'Yes' : 'No') : null}</td>
                                    <td className="column result">{getOptionLabel(ResultCodes, Action?.Result, 'value', 'label')}</td>
                                    <td className="column status">{getOptionLabel(StatusCodes, Action?.Status, 'value', 'label')}</td>
                                    <td className="column date">
                                        {formatDate(Action?.FollowUpDate)}
                                        {Action?.EngagementType === 'Action' && Action?.FollowUpDate && new Date(Action?.FollowUpDate) < new Date() ? <i className="fas fa-exclamation"></i> : ''}
                                    </td>
                                </tr>
                            );
                        })}
                </tbody>
            </table>
        </div>
    );
};

export default React.memo(withStyles(styles)(ActionTable));
