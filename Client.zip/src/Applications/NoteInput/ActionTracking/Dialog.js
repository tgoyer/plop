import React, { useEffect, useMemo, useState } from 'react';
import cn from 'classnames';
import { useSelector } from 'react-redux';

//import _orderBy from 'lodash/orderBy';
//import _some from 'lodash/some';

import { withStyles } from '@material-ui/core/styles';

import { Heading } from 'components/Content';
import { Button, ButtonBar, ButtonTypes, DatePicker, Label, Select, TextField, toOptionList } from 'components/Form';
import { Popover, DialogSizes } from 'components/Dialogs';

import { ResultCodes } from 'Applications/NoteInput/ActionTracking/constants';

import { hasEntries } from 'Utils/arrayHelpers';
import { isNullOrEmpty } from 'Utils/stringHelper';
import { isNullOrUndefined } from 'Utils/objectHelpers';

//import { createInitialAction } from './actionHelper';
import { Colors } from '../_constants';
//import { ImportantDevices } from '@material-ui/icons';
//import { isLeftFixed } from 'react-table-hoc-fixed-columns/lib/helpers';

const styles = () => ({
    error: {
        color: '#990000',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: 16,
        height: '100%',
    },
    editorRoot: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        padding: 8,
        '& .heading': {
            background: '#ffffff',
            fontSize: 16,
            fontWeight: 700,
            padding: '4px 8px 8px 8px',
        },
        '& .data': {
            display: 'flex',
            flexDirection: 'row',
            flexGrow: 1,
            background: '#eeeeee',
            height: '100%',
            '& .actions': {
                position: 'relative',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'flex-start',
                background: '#fafafa',
                border: '1px solid #cccccc',
                flexBasis: '25%',
                height: '100%',
                listStyle: 'none',
                margin: 0,
                padding: 0,
                overflow: 'hidden',
                overflowY: 'auto',
                '& > * + div': {
                    borderTop: '1px solid #cccccc',
                },
                '& .list-heading': {
                    padding: 8,
                },
                '& ul': {
                    flexGrow: 1,
                    margin: 0,
                    listStyle: 'none',
                    maxHeight: 'calc(100% - 100px)',
                    overflowY: 'auto',
                },
                '& li': {
                    position: 'relative',
                    fontSize: 14,
                    fontWeight: 700,
                    marginLeft: -40,
                    '& span': {
                        padding: '6px 12px',
                        width: '100%',
                        display: 'block',
                    },
                    '& i.actionTag': {
                        backgroundColor: '#999999 !important',
                        //padding: '4px 8px',
                        color: '#ffffff !important',
                        borderRadius: 2,
                        //right: '8%',
                        fontSize: '9pt',
                    },
                    '& i:not(.actionTag)': {
                        position: 'absolute',
                        top: 'calc(50% - 10px)',
                        right: 4,
                        color: '#fff',
                        padding: '0 6px',
                    },
                    '& .badge': {
                        position: 'absolute',
                        top: 4,
                        //right: 4,
                        color: '#c27070',
                        background: 'transparent',
                        padding: 4,
                        fontSize: '8pt',
                        fontWeight: 700,
                    },
                    // '&:not(.deleted)': {
                    //     '&:hover': {
                    //         cursor: 'pointer',
                    //         '& > .badge, & > i.fa-exclamation': {
                    //             display: 'none',
                    //         },
                    //         '& > i.fa-times-circle': {
                    //             display: 'inline',
                    //         },
                    //     },
                    //     '&:hover, &.active': {
                    //         color: 'white',
                    //     },
                    // },
                    // '&.deleted': {
                    //     opacity: 0.45,
                    //     textDecoration: 'line-through',
                    //     '&:hover': {
                    //         color: 'white',
                    //         cursor: 'not-allowed',
                    //         '& > i.fa-undo-alt': {
                    //             cursor: 'pointer',
                    //             display: 'inline',
                    //         },
                    //     },
                    // },
                    '&:hover, &.active': {
                        cursor: 'pointer',
                        color: 'white !important',
                        '& i:not(.fa-exclamation)': {
                            background: 'transparent',
                        },
                        // '& i.actionTag': {
                        //     backgroundColor: '#999999',
                        //     color: '#ffffff',
                        // },
                    },
                    '&.e': {
                        color: Colors.e,
                        '&:hover': {
                            background: `${Colors.e}99`,
                        },
                        '&.active': {
                            background: Colors.e,
                        },
                    },
                    '&.s': {
                        color: Colors.s,
                        '&:hover': {
                            background: `${Colors.s}99`,
                        },
                        '&.active': {
                            background: Colors.s,
                        },
                    },
                    '&.g': {
                        color: Colors.g,
                        '&:hover': {
                            background: `${Colors.g}99`,
                        },
                        '&.active': {
                            background: Colors.g,
                        },
                    },
                    '& i.fa-exclamation': {
                        background: '#e00!important',
                        borderRadius: 16,
                        fontSize: 12,
                        padding: '4px 12px',
                    },
                    '& i.fa-times-circle': {
                        display: 'none',
                        fontSize: 20,
                    },
                    '& i.fa-undo-alt': {
                        display: 'none',
                        fontSize: 20,
                    },
                },
                '& .addNew': {
                    position: 'absolute',
                    bottom: 0,
                    width: '100%',
                    backgroundColor: '#fff',

                    display: 'flex',
                    flexDirection: 'column',
                    gap: 12,
                    flexBasis: 425,
                    minHeight: 425,
                    padding: 12,
                    transition: 'all 250ms',
                    '&.full': {
                        minHeight: '100%',
                    },
                    '&.collapsed': {
                        flexBasis: 60,
                        minHeight: 60,
                    },
                    '& .select': {
                        width: '100%',
                    },
                    '& > div:last-of-type': {
                        marginTop: 'auto',
                        alignSelf: 'center',
                    },
                    '& > .add-button': {
                        alignSelf: 'flex-end',
                    },
                    '& > .close-button, & > .close-button button': {
                        width: '100%',
                    },
                    '& .e': { color: Colors.e },
                    '& .s': { color: Colors.s },
                    '& .g': { color: Colors.g },
                    '& .e.selected': { color: 'white', backgroundColor: Colors.e },
                    '& .s.selected': { color: 'white', backgroundColor: Colors.s },
                    '& .g.selected': { color: 'white', backgroundColor: Colors.g },
                },
                '& li:hover .badge, & li.active .badge': {
                    color: 'white',
                },
            },
            '& .editor': {
                display: 'flex',
                flexDirection: 'column',
                flexGrow: 1,
                background: '#ffffff',
                border: '1px solid #cccccc',
                borderLeftWidth: 0,
                height: '100%',
                overflow: 'hidden',
                overflowY: 'auto',
                padding: 12,
                gap: 18,
                '& .zeroState': {
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    gap: 16,
                    padding: 24,
                    flexGrow: 1,
                    '& i': {
                        color: '#6987B9',
                        fontSize: 60,
                    },
                    '& div': {
                        fontWeight: 700,
                        width: '75%',
                    },
                },
                '& .editorRow': {
                    display: 'flex',
                    flexDirection: 'row',
                    '&.vertical': {
                        display: 'flex',
                        flexDirection: 'column',
                    },
                    '& > * + *': {
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        gap: 8,
                        marginLeft: 12,
                    },
                },
                '& .errorText': {
                    color: '#cc0000',
                    fontSize: '.8rem',
                    fontWeight: 700,
                    paddingLeft: 8,
                },
            },
        },
    },
});

// const sortKeyIssues = (keyIssues) => {
//     return _orderBy(keyIssues, ['PillarID', 'KeyIssueName']);
// };
const validateKeyIssue = (ki, escalationPathOtherID) => {
    // Only validate if there is Action data.
    //if (ki?.Action?.WasDiscussed === true && ki.isDeleted !== true && ki?.Action != null) {
    if (ki?.Action?.WasDiscussed === true && ki?.Action?.EngagementType === 'Action') {
        const { Action, EscalationPathOther, EscalationPathID, Result, Status, FollowUpDate, ActionTypeID, TargetEndDate } = ki?.Action;
        ki.errors = {};

        // Validate "Action" field
        if (Action == null || isNullOrEmpty(Action) || String(Action).length === 0 || String(Action).length > 2048) {
            ki.errors = {
                ...ki.errors,
                Action: 'Entry is required and it should be less than 2048 characters.',
            };
        }

        // Validate "Other Escalation Path" field
        if (escalationPathOtherID === EscalationPathID && (isNullOrEmpty(EscalationPathOther) || EscalationPathOther == null || String(EscalationPathOther).length === 0)) {
            ki.errors = {
                ...ki.errors,
                EscalationPathOther: 'Entry is required if other is selected.',
            };
        }

        // Validate "Result of Key Issue Discussion" field
        if (isNullOrUndefined(Result)) {
            ki.errors = {
                ...ki.errors,
                Result: 'A result selection is required.',
            };
        }

        // Validate "Status" selection
        if (Status == null) {
            ki.errors = {
                ...ki.errors,
                Status: 'A status selection is required.',
            };
        }

        // Validate "Follow up date" field
        // if (Status === true && FollowUpDate === null) {
        //     ki.errors = {
        //         ...ki.errors,
        //         FollowUpDate: 'Follow up date is required.',
        //     };
        // }

        if (Status === true && (FollowUpDate === null || (FollowUpDate !== null && new Date(FollowUpDate) < new Date()))) {
            ki.errors = {
                ...ki.errors,
                FollowUpDate: "Date is required and should be later than today's date",
            };
        }

        // Validate "Action Type" field
        if (isNullOrEmpty(ActionTypeID)) {
            ki.errors = {
                ...ki.errors,
                ActionTypeID: 'An action type selection is required.',
            };
        }

        // Validate "Target End date" field
        if (TargetEndDate === null) {
            //|| (TargetEndDate !== null && new Date(TargetEndDate) < new Date())) {
            ki.errors = {
                ...ki.errors,
                TargetEndDate: 'Date is required.',
            };
        }

        // // Validate "Target End date" field
        // if (TargetEndDate !== null && new Date(TargetEndDate) < new Date()) {
        //     ki.errors = {
        //         ...ki.errors,
        //         TargetEndDate: "Date should not be before today's date",
        //     };
        // }

        ki.isValid = !hasEntries(Object.keys(ki.errors));
    } else if (ki?.Action?.WasDiscussed !== true && ki?.Action?.EngagementType === 'Action') {
        const { Status, FollowUpDate } = ki?.Action;
        ki.errors = {};
        //// Validate "Follow up date" field
        // if (FollowUpDate == null) {
        //     ki.errors = {
        //         ...ki.errors,
        //         FollowUpDate: 'Follow up date is required.',
        //     };
        // }

        // Validate "Follow up date" field
        if (isNullOrUndefined(Status)) {
            ki.errors = {
                ...ki.errors,
                Status: 'A status selection is required.',
            };
        } else if (Status === true) {
            if (FollowUpDate === null || (FollowUpDate !== null && new Date(FollowUpDate) < new Date())) {
                ki.errors = {
                    ...ki.errors,
                    FollowUpDate: "Date is required and should be later than today's date",
                };
            }
        }

        ki.isValid = !hasEntries(Object.keys(ki.errors));
    } else {
        // Don't need to validate non-action key issues.
        ki.isValid = true;
    }

    ki.Action.IsDeleted = ki.isDeleted ?? false;
    return ki;
};

const validate = (kis, escalationPathOtherID) => {
    const clearWasDiscussedFields = (keyIssue) => {
        const ki = {
            ...keyIssue,
            Action: {
                ...keyIssue.Action,
                Action: '',
                //Comment: '',
                EscalationPathOther: '',
                EscalationPathID: null,
                Result: null,
                ActionTypeID: null,
                TargetEndDate: null,
            },
        };

        return ki;
    };

    const clearAllFields = (keyIssue) => {
        const ki = {
            ...keyIssue,
            Action: {
                ...keyIssue.Action,
                Action: '',
                Comment: '',
                EscalationPathOther: '',
                EscalationPathID: null,
                Result: null,
                ActionTypeID: null,
                TargetEndDate: null,
                FollowUpDate: null,
                Status: null,
                WasDiscussed: null,
            },
        };

        return ki;
    };

    const validated = kis.map((ki) => {
        ki = ki?.Action?.EngagementType === 'Insight' ? clearAllFields(ki) : ki;
        ki = ki?.Action?.EngagementType === 'Action' && ki.Action.WasDiscussed === false ? clearWasDiscussedFields(ki) : ki;
        return validateKeyIssue(ki, escalationPathOtherID);
    });

    return { validated, isValid: validated.every((ki) => Boolean(ki.isValid)) && validated.some((ki) => !ki.isDeleted) };
};

const ActionTrackingDialog = ({ classes, keyIssues, parentID = null, show, onCancel, onSave, selectedKeyIssue, otherText }) => {
    const [globalError, setGlobalError] = useState(null);
    const [keyIssueID, setKeyIssueID] = useState(null);
    const [localKIs, setLocalKIs] = useState([]);
    //const [otherText] = useState({});

    const escalationPaths = useSelector((state) => state.DimensionReducer.EscalationPaths);
    const escalationPathOtherID = useMemo(() => {
        return hasEntries(escalationPaths) ? escalationPaths.find((ep) => ep.Name === 'Other').ID : null;
    }, [escalationPaths]);

    //const actionTypes = useSelector((state) => state.DimensionReducer.ActionTypes);

    // const handleAddKeyIssue = (keyIssue, otherText) => {
    //     const newKeyIssue = createInitialAction(localKIs, keyIssue, parentID, true);
    //     newKeyIssue.IsSelected = true;
    //     const newList = sortKeyIssues([...localKIs, newKeyIssue]);
    //     setLocalKIs(newList);
    //     setKeyIssueID(newKeyIssue?.KeyIssueID);
    //     setOtherText((other) => ({
    //         ...other,
    //         [newKeyIssue.PillarName]: otherText,
    //     }));
    // };

    const handleCancel = () => {
        setKeyIssueID(null);
        setLocalKIs([...keyIssues]);
        onCancel();
    };

    const handleChange = (keyIssue) => {
        const newArr = [...localKIs];
        const index = newArr.findIndex((ki) => keyIssue?.KeyIssueID === ki.KeyIssueID);
        newArr[index].Action = { ...keyIssue.Action };
        newArr[index].IsSelected = true;
        setLocalKIs(newArr);
    };

    const handleKeyIssueClick = (keyIssue) => () => {
        setGlobalError(null);
        if (!keyIssue.isDeleted) {
            setKeyIssueID(keyIssue?.KeyIssueID);
            if (activeKeyIssue !== null && activeKeyIssue !== undefined) validateKeyIssue(activeKeyIssue, escalationPathOtherID);
        }
    };

    // const handleRemoveKeyIssue = (id) => () => {
    //     const found = localKIs.find((ki) => ki.KeyIssueID === id);
    //     const isDeleted = !found.isDeleted;
    //     const selectedID = isDeleted === false ? found.KeyIssueID : null;
    //     const newKis = localKIs.map((ki) => {
    //         const deleted = ki.KeyIssueID === id ? isDeleted : ki.isDeleted;
    //         return {
    //             ...ki,
    //             Action: {
    //                 ...ki.Action,
    //                 IsDeleted: deleted,
    //             },
    //             isDeleted: deleted,
    //         };
    //     });

    //     setKeyIssueID(selectedID);
    //     setLocalKIs(newKis);
    // };

    const handleSave = () => {
        const { validated, isValid } = validate(localKIs, escalationPathOtherID);

        setLocalKIs(validated);
        setGlobalError(null);

        if (isValid) {
            onSave(
                validated.filter((ki) => ki.Action.IsDeleted !== true),
                otherText
            );
        } else if (!hasEntries(validated) || validated.every((ki) => ki.isDeleted)) {
            setGlobalError('You must add at least one key issue.');
        }
    };

    useEffect(() => {
        setLocalKIs(keyIssues);
    }, [keyIssues]);

    useEffect(() => {
        setGlobalError(null);
        //For selecting the key issue as soon as Edit Key Issue pop up is opened.
        if (selectedKeyIssue && !selectedKeyIssue.isDeleted) {
            setKeyIssueID(selectedKeyIssue?.KeyIssueID);
        }
    }, [selectedKeyIssue]);

    const activeKeyIssue = React.useMemo(() => {
        let aki = null;

        //If selectedKeyIssue is not null (i.e. when user clicks on KeyIssue name on ActionTable), set this keyIssue as activeKeyIssue.
        //Immediately set it to null so that when user clicks on other key issues on pop-up, the activeKeyIssue changes accordingly.
        // if (selectedKeyIssue !== null && Object.keys(selectedKeyIssue).length !== 0) {
        //     aki = { ...selectedKeyIssue };
        //     selectedKeyIssue = {};

        //     return aki;
        // }

        //return hasEntries(localKIs) ? localKIs.find((keyIssue) => keyIssue?.KeyIssueID === keyIssueID) : null;
        aki = hasEntries(localKIs) ? localKIs.find((keyIssue) => keyIssue?.KeyIssueID === keyIssueID) : null;
        // if (aki !== null && aki !== undefined) {
        //     aki.Action = { ...aki?.Action, Type: isNullOrEmpty(aki?.Action?.Action) ? 'Insight' : 'Action' };
        // }

        return aki;
    }, [localKIs, keyIssueID]);

    return (
        <Popover
            onClose={handleCancel}
            show={show}
            title="Key Issues"
            size={DialogSizes.FULL}
            lockHeight={true}
            closeOnOutsideClick={false}
            actions={
                <>
                    <Button type={ButtonTypes.MINIMAL} onClick={handleCancel}>
                        Cancel
                    </Button>
                    <Button type={ButtonTypes.FLAT} onClick={handleSave}>
                        Save
                    </Button>
                </>
            }
        >
            <div className={classes.editorRoot}>
                <div className="data">
                    <div className="actions">
                        {hasEntries(localKIs) && (
                            <>
                                <div className="list-heading">
                                    <Heading>Key Issues</Heading>
                                </div>
                                <ul>
                                    {localKIs
                                        .filter((ki) => ki.Action != null)
                                        .map((ki) => {
                                            const other = ki.KeyIssueName === 'Other' ? otherText[ki.PillarName] : '';
                                            const kiName = isNullOrEmpty(other) ? ki.KeyIssueName : `${ki.KeyIssueName}: ${other}`;
                                            return (
                                                <li
                                                    key={ki?.KeyIssueID}
                                                    className={cn({
                                                        active: ki?.KeyIssueID === keyIssueID,
                                                        e: ki?.PillarID === 1,
                                                        s: ki?.PillarID === 2,
                                                        g: ki?.PillarID === 3,
                                                        deleted: ki.isDeleted === true,
                                                    })}
                                                >
                                                    <span onClick={handleKeyIssueClick(ki)}>
                                                        {kiName} {ki.Action.EngagementType === 'Action' ? <i className="actionTag">Action</i> : ''}
                                                    </span>

                                                    {ki?.isValid === false && <i className="fas fa-exclamation"></i>}
                                                    {/* {ki?.isDeleted === true ? (
                                                        <i className="fas fa-undo-alt" onClick={handleRemoveKeyIssue(ki.KeyIssueID)}></i>
                                                    ) : (
                                                        <i className="far fa-times-circle" onClick={handleRemoveKeyIssue(ki.KeyIssueID)}></i>
                                                    )} */}
                                                </li>
                                            );
                                        })}
                                </ul>
                            </>
                        )}
                        {/* <AddKeyIssue keyIssues={localKIs} onAdd={handleAddKeyIssue} /> */}
                    </div>
                    <div className="editor">
                        {globalError != null ? <div className={classes.error}>{globalError}</div> : activeKeyIssue != null ? <EditorForm keyIssue={activeKeyIssue} onChange={handleChange} /> : null}
                    </div>
                </div>
            </div>
        </Popover>
    );
};

export default withStyles(styles)(ActionTrackingDialog);

const EditorForm = ({ keyIssue, onChange }) => {
    const escalationPaths = useSelector((state) => state.DimensionReducer.EscalationPaths);
    const actionTypes = useSelector((state) => state.DimensionReducer.ActionTypes);
    const escalationPathOtherID = React.useMemo(() => {
        return hasEntries(escalationPaths) ? escalationPaths.find((ep) => ep.Name === 'Other').ID : null;
    }, [escalationPaths]);
    const [tomorrowsDate, setTomorrowsDate] = useState(null);

    useEffect(() => {
        let date = new Date();
        date.setDate(date.getDate() + 1);
        setTomorrowsDate(date);

        keyIssue.Action.FollowUpDate = keyIssue.Action.FollowUpDate ?? date;
    }, []);

    const handleChange = (field, value, e) => {
        if (field === 'EngagementType' && value === 'Insight' && (isNullOrUndefined(keyIssue.Action.IsNew) || keyIssue.Action.IsNew === false)) {
            e?.stopPropagation();
            return;
        }

        if (field === 'EngagementType' && value === 'Action' && keyIssue.Action[field] === 'Action') {
            e?.stopPropagation();
            return;
        }

        let action = null;

        if (field === 'EngagementType' && value === 'Action') {
            action = {
                ...keyIssue.Action,
                WasDiscussed: field === 'WasDiscussed' ? value : true,
                [field]: value,
            };
        } else {
            action = {
                ...keyIssue.Action,
                //WasDiscussed: field === 'WasDiscussed' ? value : field === 'EngagementType' ? true : true,
                [field]: value,
            };
        }

        if (field === 'Status') {
            if (action.WasDiscussed === false) {
                action.FollowUpDate = null;
                //e?.stopPropagation();
                //return;
            }

            if (value === true) action.FollowUpDate = isNullOrEmpty(action.FollowUpDate) ? tomorrowsDate : action.FollowUpDate;
            else action.FollowUpDate = null;
        } else {
            if (action.WasDiscussed === false) {
                //action.Status = true;

                if (keyIssue !== null && !isNullOrUndefined(keyIssue.errors)) {
                    keyIssue.errors.Status = '';
                    keyIssue.errors.Action = '';
                    keyIssue.errors.ActionTypeID = '';
                    keyIssue.errors.EscalationPathOther = '';
                    keyIssue.errors.Result = '';
                    keyIssue.errors.TargetEndDate = '';
                }
            }
        }

        // Set default followup date if status is follow up.

        onChange({
            ...keyIssue,
            Action: action,
        });
    };

    return (
        keyIssue != null && (
            <React.Fragment key={keyIssue.KeyIssueID}>
                <div className="editorRow">
                    <ButtonBar label="Type">
                        <Button type={keyIssue?.Action?.EngagementType !== 'Action' ? ButtonTypes.FLAT : ButtonTypes.MINIMAL} onClick={(e) => handleChange('EngagementType', 'Insight', e)}>
                            Insight
                        </Button>
                        <Button type={keyIssue?.Action?.EngagementType === 'Action' ? ButtonTypes.FLAT : ButtonTypes.MINIMAL} onClick={(e) => handleChange('EngagementType', 'Action', e)}>
                            Action
                        </Button>
                    </ButtonBar>
                </div>
                <div className="editorRow">
                    <ButtonBar label="Was this key issue discussed during the engagement meeting?">
                        <Button
                            type={keyIssue?.Action?.WasDiscussed === true ? ButtonTypes.FLAT : ButtonTypes.MINIMAL}
                            onClick={() => handleChange('WasDiscussed', true)}
                            disabled={keyIssue?.Action?.EngagementType === 'Insight'}
                        >
                            Yes
                        </Button>
                        <Button
                            type={keyIssue?.Action?.WasDiscussed === false ? ButtonTypes.FLAT : ButtonTypes.MINIMAL}
                            onClick={() => handleChange('WasDiscussed', false)}
                            disabled={keyIssue?.Action?.EngagementType === 'Insight'}
                        >
                            No
                        </Button>
                    </ButtonBar>
                </div>
                <div className="editorRow">
                    <ButtonBar required={keyIssue?.Action?.EngagementType === 'Action'} label="Status" errorText={keyIssue?.errors?.Status}>
                        <Button
                            type={keyIssue?.Action?.Status === true ? ButtonTypes.FLAT : ButtonTypes.MINIMAL}
                            onClick={() => handleChange('Status', true)}
                            disabled={keyIssue?.Action?.EngagementType === 'Insight'}
                        >
                            Follow Up
                        </Button>
                        <Button
                            type={keyIssue?.Action?.Status === false ? ButtonTypes.FLAT : ButtonTypes.MINIMAL}
                            onClick={() => handleChange('Status', false)}
                            disabled={keyIssue?.Action?.EngagementType === 'Insight'}
                        >
                            Close
                        </Button>
                    </ButtonBar>
                    {keyIssue?.Action?.Status === true && (
                        <div className="editorRow vertical">
                            <Label required={keyIssue?.Action?.EngagementType === 'Action'}>Follow-up On Date</Label>
                            <DatePicker
                                value={keyIssue.Action.FollowUpDate}
                                onChange={(date) => handleChange('FollowUpDate', date)}
                                animateYearScrolling={true}
                                style={{ width: 200 }}
                                disablePast={true}
                                minDateMessage={null} //"Date should not be before today's date"
                                disabled={keyIssue?.Action?.EngagementType === 'Insight'}
                                minDate={tomorrowsDate}
                            />
                            {keyIssue?.errors?.FollowUpDate && <small className="errorText">* {keyIssue?.errors?.FollowUpDate}</small>}
                        </div>
                    )}
                </div>

                <div className="editorRow">
                    <TextField
                        autoFocus={true}
                        defaultValue={keyIssue?.Action?.Action}
                        errorText={keyIssue?.errors?.Action}
                        multiline={true}
                        onChange={(evt) => handleChange('Action', evt.target.value)}
                        placeholder="Enter required action"
                        required={keyIssue?.Action?.WasDiscussed === true && keyIssue?.Action?.EngagementType === 'Action' ? true : false}
                        title="Requested Company Action"
                        inputProps={{ maxLength: 2048 }}
                        disabled={keyIssue?.Action?.EngagementType === 'Insight' || keyIssue?.Action?.WasDiscussed !== true}
                    />
                </div>
                <div className="editorRow">
                    <Select
                        label="Action Type"
                        required={keyIssue?.Action?.WasDiscussed === true && keyIssue?.Action?.EngagementType === 'Action' ? true : false}
                        errorText={keyIssue?.errors?.ActionTypeID}
                        onChange={(option) => handleChange('ActionTypeID', option.value)}
                        options={toOptionList(actionTypes, 'ID', 'Name')}
                        value={keyIssue?.Action?.ActionTypeID}
                        isDisabled={keyIssue?.Action?.EngagementType === 'Insight' || keyIssue?.Action?.WasDiscussed !== true}
                    />
                    <div className="editorRow vertical">
                        <Label required={keyIssue?.Action?.WasDiscussed === true && keyIssue?.Action?.EngagementType === 'Action' ? true : false}>Target End Date</Label>
                        <DatePicker
                            value={keyIssue?.Action?.TargetEndDate}
                            onChange={(date) => handleChange('TargetEndDate', date)}
                            animateYearScrolling={false}
                            //style={{ width: 200 }}
                            disablePast={true}
                            minDateMessage={null}
                            disabled={keyIssue?.Action?.EngagementType === 'Insight' || keyIssue?.Action?.WasDiscussed !== true}
                        />
                        {keyIssue?.errors?.TargetEndDate && <small className="errorText">* {keyIssue?.errors?.TargetEndDate}</small>}
                    </div>
                </div>
                <div className="editorRow">
                    <TextField
                        defaultValue={keyIssue?.Action?.Comment}
                        multiline={true}
                        onChange={(evt) => handleChange('Comment', evt.target.value)}
                        placeholder="Enter comments about the discussion"
                        title="Details"
                        inputProps={{ maxLength: 2048 }}
                        disabled={keyIssue?.Action?.EngagementType === 'Insight'}
                    />
                </div>
                <div className="editorRow">
                    <Select
                        label="Future Escalation Path"
                        onChange={(option) => handleChange('EscalationPathID', option.value)}
                        options={toOptionList(escalationPaths, 'ID', 'Name')}
                        value={keyIssue?.Action?.EscalationPathID}
                        isDisabled={keyIssue?.Action?.EngagementType === 'Insight' || keyIssue?.Action?.WasDiscussed !== true}
                        menuPlacement="top"
                        //menuPosition="fixed"
                    />
                    {keyIssue?.Action?.EscalationPathID === escalationPathOtherID && (
                        <TextField
                            defaultValue={keyIssue?.Action?.EscalationPathOther}
                            errorText={keyIssue?.errors?.EscalationPathOther}
                            onChange={(evt) => handleChange('EscalationPathOther', evt.target.value)}
                            placeholder="Enter other escalation path"
                            required={keyIssue?.Action?.WasDiscussed === true && keyIssue?.Action?.EngagementType === 'Action' ? true : false}
                            title="Other Escalation Path"
                            inputProps={{ maxLength: 2048 }}
                            disabled={keyIssue?.Action?.EngagementType === 'Insight' || keyIssue?.Action?.WasDiscussed !== true}
                        />
                    )}
                </div>
                <div className="editorRow">
                    <Select
                        label="Result of Key Issue Discussion"
                        required={keyIssue?.Action?.WasDiscussed === true && keyIssue?.Action?.EngagementType === 'Action' ? true : false}
                        errorText={keyIssue?.errors?.Result}
                        onChange={(option) => handleChange('Result', option.value)}
                        options={toOptionList(ResultCodes, 'value', 'label')}
                        value={keyIssue?.Action?.Result}
                        isDisabled={keyIssue?.Action?.EngagementType === 'Insight' || keyIssue?.Action?.WasDiscussed !== true}
                        menuPlacement="top"
                        //menuPosition="fixed"
                    />
                </div>
            </React.Fragment>
        )
    );
};

// const AddKeyIssue = ({ keyIssues, onAdd }) => {
//     const noteKIs = useSelector((state) => state.NoteReducer.NoteKeyIssues);
//     const [collapsed, setCollapsed] = useState(true);
//     const [pillar, setPillar] = useState(null);
//     const [otherError, setOtherError] = useState(null);
//     const [otherText, setOtherText] = useState('');
//     const [selected, setSelected] = useState(null);

//     const clear = () => {
//         setPillar(null);
//         setSelected(null);
//         setOtherText(null);
//     };
//     const handleAddClick = () => {
//         const found = noteKIs.find((ki) => ki.KeyIssueID === selected.value);
//         if (selected?.option.label === 'Other' && isNullOrEmpty(otherText)) {
//             setOtherError('This is required for the selected key issue.');
//         } else {
//             onAdd(found, otherText);
//             clear();
//         }
//     };
//     const handleCollapseToggle = (collapsed) => () => {
//         clear();
//         setCollapsed(collapsed);
//     };
//     const handleKeyIssueChange = (option) => {
//         setSelected(option);
//         setOtherText(null);
//     };
//     const handleOtherTextChange = (evt) => {
//         setOtherText(evt.target.value);
//     };
//     const handlePillarClick = (type) => () => {
//         setPillar(type);
//     };

//     const filteredKeyIssues = useMemo(() => {
//         const kis = pillar == null ? [] : noteKIs;
//         return kis
//             .filter((ki) => ki.PillarName === pillar && !ki.IsDeprecated)
//             .reduce((acc, ki) => {
//                 if (!_some(keyIssues, ['KeyIssueID', ki.KeyIssueID])) {
//                     acc.push(ki);
//                 }
//                 return acc;
//             }, []);
//     }, [noteKIs, pillar, keyIssues]);

//     return (
//         <div className={cn('addNew', { collapsed: collapsed === true && hasEntries(keyIssues), full: !hasEntries(keyIssues) })}>
//             {collapsed === true && hasEntries(keyIssues) ? (
//                 <Button type={ButtonTypes.FLAT} onClick={handleCollapseToggle(false)}>
//                     Add Key Issue
//                 </Button>
//             ) : (
//                 <>
//                     <Heading>Add Key Issue</Heading>
//                     <ButtonBar label="Select Pillar">
//                         <Button type={ButtonTypes.MINIMAL} className={cn('e', { selected: pillar === 'Environment' })} onClick={handlePillarClick('Environment')}>
//                             Env
//                         </Button>
//                         <Button type={ButtonTypes.MINIMAL} className={cn('s', { selected: pillar === 'Social' })} onClick={handlePillarClick('Social')}>
//                             Soc
//                         </Button>
//                         <Button type={ButtonTypes.MINIMAL} className={cn('g', { selected: pillar === 'Governance' })} onClick={handlePillarClick('Governance')}>
//                             Gov
//                         </Button>
//                     </ButtonBar>
//                     {pillar != null && (
//                         <div className="select">
//                             <Select
//                                 label="Select Key Issue"
//                                 options={toOptionsList(filteredKeyIssues, 'KeyIssueName', 'KeyIssueID')}
//                                 onChange={handleKeyIssueChange}
//                                 styles={{
//                                     menuList: (style) => ({
//                                         ...style,
//                                         maxHeight: 150,
//                                     }),
//                                 }}
//                             />
//                         </div>
//                     )}
//                     {selected?.option.label === 'Other' && (
//                         <TextField
//                             autoFocus={true}
//                             errorText={otherError}
//                             multiline={false}
//                             onChange={handleOtherTextChange}
//                             placeholder="Enter other key issue"
//                             required={true}
//                             title="Other Key Issue Name"
//                         />
//                     )}
//                     <div className="add-button">
//                         <Button disabled={selected == null} type={ButtonTypes.PRIMARY} onClick={handleAddClick}>
//                             Add
//                         </Button>
//                     </div>
//                     <div className="close-button">
//                         {hasEntries(keyIssues) && (
//                             <Button type={ButtonTypes.FLAT} onClick={handleCollapseToggle(true)}>
//                                 Close
//                             </Button>
//                         )}
//                     </div>
//                 </>
//             )}
//         </div>
//     );
// };

/*
    <TextEditor value={note.data.Text} isEdit={canEdit} onChange={handleEditText} />
*/
