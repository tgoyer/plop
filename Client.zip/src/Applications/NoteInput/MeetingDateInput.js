import * as React from 'react';
import cn from 'classnames';
import { useSelector } from 'react-redux';

import { withStyles } from '@material-ui/core/styles';

import { InputLabel } from '@material-ui/core';

import DatePicker from 'components/Form/DatePicker';
import SearchableDropdown from 'UIComponents/MaterialUI/SearchableDropdown';
import Tooltip from 'UIComponents/Tooltip';

import { dateTimeFormat, toDateTime, formatDate } from 'Utils/dateHelper';
import { pxToRem, getUrlParameter } from 'Utils/layoutHelper';
import { toOptionsList, toSingleOption } from 'Utils/selectHelper';

const styles = (theme) => ({
    clearButton: {
        background: 'none',
        border: 'none',
        fontSize: pxToRem(11),
        marginTop: 4,
        '&:active, &:focus': {
            outline: 0,
            border: 'none',
        },
    },
    container: {
        display: 'flex',
        flexDirection: 'row',
        margin: 0,
        width: '100%',
    },
    divider: {
        position: 'relative',
        width: 25,
        margin: '6px 20px',
        '& .line': {
            position: 'absolute',
            left: '49%',
            top: 0,
            bottom: 0,
            width: 1,
            background: '#ccc',
        },
        '& .wordwrapper': {
            textAlign: 'center',
            height: 12,
            position: 'absolute',
            left: 0,
            right: 0,
            top: '50%',
            marginTop: -12,
            '& .word': {
                color: '#ccc',
                textTransform: 'uppercase',
                letterSpacing: '1px',
                padding: 3,
                font: 'bold 12px arial, sans-serif',
                background: '#fff',
            },
        },
    },
    control: {
        minWidth: 'calc(50% - 32px)',
    },
    dropDown: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-end',
        marginTop: 9,
        width: '100%',
    },
    label: {
        fontSize: pxToRem(11),
        marginBottom: 6,
        color: 'rgba(0,0,0,.5)',
        fontWeight: 700,
    },
    readOnly: {
        marginBottom: 16,
    },
});

const MeetingDateInput = ({ classes, disabled, editable, onChange, meetingID, engagementDate, parentEngageDate }) => {
    const meetings = useSelector((state) => state.CompanyReducer.Meetings.Data);
    const urlMeetingID = Number(getUrlParameter('meetingID'));

    const handleMeetingChange = (evt) => {
        const meeting = meetings.find((m) => m.CalendarMeetingID === evt?.value);
        const val = {
            meeting: meeting == null ? null : meeting,
            engagementDate: null,
        };
        onChange(val);
    };

    const handleDatePickerChange = (date) => {
        const val = {
            meeting: null,
            engagementDate: date,
        };
        onChange(val);
    };

    const meetingOptions = React.useMemo(() => {
        return toOptionsList(meetings, 'MeetingDate', 'CalendarMeetingID').map((option) => {
            option.label = toDateTime(option.label).toFormat(dateTimeFormat);
            return option;
        });
    }, [meetings]);

    const selectedMeeting = React.useMemo(() => {
        const meeting = meetings?.find((m) => m.CalendarMeetingID === meetingID);
        const option = meeting == null ? null : toSingleOption(meeting, 'MeetingDate', 'CalendarMeetingID');
        if (option != null) {
            option.label = toDateTime(option.label).toFormat(dateTimeFormat);
        }
        return option;
    }, [meetingID, meetings]);

    React.useEffect(() => {
        if (urlMeetingID != null && urlMeetingID > 0) {
            const meeting = meetings?.find((m) => m.CalendarMeetingID === urlMeetingID);
            onChange({
                meeting: meeting == null ? null : meeting,
                engagementDate: null,
            });
        }
    }, [onChange, urlMeetingID, meetings]);

    return (
        <div className={classes.container}>
            {editable === true ? (
                <>
                    <div className={classes.control}>
                        <InputLabel style={{ width: '100%' }}>
                            <div className={classes.label} data-tip data-for="Tooltip_Meeting">
                                Pick a corporate calendar meeting
                            </div>
                            <div className={classes.dropDown}>
                                <SearchableDropdown
                                    defaultValue={selectedMeeting}
                                    dropdownItems={meetingOptions}
                                    isDisabled={disabled}
                                    onChange={handleMeetingChange}
                                    placeholder={'Select'}
                                    style={{ width: '100%' }}
                                />
                                <button className={classes.clearButton} onClick={() => handleMeetingChange({ value: -1 })}>
                                    clear
                                </button>
                            </div>
                        </InputLabel>
                    </div>
                    <div className={classes.divider}>
                        <div className="line"></div>
                        <div className="wordwrapper">
                            <div className="word">or</div>
                        </div>
                    </div>
                    <div className={classes.control}>
                        <DatePicker
                            label="Enter engagement date"
                            value={engagementDate}
                            onChange={handleDatePickerChange}
                            animateYearScrolling={false}
                            style={{ width: '100%' }}
                            disableFuture={true}
                            maxDateMessage="Date should not be after today's date"
                            InputLabelProps={{
                                className: cn({
                                    'required asterisk': editable,
                                }),
                                shrink: true,
                            }}
                            data-tip
                            data-for="Tooltip_EngagementDate"
                            disabled={disabled}
                            minDate={parentEngageDate ?? undefined}
                        />
                    </div>
                </>
            ) : (
                <div className={classes.readOnly}>
                    <div className={classes.label} data-tip data-for="Tooltip_EngagementDate">
                        Engagement Date
                    </div>
                    {formatDate(engagementDate)}
                </div>
            )}
            <Tooltip id="Tooltip_Meeting">Pick a meeting date and time from the list of scheduled meetings.</Tooltip>
            <Tooltip id="Tooltip_EngagementDate">Date of the engagement meeting (in person or call)</Tooltip>
        </div>
    );
};
export default React.memo(withStyles(styles)(MeetingDateInput));
