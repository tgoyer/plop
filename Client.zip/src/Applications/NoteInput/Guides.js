import React from 'react';
import cn from 'classnames';

import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from '../../UIComponents/Tooltip';

const styles = (theme) => ({
    root: {
        ...theme.mixins.gutters(),
        padding: '10px 16px !important',
        margin: '0 0 16px 0',
    },
    guideContainer: {
        color: '#6987b9',
        display: 'inline-block',
        fontWeight: 700,
        margin: '2px 5px',
    },
    questionaireLink: {
        color: theme.palette.primary.main,
        display: 'inline-block',
        padding: '2px 10px',
    },
    questionaireIcon: {
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        padding: '6px 8px',
    },
});

const NoteGuides = (props) => {
    const { classes, sectorGuide } = props;

    const guideComponents = [];

    if (sectorGuide != null) {
        guideComponents.push({
            link: (
                <a
                    data-tip
                    data-for="Tooltip_Env_Guide"
                    href={'/assets/documents/questionaires/Environmental_Questions_' + sectorGuide.replace(' ', '_') + '.pdf'}
                    rel="noreferrer noopener"
                    target="_blank"
                    className={classes.questionaireLink}
                >
                    {sectorGuide + ' Sector Environmental Guide'}
                </a>
            ),
            tooltip: (
                <Tooltip id="Tooltip_Env_Guide">
                    <p>A brief overview and list of questions to guide research and engagement with companies in the {sectorGuide} Sector on material environmental issues</p>
                </Tooltip>
            ),
        });
        guideComponents.push({
            link: (
                <a
                    data-tip
                    data-for="Tooltip_Soc_Guide"
                    href={'/assets/documents/questionaires/Social_Questions_' + sectorGuide.replace(' ', '_') + '.pdf'}
                    rel="noreferrer noopener"
                    target="_blank"
                    className={classes.questionaireLink}
                >
                    {sectorGuide + ' Sector Social Guide'}
                </a>
            ),
            tooltip: (
                <Tooltip id="Tooltip_Soc_Guide">
                    <p>A brief overview and list of questions to guide research and engagement with companies in the {sectorGuide} Sector on material social issues</p>
                </Tooltip>
            ),
        });
    }
    guideComponents.push({
        link: (
            <a data-tip data-for="Tooltip_Gov_Guide" href={'/assets/documents/questionaires/Governance_Questions.pdf'} rel="noreferrer noopener" target="_blank" className={classes.questionaireLink}>
                {'Governance Guide'}
            </a>
        ),
        tooltip: (
            <Tooltip id="Tooltip_Gov_Guide">
                <p>A general guide to evaluating and engaging with companies across all sectors and industries on material issues related to corporate governance</p>
            </Tooltip>
        ),
    });

    return (
        <Paper className={classes.root} elevation={1}>
            <div className={classes.guideContainer}>ESG Guide(s):</div>
            {guideComponents.map((item, idx) => (
                <div key={idx} style={{ backgroundColor: '#e0ebff', margin: '2px 5px', display: 'inline-block' }}>
                    <i className={cn('fas fa-book', classes.questionaireIcon)}></i>
                    {item.link}
                    {item.tooltip}
                </div>
            ))}
        </Paper>
    );
};

export default withStyles(styles)(React.memo(NoteGuides));
