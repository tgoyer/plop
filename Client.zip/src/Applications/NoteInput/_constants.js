export const Colors = Object.freeze({
    e: "#60ba53",
    s: "#1e98d7",
    g: "#f08f50",
});

export const InputTypes = Object.freeze({
    ENGAGEMENT: 2,
    RESEARCH: 1
});

export const PillarTypes = Object.freeze({
    ENV: { ID: 'Environment', LABEL: 'Environmental' },
    SOC: { ID: 'Social', LABEL: 'Social' },
    GOV: { ID: 'Governance', LABEL: 'Governance' },
});