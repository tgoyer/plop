import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import cn from 'classnames';

import _get from 'lodash/get';

import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import Dropzone from 'react-dropzone';

import CommonDialog from 'UIComponents/MaterialUI/CommonDialog';
import ErrorDialog from 'UIComponents/MaterialUI/CommonErrorDialog';
import UploadStepper from '../KnowledgeCenter/UploadTab/UploadStepper';

import { clearSearchFilesByName, getFileDefinitions, searchFilesByName } from 'store/FileModule';

import { generateId } from 'Utils/layoutHelper';
import { formatByteSize } from 'Utils/numberHelper';
import Downloader from 'componentlibrary/file/Downloader';

const styles = (theme) => ({
    button: {
        marginBottom: 10,
        marginLeft: 10,
        '&:disabled': {
            backgroundColor: '#cccccc',
            boxShadow: 'none',
        },
    },
    confirmFile: {
        marginLeft: 20,
    },
    confirmMessage: {
        fontWeight: 700,
    },
    dropZone: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 25,
    },
    iconActions: {
        width: 105,
        textAlign: 'center',
        '& > div': {
            display: 'flex',
            flexDirection: 'row',
        },
        '& i': {
            color: '#000000',
            cursor: 'pointer',
            fontSize: 20,
            padding: '5px 10px',
        },
        '& a, & a:hover': {
            color: '#000000',
        },
    },
    iconUpload: {
        fontSize: 32,
        padding: '0 15px 0 0',
    },
    filesTable: {
        border: 0,
        borderCollapse: 'collapse',
        fontSize: 12,
        margin: '0 10px',
        width: 'calc(100% - 20px)',
        '& thead th': {
            backgroundColor: '#6987B9',
            color: '#ffffff',
            fontWeight: 700,
            padding: '4px 8px',
            textAlign: 'center',
        },
        '& tbody tr': {
            '&:nth-child(odd)': {
                backgroundColor: '#eee',
            },
            backgroundColor: '#fafafa',
        },
        '& tbody tr.white': {
            backgroundColor: '#ffffff !important',
            '& td': {
                fontWeight: 700,
            },
        },
        '& tbody td': {
            border: '2px solid #ffffff',
            color: '#000000',
            fontWeight: 400,
            margin: 2,
            padding: '4px 8px',
        },
    },
    sectionHeader: {
        borderBottom: '2px solid #bdd7ff',
        color: '#666',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '0 0 10px 0',
        padding: 5,
    },
    subtext: {
        color: '#666666',
        fontSize: 8,
        fontStyle: 'italic',
        lineHeight: '9px',
        marginLeft: 20,
    },
});

const buildDefault = (company) => ({
    companies: company == null ? [] : [{ id: company.CompanyID, name: `${company.CompanyName} (${company.Ticker})`, value: 'include' }],
});
const getExistingFiles = (allFiles, files, noteId) => {
    const attachmentList = _get(files, 'Data.' + noteId, []);
    return Array.isArray(attachmentList) && attachmentList.length > 0 ? getFileDefinitions(attachmentList, allFiles) : [];
};
const processFiles = (droppedFiles, duplicates, maxFileSize) => {
    const getDuplicateFile = (file) => duplicates.find((df) => df.FileName === file.name);
    const checkFileSize = (file, maxSize) => file.size <= Number(maxSize) && file.size >= 1;

    const newMap = droppedFiles.reduce((acc, file) => {
        const invalidSize = !checkFileSize(file, maxFileSize);
        const dupFile = getDuplicateFile(file);
        const isDuplicate = dupFile != null;

        acc[file.name] = {
            id: generateId(),
            file,
            isNew: true,
            isUploading: false,
            isValid: invalidSize ? false : null,
            isWarning: isDuplicate,
            message: invalidSize
                ? `File cannot be larger than ${formatByteSize(maxFileSize)} or less than 1 B file.`
                : isDuplicate
                ? `A file with this name has already been uploaded by ${_get(dupFile, 'External.UploadedBy.FullName', 'Unknown')}. You may continue to upload your file.`
                : null,
        };

        return acc;
    }, {});

    return newMap;
};

const Attachments = ({ classes, editable, files = {}, metadata = {}, onChange, onDelete, uploadCount }) => {
    const dispatch = useDispatch();
    const dropZoneRef = React.useRef();

    const [deleteFileName, setDeleteFileName] = React.useState(null);
    const [deleteId, setDeleteId] = React.useState(null);
    const [droppedFiles, setDroppedFiles] = React.useState([]);
    const [errorMessages, setErrorMessages] = React.useState([]);
    const [fileData, setFileData] = React.useState([]);
    const [fileMap, setFileMap] = React.useState({});
    const [tmpFileMap, setTmpFileMap] = React.useState({});
    const [showDeleteConfirm, setShowDeleteConfirm] = React.useState(false);
    const [showFileStepper, setShowFileStepper] = React.useState(false);
    const [loadComplete, setLoadComplete] = React.useState(false);

    const allFiles = useSelector((state) => state.FileReducer.Files.Data);
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const maxFileSize = useSelector((state) => state.AppSettingsReducer.ServerSettings.Attachments.FileSizeLimitInKB);
    const maxFileCount = useSelector((state) => state.AppSettingsReducer.ServerSettings.Attachments.MaxFiles);
    const searchFiles = useSelector((state) => state.FileReducer.SearchFilesByName);

    const noteId = React.useMemo(() => metadata?.noteId, [metadata]);
    const defaultUploadData = React.useMemo(() => buildDefault(company), [company]);
    const existingFiles = React.useMemo(() => getExistingFiles(allFiles, files, noteId), [allFiles, files, noteId]);

    const handleDelete = (id) => (evt) => {
        const ids = _get(files, 'Data.' + noteId, []);
        const found = ids.find((i) => i === id);
        const file = allFiles[found];
        if (file != null) {
            setDeleteId(file.Id);
            setDeleteFileName(file.FileName);
            setShowDeleteConfirm(true);
        }
    };
    const handleDeleteClose = () => {
        setShowDeleteConfirm(false);
    };
    const handleDeleteConfirm = () => {
        setShowDeleteConfirm(false);
        if (onDelete != null && deleteId != null) {
            onDelete(deleteId);
        }
    };
    const handleDrop = (files) => {
        if (files.length > maxFileCount) {
            setErrorMessages(['Max number of files exceeded.  Maximum allowed files is ' + maxFileCount]);
            return;
        }
        dispatch(searchFilesByName(files.map((file) => file.name)));
        setDroppedFiles(files);
    };
    const handleErrorClose = () => {
        setErrorMessages([]);
    };
    const handleRemove = (id) => (evt) => {
        const newData = fileData.filter((data) => data.file.id !== id);
        const files = Object.keys(fileMap).reduce((acc, key) => {
            const newFile = fileMap[key];
            if (newFile.id !== id) acc[key] = newFile;
            return acc;
        }, {});

        setFileData(newData);
        setFileMap(files);

        if (onChange) {
            onChange(files);
        }
    };
    const handleUploadCancel = () => {
        setFileMap({});
    };
    const handleUploadConfirm = (data) => {
        const newData = [...fileData, ...data];
        const newMap = {
            ...fileMap,
            ...tmpFileMap,
        };

        setFileData(newData);
        setFileMap(newMap);
        setShowFileStepper(false);

        if (onChange) {
            onChange(newData);
        }
    };

    React.useEffect(() => {
        if (searchFiles.isLoaded) {
            const map = processFiles(droppedFiles, searchFiles.Hits, maxFileSize);
            setTmpFileMap(map);
            setShowFileStepper(true);
        }
    }, [searchFiles, droppedFiles, maxFileSize]);

    React.useEffect(() => {
        if (files.isLoaded === true) {
            setLoadComplete(true);
        }
    }, [files.isLoaded]);

    React.useEffect(() => {
        return () => {
            dispatch(clearSearchFilesByName());
        };
    }, [dispatch]);

    return (
        <>
            <div className={classes.sectionHeader}>Attachments</div>
            {!loadComplete && (
                <div className={classes.iconActions}>
                    <i className="fas fa-circle-notch fa-spin"></i>
                </div>
            )}
            {editable && loadComplete && (
                <>
                    <Dropzone
                        ref={dropZoneRef}
                        disableClick={true}
                        onDrop={handleDrop}
                        style={{
                            border: '3px dashed #cfcfcf',
                            margin: 10,
                            padding: 10,
                        }}
                        activeStyle={{
                            backgroundColor: '#dce3ef',
                            border: '3px dashed #6987B9',
                        }}
                        multiple
                    >
                        {({ getRootProps }) => (
                            <div className={classes.dropZone} {...getRootProps()}>
                                <i className={cn(classes.iconUpload, 'fas fa-file-upload')}></i>
                                <span>
                                    Drag and drop one or more files directly into this box to add them to this note. You can also press the <strong>Attach Files</strong> button below to bring up a
                                    file browser.
                                </span>
                            </div>
                        )}
                    </Dropzone>
                    <Button variant="contained" className={classes.button} color="primary" onClick={() => dropZoneRef.current.open()}>
                        Attach Files
                    </Button>
                </>
            )}
            {loadComplete && (
                <table className={classes.filesTable}>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(!Array.isArray(existingFiles) || existingFiles.length === 0) && (fileMap == null || Object.keys(fileMap).length === 0) && (
                            <tr>
                                <td colSpan="2">No files have been attached to this note.</td>
                            </tr>
                        )}
                        {existingFiles.map((file) => (
                            <tr key={file.Id}>
                                <td>{file.FileName}</td>
                                <td className={classes.iconActions}>
                                    <div>
                                        <Downloader useApiResource={true} uri={`/files/${file.Id}`}>
                                            <i className="fas fa-download"></i>
                                        </Downloader>
                                        {editable && <i className="fas fa-trash-alt" onClick={handleDelete(file.Id)}></i>}
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {fileMap != null &&
                            Object.keys(fileMap).map((key) => {
                                const newFile = fileMap[key];
                                return (
                                    <tr key={newFile.id}>
                                        <td>
                                            {newFile.file.name}
                                            <br />
                                            <span className={classes.subtext}>(Upload pending. File will be uploaded when the note is saved.)</span>
                                        </td>
                                        <td className={classes.iconActions}>{editable && <i className="fas fa-minus" onClick={handleRemove(newFile.id)}></i>}</td>
                                    </tr>
                                );
                            })}
                        {uploadCount != null && (
                            <tr className="white">
                                <td colSpan="2">Uploading files. Please wait...</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            )}
            <ErrorDialog onClose={handleErrorClose} messages={errorMessages} />

            <CommonDialog showActions={true} title="Confirm Delete" open={showDeleteConfirm} onClose={handleDeleteClose} onConfirm={handleDeleteConfirm}>
                <p className={classes.confirmMessage}>This will delete the following file. This cannot be undone.</p>
                <p className={classes.confirmFile}>{deleteFileName}</p>
                <p className={classes.confirmMessage}>Are you sure you wish to continue?</p>
            </CommonDialog>

            <UploadStepper defaultValues={defaultUploadData} onCancel={handleUploadCancel} onComplete={handleUploadConfirm} show={showFileStepper} files={tmpFileMap} />
        </>
    );
};

export default withStyles(styles)(React.memo(Attachments));
