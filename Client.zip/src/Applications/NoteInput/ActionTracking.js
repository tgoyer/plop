import React from 'react';
import cn from 'classnames';
//import { useParams } from 'react-router-dom';

import { Paper } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';

import ActionTable from 'Applications/NoteInput/ActionTracking/ActionTable';
import Dialog from 'Applications/NoteInput/ActionTracking/Dialog';
import HistoryDialog from 'Applications/NoteInput/ActionTracking/HistoryDialog';
import Setup from 'Applications/NoteInput/ActionTracking/Setup';

import { Button, ButtonTypes } from 'components/Form';
import { createInitialActions } from 'Applications/NoteInput/ActionTracking/actionHelper';

import { hasEntries } from 'Utils/arrayHelpers';
import { PillarTypes } from 'Applications/NoteInput/_constants';
import _orderBy from 'lodash/orderBy';
import { isNullOrUndefined } from 'Utils/objectHelpers';

const styles = (theme) => ({
    root: {
        display: 'flex',
        flexDirection: 'row',
        '& .paper': {
            ...theme.mixins.gutters(),
            padding: '12px !important',
            margin: '0 0 16px 0',
            flex: '0 1 100%',
            //width: '50%',
            '&.setup-wizard': {
                flexBasis: '100%',
                maxWidth: 850,
                //width: '100%',
            },
            '&.action-table': {
                //flexBasis: '100%',
                width: '100%',
            },
        },
    },
    container: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
    },
    header: {
        display: 'flex',
        flexDirection: 'row',
        '& > button + button': {
            marginLeft: 8,
        },
        '& span + i, & i + span': {
            marginLeft: 8,
        },
    },
    '@media (max-width: 990px)': {
        root: {
            '&.action-table': {
                flexBasis: '50%',
                //maxWidth: '600',
            },
        },
    },
});

// Map flattened key issues list back to a pillars dictionary for returning to Engagement entry.
const mapKeyIssuesToPillars = (pillars, newKeyIssues) => {
    const newLocalPillars = { ...pillars };

    newLocalPillars.hasActions = newKeyIssues.some((ki) => ki.Action != null);

    // Generate new pillar -> key issue lists.
    Object.keys(newLocalPillars).forEach((key) => {
        const pillar = newLocalPillars[key];
        if (hasEntries(pillar?.keyIssues)) {
            pillar.keyIssues = pillar.keyIssues.map((pki) => {
                const newKI = newKeyIssues.find((nki) => nki.KeyIssueID === pki.KeyIssueID);
                return newKI != null ? newKI : { ...pki, IsSelected: false, Action: null };
            });
        }
    });

    return newLocalPillars;
};

const ActionTracking = ({ classes, readOnly = true, pillars, onChange, isRightDrawerOpen }) => {
    const [localPillars, setLocalPillars] = React.useState({});
    const [showDialog, setShowDialog] = React.useState(false);
    const [showHistoryDialog, setShowHistoryDialog] = React.useState(false);
    const [parentNoteID, setParentNoteID] = React.useState(null);
    //const { noteID } = useParams();
    const [selectedKeyIssue, setSelectedKeyIssue] = React.useState({});
    const [otherText, setOtherText] = React.useState({});

    const handleDialogCancel = () => {
        setShowDialog(false);

        onChange({
            ...pillars,
        });
    };
    const handleDialogSave = (keyIssues, otherTextObject, engageDate) => {
        const newPillars = mapKeyIssuesToPillars(localPillars, keyIssues);

        Object.keys(otherTextObject).forEach((pillar) => {
            newPillars[pillar].other = otherTextObject[pillar];
        });

        if (engageDate !== undefined) newPillars.ParentNoteEngageDate = engageDate;

        setShowDialog(false);

        Object.keys(newPillars).forEach((key) => {
            if (key !== 'hasActions' && key !== 'other' && key !== 'ParentNoteEngageDate') newPillars[key].checked = newPillars[key].keyIssues?.some((ki) => ki.IsSelected === true);
        });

        onChange(newPillars);
    };
    const handleHistoryDialogToggle = (value) => () => {
        setShowHistoryDialog(value);
    };
    const handleEditClick = () => {
        setSelectedKeyIssue(selectedIssues[0]);
        setShowDialog(true);
    };
    const handleSetupComplete = (config) => {
        //setShowDialog(config?.isOngoing);
        setParentNoteID(config?.noteID);

        if (config?.parentKeyIssues != null) {
            const actions = createInitialActions(config?.parentKeyIssues, config?.noteID);
            const kis = mapKeyIssuesToPillars(localPillars, actions);

            setLocalPillars(kis);

            const theSelectedIssues = Object.keys(kis).reduce((acc, key) => {
                if (kis[key] === null || kis[key] === 'hasActions') return acc;
                const { keyIssues } = kis[key];
                const selected = hasEntries(keyIssues) ? keyIssues.filter((ki) => ki.IsSelected === true) : [];
                return [...acc, ...selected];
            }, []);

            const issue = theSelectedIssues.filter((ki) => ki.Action.IsDeleted !== true);
            handleDialogSave(issue, config?.otherText, config?.engageDate);
        } else {
            setLocalPillars({});
            onChange({ hasActions: true });
        }
    };

    React.useEffect(() => {
        setLocalPillars(pillars);
        setOtherText({
            Environment: pillars['Environment']?.other,
            Social: pillars['Social']?.other,
            Governance: pillars['Governance']?.other,
        });
    }, [pillars]);

    const handleKeyIssueClick = (keyIssue) => {
        setSelectedKeyIssue(keyIssue);
        setShowDialog(true);
    };

    const selectedIssues = React.useMemo(() => {
        let issues = Object.keys(localPillars).reduce((acc, key) => {
            if (isNullOrUndefined(localPillars[key])) return acc;
            const { keyIssues } = localPillars[key];
            const selected = hasEntries(keyIssues) ? keyIssues.filter((ki) => ki.IsSelected === true) : [];
            //return [...acc, ...selected];
            //Sort in the same way as is done in Pillar dropdowns
            let kis =
                key === PillarTypes.GOV.ID
                    ? _orderBy(
                          selected.map((o) => ({
                              ...o,
                              SortBy: o.KeyIssueName === 'Other' ? null : Boolean(o.IsDeprecated) ? 0 : 1,
                          })),
                          ['SortBy', (o) => o.ThemeName.toLowerCase(), (o) => o.KeyIssueName.toLowerCase()],
                          ['asc', 'asc', 'asc']
                      )
                    : _orderBy(
                          selected.map((o) => ({
                              ...o,
                              SortBy: o.KeyIssueName === 'Other' ? null : Boolean(o.IsMaterial) ? 0 : 1,
                              ThemeName: Boolean(o.IsMaterial) ? 'Material AB Key Issues' : 'Potentially Material AB Key Issues',
                          })),
                          ['PillarName', 'SortBy', 'SortOrder', (o) => o.ThemeName.toLowerCase(), (o) => o.KeyIssueName.toLowerCase()],
                          ['asc', 'asc', 'asc', 'asc']
                      );

            kis = [...acc, ...kis];
            return kis;
        }, []);

        return issues;
    }, [localPillars]);

    return readOnly && !hasEntries(selectedIssues) ? null : (
        <div className={classes.root}>
            <Paper className={cn('paper', { 'setup-wizard': !readOnly && !localPillars.hasActions }, { 'action-table': localPillars.hasActions })} elevation={1}>
                <div className={classes.container}>
                    {!localPillars.hasActions && !readOnly && (
                        <div>
                            <Setup onComplete={handleSetupComplete} />
                        </div>
                    )}
                    {localPillars.hasActions && (
                        <>
                            <ActionTable issues={selectedIssues} pillars={pillars} onKeyIssueClick={handleKeyIssueClick} isRightDrawerOpen={isRightDrawerOpen} />
                            <div className={classes.header}>
                                {!readOnly && (
                                    <Button compact="true" type={ButtonTypes.FLAT} onClick={handleEditClick} disabled={selectedIssues.length === 0}>
                                        <i className="fas fa-edit"></i>
                                        <span>Edit Key Issues</span>
                                    </Button>
                                )}
                                {/* {noteID != null && (
                                    <Button compact="true" type={ButtonTypes.FLAT} onClick={handleHistoryDialogToggle(true)}>
                                        <i className={cn('fas fa-project-diagram')}></i>
                                        <span>View History Thread</span>
                                    </Button>
                                )} */}
                            </div>
                        </>
                    )}
                </div>
                <Dialog
                    keyIssues={selectedIssues}
                    show={showDialog}
                    parentID={parentNoteID}
                    onCancel={handleDialogCancel}
                    onSave={handleDialogSave}
                    selectedKeyIssue={selectedKeyIssue}
                    otherText={otherText}
                />
                <HistoryDialog show={showHistoryDialog} onClose={handleHistoryDialogToggle(false)} />
            </Paper>
        </div>
    );
};

export default withStyles(styles)(ActionTracking);
