import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import KeyIssueCard from './KeyIssues/KeyIssueCard';
import { PillarTypes } from './_constants';

const styles = (theme) => ({
    container: {
        display: 'flex',
        flexDirection: 'column',
        '& > div': {
            margin: '0 8px 16px 8px',
        },
    },
    vertical: {
        flexDirection: 'column !important',
        '& > div': {
            margin: '0 0 16px 0',
        },
    },
    '@media (min-width: 1024px)': {
        container: {
            flexDirection: 'row',
        },
    },
});

const KeyIssues = ({ classes, data, inputType, readOnly, vertical = false, onChange }) => {
    const handleChange = (type, value) => {
        if (onChange != null) {
            onChange({ ...data, [type]: value });
        }
    };

    return (
        <React.Fragment>
            {!readOnly && <div className="small required asterisk message">At least one ESG pillar or key issue is required.</div>}
            <div className={cn(classes.container, { [classes.vertical]: vertical })}>
                {Object.keys(PillarTypes).map((key) => {
                    const pillarType = PillarTypes[key];
                    const pillarData = data[pillarType.ID] != null ? data[pillarType.ID] : {};
                    return <KeyIssueCard key={pillarType.ID} typeID={pillarType.ID} label={pillarType.LABEL} data={pillarData} inputType={inputType} readOnly={readOnly} onChange={handleChange} />;
                })}
            </div>
        </React.Fragment>
    );
};

export default withStyles(styles)(React.memo(KeyIssues));
