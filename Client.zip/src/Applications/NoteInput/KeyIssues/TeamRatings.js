import React from 'react';
import { withStyles } from '@material-ui/core/styles';

import SearchableDropdown from 'UIComponents/MaterialUI/SearchableDropdown';

import { convertRgbaToCss, convertCssRgbToRgb, calculateContrastColorRgb } from 'Utils/layoutHelper';

const styles = () => ({
    ratingReadOnly: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#000000',
        height: 30,
        textShadow: 'none',
        width: 85,
    },
    ratingSelect: {
        alignItems: 'center',
        display: 'flex',
        textShadow: 'none',
        width: 85,
        '& input': {
            backgroundColor: 'transparent',
            color: '#000000',
            fontWeight: 700,
            textAlign: 'center',
        },
    },
});

const TeamRatings = ({ classes, onChange, ratings, selected = null, disabled = false }) => {
    const selectedRating = React.useMemo(() => {
        const item = Array.isArray(ratings) && ratings.length > 0 ? ratings.find((rating) => rating.value === selected) : null;

        return item == null ? {} : item;
    }, [selected, ratings]);

    const handleOnSearch = (rating) => {
        if (onChange != null) {
            onChange(rating);
        }
    };

    const contrastColor = React.useMemo(() => {
        const convert = (color) => {
            const rgbValues = convertCssRgbToRgb(selectedRating.colorCode);
            return rgbValues != null ? convertRgbaToCss(calculateContrastColorRgb(rgbValues.r, rgbValues.g, rgbValues.b)) : 'inherit';
        };

        return selectedRating.colorCode != null ? convert(selectedRating.colorCode) : 'inherit';
    }, [selectedRating.colorCode]);

    return (
        <div className={classes.ratingSelect} style={{ backgroundColor: selectedRating.colorCode, borderRadius: disabled === true ? 4 : 0 }}>
            {disabled === true ? (
                <div className={classes.ratingReadOnly} style={{ color: contrastColor }}>
                    {selectedRating.value}
                </div>
            ) : (
                <SearchableDropdown
                    dropdownItems={ratings}
                    placeholder=""
                    defaultValue={selectedRating}
                    onChange={handleOnSearch}
                    selectStyles={{ width: '100%' }}
                    isDisabled={disabled || !Array.isArray(ratings) || ratings.length === 1 /* Only 'N/A' */}
                    isClearable={false}
                />
            )}
        </div>
    );
};

export default React.memo(withStyles(styles)(TeamRatings));
