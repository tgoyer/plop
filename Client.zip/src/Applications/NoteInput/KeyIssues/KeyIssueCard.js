import React from 'react';
import cn from 'classnames';
import _orderBy from 'lodash/orderBy';

import { default as MuiTextField } from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';

import TeamRatings from './TeamRatings';
import { Colors, PillarTypes, InputTypes } from '../_constants';
import { Checkbox, List, mapSelectOptions } from 'components/Form';
import LoadingSpinner from 'componentlibrary/spinners/Loading';
import Tooltip from 'UIComponents/Tooltip';

import { calculateBrightness, convertHexToRgba, convertRgbaToCss } from '../../../Utils/layoutHelper';
import { isNullOrUndefined } from '../../../Utils/objectHelpers';

const styles = () => ({
    card: {
        display: 'flex',
        backgroundColor: '#fff',
        borderRadius: 4,
        boxShadow: '0px 1px 3px 0px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14), 0px 2px 1px -1px rgba(0, 0, 0, 0.12)',
        flexBasis: '100%',
        flexDirection: 'column',
        flexGrow: 1,
        margin: '0 0 16px 0',
    },
    '@media (min-width: 1024px)': {
        card: {
            flexBasis: '33.3333%',
            '&:first-child': {
                marginLeft: 0,
            },
            '&:last-child': {
                marginRight: 0,
            },
        },
    },
    content: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
    },
    contentReadOnly: {
        justifyContent: 'flex-start',
    },
    deprecated: {
        marginLeft: 12,
        color: '#ff0000',
    },
    hasCategory: {
        marginLeft: 16,
    },
    header: {
        borderRadius: '4px 4px 0 0',
        fontSize: '12pt',
        fontWeight: 700,
        height: 'auto',
        margin: 0,
        padding: 6,
        width: '100%',
    },
    highlight: {
        backgroundColor: '#f6f6f6',
    },
    infoIcon: {
        color: '#ffffff',
        marginLeft: 8,
    },
    keyIssueSelector: {
        borderRadius: '0 0 4px 4px',
        margin: 8,
    },
    otherField: {
        marginLeft: 15,
        width: '100%',
        '& textarea:disabled': {
            opacity: 0.35,
        },
    },
    researchConclusion: {
        display: 'flex',
        flexDirection: 'column',
        margin: '0 8px',
        padding: 8,
    },
    researchConclusionComment: {
        marginLeft: 12,
    },
    researchConclusionTitle: {
        fontWeight: 700,
    },
    titleCheckbox: {
        color: '#ffffff',
        marginLeft: 0,
    },
    titleLabel: {
        display: 'flex',
        alignItems: 'center',
        color: '#fff',
        fontSize: 14,
        fontWeight: 700,
        height: 36,
        marginRight: 12,
        paddingLeft: 0,
        textShadow: `1px 1px rgba(0,0,0,.5)`,
    },

    // placed here for css cascade to override 'titleLabel'.
    ratingLabel: {
        display: 'flex',
        justifyContent: 'space-between',
        marginRight: 0,
        paddingLeft: 10,
    },
    ratingSelect: {
        display: 'flex',
        alignItems: 'center',
        '& > span': {
            marginRight: 8,
        },
    },

    // ESG Sections
    envBackColor: {
        backgroundColor: Colors.e,
    },
    envColor: {
        color: Colors.e,
    },
    envHeader: {
        borderBottom: `1px solid ${calculateBrightness(Colors.e, -30)}`,
    },
    envHover: {
        boxShadow: `inset 0 0 0 2px ${convertRgbaToCss(convertHexToRgba(Colors.e, 0.25))}, 0 0 2px 2px ${convertRgbaToCss(convertHexToRgba(Colors.e, 0.25))}`,
    },

    govBackColor: {
        backgroundColor: Colors.g,
    },
    govColor: {
        color: Colors.g,
    },
    govHeader: {
        borderBottom: `1px solid ${calculateBrightness(Colors.g, -30)}`,
    },
    govHover: {
        boxShadow: `inset 0 0 0 2px ${convertRgbaToCss(convertHexToRgba(Colors.g, 0.25))}, 0 0 2px 2px ${convertRgbaToCss(convertHexToRgba(Colors.g, 0.25))}`,
    },

    socBackColor: {
        backgroundColor: Colors.s,
    },
    socColor: {
        color: Colors.s,
    },
    socHeader: {
        borderBottom: `1px solid ${calculateBrightness(Colors.s, -30)}`,
    },
    socHover: {
        boxShadow: `inset 0 0 0 2px ${convertRgbaToCss(convertHexToRgba(Colors.s, 0.25))}, 0 0 2px 2px ${convertRgbaToCss(convertHexToRgba(Colors.s, 0.25))}`,
    },
});

const santize = (value) =>
    String(value)
        .split(',')
        .map((v) => String(v).trim())
        .join(', ');

const KeyIssueCard = ({ classes, data, inputType, label, typeID, readOnly, onChange }) => {
    const options = React.useMemo(() => {
        if (data.keyIssues == null) return null;

        const keyIssues =
            typeID === PillarTypes.GOV.ID
                ? _orderBy(
                      data.keyIssues.map((o) => ({
                          ...o,
                          SortBy: o.KeyIssueName === 'Other' ? null : Boolean(o.IsDeprecated) ? 0 : 1,
                      })),
                      ['SortBy', (o) => o.ThemeName.toLowerCase(), (o) => o.KeyIssueName.toLowerCase()],
                      ['asc', 'asc', 'asc']
                  )
                : _orderBy(
                      data.keyIssues.map((o) => ({
                          ...o,
                          SortBy: o.KeyIssueName === 'Other' ? null : Boolean(o.IsMaterial) ? 0 : 1,
                          ThemeName: Boolean(o.IsMaterial) ? 'Material AB Key Issues' : 'Potentially Material AB Key Issues',
                      })),
                      ['PillarName', 'SortBy', 'SortOrder', (o) => o.ThemeName.toLowerCase(), (o) => o.KeyIssueName.toLowerCase()],
                      ['asc', 'asc', 'asc', 'asc']
                  );

        return mapSelectOptions(
            keyIssues.filter((ki) => !Boolean(ki.IsDeprecated) || Boolean(ki.IsSelected)), //&& ki.Action == null
            (item, mapper) =>
                mapper(
                    item.KeyIssueID, // id
                    item.KeyIssueName, // name
                    Boolean(item.IsSelected), // value
                    item.KeyIssueName === 'Other' ? null : item.ThemeName, // group
                    {
                        tooltip: item.Definition,
                        mappedIssue: item.MappedKeyIssueName,
                        isDeprecated: Boolean(item.IsDeprecated),
                    } // meta
                )
        );
    }, [data, typeID]);

    const getSelected = (list) => {
        return Array.isArray(list) ? list.filter((item) => item.value === true) : [];
    };

    const handleInputChange = (field) => (text) => {
        if (onChange != null) {
            onChange(typeID, {
                ...data,
                [field]: text,
            });
        }
    };

    const handleChangeSelect = (items) => {
        const selected = getSelected(items);
        const other = selected.find((s) => s.name === 'Other');

        const nextState = {
            ...data,
            checked: false,
            selected: items.some((i) => i.value === true),
            keyIssues: data.keyIssues.map((ki) => ({
                ...ki,
                Action: !isNullOrUndefined(ki.Action)
                    ? {
                          ...ki.Action,
                          IsDeleted: ki.IsSelected === true && !selected.some((ski) => ski.id === ki.KeyIssueID) ? true : false,
                      }
                    : {
                          Action: '',
                          Comment: '',
                          EscalationPathOther: '',
                          EscalationPathID: null,
                          NoteID: null,
                          ParentID: null,
                          Result: null,
                          Status: null,
                          FollowUpDate: null,
                          IsDeleted: false,
                          WasDiscussed: null,
                          IsNew: true,
                          EngagementType: 'Insight',
                          ActionTypeID: null,
                          TargetEndDate: null,
                      },
                //IsSelected: ki.Action != null || selected.map((s) => s.id).indexOf(ki.KeyIssueID) >= 0,
                IsSelected: selected.map((s) => s.id).indexOf(ki.KeyIssueID) >= 0,
            })),
            other: other == null || other.value === false ? '' : data.other,
        };

        onChange(typeID, nextState);
    };

    const handleRatingChange = (value) => {
        if (onChange != null) {
            const nextState = {
                ...data,
                rating: value?.value,
            };
            onChange(typeID, nextState);
        }
    };

    return (
        data != null && (
            <React.Fragment>
                <div className={classes.card}>
                    <div
                        className={cn(classes.header, {
                            [classes.envHeader]: typeID === PillarTypes.ENV.ID,
                            [classes.govHeader]: typeID === PillarTypes.GOV.ID,
                            [classes.socHeader]: typeID === PillarTypes.SOC.ID,
                            [classes.envBackColor]: typeID === PillarTypes.ENV.ID,
                            [classes.govBackColor]: typeID === PillarTypes.GOV.ID,
                            [classes.socBackColor]: typeID === PillarTypes.SOC.ID,
                        })}
                    >
                        <div className={cn(classes.titleLabel, classes.ratingLabel)}>
                            <span>
                                {label}
                                <a href="/assets/documents/AB_to_MSCI_Key_Issue_Map.pdf" target="_blank" rel="noreferrer noopener" title="AB to MSCI Key Issue Map">
                                    <i className={cn('fas fa-info-circle', classes.infoIcon)} />
                                </a>
                            </span>
                            {inputType === InputTypes.RESEARCH && (
                                <div className={classes.ratingSelect}>
                                    <span>Rating:</span>
                                    <TeamRatings typeID={typeID} selected={data.rating} ratings={data.ratings} onChange={handleRatingChange} disabled={readOnly} />
                                </div>
                            )}
                        </div>
                    </div>
                    <div className={cn(classes.content, { [classes.contentReadOnly]: readOnly === true })}>
                        {Array.isArray(options) ? (
                            (readOnly === false || (readOnly === true && options.filter((o) => o.value === true).length > 0)) && (
                                <div className={classes.keyIssueSelector}>
                                    <List
                                        classes={{
                                            badge: cn({
                                                [classes.envBackColor]: typeID === PillarTypes.ENV.ID,
                                                [classes.govBackColor]: typeID === PillarTypes.GOV.ID,
                                                [classes.socBackColor]: typeID === PillarTypes.SOC.ID,
                                            }),
                                        }}
                                        formatter={(item) => {
                                            const { id, name, meta } = item;
                                            const isOther = name === 'Other' && data.other != null && data.other.length > 0;
                                            return isOther || readOnly ? (
                                                <React.Fragment>
                                                    <span data-tip data-for={'Desc_TT_' + id}>
                                                        {isOther ? 'Other: ' + data.other : name}
                                                    </span>
                                                    {meta.tooltip != null && (
                                                        <Tooltip id={'Desc_TT_' + id} place="left">
                                                            {meta.tooltip != null && <p>{meta.tooltip}</p>}
                                                            {meta.mappedIssue != null && <p>Maps to MSCI key issue: {santize(meta.mappedIssue)}</p>}
                                                        </Tooltip>
                                                    )}
                                                </React.Fragment>
                                            ) : readOnly ? (
                                                <React.Fragment></React.Fragment>
                                            ) : (
                                                name
                                            );
                                        }}
                                        onSelect={handleChangeSelect}
                                        options={options}
                                        placeholder="+ Add Key Issue"
                                        readOnly={readOnly}
                                        selected={options.filter((o) => o.value === true)}
                                        component={({ data, highlighted, onChange }) => {
                                            const { id, name, value, group, meta } = data;
                                            const isOtherOption = name === 'Other';
                                            const isDeprecated = meta.isDeprecated;
                                            const isOtherEnabled = isOtherOption && Boolean(value);
                                            const tooltipKey = `KeyIssueTooltip-${id}`;
                                            return (
                                                <React.Fragment>
                                                    <div data-tip data-for={tooltipKey} className={cn({ [classes.hasCategory]: group != null, [classes.highlight]: highlighted })}>
                                                        <Checkbox
                                                            disabled={readOnly || (isDeprecated && !Boolean(value))}
                                                            focused={highlighted}
                                                            onChange={onChange}
                                                            text={
                                                                <React.Fragment>
                                                                    <span>{name}</span>
                                                                    {isDeprecated && <i className={cn('fas fa-exclamation', classes.deprecated)}></i>}
                                                                </React.Fragment>
                                                            }
                                                            value={value}
                                                            classes={{
                                                                checkbox: cn({
                                                                    [classes.envColor]: typeID === PillarTypes.ENV.ID,
                                                                    [classes.govColor]: typeID === PillarTypes.GOV.ID,
                                                                    [classes.socColor]: typeID === PillarTypes.SOC.ID,
                                                                }),
                                                                hover: cn({
                                                                    [classes.envHover]: typeID === PillarTypes.ENV.ID,
                                                                    [classes.govHover]: typeID === PillarTypes.GOV.ID,
                                                                    [classes.socHover]: typeID === PillarTypes.SOC.ID,
                                                                }),
                                                            }}
                                                        >
                                                            {isOtherOption && (
                                                                <TextField
                                                                    classes={{ root: classes.otherField }}
                                                                    disabled={!isOtherEnabled}
                                                                    multiline={true}
                                                                    placeholder="Please specify..."
                                                                    onChange={handleInputChange('other')}
                                                                    inputProps={{ maxLength: 140 }}
                                                                    value={data.other}
                                                                />
                                                            )}
                                                        </Checkbox>
                                                    </div>
                                                    <Tooltip id={tooltipKey} place="left">
                                                        {isDeprecated && (
                                                            <p>
                                                                <strong>This key issue is not a part of AB's set of material issues. Please select a different key issue for this note.</strong>
                                                            </p>
                                                        )}
                                                        {meta.tooltip != null && <p>{meta.tooltip}</p>}
                                                        {meta.mappedIssue != null && <p>Maps to MSCI key issue: {santize(meta.mappedIssue)}</p>}
                                                    </Tooltip>
                                                </React.Fragment>
                                            );
                                        }}
                                    />
                                </div>
                            )
                        ) : (
                            <LoadingSpinner />
                        )}
                        {inputType === InputTypes.RESEARCH ? (
                            <React.Fragment>
                                <div className={classes.researchConclusion}>
                                    {readOnly === true ? (
                                        data.comment != null &&
                                        data.comment !== '' && (
                                            <React.Fragment>
                                                <div className={classes.researchConclusionTitle}>Research Conclusion</div>
                                                <div className={classes.researchConclusionComment}>{data.comment}</div>
                                            </React.Fragment>
                                        )
                                    ) : (
                                        <React.Fragment>
                                            <TextField
                                                label="Research Conclusion"
                                                placeholder="Enter Research Conclusion"
                                                className={classes.textField}
                                                multiline={true}
                                                margin="normal"
                                                value={data.comment}
                                                InputLabelProps={{
                                                    className: cn({
                                                        'required asterisk': readOnly === false && Array.isArray(data.keyIssues) && data.keyIssues.some((i) => i.IsSelected === true),
                                                    }),
                                                    shrink: true,
                                                }}
                                                inputProps={{ maxLength: 2048 }}
                                                onChange={handleInputChange('comment')}
                                                data-tip
                                                data-for="Tooltip_ResearchConclusion"
                                            />
                                            <Tooltip id="Tooltip_ResearchConclusion">Key findings from the analyst's research on the Company's environmental performance. </Tooltip>
                                        </React.Fragment>
                                    )}
                                </div>
                            </React.Fragment>
                        ) : null}
                    </div>
                </div>
            </React.Fragment>
        )
    );
};

export default withStyles(styles)(React.memo(KeyIssueCard));

const TextField = ({ onChange, value, ...props }) => {
    const [text, setText] = React.useState('');

    const handleBlur = (evt) => onChange(text);
    const handleChange = (evt) => {
        evt.preventDefault();
        evt.stopPropagation();

        const value = evt.currentTarget.value;
        setText(value);
    };

    React.useEffect(() => {
        setText(value);
    }, [value]);

    return <MuiTextField onBlur={handleBlur} onChange={handleChange} value={text} {...props} />;
};
