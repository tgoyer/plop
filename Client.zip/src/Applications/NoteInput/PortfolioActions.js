import React from 'react';

import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({});

const PortfolioActions = (props) => {
    return <></>;
};

export default withStyles(styles)(React.memo(PortfolioActions));
