import React from 'react';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';

import Drawer from '@material-ui/core/SwipeableDrawer';
import { withStyles } from '@material-ui/core/styles';

import MaterialityMaps from 'Applications/Grids/MaterialityMaps';
import { getMsci } from 'store/GridDataModule';

const drawerWidth = 575;
const styles = (theme) => ({
    drawer: {
        display: 'none',
        flexShrink: 0,
        opacity: 0,
        width: drawerWidth,
    },
    drawerOpen: {
        display: 'block',
        opacity: 1,
    },
    drawerPaper: {
        borderRadius: 4,
        boxShadow: '0px 1px 3px 0px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14)',
        height: 'auto',
        padding: 12,
        position: 'absolute',
        margin: '12px 0',
        width: drawerWidth,
        zIndex: 'auto',
    },
});

const NoteDrawer = ({ classes, open, onToggle }) => {
    const dispatch = useDispatch();
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);

    const { CompanyID } = company || {};

    const getMsciDispatch = React.useCallback(
        (companyID) => {
            dispatch(getMsci(companyID));
        },
        [dispatch]
    );

    React.useEffect(() => {
        if (open && CompanyID != null) {
            getMsciDispatch(CompanyID);
        }
    }, [getMsciDispatch, open, CompanyID]);

    return (
        <Drawer
            className={cn(classes.drawer, { [classes.drawerOpen]: open })}
            variant="persistent"
            anchor="right"
            open={open}
            onClose={onToggle}
            onOpen={onToggle}
            classes={{ paper: classes.drawerPaper }}
        >
            <MaterialityMaps companyID={CompanyID} />
        </Drawer>
    );
};

export default withStyles(styles)(React.memo(NoteDrawer));
