import React from 'react';

import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import DeleteDialog from '../../UIComponents/MaterialUI/CommonDialog';

const styles = (theme) => ({
    button: {
        margin: theme.spacing(1),
        '&:disabled': {
            backgroundColor: '#cccccc',
            boxShadow: 'none',
        },
    },
});

const NoteActions = (props) => {
    const { canDelete, canEdit, classes, onCancel, onDelete, onSubmit, validator } = props;
    const [actionsDisabled, setActionsDisabled] = React.useState(false);
    const [showDeleteConfirmation, setShowDeleteConfirmation] = React.useState(false);

    const handleClose = (event) => {
        if (onCancel != null) {
            onCancel(event);
        }
    };

    const handleConfirmDelete = () => {
        setShowDeleteConfirmation(true);
    };

    const handleDelete = (event) => {
        setActionsDisabled(true);

        if (onDelete != null) {
            setTimeout(() => onDelete(event), 150);
        } else {
            setActionsDisabled(false);
        }
    };

    const handleSubmit = (event) => {
        setActionsDisabled(true);
        const isValid = validator != null ? validator() : true;

        if (isValid === true && onSubmit != null) {
            setTimeout(() => onSubmit(event), 150);
        } else {
            setActionsDisabled(false);
        }
    };

    return (
        <React.Fragment>
            {canEdit ? (
                <React.Fragment>
                    <Button variant="contained" color="primary" disabled={actionsDisabled} className={classes.button} onClick={handleSubmit}>
                        Submit
                    </Button>
                    <Button variant="contained" color="primary" disabled={actionsDisabled} className={classes.button} onClick={handleClose}>
                        Cancel
                    </Button>
                    {canDelete && (
                        <Button variant="contained" color="primary" disabled={actionsDisabled} className={classes.button} onClick={handleConfirmDelete}>
                            Delete
                        </Button>
                    )}
                </React.Fragment>
            ) : (
                <Button variant="contained" color="primary" disabled={actionsDisabled} className={classes.button} onClick={handleClose}>
                    Close
                </Button>
            )}
            <DeleteDialog
                showActions={true}
                title="Are you sure you wish to continue?"
                open={showDeleteConfirmation}
                onClose={() => setShowDeleteConfirmation(false)}
                onConfirm={handleDelete}
            >
                You are about to delete this note. This action is irreversable. Are you sure you wish to do this?
            </DeleteDialog>
        </React.Fragment>
    );
};

export default withStyles(styles)(React.memo(NoteActions));
