import React from 'react';
import cn from 'classnames';
import { Link, NavLink } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';

import Tooltip from '../../componentlibrary/tooltip/Tooltip';

import { getEnvironment, pxToRem } from '../../Utils/layoutHelper';

const routeCount = 8;

const topBlocks = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',

    color: 'white',
    lineHeight: '12px',
    paddingLeft: '10px',
    paddingRight: '10px',
    textDecoration: 'none',
    textShadow: '1px 1px rgba(65, 92, 139, 1)',
};

const menuItemHeight = {
    small: 51,
    medium: 75,
};

const heightBreakpoint = {
    small: 250 + routeCount * menuItemHeight.small,
    medium: 250 + routeCount * menuItemHeight.medium,
};

const styles = (theme) => ({
    nav: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 16,
        backgroundColor: theme.palette.primary.main,
        padding: '10px 0',
    },
    logo: {
        ...topBlocks,
        '& img': {
            backgroundColor: '#000000',
            boxShadow: '0 0 0px 3px rgba(255, 255, 255, .5)',
            height: 'auto',
            width: '100%',
        },
    },
    status: {
        ...topBlocks,
        fontSize: 16,
        fontWeight: 700,
        width: '100%',
    },
    statusMsg: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',

        backgroundColor: '#c33',
        borderBottom: '1px solid #fee',
        borderTop: '1px solid #fee',
        color: 'white',
        fontSize: 12,
        fontWeight: 700,
        padding: '3px 0',
        width: '100%',
    },
    envBadge: {
        ...topBlocks,
        backgroundColor: '#f08f50',
        fontSize: 16,
        fontWeight: 700,
        padding: 8,
        width: '100%',
    },
    version: {
        ...topBlocks,
        fontSize: 11,
    },
    versionToolTip: {
        '& table': {
            border: 0,
        },
        'table tbody tr td:first-child': {
            paddingRight: 10,
            textAlign: 'right',
            fontWeight: 700,
            verticalAlign: 'baseline',
            minWidth: 100,
        },
    },
    menu: {
        display: 'flex',
        flexDirection: 'column',
        listStyleType: 'none',
        margin: 0,
        padding: '10px 0',
        width: '100%',
    },
    menuItem: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        '& span': {
            textAlign: 'center',
            fontSize: pxToRem(12),
            lineHeight: 1.3,
        },
        '& a': {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 4,

            minHeight: 65,
            padding: 10,
            textDecoration: 'none',
            textShadow: '1px 1px rgba(65, 92, 139, 1)',
            color: 'white !important',
            width: '100%',
            '&.active': {
                backgroundColor: '#ffffff',
                border: 'transparent',
                color: `${theme.palette.primary.main} !important`,
                textShadow: 'none',
            },
            '&:hover:not(.active)': {
                backgroundColor: '#5273ad',
            },
        },
    },
    linkText: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
    },
    [`@media (max-height: ${heightBreakpoint.medium}px)`]: {
        menuItem: {
            '& a': {
                paddingTop: 8,
                paddingBottom: 8,
                minHeight: 'max-content',
            },
            '& i': {
                fontSize: 16,
            },
            '& span': {
                fontSize: 10,
            },
        },
    },
    [`@media (max-height: ${heightBreakpoint.small}px)`]: {
        menuItem: {
            gap: 2,
        },
    },
});

const env = getEnvironment();
const getDbType = (type) => (type === 'P' ? '(Production)' : type === 'T' ? '(Test)' : '');
const getEnvBadge = () => (env === 'DEVELOPMENT' || env === 'LOCAL' ? 'DEV' : env === 'TEST' ? 'TEST' : '');
const showEnvBadge = (type) => type !== 'P';

const Navigation = ({ User, onlineStatus, buildVersion, classes, routes }) => {
    const isAuthorized = React.useMemo(() => {
        return User != null && User.Permissions != null && (User.Permissions.CanRead || User.Permissions.CanWrite);
    }, [User]);

    const routeList = React.useMemo(() => {
        return routes.map((route) => {
            return (
                route.linkVisibile && (
                    <li className={classes.menuItem} key={route.url}>
                        <NavLink exact={route.exact} to={route.url}>
                            <div className={classes.linkIcon}>
                                <i className={cn('fas', `fa-${route.icon} fa-2x`)}></i>
                            </div>
                            <div className={classes.linkText}>
                                <span>{route.label}</span>
                            </div>
                        </NavLink>
                    </li>
                )
            );
        });
    }, [classes, routes]);

    return (
        <div className={classes.nav} data-test="primary-navigation-menu">
            <Link to="/" className={classes.logo}>
                <img src="/images/logo.svg" alt="Alliance Bernstein" />
            </Link>
            {isAuthorized && (
                <React.Fragment>
                    <Tooltip side="right" trigger={<div className={classes.version}>{`v${buildVersion.clientVersion}`}</div>}>
                        <table>
                            <tbody>
                                <tr>
                                    <td>Build Date:</td>
                                    <td>{`${buildVersion.clientBuildDate}`}</td>
                                </tr>
                                <tr>
                                    <td>Client Version:</td>
                                    <td>{`${buildVersion.clientVersion} (${buildVersion.clientBuildHash})`}</td>
                                </tr>
                                <tr>
                                    <td>API Version:</td>
                                    <td>{buildVersion.api}</td>
                                </tr>
                                <tr>
                                    <td>Database:</td>
                                    <td>{`${buildVersion.databaseName} ${getDbType(buildVersion.databaseType)}`}</td>
                                </tr>
                            </tbody>
                        </table>
                    </Tooltip>
                </React.Fragment>
            )}
            {buildVersion != null && showEnvBadge(buildVersion.databaseType) && <div className={classes.envBadge}>{getEnvBadge(buildVersion.databaseType)}</div>}
            {!onlineStatus && (
                <div className={classes.status}>
                    <div className={classes.statusMsg}>OFFLINE</div>
                </div>
            )}
            <ul className={classes.menu}>{routeList}</ul>
        </div>
    );
};

export default withStyles(styles)(Navigation);
