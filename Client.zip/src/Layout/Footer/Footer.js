import React from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

const styles = (themes) => ({
    footer: {
        alignItems: 'center',
        backgroundColor: '#d2dbea',
        display: 'flex',
        fontSize: 9,
        justifyContent: 'center',
        padding: '3px 12px',
        '& p': {
            margin: 0,
        },
    },
    contentArea: {
        display: 'flex',
        flexGrow: 1,
        flexDirection: 'column',
    },
    center: {
        justifyContent: 'center',
        textAlign: 'center',
    },
    left: {
        justifyContent: 'flex-start',
        textAlign: 'left',
    },
    right: {
        justifyContent: 'flex-end',
        textAlign: 'right',
    },
});

const Footer = (props) => {
    const { classes, center, left, right } = props;
    return (
        <div className={classes.footer}>
            {left != null && <div className={cn(styles['content-area'], classes.left)}>{left()}</div>}
            {center != null && <div className={cn(styles['content-area'], classes.center)}>{center()}</div>}
            {right != null && <div className={cn(styles['content-area'], classes.right)}>{right()}</div>}
        </div>
    );
};

export default withStyles(styles)(Footer);
