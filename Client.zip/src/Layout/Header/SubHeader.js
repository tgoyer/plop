import React from 'react';
import ReactDOM from 'react-dom';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

const styles = themes => ({
    subHeader: {
        background: '#f8f8f8',
        boxShadow: '0 1px 1px 0px rgba(0, 0, 0, 0.2), inset 0 1px 1px 0px rgba(0, 0, 0, 0.2)',
        display: 'flex',
        flexGrow: 0,
        flexShrink: 0,
        flexBasis: '50px',
        height: 50,
        padding: '0 12px',
        alignItems: 'center',
    },
    contentArea: {
        flexGrow: 1,
        flexShrink: 1,
        flexDirection: 'column',
    },
    center: {
        justifyContent: 'center',
        textAlign: 'center',
    },
    left: {
        justifyContent: 'flex-start',
        textAlign: 'left',
    },
    right: {
        justifyContent: 'flex-end',
        textAlign: 'right',
    }
});

const SubHeader = (props) => {
    const { classes, center, left, right } = props;

    return ReactDOM.createPortal((
        <div className={classes.subHeader} data-test="app-subheader">
            {left != null && (
                <div className={cn(classes.contentArea, classes.left)}>
                    {left()}
                </div>
            )}
            {center != null && (
                <div className={cn(classes.contentArea, classes.center)}>
                    {center()}
                </div>
            )}
            {right != null && (
                <div className={cn(classes.contentArea, classes.right)}>
                    {right()}
                </div>
            )}
        </div>
    ), document.querySelector('#app_subheader'))
}

export default withStyles(styles)(SubHeader);