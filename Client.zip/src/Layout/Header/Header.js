import React from 'react';
import { useSelector } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';

import SecuritySearch from '../../UIComponents/SecuritySearch';

const styles = (themes) => ({
    header: {
        background: '#ffffff',
        boxShadow: '0 0 2px 1px rgba(0, 0, 0, 0.2)',
        flex: '0 0 66px',
        height: 66,
        padding: '0 24px',
        display: 'grid',
        gridTemplateColumns: 'auto 2fr auto',
    },
    center: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 8,
        color: '#333333',
        fontWeight: 700,
        fontSize: 20,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        '& img': {
            maxHeight: 50,
            width: 'auto',
            padding: '0 8px',
        },
    },
    left: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    right: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    productName: {
        color: 'black',
        display: 'block',
        fontFamily: 'Klavika Bold',
        fontSize: 30,
        letterSpacing: 1.25,
        lineHeight: 1.15,
        textTransform: 'uppercase',
    },
    productNameGreen: {
        color: '#60ba53',
    },
    securityInfo: {
        whiteSpace: 'nowrap',
    },
    userName: {
        verticalAlign: 'middle',
        padding: 5,
        paddingRight: 10,
        textAlign: 'right',
    },
});

const Header = ({ classes, history }) => {
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const headerSettings = useSelector((state) => state.LayoutReducer.HeaderSettings);
    const logoUri = useSelector((state) => state.AppSettingsReducer.ServerSettings.LogoURI);
    const user = useSelector((state) => state.UserReducer.UserInfo.Data);

    const [headerTitle, setHeaderTitle] = React.useState('');
    const [showIcon, setShowIcon] = React.useState(false);

    const securityName = React.useMemo(() => {
        return company?.CompanyID != null ? company.CompanyName : '';
    }, [company]);

    const lookupSecurityHandler = (company) => history.push(`/CompanyAnalysis/${company.CompanyID}`);

    React.useEffect(() => {
        setHeaderTitle(headerSettings?.ShowSecurityInfo && company?.CompanyName != null ? `${headerSettings.Title} - ` : headerSettings.Title);
        setShowIcon(headerSettings.ShowSecurityInfo && company?.CompanyID != null);
    }, [company, headerSettings]);

    return (
        <div className={classes.header}>
            <div className={classes.left}>{user?.Permissions?.CanRead && <SecuritySearch clickAction={lookupSecurityHandler} selectedItem={company} />}</div>
            <div className={classes.center}>
                {headerTitle}
                {showIcon && company != null && <img onError={() => setShowIcon(false)} alt={`${company.CompanyName} Logo`} src={logoUri.replace(':companyID', company.CompanyID)} />}
                {headerSettings?.ShowSecurityInfo && securityName}
            </div>
            <div className={classes.right}>
                <div className={classes.userName}>
                    <span className={classes.productName}>
                        <span className={classes.productNameGreen}>es</span>i<span className={classes.productNameGreen}>g</span>ht
                    </span>
                    <span className={classes.userProfile}>{user?.FullName}</span>
                </div>
            </div>
        </div>
    );
};

export default withStyles(styles)(withRouter(Header));
