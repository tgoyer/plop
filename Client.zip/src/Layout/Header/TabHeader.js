import React from 'react';
import ReactDOM from 'react-dom';

import Tabs from '@material-ui/core/Tabs';
import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    tabHeader: {
        background: '#f8f8f8',
        boxShadow: '0 1px 1px 0px rgba(0, 0, 0, 0.2), inset 0 1px 1px 0px rgba(0, 0, 0, 0.2)',
        display: 'flex',
        flexGrow: 0,
        flexShrink: 0,
        flexBasis: '50px',
        height: 50,
        padding: '0 12px',
        alignItems: 'center',
    },
    tabSelected: {},
    tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: 400,
        marginRight: theme.spacing(4),
        '& button': {
            cursor: 'pointer',
        },
        '&:hover': {
            color: '#40a9ff',
            opacity: 1,
        },
        '&$tabSelected': {
            color: '#1890ff',
            fontWeight: 700,
        },
        '&:focus': {
            color: '#40a9ff',
        },
    },
});

const TabHeader = (props) => {
    const { children, classes, activeTab, onTabChange, ...rest } = props;
    const [tabIndex, setTabIndex] = React.useState(activeTab || 0);

    const handleChange = (event, tabIdx) => {
        setTabIndex(tabIdx);
        if (onTabChange != null) {
            onTabChange(tabIdx);
        }
    };

    return ReactDOM.createPortal(
        <div className={classes.tabHeader} data-test="app-tabheader">
            <div className={classes.root}>
                <Tabs value={tabIndex} onChange={handleChange}>
                    {React.Children.map(children, (child, idx) => {
                        return child != null && child !== false ? React.cloneElement(child, { disableRipple: true, ...rest, value: idx }) : null;
                    })}
                </Tabs>
            </div>
        </div>,
        document.querySelector('#app_tabheader')
    );
};

export default withStyles(styles)(TabHeader);
