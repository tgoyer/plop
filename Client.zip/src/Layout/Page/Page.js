import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';

import { Helmet } from 'react-helmet-async';

import { setHeaderSettings } from 'store/LayoutModule';
import { doOidcRedirect } from 'Utils/oidcHelper';

export default ({ children, secure = true, showSecurity = false, title = '' }) => {
    const dispatch = useDispatch();
    const history = useHistory();
    const company = useSelector((state) => state.CompanyReducer.Selected.Data);
    const [pageTitle, setPageTitle] = useState('');

    useEffect(() => {
        const header = showSecurity && company?.CompanyName != null ? `${title} - ${company.CompanyName}` : title;
        setPageTitle(`ESIGHT - ${header}`);
    }, [company, showSecurity, title]);

    useEffect(() => {
        dispatch(setHeaderSettings({ Title: title, ShowSecurityInfo: showSecurity }));
    }, [dispatch, showSecurity, title]);

    useEffect(() => {
        doOidcRedirect(history.replace, history.push);
    }, [history]);

    return (
        <>
            <Helmet>
                <title>{pageTitle}</title>
            </Helmet>
            {children}
        </>
    );
};
