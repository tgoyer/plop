import React from 'react';
import { connect } from 'react-redux';
import cn from 'classnames';
import { Route, Switch, withRouter } from 'react-router-dom';

import NavigationPrompt from 'react-router-navigation-prompt';
import { withStyles } from '@material-ui/core/styles';

import CommonDialog from '../../UIComponents/MaterialUI/CommonDialog';
import NotificationBar from '../../UIComponents/NotificationBar/NotificationBar';
import ErrorBoundary from '../../UIComponents/ErrorBoundary';
import { setViewStatus } from '../../store/AppSettingsModule';
import { clearError } from '../../store/ApiModule';
import { Header, Navigation } from '../../Layout';

import { getUrlParameter } from '../../Utils/layoutHelper';
import createRoutes from '../../routes';

const styles = (theme) => ({
    alertBanner: {
        borderBottom: '1px solid white',
        color: 'white',
        display: 'none',
        justifyContent: 'space-between',
        width: '100%',
        padding: 0,
        fontSize: 16,
        fontWeight: 700,
        backgroundColor: '#c33',
        textAlign: 'center',
        textShadow: '1px 1px rgba(65, 92, 139, 1)',
        height: 0,
        animation: 'grow 250ms ease-in-out',
    },
    container: {
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100%',
    },
    main: {
        display: 'grid',
        gridTemplateColumns: '100px auto',

        height: '100%',
        minHeight: '100vh',
        width: '100%',
    },
    body: {
        display: 'flex',
        flexDirection: 'column',
        flexGrow: 1,
        flexShrink: 1,
        width: '100%',
    },
    content: {
        display: 'flex',
        position: 'relative',
        flexDirection: 'column',
        flexGrow: 1,
        flexShrink: 1,
        padding: 12,
    },
    consolePanel: {
        backgroundColor: '#ccc',
        boxShadow: '0px 1px 5px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 3px 1px -2px rgba(0, 0, 0, 0.12)',
        borderRadius: 4,
        color: 'black',
        display: 'block',
        padding: 10,
        position: 'absolute',
        bottom: 20,
        left: 20,
        minHeight: 300,
        maxHeight: 'calc(100vh - 40px)',
        minWidth: 250,
        maxWidth: 'calc(33vw - 40px)',
        overflow: 'auto',
        zIndex: 100,
    },
    errorLink: {
        '&:active, &:focus, &:visited, &:hover': {
            color: 'white',
            textDecoration: 'underline',
        },
    },
    hasAlertBanner: {
        minHeight: '100vh',
    },
    showAlert: {
        display: 'flex',
        height: 40,
        padding: '8px 12px',
    },
    '@keyframes grow': {
        '0%': {
            display: 'none',
            opacity: 0,
        },
        '1%': {
            display: 'flex',
            opacity: 0,
            transform: 'scaleY(0)',
        },
        '100%': {
            opacity: 1,
            transform: 'scaleY(1)',
        },
    },
});

class Main extends React.Component {
    consoleRef = React.createRef();
    refreshRef = React.createRef();
    state = {
        fullscreen: false,
        showAlert: /MSIE (\d+\.\d+);/.test(navigator.userAgent) || navigator.userAgent.indexOf('Trident/') > -1,
        showNav: false,
        showHeader: false,
    };

    componentDidMount = () => {
        this.setState({
            fullscreen: getUrlParameter('fullscreen') === '1',
        });
    };

    componentDidUpdate = (prevProps) => {
        const consoleDiv = this.consoleRef.current;
        const prevLogLen = prevProps.Console != null && prevProps.Console.log != null && prevProps.Console.log.length != null ? prevProps.Console.log.length : 0;
        const thisLogLen = this.props.Console != null && this.props.Console.log != null && this.props.Console.log.length != null ? this.props.Console.log.length : 0;

        if (prevLogLen !== thisLogLen) {
            consoleDiv.scrollTop = consoleDiv.scrollHeight;
        }
    };

    handlePromptConfirm = () => {
        this.props.setDirtyFlagDispatcher(false);
    };

    handleNotificationClose = (key) => (event) => {
        this.props.clearErrorDispatcher(key);
    };

    showConsole = () => {
        const notProd = this.props.BuildVersion != null && this.props.BuildVersion.databaseType !== 'P';
        return getUrlParameter('console') === 'true' && notProd;
    };

    closeAlert = () => {
        this.setState({
            showAlert: false,
        });
    };

    render() {
        const { Account, BuildVersion, Errors, Messages, OnlineStatus, Selected, UserInfo, ViewStatus, classes, isLoggingIn, hasLoginError, offline } = this.props;
        const routes = UserInfo != null ? createRoutes({ Account, SelectedCompany: Selected, UserInfo }) : [];

        return (
            <React.Fragment>
                <div className={classes.container}>
                    <div className={cn(classes.alertBanner, { [classes.showAlert]: this.state.showAlert })}>
                        <span>This site is best viewed in Google Chrome, Microsoft Edge or Web@Work browsers. Internet Explorer is not supported.</span>
                        <i className="fas fa-times" onClick={this.closeAlert}></i>
                    </div>
                    <div className={classes.main}>
                        {!this.state.fullscreen && <Navigation buildVersion={BuildVersion} onlineStatus={OnlineStatus} routes={routes} User={UserInfo} />}
                        <div className={classes.body}>
                            {!this.state.fullscreen && <Header />}
                            <div id="app_subheader"></div>
                            <div id="app_tabheader"></div>
                            <div className={classes.content} data-test="content-container">
                                {offline === true ? (
                                    <div className={classes.container}>The ESIGHT server is offline. Please try again later.</div>
                                ) : isLoggingIn === true ? (
                                    <LoadingUser />
                                ) : hasLoginError === true ? (
                                    <LoadingUserError />
                                ) : (
                                    <ErrorBoundary>
                                        <Switch>
                                            {routes.map((route) => (
                                                <Route key={route.route} path={route.route} exact={route.exact} render={route.render({ selectedCompany: Selected })} />
                                            ))}
                                        </Switch>
                                    </ErrorBoundary>
                                )}
                            </div>
                            <NavigationPrompt when={ViewStatus.mustConfirmNavigation} afterClose={this.handlePromptClose} afterConfirm={this.handlePromptConfirm}>
                                {({ isActive, onCancel, onConfirm }) =>
                                    isActive && (
                                        <CommonDialog title="Wait!" open={isActive} showActions={true} onConfirm={onConfirm} onClose={onCancel}>
                                            <span style={{ color: '#990000', marginBottom: 5 }}>You have unsaved changes!</span>
                                            <br />
                                            <span style={{ color: '#000000' }}>If you continue, the unsaved changes will be lost. Do you want to continue?</span>
                                        </CommonDialog>
                                    )
                                }
                            </NavigationPrompt>
                            {Errors != null &&
                                Object.keys(Errors).map((key) => (
                                    <NotificationBar open={true} key={key} variant="error" onClose={this.handleNotificationClose(key)}>
                                        <strong>
                                            {Errors[key].message && Errors[key].message}
                                            {Errors[key].message == null && 'An error occurred processing your request.'}
                                        </strong>
                                        <br />
                                        If you continue to get this error, contact{' '}
                                        <a className={classes.errorLink} href="mailto:ESiGhtFeedback@alliancebernstein.com">
                                            esight Feedback
                                        </a>{' '}
                                        for assistance.
                                        <br />
                                    </NotificationBar>
                                ))}
                            {Messages != null &&
                                Object.keys(Messages).map((key) => (
                                    <NotificationBar open={true} key={key} variant="error" onClose={this.handleNotificationClose(key)}>
                                        {Messages[key].title && (
                                            <p>
                                                <strong>{Messages[key].title}</strong>
                                            </p>
                                        )}
                                        {Messages[key].message}
                                    </NotificationBar>
                                ))}
                        </div>
                    </div>
                </div>
                {this.showConsole() && (
                    <div id="app_console_panel" className={classes.consolePanel} ref={this.consoleRef}>
                        {this.props.Console.log.map((l, i) => (
                            <pre key={i}>{l}</pre>
                        ))}
                    </div>
                )}
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => ({
    Account: state.PortfolioReducer.Account.Data,
    BuildVersion: state.AppSettingsReducer.ServerSettings.BuildVersion,
    Console: state.LayoutReducer.Console,
    Errors: state.ApiReducer.Errors,
    Messages: state.AppSettingsReducer.Messages,
    OnlineStatus: state.AppSettingsReducer.OnlineStatus,
    Selected: state.CompanyReducer.Selected.Data,
    UserInfo: state.UserReducer.UserInfo.Data,
    ViewStatus: state.AppSettingsReducer.ViewStatus,
});

const mapDispatchToProps = (dispatch) => ({
    setDirtyFlagDispatcher: (isDirty) => dispatch(setViewStatus({ mustConfirmNavigation: isDirty })),
    clearErrorDispatcher: (errorKey) => dispatch(clearError(errorKey)),
});

export default withRouter(withStyles(styles)(connect(mapStateToProps, mapDispatchToProps)(Main)));

const LoadingUserBase = ({ classes }) => (
    <div className={classes.container}>
        <i className="fas fa-circle-notch fa-3x fa-spin"></i>
    </div>
);
const LoadingUser = withStyles((theme) => ({
    container: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '12px',

        color: 'gray',
        fontSize: '1.2em',
        height: '100%',
        width: '100%',
    },
}))(LoadingUserBase);

const LoadingUserErrorBase = ({ classes }) => {
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    const error_description = urlParams.get('error_description');
    const state = urlParams.get('state');

    return (
        <div className={classes.container}>
            <div className={classes.header}>Error Logging In</div>
            <div>
                <div>There was an error logging in. Please try again.</div>
                <div>
                    If it still continues to fail, contact <a href="mailto:EIMT-ApplicationSupport@alliancebernstein.com">EIMT - Application Support</a>
                </div>
                <table>
                    <tbody>
                        <tr>
                            <td>Error</td>
                            <td>{error}</td>
                        </tr>
                        <tr>
                            <td>Description</td>
                            <td>{error_description}</td>
                        </tr>
                        <tr>
                            <td>State</td>
                            <td>{state}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};
const LoadingUserError = withStyles((theme) => ({
    container: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '12px',

        fontSize: '1.2em',
        height: '100%',
        width: '100%',
    },
    header: {
        fontSize: '1.5em',
    },
    '& table': {
        borderCollapse: 'collapse',
        borderSpacing: 0,
        width: '450px',
        '& td': {
            border: '1px solid gray',
            padding: '4px 8px',
        },
        '& tr': {
            '&:nth-child(even)': {
                backgroundColor: '#f2f2f2',
            },
        },
    },
}))(LoadingUserErrorBase);
