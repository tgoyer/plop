import React, { Suspense } from 'react';

import LoadingPanel from 'UIComponents/LoadingPanel';
import Unauthorized from 'Applications/Unauthorized';
import ZeroState from 'UIComponents/ZeroState';
import { Page } from 'Layout/Page';

const CompanyAnalysis = React.lazy(() => import('./Applications/CompanyAnalysis'));
const EimtTools = React.lazy(() => import('./Applications/EimtTools'));
const Feedback = React.lazy(() => import('./Applications/Feedback'));
const Home = React.lazy(() => import('./Applications/Home'));
const KnowledgeCenter = React.lazy(() => import('./Applications/KnowledgeCenter'));
const NotFound = React.lazy(() => import('./Applications/NotFound'));
const Portfolio = React.lazy(() => import('./Applications/Portfolio'));
const Preferences = React.lazy(() => import('./Applications/Preferences'));

const EngagementInput = React.lazy(() => import('./Containers/EngagementInputContainer'));
const ResearchInput = React.lazy(() => import('./Containers/ResearchInputContainer'));

const eimtTeamID = 4;

const Loader = ({ children }) => <Suspense fallback={<LoadingPanel />}>{children}</Suspense>;
const createRoutes = ({ Account, SelectedCompany, UserInfo }) => {
    const userCanRead = UserInfo?.Permissions?.CanRead ?? false;
    const userCanWrite = UserInfo?.Permissions?.CanWrite ?? false;
    const noPermissions = !userCanRead && !userCanWrite;
    const showEimtTools = UserInfo?.Teams?.some((t) => t.TeamID === eimtTeamID);

    return noPermissions
        ? [
              {
                  route: '/',
                  url: '/',
                  label: 'Unauthorized',
                  icon: '',
                  exact: false,
                  linkVisibile: false,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="Unauthorized" showSecurity={false} secure={false}>
                                  <Unauthorized {...props} />
                              </Page>
                          </Loader>
                      ),
              },
          ]
        : [
              {
                  route: '/',
                  url: '/',
                  label: 'Knowledge Center',
                  icon: 'home',
                  exact: true,
                  linkVisibile: userCanRead || userCanWrite,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="Knowledge Center" showSecurity={false}>
                                  <KnowledgeCenter {...props} />
                              </Page>
                          </Loader>
                      ),
              },
              {
                  route: '/ResearchInput/:companyID?/:noteID?',
                  url: SelectedCompany != null && SelectedCompany.CompanyID != null ? `/ResearchInput/${SelectedCompany.CompanyID}` : '/ResearchInput',
                  label: 'Research Input',
                  icon: 'user-edit',
                  exact: false,
                  linkVisibile: userCanWrite,
                  render: (options) => (props) => {
                      const headerProps = { title: 'Research Input', showSecurity: true };
                      return SelectedCompany == null && props.match.params.companyID == null ? (
                          <Page {...headerProps}>
                              <ZeroState />
                          </Page>
                      ) : (
                          <Loader>
                              <Page {...headerProps}>
                                  <ResearchInput {...props} />
                              </Page>
                          </Loader>
                      );
                  },
              },
              {
                  route: '/EngagementInput/:companyID?/:noteID?',
                  url: SelectedCompany != null && SelectedCompany.CompanyID != null ? `/EngagementInput/${SelectedCompany.CompanyID}` : '/EngagementInput',
                  label: 'Engagement Input',
                  icon: 'building',
                  exact: false,
                  linkVisibile: userCanWrite,
                  render: (options) => (props) => {
                      const headerProps = { title: 'Engagement Input', showSecurity: true };
                      return SelectedCompany == null && props.match.params.companyID == null ? (
                          <Page {...headerProps}>
                              <ZeroState />
                          </Page>
                      ) : (
                          <Loader>
                              <Page {...headerProps}>
                                  <EngagementInput {...props} />
                              </Page>
                          </Loader>
                      );
                  },
              },
              {
                  route: '/CompanyAnalysis/:companyID?',
                  url: SelectedCompany != null && SelectedCompany.CompanyID != null ? `/CompanyAnalysis/${SelectedCompany.CompanyID}` : '/CompanyAnalysis',
                  label: 'Company Analysis',
                  icon: 'chart-line',
                  exact: false,
                  linkVisibile: userCanRead || userCanWrite,
                  render: (options) => (props) => {
                      const headerProps = { title: 'Company Analysis', showSecurity: true };
                      return SelectedCompany == null && props.match.params.companyID == null ? (
                          <Page {...headerProps}>
                              <ZeroState />
                          </Page>
                      ) : (
                          <Loader>
                              <Page {...headerProps}>
                                  <CompanyAnalysis {...props} />
                              </Page>
                          </Loader>
                      );
                  },
              },
              {
                  route: '/Portfolio/:accountId?',
                  url: Account != null && Account.AccountID != null ? `/Portfolio/${Account.AccountID}` : '/Portfolio',
                  label: 'Portfolio',
                  icon: 'table',
                  exact: false,
                  linkVisibile: userCanRead || userCanWrite,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="Portfolio" showSecurity={false}>
                                  <Portfolio {...props} />
                              </Page>
                          </Loader>
                      ),
              },
              {
                  route: '/RecentEntries',
                  url: '/RecentEntries',
                  label: 'Recent Entries',
                  icon: 'clipboard',
                  exact: false,
                  linkVisibile: userCanRead || userCanWrite,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="Recent Entries" showSecurity={false}>
                                  <Home {...props} />
                              </Page>
                          </Loader>
                      ),
              },
              {
                  route: '/Feedback',
                  url: '/Feedback',
                  label: 'Feedback',
                  icon: 'envelope',
                  exact: true,
                  linkVisibile: userCanRead || userCanWrite,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="Feedback" showSecurity={false}>
                                  <Feedback {...props} />
                              </Page>
                          </Loader>
                      ),
              },
              {
                  route: '/Preferences/:module?/:moduleID?',
                  url: '/Preferences',
                  label: 'User Preferences',
                  icon: 'cog',
                  exact: true,
                  linkVisibile: userCanRead || userCanWrite,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="User Preferences" showSecurity={false}>
                                  <Preferences {...props} />
                              </Page>
                          </Loader>
                      ),
              },
              {
                  route: '/AppTools/:setting?',
                  url: '/AppTools',
                  label: 'App Tools',
                  icon: 'wrench',
                  exact: false,
                  linkVisibile: showEimtTools,
                  render: (options) => (props) => {
                      const headerProps = { title: 'Application Tools' };
                      return (
                          <Loader>
                              <Page {...headerProps}>
                                  <EimtTools {...props} />
                              </Page>
                          </Loader>
                      );
                  },
              },
              {
                  route: null,
                  url: '/404',
                  label: 'Not Found',
                  icon: '',
                  exact: true,
                  linkVisibile: false,
                  render: (options) => (props) =>
                      (
                          <Loader>
                              <Page title="" showSecurity={false} secure={false}>
                                  <NotFound {...props} />
                              </Page>
                          </Loader>
                      ),
              },
          ];
};

export default createRoutes;
