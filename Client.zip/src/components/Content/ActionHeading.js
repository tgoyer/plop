import React from 'react';
import { withStyles } from '@material-ui/core/styles';

import { Heading } from './';

const styles = theme => ({
    actionContainer: {
        display: 'inline-flex',
        margin: '4px 0 4px 4px',
        '& button': {
            marginLeft: 8,
            minHeight: 23,
            padding: 0,
        }
    }
});

const ActionHeading = ({ actions, classes, title }) => (
    <Heading title={title}>
        <div className={ classes.actionContainer }>
            { actions }
        </div>
    </Heading>
);

// ActionHeading.whyDidYouRender = { customName: 'ActionHeading' }
export default withStyles(styles)(
    React.memo(ActionHeading)
);