import React from 'react';

import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import { withStyles } from '@material-ui/core/styles';

import Heading from 'components/Content/Heading';

const styles = (theme) => ({
    tabRoot: {
        display: 'inline-flex',
        minHeight: 0,
        '& button': {
            minHeight: 0,
            borderBottom: '3px solid transparent',
            '&:hover': {
                //borderBottom: '3px solid #6987B9',
                color: '#000000',
                fontWeight: 700,
            },
            '&[aria-selected="true"]': {
                color: '#000000',
                fontWeight: 700,
            },
        },
    },
    tabIndicator: {
        backgroundColor: '#f08f50',
        height: 3,
    },
});

const styleBase = {
    display: 'block',
    height: '100%',
    overflowY: 'auto',
};

const TabHeading = ({ classes, value = 0, tabs, title }) => {
    const [index, setIndex] = React.useState(0);

    const handleTabChange = (evt, idx) => {
        setIndex(idx);
    };

    React.useEffect(() => {
        setIndex(value);
    }, [value]);

    return (
        tabs != null &&
        Array.isArray(tabs) && (
            <React.Fragment>
                <Heading title={title}>
                    <Tabs
                        classes={{
                            root: classes.tabRoot,
                            indicator: classes.tabIndicator,
                        }}
                        value={index}
                        onChange={handleTabChange}
                    >
                        {tabs.map((tab, idx) => (
                            <Tab key={idx} label={tab.label} disabled={tab.disabled} />
                        ))}
                    </Tabs>
                </Heading>
                {tabs.map((tab, idx) => (
                    <div style={{ ...styleBase, display: idx === index ? 'block' : 'none' }} key={idx}>
                        {tab.component(setIndex)}
                    </div>
                ))}
            </React.Fragment>
        )
    );
};

// TabHeading.whyDidYouRender = { customName: 'TabHeading' }
export default withStyles(styles)(React.memo(TabHeading));
