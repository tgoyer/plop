import React from 'react';

export const Page = (props) => {
    return <div></div>;
};
