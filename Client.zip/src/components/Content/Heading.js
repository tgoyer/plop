import React from 'react';

import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    title: {
        alignItems: 'center',
        borderBottom: '2px solid #bdd7ff',
        color: ' #666',
        display: 'flex',
        fontSize: 16,
        fontWeight: 700,
        justifyContent: 'space-between',
        margin: 0,
    },
    text: {
        margin: '4px 8px',
    },
});

const Heading = ({ classes, children, title }) => (
    <div className={classes.title}>
        {title != null && title !== '' && <span className={classes.text}>{title}</span>}
        {children}
    </div>
);

// Heading.whyDidYouRender = { customName: 'Heading' }
export default withStyles(styles)(React.memo(Heading));
