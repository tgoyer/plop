import React from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const RichTextEditor = ({ initialValue = '', onChange }) => {
    const handleChange = (ev) => {
        if (onChange != null) {
            onChange(ev);
        }
    };

    return <ReactQuill className="mb-2" theme="snow" value={initialValue} onChange={handleChange} />;
};

export default RichTextEditor;
