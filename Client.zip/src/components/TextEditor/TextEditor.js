import React from 'react';
import { Editor } from 'slate-react';
import { Value } from 'slate';

import { withStyles } from '@material-ui/core/styles';

const buildStringValue = (value) => Value.fromJSON({
    document: {
        nodes: [{
            object: 'block',
            type: 'paragraph',
            nodes: [{
                object: 'text',
                text: value
            }]
        }],
    }
});

const styles = theme => ({
    singleLine: {
        display: 'inline-block',
    }
});

const TextEditor = ({ classes, onChange, isEdit, value }) => {
    const [ editorState, setEditorState ] = React.useState(buildStringValue(''));

    const handleChange = (evt) => {
        const value = evt.value;
        setEditorState(value);
        if (value.document !== editorState.document) {
            onChange(value);
        }
    }

    React.useEffect(() => {
        const editorState = (typeof(value) === 'string') 
            ? buildStringValue(value)
            : value;
        setEditorState(editorState);
    }, [ value ])

    return (
        <Editor
            autoCorrect={isEdit}
            className={classes.singleLine}
            onChange={handleChange}
            readOnly={!isEdit}
            spellCheck={isEdit}
            value={editorState}
        />
    );
}

export default withStyles(styles)(TextEditor);
