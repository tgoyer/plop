export default {
    CONFIRM: 'CONFIRM',
    SMALL: 'SMALL',
    MEDIUM: 'MEDIUM',
    LARGE: 'LARGE',
    FULL: 'FULL'
}
