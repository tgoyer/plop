import React from 'react';
import ReactDOM from 'react-dom';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

import DialogSizes from './DialogSizes';

const styles = (theme) => ({
    background: {
        backgroundColor: 'white',
        opacity: 0.65,
        display: 'none',
        position: 'fixed',
        height: '100%',
        width: '100%',
        minHeight: '100vh',
        minWidth: '100vw',
        top: 0,
        left: 0,
        zIndex: 1200,
    },
    closeButton: {
        cursor: 'pointer',
        padding: '4px 2px',
    },
    dialogPopover: {
        animation: 'fadeIn 250ms cubic-bezier(0.390, 0.575, 0.565, 1.000) both',
        backgroundColor: 'grey',
        border: '1px solid #6987B9',
        boxShadow: '1px 1px 4px 2px rgba(0, 0, 0, 0.3)',
        display: 'none',
        position: 'fixed',
        zIndex: 1201,
    },
    dialogPopoverActions: {
        display: 'flex',
        justifyContent: 'flex-end',
        marginTop: 10,
        '& button': {
            marginLeft: 8,
        },
    },
    dialogPopoverContainer: {
        position: 'relative',
        backgroundColor: '#fefefe',
        height: 'calc(100% - 52px)',
        padding: 20,
    },
    dialogPopoverContent: {
        position: 'relative',
        height: '100%',
        overflow: 'hidden',
        // overflow: 'scroll',
        // overflowX: 'hidden',
        overflowY: 'auto',
    },
    dialogPopoverContentWithActions: {
        height: 'calc(100% - 40px)',
    },
    dialogPopoverHeader: {
        display: 'flex',
        justifyContent: 'space-between',
        backgroundColor: '#1e9bd7',//theme.palette.primary.main,
        height: 52,
        fontSize: 22,
        padding: 10,
        '& *': {
            color: 'white',
            padding: '0 8px',
        },
    },
    dialogPopoverHeaderActions: {
        display: 'inline',
    },
    dialogPopoverHeaderTitle: {
        display: 'inline',
        fontFamily: 'Klavika,Arial,Helvetica,sans-serif'
    },
    backgroundShow: {
        display: 'block',
    },
    dialogPopoverShow: {
        display: 'block',
    },
    '@keyframes fadeIn': {
        '0%': {
            opacity: 0,
        },
        '100%': {
            opacity: 1,
        },
    },
});

const KeyCodes = Object.freeze({ ESC: 'Escape' });

const getPositionStyles = (lockHeight, size) => {
    const calculateStyles = (height, width) => ({
        left: '50%',
        top: 40,
        marginLeft: -(width / 2),
        minHeight: height,
        height: lockHeight === true ? height : 'calc(100vh - 100px)',
        maxHeight: lockHeight === true ? height : 'calc(100vh - 100px)',
        width: width,
    });

    switch (size) {
        case DialogSizes.CONFIRM:
            return calculateStyles(250, 500);

        case DialogSizes.SMALL:
            return calculateStyles(350, 500);

        case DialogSizes.MEDIUM:
            return calculateStyles(450, 700);

        case DialogSizes.LARGE:
            return calculateStyles(700, 1000);

        default:
            return {
                height: 'calc(100vh - 100px)',
                maxHeight: 'calc(100vh - 100px)',
                width: 'calc(100vw - 100px)',
                top: 50,
                left: 50,
            };
    }
};

const PopoverDialog = ({ actions, closeOnOutsideClick = true, classes, className, children, headerActions, onClose, title, show = false, style = {}, size = DialogSizes.FULL, lockHeight = false }) => {
    const [modalVisible, setModalVisible] = React.useState(false);
    const popupNode = React.useRef();
    const popupNodeBg = React.useRef();

    React.useEffect(() => {
        const handleClickOutside = (evt) => {
            if (modalVisible && closeOnOutsideClick) {
                setModalVisible(false);
                onClose(evt);
            }
        };

        const handleKeydown = (evt) => {
            if (evt.key === KeyCodes.ESC) {
                setModalVisible(false);
                onClose(evt);
            }
        };

        if (show === true) {
            popupNodeBg.current && popupNodeBg.current.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleKeydown);
        } else {
            popupNodeBg.current && popupNodeBg.current.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleKeydown);
        }

        setModalVisible(show);

        return () => {
            document.removeEventListener('keydown', handleKeydown);
        };
    }, [modalVisible, closeOnOutsideClick, show, onClose]);

    return (
        show &&
        ReactDOM.createPortal(
            <React.Fragment>
                <div
                    ref={popupNode}
                    className={cn(classes.dialogPopover, { [classes.dialogPopoverShow]: show, [className]: className != null })}
                    style={{ ...getPositionStyles(lockHeight, size), ...style }}
                >
                    <div className={classes.dialogPopoverHeader}>
                        <div className={classes.dialogPopoverHeaderTitle}>{title}</div>
                        <div className={classes.dialogPopoverHeaderActions}>
                            {headerActions}
                            <i className={cn('fas', 'fa-times', classes.closeButton)} onClick={onClose} />
                        </div>
                    </div>
                    <div className={classes.dialogPopoverContainer}>
                        <div className={cn(classes.dialogPopoverContent, { [classes.dialogPopoverContentWithActions]: actions != null })}>{children}</div>
                        {actions != null && <div className={classes.dialogPopoverActions}>{actions}</div>}
                    </div>
                </div>
                <div ref={popupNodeBg} className={cn(classes.background, { [classes.backgroundShow]: show })} />
            </React.Fragment>,
            document.getElementById('app_dialog_popover')
        )
    );
};

// PopoverDialog.whyDidYouRender = { customName: 'PopoverDialog' }
export default withStyles(styles)(React.memo(PopoverDialog));
