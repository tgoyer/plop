import React from "react";
import { useSelector } from 'react-redux';

import _get from 'lodash/get';

import SearchBase, { mapData } from "./SearchBase";
import { generateId } from '../../Utils/layoutHelper';

const createNewItem = (dataSourceId, value) => ({
    DocumentSourceID: dataSourceId,
    Name: value,
    PublisherID: generateId(),
    IsNew: true,
})

const PublisherSearch = ({ onSearch, closeOnSearch = true, selected = null, dataSource = null, disabled = false, filterBy }) => {
    const dimensions = useSelector(state => state.DimensionReducer.Publishers.Data);
    const [expanded, setExpanded] = React.useState(false);
    const [publishers, setPublishers] = React.useState([]);
    const dataSourceId = _get(dataSource, '0.id', null);

    const handleInputOnChange = (value) => {
        const itemIdx = dimensions.findIndex(c => (c.DocumentSourceID === dataSourceId || dataSourceId === null) && c.Name.toUpperCase().startsWith(value.toUpperCase()));
        const items = dimensions.filter(c => c.Name.toUpperCase().startsWith(value.toUpperCase()));

        if (itemIdx < 0 && value.length > 0) items.push(createNewItem(dataSourceId, value));
        setPublishers(items);
    }

    const handleInputOnBlur = (event) => {
        setExpanded(false);
    }

    const handleInputOnFocus = (event) => {
        setPublishers(dimensions);
        setExpanded(true);
    }

    const handleOnSearch = (item) => {
        const found = dimensions.find(c => c.PublisherID === item.id)
        const dataItem = found ? found : createNewItem(dataSourceId, item.name);

        if (onSearch != null) {
            onSearch(dataItem);
        }
        setExpanded(!closeOnSearch);
        setPublishers(dimensions);
    }

    React.useEffect(() => {
        setPublishers(dimensions);
    }, [dimensions])

    const data = React.useMemo(() => {
        const selectedIds = Array.isArray(selected) ? selected.map(s => s.id) : [];

        const list = Array.isArray(publishers)
            ? publishers.filter(c => selectedIds.indexOf(c.PublisherID) < 0)
            : [];

        return filterBy != null
            ? list.filter(filterBy).map(c => mapData(c.PublisherID, c.PublisherID, c.Name))
            : list.map(c => mapData(c.PublisherID, c.PublisherID, c.Name));
    }, [filterBy, publishers, selected]);

    return (
        <SearchBase
            data={data}
            expanded={expanded}
            filterBy={filterBy}
            onSearch={handleOnSearch}
            onInputBlur={handleInputOnBlur}
            onInputChange={handleInputOnChange}
            onInputFocus={handleInputOnFocus}
            placeholder="Enter publisher name"
            disabled={disabled}
            selected={selected}
        />
    );
}

export default PublisherSearch;