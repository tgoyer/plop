import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import SearchBase, { mapData } from "./SearchBase";
import { getCompanySearch } from '../../store/CompanyModule';

const styles = theme => ({
    container: {
        margin: 8,
        padding: 0,
    },
    name: {
        display: 'inline-block',
        fontSize: 12,
        width: 'calc(100% - 80px)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
    },
    ticker: {
        display: 'inline-block',
        color: '#002463',
        fontWeight: 700,
        paddingLeft: 4,
        width: 80,
    },
});

const CompanySearch = ({ classes, onSearch, selected = null, disabled = false }) => {
    const dispatch = useDispatch();
    const dimensions = useSelector(state => state.CompanyReducer.CompanyList.Data);
    const selectedValue = selected == null ? '' : selected.Ticker;

    const handleInputOnChange = (value) => {
        dispatch(getCompanySearch(value));
    }

    const handleOnSearch = ({ id, name }) => {
        const found = dimensions.find(c => c.CompanyID === id)
        if (onSearch != null) {
            onSearch(found);
        }
    }

    const data = React.useMemo(() => {
        return Array.isArray(dimensions)
            ? dimensions.map(c => mapData(
                c.SecurityID,
                c.CompanyID,
                c.Ticker,
                <div className={classes.container}>
                    <div className={classes.ticker}>{c.Ticker}</div>
                    <div className={classes.name}>{c.CompanyName}</div>
                </div>
            ))
            : [];
    }, [dimensions, classes])

    return (
        <SearchBase
            data={data}
            onSearch={handleOnSearch}
            onInputChange={handleInputOnChange}
            placeholder="Enter ticker or company name"
            disabled={disabled}
            selected={selected}
            value={selectedValue}
        />
    );
}

export default withStyles(styles)(CompanySearch);