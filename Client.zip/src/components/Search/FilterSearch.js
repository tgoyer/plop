import React from "react";

import DropdownInput from '../../componentlibrary/DropdownInput.js';
import "./FilterSearch.css";

const FilterSearch = ({
    filterOptions,
    activeFilters,
    setActiveFilters,
    filterInputString,
    setFilterInputString,
    resetFilters }) => {
    // Reset

    // OnKeydown
    const handleInputChange = e => {
        setFilterInputString(e.target.value);
    };

    const handleChange = selectedFilterID => {
        const selectedFilter = filterOptions.find(fo => fo.filterID === selectedFilterID);

        const result = activeFilters.map(f => f.filterID).includes(selectedFilterID) ?
            activeFilters.filter(f => f.filterID !== selectedFilterID)
            : activeFilters.concat(selectedFilter);

        if (result.length === 0) return; // Minimum of 1 filter is required

        return activeFilters.length ? setActiveFilters(result) : setActiveFilters([selectedFilter]);
    };

    return <div className="filter-search">
        <DropdownInput label="Filter by keyword"
            optionsPlaceholder="Select field(s) to match on:"
            value={filterInputString}
            handleChange={handleChange}
            handleInputChange={handleInputChange}
            ActionButtons={() => <>
                {activeFilters.length !== filterOptions.length && <span onClick={() => resetFilters()}>Select All</span>}
            </>}
            dropdownIcon="fa-filter"
            InputValueActions={() => filterInputString.length > 0 && <i className=" fas fa-times" onClick={() => setFilterInputString("")}></i>}
            OptionsFooter={({ callback, children }) => <div className="ab-dropdowninput-actions-bottom">
                <div className="actions-btns">
                    <span onClick={() => {
                        resetFilters();
                        callback();
                    }}>Clear Filters</span>
                    {children}
                </div>
            </div>}
            hasOptionsFooter={true}
            options={filterOptions.map(o => ({ identifier: o.filterID, label: o.filterName }))}
            isOptionSelected={(identifier) => activeFilters.map(f => f.filterID).includes(identifier)}
            onReset={resetFilters} />
    </div>
};

export const itemPassedAtLeastOneFilter = (activeFilters, filterInputString, dataItem) => {
    if (activeFilters.length === 0) return true;

    return getPassedFilterIDs(activeFilters, filterInputString, dataItem)
        .length >= 1;
};

const getPassedFilterIDs = (activeFilters, filterInputString, dataItem) => {
    return activeFilters
        .filter(filter => itemPassedFilter(dataItem, filter, filterInputString))
        .map(filter => filter.filterID);
};

const itemPassedFilter = (item, activeFilter, filterInputString) => {
    if (filterInputString === "") return true;

    return item[activeFilter.key] && activeFilter
        .getFormattedValue(item)
        .toUpperCase()
        .trim()
        .includes(filterInputString.toUpperCase().trim());
};

export default FilterSearch;