import React from "react";
import { useSelector } from 'react-redux';

import SearchBase, { mapData } from "./SearchBase";

const CountrySearch = ({ onSearch, closeOnSearch = true, selected = null, disabled = false }) => {
    const dimensions = useSelector(state => state.DimensionReducer.Countries.Data);
    const [expanded, setExpanded] = React.useState(false);
    const [countries, setCountries] = React.useState([]);

    const handleInputOnChange = (value) => {
        const items = dimensions.filter(c => c.Name.toUpperCase().startsWith(value.toUpperCase()));
        setCountries(items);
    }

    const handleInputOnBlur = (event) => {
        setExpanded(false);
    }

    const handleInputOnFocus = (event) => {
        setCountries(dimensions);
        setExpanded(true);
    }

    const handleOnSearch = ({ id, name }) => {
        const found = dimensions.find(c => c.CountryID === id)
        if (onSearch != null) {
            onSearch(found);
        }
        setExpanded(!closeOnSearch);
        setCountries(dimensions);
    }

    React.useEffect(() => {
        setCountries(dimensions);
    }, [dimensions])

    const data = React.useMemo(() => {
        const selectedIds = Array.isArray(selected) ? selected.map(s => s.id) : [];
        return Array.isArray(countries)
            ? countries
                .filter(c => selectedIds.indexOf(c.CountryID) < 0)
                .map(c => mapData(c.CountryID, c.CountryID, c.Name))
            : [];
    }, [countries, selected])

    return (
        <SearchBase
            data={data}
            expanded={expanded}
            onSearch={handleOnSearch}
            onInputBlur={handleInputOnBlur}
            onInputChange={handleInputOnChange}
            onInputFocus={handleInputOnFocus}
            placeholder="Enter country name"
            disabled={disabled}
            selected={selected}
        />
    );
}

export default CountrySearch;