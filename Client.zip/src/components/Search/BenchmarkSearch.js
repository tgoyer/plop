import React from "react";
import { useDispatch, useSelector } from 'react-redux';

import SearchBase, { mapData } from "./SearchBase";
import { searchBenchmarks } from '../../store/DimensionModule';

const BenchmarkSearch = ({ onSearch, selected = null, disabled = false }) => {
    const dispatch = useDispatch();

    const dimensions = useSelector(store => store.DimensionReducer.BMSearch.Data);
    const handleInputOnChange = (value) => dispatch(searchBenchmarks(value));
    const selectedValue = selected == null ? '' : selected.Name;
    
    const handleOnSearch = ({ id, name }) => {
        const found = dimensions.find(c => c.BenchmarkID === id)
        if (onSearch != null) {
            onSearch(found);
        }
    }

    const data = React.useMemo(() => {
        return Array.isArray(dimensions) 
            ? dimensions.map(c => mapData(
                c.BenchmarkID,
                c.BenchmarkID, 
                c.Name
            ))
            : [];
    }, [dimensions])
    
    return (
        <SearchBase 
            data={data} 
            onSearch={handleOnSearch}
            onInputChange={handleInputOnChange}
            placeholder="Enter benchmark name"
            disabled={disabled}
            selected={selected}
            value={selectedValue}
        />
    );
}

export default BenchmarkSearch;