import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

import SearchBase, { mapData } from "./SearchBase";
import { searchAccounts } from '../../store/PortfolioModule';

const styles = theme => ({
    account: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        margin: 8,
        padding: 0,
    },
    name: {
        fontSize: 12,
        width: 'calc(100% - 80px)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
    },
    subAccount: {
        color: '#002463',
        fontWeight: 700,
        paddingLeft: 4,
        width: 80,
    },
});

const PortfolioSearch = ({ classes, onSearch, selected = null, disabled = false }) => {
    const dispatch = useDispatch();
    const dimensions = useSelector(state => state.PortfolioReducer.Search.Data);
    const selectedValue = selected == null ? ''
        : selected.Subaccount != null ? `(${selected.Subaccount}) ${selected.AccountName}`
            : selected.AccountName;

    const handleInputOnChange = (value) => {
        dispatch(searchAccounts(value));
    }

    const handleOnSearch = ({ id, name }) => {
        const found = dimensions.find(c => c.AccountID === id)
        if (onSearch != null) {
            onSearch(found);
        }
    }

    const data = React.useMemo(() => {
        return Array.isArray(dimensions)
            ? dimensions.map(item => mapData(
                item.AccountID,
                item.AccountID,
                item.AccountName,
                <div className={classes.account}>
                    <div className={classes.subAccount}>{item.AccountNumber}</div>
                    <div className={classes.name}>{item.Subaccount == null ? '' : '(' + item.Subaccount + ') '}{item.AccountName}</div>
                </div>
            ))
            : [];
    }, [dimensions, classes])

    return (
        <SearchBase
            data={data}
            onSearch={handleOnSearch}
            onInputChange={handleInputOnChange}
            placeholder="Enter account name or number"
            disabled={disabled}
            selected={selected}
            value={selectedValue}
        />
    );
}

export default withStyles(styles)(PortfolioSearch);