import React from "react";
import { useDispatch, useSelector } from 'react-redux';

import SearchBase, { mapData } from "./SearchBase";
import { searchProducts } from '../../store/DimensionModule';

const BenchmarkSearch = ({ onSearch, selected = null, disabled = false }) => {
    const dispatch = useDispatch();

    const dimensions = useSelector(store => store.DimensionReducer.ProductSearch.Data);
    const handleInputOnChange = (value) => dispatch(searchProducts(value));
    const selectedValue = selected == null ? '' : selected.Name;
    
    const handleOnSearch = ({ id, name }) => {
        const found = dimensions.find(c => c.ProductID === id)
        if (onSearch != null) {
            onSearch(found);
        }
    }

    const data = React.useMemo(() => {
        return Array.isArray(dimensions) 
            ? dimensions.map(c => mapData(
                c.ProductID,
                c.ProductID, 
                c.Name
            ))
            : [];
    }, [dimensions])
    
    return (
        <SearchBase 
            data={data} 
            onSearch={handleOnSearch}
            onInputChange={handleInputOnChange}
            placeholder="Enter product name"
            disabled={disabled}
            selected={selected}
            value={selectedValue}
        />
    );
}

export default BenchmarkSearch;