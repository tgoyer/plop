import React from 'react';
import cn from 'classnames';

import Downshift from 'downshift';
import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
    container: {
        display: 'inline-block',
        position: 'relative',
        width: '100%',
        '&::after': {
            backgroundColor: '#000000',
            bottom: 0,
            content: "''",
            height: 2,
            left: 0,
            opacity: 0,
            position: 'absolute',
            transition: 'opacity 150ms ease-in-out',
            width: '100%',
        },
        '&:hover::after, &:focus::after': {
            opacity: 1,
        },
    },
    input: {
        border: 'none',
        borderBottom: '1px solid #000000',
        boxShadow: 'none',
        display: 'inline-block',
        fontSize: 14,
        height: 16,
        lineHeight: '16px',
        padding: '16px 8px 14px',
        width: '100%',
        '&::placeholder': {
            color: '#c1c1c1',
            fontWeight: 400,
        },
    },
    listContainer: {
        backgroundColor: '#ffffff',
        border: '1px solid rgba(0,0,0,.5)',
        boxShadow: '0 1px 2px rgba(0,0,0,0.5)',
        maxHeight: 200,
        overflowY: 'auto',
        overflowX: 'hidden',
        position: 'absolute',
        left: 20,
        width: 'calc(100% - 20px)',
        zIndex: 1000,
    },
    listItem: {
        backgroundColor: 'white',
        fontWeight: 400,
        margin: 0,
        padding: 0,
    },
    listItemHighlighted: {
        backgroundColor: '#cfcfcf',
    },
    listItemSelected: {
        fontWeight: 700,
    },
    listItemText: {
        margin: 0,
        padding: 0,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
    },
    noData: {
        marginLeft: 20,
        padding: 5,
    },
});

const SearchBase = ({
    classes,
    disabled,
    expanded,
    data = [],
    filterBy,
    inputProps,
    onSearch,
    onInputBlur,
    onInputChange,
    onInputFocus,
    placeholder = 'Select an option',
    selected = null,
    value = '',
}) => {
    const inputRef = React.useRef();
    const [inputValue, setInputValue] = React.useState(value);

    const handleOnFocus = (evt) => {
        const { current } = inputRef;
        if (current != null) {
            current.focus();
            current.select();
        }
        if (onInputFocus != null) {
            onInputFocus(evt);
        }
    };

    const handleInputChange = (event) => {
        const value = String(event.target.value).trimStart();
        setInputValue(value);
        if (onInputChange != null) {
            onInputChange(value);
        }
    };

    const handleChange = (item) => {
        setInputValue('');
        if (onSearch != null) {
            onSearch(item);
        }
    };

    React.useEffect(() => {
        setInputValue(value);
    }, [value]);

    return (
        <Downshift
            defaultHighlightedIndex={0}
            onChange={handleChange}
            selectedItem={selected}
            itemToString={(item) => {
                return item != null ? item.name : '';
            }}
        >
            {({ getInputProps, getItemProps, highlightedIndex, isOpen, selectedItem }) => (
                <div className={classes.container}>
                    <input
                        {...getInputProps({
                            disabled,
                            placeholder,
                            onBlur: onInputBlur,
                            onChange: handleInputChange,
                        })}
                        style={inputProps != null ? inputProps.style : null}
                        ref={inputRef}
                        onFocus={handleOnFocus}
                        className={classes.input}
                        value={inputValue}
                    />
                    {isOpen || expanded ? (
                        <div className={classes.listContainer}>
                            {data.length === 0 && <div className={cn('dropdown-item', classes.noRows)}>No rows found.</div>}
                            {data.length > 0 &&
                                data.map((item, index) => (
                                    <div
                                        key={item.key}
                                        className={cn(classes.listItem, classes.listItemText, 'dropdown-item row', {
                                            [classes.listItemHighlighted]: highlightedIndex === index,
                                            [classes.listItemSelected]: selectedItem === item,
                                        })}
                                        {...getItemProps({ index, item })}
                                    >
                                        {item.component}
                                    </div>
                                ))}
                        </div>
                    ) : null}
                </div>
            )}
        </Downshift>
    );
};

export default withStyles(styles)(SearchBase);

export const mapData = (key, value, label, displayComponent) => ({
    key: key,
    id: value,
    name: label,
    component: displayComponent != null ? displayComponent : <DisplayComponent>{label}</DisplayComponent>,
});

const DisplayComponent = ({ children }) => {
    return <div style={{ padding: 4, margin: 8 }}>{children}</div>;
};
