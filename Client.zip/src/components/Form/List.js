import React from 'react';
import ListPanel from './Panels/ListPanel';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

const styles = {
    badge: {},
    badgeBase: {
        alignSelf: 'flex-start',
        backgroundColor: '#6987B9',
        borderRadius: 12,
        color: '#fff',
        display: 'block',
        fontSize: 13,
        fontWeight: 700,
        lineHeight: 1,
        margin: 4,
        maxWidth: 275,
        overflow: 'hidden',
        padding: '4px 12px',
        position: 'relative',
        textAlign: 'center',
        textOverflow: 'ellipsis',
        verticalAlign: 'baseline',
        whiteSpace: 'nowrap',
        '& i': {
            cursor: 'pointer',
            marginLeft: 4,
        },
    },
    badgeList: {
        display: 'flex',
        alignContent: 'flex-start',
        background: '#ffffff',
        flexGrow: 1,
        flexWrap: 'wrap',
        minHeight: 30,
        position: 'relative',
        userSelect: 'none',
        width: '100%',
    },
    badgeEditable: {
        padding: '4px 24px 4px 12px',
    },
    delete: {
        position: 'absolute',
        right: 4,
    },
    editable: {
        border: '1px solid #bfbfbf',
        '&:focus, &:hover': {
            border: '1px solid #404040',
            boxShadow: 'inset 0px 0px 1px 1px #000000',
        },
    },
    faded: {
        opacity: 0.5,
    },
    groupName: {
        fontWeight: 700,
    },
    groupSection: {
        marginBottom: 12,
        '&:last-child': {
            marginBottom: 0,
        },
    },
};

const KEYCODES = Object.freeze({
    ARROW_DOWN: 40,
    ARROW_LEFT: 37,
    ARROW_RIGHT: 39,
    ARROW_UP: 38,
    ENTER: 13,
    ESC: 27,
    SPACE: 32,
    TAB: 9,
});

const getGroupItems = (list, group) => list.filter((item) => item.group === group);

const getGroups = (list) => {
    return list.reduce((agg, item) => {
        if (agg.indexOf(item.group) < 0) {
            agg.push(item.group);
        }
        return agg;
    }, []);
};

const getNextHighlightId = (list, id, dir) => {
    if (list.length > 0) {
        const prevValue = id != null ? list.findIndex((i) => i.id === id) : -1;
        const lastIdx = list.length - 1;

        const idx = dir === 'down' ? (prevValue < 0 ? 0 : prevValue === lastIdx ? 0 : prevValue + 1) : dir === 'up' ? (prevValue < 0 ? 0 : prevValue - 1 < 0 ? lastIdx : prevValue - 1) : 0;

        return list[idx].id;
    }
    return id;
};

const List = ({ classes, component, formatter, options, placeholder = '+ Add Item', readOnly = false, selected, onClose, onSelect }) => {
    const [coords, setCoords] = React.useState({});
    const [filterText, setFilterText] = React.useState('');
    const [highlightId, setHighlightId] = React.useState(null);
    const [showList, setShowList] = React.useState(true);
    const ref = React.useRef();

    //// MOVE FILTERING TO NEW FILTERPANEL COMPONENT (DERIVED FROM PANEL ---> LIST PANEL)
    //// MOVE FILTERING TO NEW FILTERPANEL COMPONENT (DERIVED FROM PANEL ---> LIST PANEL)
    //// MOVE FILTERING TO NEW FILTERPANEL COMPONENT (DERIVED FROM PANEL ---> LIST PANEL)
    //// MOVE FILTERING TO NEW FILTERPANEL COMPONENT (DERIVED FROM PANEL ---> LIST PANEL)
    //// MOVE FILTERING TO NEW FILTERPANEL COMPONENT (DERIVED FROM PANEL ---> LIST PANEL)
    //// MOVE FILTERING TO NEW FILTERPANEL COMPONENT (DERIVED FROM PANEL ---> LIST PANEL)

    const listItems = React.useMemo(() => {
        return Array.isArray(options) ? (filterText == null || filterText.length === 0 ? options : options.filter((li) => li.name.toLowerCase().startsWith(filterText.toLowerCase()))) : [];
    }, [filterText, options]);

    const close = React.useCallback(() => {
        setFilterText('');
        setHighlightId(null);
        setShowList(false);
        if (onClose) {
            onClose();
        }
    }, [onClose]);

    const focus = React.useCallback(() => {
        if (ref.current != null && readOnly === true) {
            ref.current.focus();
        }
    }, [readOnly]);

    const moveDown = React.useCallback(() => {
        const nextId = getNextHighlightId(listItems, highlightId, 'down');
        setHighlightId(nextId);
    }, [listItems, highlightId]);

    const moveUp = React.useCallback(() => {
        const nextId = getNextHighlightId(listItems, highlightId, 'up');
        setHighlightId(nextId);
    }, [listItems, highlightId]);

    const handleKeyPress = React.useCallback(
        (evt) => {
            const panelKeyPress = ref.current === evt.target;
            const key = evt.key;
            const keyCode = evt.keyCode;
            const shifted = evt.shiftKey;

            // Tab blur
            if (evt.keyCode === KEYCODES.TAB) {
                close();
                return;
            }

            if (panelKeyPress) {
                evt.preventDefault();
                evt.stopPropagation();

                // Alphanumeric filtering
                if (
                    (keyCode >= 48 && keyCode <= 57) || // numbers
                    (keyCode >= 65 && keyCode <= 90) // letters
                ) {
                    setFilterText((f) => `${f}${key}`);
                    return;
                } else if (keyCode === 8) {
                    setFilterText((f) => (f.length <= 0 ? '' : f.slice(0, f.length - 1)));
                    return;
                }
            }

            // Navigation keys
            switch (evt.keyCode) {
                case KEYCODES.ARROW_DOWN:
                    if (!shifted) {
                        evt.preventDefault();
                        evt.stopPropagation();
                        moveDown();
                        focus();
                    }
                    break;

                case KEYCODES.ARROW_UP:
                    if (!shifted) {
                        evt.preventDefault();
                        evt.stopPropagation();
                        moveUp();
                        focus();
                    }
                    break;

                default:
                    break;
            }
        },
        [close, focus, moveDown, moveUp, ref]
    );

    const handleListHide = React.useCallback(() => {
        close();
    }, [close]);

    const handleListShow = React.useCallback(() => {
        setShowList(true);
    }, [setShowList]);

    const getCoords = () => {
        if (ref.current != null) {
            const elemRect = ref.current.getBoundingClientRect();
            return elemRect == null
                ? {}
                : {
                      y: elemRect.height,
                      x: 0,
                      width: elemRect.right - elemRect.left,
                  };
        }
        return { y: 0, x: 0, width: 0 };
    };

    const handleChange = (item) => (value) => {
        const nextOptions = Array.isArray(options) ? options.map((o) => (o.id === item.id ? { ...o, value } : o)) : [];
        onSelect(nextOptions);
    };

    const handleDelete = (item) => () => {
        const nextOptions = Array.isArray(options) ? options.map((o) => (o.id === item.id ? { ...o, value: o.valueDefault } : o)) : [];
        onSelect(nextOptions);
    };

    const handlePanelChange = () => {
        setCoords(getCoords());
    };

    React.useEffect(() => {
        close();
    }, [close]);

    React.useEffect(() => {
        setCoords(getCoords());
    }, [ref]);

    return (
        <React.Fragment>
            <div tabIndex="0" className={cn(classes.badgeList, { [classes.editable]: readOnly === false })} ref={ref} onClick={handleListShow} onFocus={handleListShow} onKeyDown={handleKeyPress}>
                {readOnly === false && (!Array.isArray(selected) || selected.length === 0) && <div className={cn(classes.badgeBase, classes.badge, classes.faded)}>{placeholder}</div>}
                {Array.isArray(selected) &&
                    selected.map((item) => (
                        <div key={item.id} className={cn(classes.badgeBase, classes.badge, { [classes.badgeEditable]: readOnly === false })}>
                            {formatter != null ? formatter(item) : item.name}
                            {!readOnly && <i className={cn('fas', 'fa-times-circle', classes.delete)} onClick={handleDelete(item)}></i>}
                        </div>
                    ))}
                {readOnly !== true && (
                    <ListPanel show={showList} filter={filterText} onClose={handleListHide} onChange={handlePanelChange} x={coords.x} y={coords.y} width={coords.width}>
                        {Array.isArray(listItems) &&
                            getGroups(listItems).map((group) => {
                                const list = getGroupItems(listItems, group);
                                const hasCategory = group != null;
                                const groupName = hasCategory === true ? group : '';
                                return (
                                    <div className={classes.groupSection} key={groupName}>
                                        {hasCategory && <div className={classes.groupName}>{groupName}</div>}
                                        {Array.isArray(list)
                                            ? list.map((item) =>
                                                  React.cloneElement(
                                                      component({
                                                          data: item,
                                                          highlighted: highlightId == null ? false : item.id === highlightId,
                                                          onChange: handleChange(item),
                                                      }),
                                                      { key: item.id }
                                                  )
                                              )
                                            : []}
                                    </div>
                                );
                            })}
                    </ListPanel>
                )}
            </div>
        </React.Fragment>
    );
};

//List.whyDidYouRender = { customName: 'List' }
export default withStyles(styles)(React.memo(List));
