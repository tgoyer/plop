import React from 'react';
import cn from 'classnames';

import MuiButton from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import ButtonTypes from './ButtonTypes';

const styles = theme => ({
    subHeader: {
        fontWeight: 700,
        '& i': {
           paddingRight: 8, 
        }
    },
    subHeaderPrimary: {
        backgroundColor: '#6987b9 !important',
        color: '#ffffff !important'
    },
    subHeaderSecondary: {
        boxShadow: 'inset 0px 0px 1px 1px rgba(105, 135, 185, .65);',
        '&:hover': {
            boxShadow: 'inset 0px 0px 1px 1px rgba(105, 135, 185, 1);',
        }
    }
});

const Button = ({ children, classes, type = ButtonTypes.PRIMARY, ...rest }) => {
    switch(type) {
        case ButtonTypes.PRIMARY:
            return <MuiButton color="primary" variant="contained" {...rest}>{children}</MuiButton>;
        case ButtonTypes.SECONDARY:
            return <MuiButton color="secondary" variant="outlined" {...rest}>{children}</MuiButton>;
        case ButtonTypes.SUBHEADER_PRIMARY:
            return <MuiButton color="primary" className={cn(classes.subHeader, classes.subHeaderPrimary)} {...rest}>{children}</MuiButton>;
        case ButtonTypes.SUBHEADER_SECONDARY:
            return <MuiButton color="secondary" className={cn(classes.subHeader, classes.subHeaderSecondary)} {...rest}>{children}</MuiButton>;
        default:
            return <MuiButton color="primary" variant="contained" {...rest}>{children}</MuiButton>;
    }
}

// Button.whyDidYouRender = { customName: 'Button' }
export default withStyles(styles)(
    React.memo(Button)
);