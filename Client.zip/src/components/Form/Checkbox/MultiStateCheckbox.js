import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    root: {
        marginBottom: 0,
        '& input': {
            opacity: 0,
            position: 'absolute',
            left: -9999,
        }
    },
    container: {
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        userSelect: 'none',
    },
    checkbox: {},
    checkboxBase: {
        fontSize: 17,
        margin: '6px 8px 6px 6px',
        '&.transparent': {
            visibility: 'hidden'
        },
        '& .hover': {
            opacity: .5
        },
    },
    checkboxContainer: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
    },
    hover: {},
    hoverBase: {
        boxShadow: 'inset 0 0 0 2px rgba(255, 255, 255, .5), 0 0 2px 2px rgba(255, 255, 255, .5)',
    },
    label: {},
    labelBase: {
        fontSize: 12,
        fontWeight: 400,
    },
});

const KEYCODES = Object.freeze({
    SPACE: 32,
});

const getValueIndex = (states, value) => {
    return Array.isArray(states)
        ? states.findIndex(s => s.value === value)
        : 0;
}

const getNextIndex = (states, value) => {
    const current = getValueIndex(states, value);
    const next = current < 0 ? 0 : current + 1;
    return next < states.length ? next : 0;
}

const MultiStateCheckbox = ({
    children, classes, states, text, value = null,
    disabled = false, focused = false,
    onChange
}) => {
    const [focus, setFocus] = React.useState(false);
    const [hover, setHover] = React.useState(false);
    const ref = React.useRef();

    const className = React.useMemo(
        () => {
            const idx = getValueIndex(states, value);
            return Array.isArray(states) ? states[idx].class : '';
        },
        [states, value]
    );

    const dispatchNext = React.useCallback(
        () => {
            if (!disabled && onChange != null) {
                const idx = getNextIndex(states, value);
                onChange(states[idx].value);
            }
        },
        [disabled, onChange, value, states]
    );

    const handleBlur = React.useCallback(
        () => setFocus(disabled === false && false),
        [disabled]
    );

    const handleFocus = React.useCallback(
        () => setFocus(disabled === false && true),
        [disabled]
    );

    const handleKeyDown = React.useCallback(
        (evt) => {
            if (ref.current.contains(evt.target)) {
                switch (evt.keyCode) {
                    case KEYCODES.SPACE:
                        evt.preventDefault();
                        evt.stopPropagation();
                        dispatchNext();
                        break;
                    default:
                        break;
                }
            }
        },
        [dispatchNext]
    );

    const handleChange = () => dispatchNext();
    const handleMouseHover = (enter) => () => setHover(disabled === false && enter);

    React.useEffect(
        () => {
            if (disabled === false) {
                const elem = ref.current;
                elem.addEventListener("blur", handleBlur);
                elem.addEventListener("focus", handleFocus);
                return () => {
                    elem.removeEventListener("blur", handleBlur);
                    elem.removeEventListener("focus", handleFocus);
                }
            }
        },
        [disabled, handleBlur, handleFocus]
    )

    React.useEffect(
        () => {
            setFocus(focused);
            if (disabled === false && focused === true) {
                ref.current.focus();
            }
        },
        [disabled, focused]
    );

    return (
        <div className={classes.container}>
            <div tabIndex="0" ref={ref} onKeyDown={handleKeyDown} onMouseEnter={handleMouseHover(true)} onMouseLeave={handleMouseHover(false)}>
                <label className={classes.root} onClick={handleChange}>
                    <div className={classes.checkboxContainer}>
                        <i className={cn(classes.checkboxBase, classes.checkbox, className, {
                            [classes.hoverBase]: (focus === true || hover === true) && disabled === false,
                            [classes.hover]: (focus === true || hover === true) && disabled === false,
                        })}></i>
                        <span className={cn(classes.labelBase, classes.label)}>{text}</span>
                    </div>
                </label>
            </div>
            {children}
        </div>
    );
}

export default withStyles(styles)(MultiStateCheckbox);
