import React from 'react';
import MultiStateCheckbox from 'components/Form/Checkbox/MultiStateCheckbox';
import { mapCheckboxState } from 'components/Form/utilities';

const states = [
    mapCheckboxState('far fa-square', null),
    mapCheckboxState('far fa-plus-square', true),
    mapCheckboxState('far fa-minus-square', false),
];

const TriStateCheckbox = ({ children, onChange, ...rest }) => {
    const handleChange = (value) => {
        if (onChange != null) {
            onChange(value === true);
        }
    }

    return (
        <MultiStateCheckbox
            states={states}
            onChange={handleChange}
            {...rest}
        >
            {children}
        </MultiStateCheckbox>
    )
}
export default TriStateCheckbox;