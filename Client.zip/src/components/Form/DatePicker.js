import React from 'react';
import { KeyboardDatePicker } from '@material-ui/pickers';

import { dateFormat } from 'Utils/dateHelper';

const DatePicker = ({ InputLabelProps = {}, KeyboardButtonProps = {}, ...props }) => {
    return (
        <KeyboardDatePicker
            autoOk={true}
            clearable={true}
            format={dateFormat}
            placeholder={dateFormat.toUpperCase()}
            InputLabelProps={{
                ...InputLabelProps,
                shrink: true,
            }}
            KeyboardButtonProps={{
                ...KeyboardButtonProps,
                'aria-label': 'change date',
            }}
            {...props}
        />
    );
};

export default DatePicker;
