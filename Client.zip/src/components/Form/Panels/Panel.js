import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

const styles = ({
    content: {
        height: '25vh',
        maxHeight: '50vh',
        minHeight: 225,
        marginRight: 8,
        overflowY: 'scroll',
    },
    panel: {
        position: 'absolute',
        top: 0,
        left: 0,

        display: 'flex',
        background: '#fff',
        boxShadow: '0px 1px 3px 0px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14), 0px 2px 1px -1px rgba(0, 0, 0, 0.12)',
        flexDirection: 'column',
        padding: '8px 0 8px 8px',
        userSelect: 'none',
        zIndex: 5000,
    },
    hidden: {
        display: 'none',
    },
});

const Panel = ({ children, classes, show, onChange, onClose, width, x, y }) => {
    const panelRef = React.useRef();

    const style = React.useMemo(
        () => ({ left: x, top: y, width }),
        [x, y, width]
    );

    const handleClick = React.useCallback(
        () => {
            if (onChange != null) {
                setTimeout(onChange, 0);
            }
        },
        [onChange]
    );

    const handleWinClick = React.useCallback(
        (evt) => {
            const panelClicked = panelRef.current != null && panelRef.current.contains(evt.target);
            if (panelClicked === false && onClose != null) {
                onClose(evt);
            }
        },
        [onClose]
    );

    React.useEffect(
        () => {
            window.addEventListener("mousedown", handleWinClick);
            window.addEventListener("touchstart", handleWinClick);
            return () => {
                window.removeEventListener("mousedown", handleWinClick);
                window.removeEventListener("touchstart", handleWinClick);
            }
        },
        [handleWinClick]
    );

    React.useEffect(
        () => {
            if (show === true) {
                setTimeout(onChange, 0);
            }
        },
        [show, onChange]
    );

    return (
        <div ref={panelRef} className={cn(classes.panel, { [classes.hidden]: !show })} style={style} onClick={handleClick}>
            <div className={classes.content}>{children}</div>
        </div>
    );
}

//ListPanel.whyDidYouRender = { customName: 'ListPanel' }
export default withStyles(styles)(
    React.memo(Panel)
);