import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import Panel from './Panel';

const styles = ({
    searchFilter: {
        border: '1px solid #e6e6e6',
        fontWeight: 700,
        marginBottom: 4,
        padding: '2px 4px',
        width: '100%',
    },
});

const FilterPanel = ({ classes, children, filter, ...rest }) => {
    return (
        <Panel {...rest}>
            {filter != null && filter.length > 0 && <div className={classes.searchFilter}>Search: {filter}</div>}
            <div className={classes.content}>{children}</div>
        </Panel>
    );
}

//ListPanel.whyDidYouRender = { customName: 'ListPanel' }
export default withStyles(styles)(
    React.memo(FilterPanel)
);