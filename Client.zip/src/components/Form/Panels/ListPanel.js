import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import FilterPanel from './FilterPanel';

const styles = ({});

const ListPanel = ({ classes, children, ...rest }) => {
    return (
        <FilterPanel {...rest}>
            {children}
        </FilterPanel>
    );
}

//ListPanel.whyDidYouRender = { customName: 'ListPanel' }
export default withStyles(styles)(
    React.memo(ListPanel)
);