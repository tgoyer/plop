import React from 'react';

import { withStyles } from '@material-ui/core/styles';
import { Heading } from '../../Content';

const styles = (theme) => ({
    container: {
        position: 'relative',
        margin: '14px 25px',
    },
    controls: {
        padding: 6,
        maxHeight: 175,
        overflowY: 'auto',
    },
    required: {
        color: '#ffffff',
        fontSize: 10,
        fontWeight: 700,
        marginLeft: 10,
        backgroundColor: '#b30000',
        padding: '2px 6px',
        borderRadius: 24,
    },
});

const InputContainer = ({ children, classes, required, title, styles = {} }) => {
    const { container, controls } = styles;

    return (
        <div className={classes.container} style={{ ...container }}>
            <Heading title={title}>{required === true && <span className={classes.required}>required</span>}</Heading>
            <div className={classes.controls} style={{ ...controls }}>
                {children}
            </div>
        </div>
    );
};

//InputContainer.whyDidYouRender = { customName: 'InputContainer' }
export default withStyles(styles)(React.memo(InputContainer));
