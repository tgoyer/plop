import React from 'react';

import _get from 'lodash/get';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import { withStyles } from '@material-ui/core/styles';

import InputContainer from './Panels/InputContainer';

const styles = (theme) => ({
    list: {
        bottom: 0,
        left: 0,
        overflowY: 'auto',
        position: 'absolute',
        top: 36,
        width: '100%',
    },
    listItem: {
        padding: '4px 12px',
        fontSize: 18,
        '& > i + div': {
            marginLeft: 8,
        },
    },
    listItemText: {
        padding: 0,
        fontSize: 14,
    },
    listOverride: {
        margin: 0,
        padding: 0,
    },
});

const defaultState = { component: <i className="far fa-square"></i>, value: null };
const defaultListStates = [{ component: <i className="far fa-check-square"></i>, value: true }];

const buildStateComponents = (list) => {
    return [{ ...defaultState }, ...(Array.isArray(list) ? list : [])];
};

const getNextComponent = (option, components) => {
    if (option == null || !Array.isArray(components)) return;

    const compIdx = option.component != null ? components.findIndex((comp) => option.component.value === comp.value) : -1;
    const len = components.length - 1;
    const nextIdx = compIdx >= len ? 0 : compIdx + 1;

    return components[nextIdx];
};

const resetComponents = (reset, list) => {
    return list.map((item) => ({
        ...item,
        value: reset === true ? defaultState.value : item.value,
        component: reset === true ? defaultState : item.component,
    }));
};

const SelectList = ({ classes, multiple = true, name, options, onChange, required, title, styles, values, valueStates = defaultListStates }) => {
    const stateComponents = React.useMemo(() => buildStateComponents(valueStates), [valueStates]);

    const list = React.useMemo(
        () =>
            options.map((o) => {
                var option = (Array.isArray(values) && values.find((v) => v.id === o.id)) || o;
                return {
                    ...option,
                    // Ignoring eslint rule because null is a valid option.  Just be careful of truthy values.
                    // eslint-disable-next-line eqeqeq
                    component: stateComponents.find((state) => option.value == state.value),
                };
            }),
        [options, values, stateComponents]
    );

    const handleSelectChange = (option) => (evt) => {
        const idx = list.findIndex((item) => item.id === option.id);
        const component = getNextComponent(option, stateComponents);
        const newList =
            idx >= 0
                ? [
                      ...resetComponents(multiple === false, list.slice(0, idx)),
                      { ...option, component: component, value: component.value },
                      ...resetComponents(multiple === false, list.slice(idx + 1)),
                  ]
                : list;

        if (onChange != null) {
            onChange(
                name,
                newList.reduce((acc, { id, name, component }) => {
                    if (component.value != null) {
                        acc.push({ id, name, value: component.value });
                    }
                    return acc;
                }, [])
            );
        }
    };

    return (
        list != null && (
            <InputContainer title={title} styles={styles}>
                <List className={classes.listOverride}>
                    {list.map((option) => {
                        return (
                            <ListItem button={true} key={option.id} onClick={handleSelectChange(option)} classes={{ button: classes.listItem }}>
                                {_get(option, 'component.component', null)}
                                <ListItemText
                                    primary={option.name}
                                    classes={{
                                        primary: classes.listItemText,
                                    }}
                                />
                            </ListItem>
                        );
                    })}
                </List>
            </InputContainer>
        )
    );
};

//SelectList.whyDidYouRender = { customName: 'SelectList' }
export default withStyles(styles)(React.memo(SelectList));
