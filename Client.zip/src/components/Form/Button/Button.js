import React from 'react';
import cn from 'classnames';

import MuiButton from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import ButtonTypes from 'components/Form/Button/ButtonTypes';

const styles = (theme) => ({
    button: {
        fontWeight: 700,
        '&:disabled': {
            backgroundColor: '#e6e6e6 !important',
        },
        '& i': {
            fontSize: '10px',
            margin: 4,
        },
    },
    compact: {
        minHeight: 0,
        padding: '4px 6px',
    },
    flat: {
        backgroundColor: '#6987b9 !important',
        border: '1px solid transparent',
        color: '#ffffff !important',
        '&:not(:disabled):hover': {
            backgroundColor: '#495e81 !important',
        },
        '&:disabled': {
            backgroundColor: '#cccccc !important',
        },
    },
    minimal: {
        border: '1px solid transparent',
        '&:disabled': {
            color: '#aaaaaa !important',
        },
    },
    secondary: {
        boxShadow: 'inset 0 0 1px 0px #bac7de, 0 0 1px 0px #bac7de',
        border: '1px solid #bac7de',
        '&:disabled': {
            backgroundColor: '#eeeeee',
            border: '1px solid #cccccc',
            boxShadow: 'inset 0 0 1px 0px #cccccc, 0 0 1px 0px #cccccc',
            color: '#aaaaaa !important',
        },
    },
});

const Button = ({ children, className, classes, compact, loading, type = ButtonTypes.PRIMARY, ...props }) => {
    return type === ButtonTypes.SECONDARY ? (
        <MuiButton color="secondary" className={cn(classes.button, { [classes.compact]: compact }, classes.secondary, className)} {...props}>
            {children}
            {loading && <i className="fas fa-circle-notch fa-spin"></i>}
        </MuiButton>
    ) : type === ButtonTypes.MINIMAL ? (
        <MuiButton color="secondary" className={cn(classes.button, { [classes.compact]: compact }, classes.minimal, className)} {...props}>
            {children}
            {loading && <i className="fas fa-circle-notch fa-spin"></i>}
        </MuiButton>
    ) : type === ButtonTypes.FLAT ? (
        <MuiButton color="primary" className={cn(classes.button, { [classes.compact]: compact }, classes.flat, className)} {...props}>
            {children}
            {loading && <i className="fas fa-circle-notch fa-spin"></i>}
        </MuiButton>
    ) : (
        <MuiButton color="primary" className={cn(classes.button, { [classes.compact]: compact }, className)} variant="contained" {...props}>
            {children}
            {loading && <i className="fas fa-circle-notch fa-spin"></i>}
        </MuiButton>
    );
};

export default React.memo(withStyles(styles)(Button));
