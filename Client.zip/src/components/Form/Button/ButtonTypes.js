export default {
    FLAT: 'flat',
    MINIMAL: 'minimal',
    PRIMARY: 'primary',
    SECONDARY: 'secondary',
    SUBHEADER_PRIMARY: 'minimal',
    SUBHEADER_SECONDARY: 'flat',
};
