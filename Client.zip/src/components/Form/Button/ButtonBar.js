import React from 'react';

import Label from 'components/Form/Label/Label';

import { withStyles } from '@material-ui/core/styles';

const styles = () => ({
    buttonBar: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
    },
    buttons: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        '& > button': {
            borderRadius: 0,
            boxShadow: 'inset 0 0 1px 0px #bac7de, 0 0 1px 0px #bac7de',
            border: '1px solid #bac7de',
            whiteSpace: 'nowrap',
        },
        '& > button + button': {
            borderLeft: 0,
        },
        '& > button:first-child': {
            borderBottomLeftRadius: 4,
            borderTopLeftRadius: 4,
        },
        '& > button:last-child': {
            borderBottomRightRadius: 4,
            borderTopRightRadius: 4,
        },
    },
    errorText: {
        color: '#cc0000',
        fontSize: '.8rem',
        fontWeight: 700,
        paddingLeft: 8,
    },
});

const ButtonBar = ({ classes, children, errorText, label, required }) => {
    return (
        <div className={classes.buttonBar}>
            <Label required={required}>{label}</Label>
            <div className={classes.buttons}>{children}</div>
            {errorText && <small className={classes.errorText}>* {errorText}</small>}
        </div>
    );
};

export default React.memo(withStyles(styles)(ButtonBar));
