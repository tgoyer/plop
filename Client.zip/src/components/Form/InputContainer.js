import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';
import { Heading } from '../Content'

const styles = theme => ({
    container: {
        position: 'relative',
        margin: '14px 25px',
        width: 'calc(33% - 50px)',
        '@media (max-width: 1024px)': {
            height: 'initial',
            width: 'calc(50% - 50px)',
        },
    },
    controls: {
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
        padding: 6,
        width: '100%',
    },
    required: {
        color: '#ffffff',
        fontSize: 10,
        fontWeight: 700,
        marginLeft: 10,
        backgroundColor: '#b30000',
        padding: '2px 6px',
        borderRadius: 24,
    },
});

const InputContainer = ({ children, classes, required, title, height = 150, maxHeight = 175, styles = {} }) => {
    const { container, controls } = styles;

    return (
        <React.Fragment>
            <div className={cn(classes.container)} style={{ minHeight: height, ...container }}>
                <Heading title={title}>
                    {required === true && <span className={classes.required}>required</span>}
                </Heading>
                <div className={classes.controls} style={{ maxHeight, ...controls }}>
                    {children}
                </div>
            </div>
        </React.Fragment>
    )
}

//InputContainer.whyDidYouRender = { customName: 'InputContainer' }
export default withStyles(styles)(React.memo(InputContainer));