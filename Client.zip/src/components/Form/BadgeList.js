import React from 'react';
import cn from 'classnames';

import { withStyles } from '@material-ui/core/styles';

import InputContainer from './Panels/InputContainer';

const styles = theme => ({
    badge: {
        backgroundColor: '#6987B9',
        borderRadius: 12,
        color: '#fff',
        display: 'inline',
        fontSize: 12,
        fontWeight: 700,
        height: 20,
        lineHeight: 1,
        margin: 4,
        padding: '4px 8px',
        textAlign: 'center',
        verticalAlign: 'baseline',
        whiteSpace: 'nowrap',
        '& i': {
            cursor: 'pointer',
            marginLeft: 4
        }
    },
    badgeList: {
        padding: 10,
        display: 'flex',
        flexWrap: 'wrap',
    },
    textSearch: {
        marginLeft: 10,
        width: 'calc(100% - 10px)'
    },
});

const BadgeList = ({ children, classes, data, styles, title, onDelete }) => {
    const handleDelete = (item) => (event) => {
        if (onDelete != null) {
            onDelete(item);
        }
    }

    return data != null && (
        <InputContainer
            height={100}
            title={title}
            styles={{
                ...styles,
                controls: {
                    flexDirection: 'column',
                    overflowY: 'visible'
                }
            }}
        >
            {Array.isArray(data) && (
                <div className={classes.badgeList}>
                    {data.map(item => (
                        <div key={item.id} className={classes.badge}>{item.name} <i className="fas fa-times-circle" onClick={handleDelete(item)}></i></div>
                    ))}
                </div>
            )}
            <div className={cn(classes.textSearch, "control")}>
                {children}
            </div>
        </InputContainer>
    )
}

//BadgeList.whyDidYouRender = { customName: 'BadgeList' }
export default withStyles(styles)(React.memo(BadgeList));