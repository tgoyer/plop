export const mapCheckboxState = (className, value) => ({
    class: className,
    value,
})

export const mapSelectOptions = (list, mapper) => {
    return (Array.isArray(list) && list.length > 0)
        ? list.map(item => item == null ? null : mapper(item, (id, name, value, group, meta) => ({ id, name, value, group, meta })))
        : list;
}
