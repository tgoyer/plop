import React from 'react';

import BaseSelect from 'components/Form/Select/BaseSelect';

const Select = ({ disabled = false, label = '', options = [], value = null, onChange, ...props }) => {
    const selectedOption = React.useMemo(() => {
        return options.find((o) => o.value === value);
    }, [options, value]);

    const handleChange = (option) => {
        onChange({ value: option?.value, option });
    };

    return <BaseSelect disabled={disabled} options={options} isClearable={true} value={selectedOption} onChange={handleChange} label={label} {...props} />;
};

export default React.memo(Select);
