import React from 'react';
import ReactSelect from 'react-select';
import { withStyles } from '@material-ui/core/styles';

import Label from 'components/Form/Label/Label';

import { hasEntries } from 'Utils/arrayHelpers';

const styles = () => ({
    container: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
        gap: 8,
    },
    errorText: {
        color: '#cc0000',
        fontSize: '.8rem',
        fontWeight: 700,
        paddingLeft: 8,
    },
    label: {
        backgroundColor: 'transparent',
        color: 'black',
        fontWeight: 700,
        opacity: 0.8,
    },
    root: {
        minWidth: 200,
        width: 'fit-content',
        '& > *': {
            '&:nth-child(2)': {
                border: '1px solid #333',
                boxShadow: 'inset 0 0 1px 0px #333, 0 0 1px 0px #333',
                '&:hover, &:active, &:focus': {
                    border: '1px solid #333',
                    boxShadow: 'inset 0 0 1px 1px #333, 0 0 1px 0px #333',
                },
            },
        },
    },
});

const rsStyles = {
    option: (styles) => ({
        ...styles,
        minWidth: 250,
        width: 'max-content',
        zIndex: 1000,
    }),
};

const BaseSelect = ({ classes, errorText, label, required, ...props }) => {
    return (
        <div className={classes.container}>
            <Label required={required}>{label}</Label>
            <ReactSelect className={classes.root} styles={rsStyles} {...props} />
            {errorText && <small className={classes.errorText}>* {errorText}</small>}
        </div>
    );
};

export default React.memo(withStyles(styles)(BaseSelect));

export const toOption = (item, valueField, labelField) => {
    return {
        value: getValue(item, valueField),
        label: getValue(item, labelField),
    };
};
export const toOptionList = (items, valueField, labelField) => {
    return hasEntries(items) ? items.map((item) => toOption(item, valueField, labelField)) : [];
};
const getValue = (item, selector) => {
    return item == null ? null : typeof selector === 'function' ? selector(item) : item[selector];
};
