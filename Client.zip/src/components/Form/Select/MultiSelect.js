import React from 'react';

import BaseSelect from 'components/Form/Select/BaseSelect';

const MultiSelect = ({ classes, disabled = false, label = '', options = [], values = [], onChange, ...props }) => {
    const selectedOptions = React.useMemo(() => {
        return options.filter((o) => values.indexOf(o.value) >= 0);
    }, [options, values]);

    const handleChange = (options) => {
        onChange({ values: options.map((o) => o.value), options });
    };

    return (
        <BaseSelect
            closeMenuOnSelect={false}
            disabled={disabled}
            isMulti={true}
            label={label}
            options={options}
            defaultValue={selectedOptions}
            onChange={handleChange}
            {...props}
        />
    );
};

export default React.memo(MultiSelect);
