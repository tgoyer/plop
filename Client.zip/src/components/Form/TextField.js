import React from 'react';

import InputBase from '@material-ui/core/InputBase';
import { withStyles } from '@material-ui/core/styles';

import Label from 'components/Form/Label/Label';

const styles = () => ({
    container: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
    },
    input: {
        width: '100%',
        '& input, & textarea': {
            borderBottom: '1px solid #333',
            padding: 4,
            '&:hover': {
                boxShadow: '0px 2px 1px -1px #333;',
            },
        },
    },
    errorText: {
        color: '#cc0000',
        fontSize: '.8rem',
        fontWeight: 700,
        paddingLeft: 8,
    },
});

const TextField = ({ classes, defaultValue, errorText, onChange, placeholder, required, title, ...rest }) => {
    const [value, setValue] = React.useState(defaultValue || '');

    const handleChange = (evt) => {
        setValue(evt.target.value);
    };

    const handleBlur = (evt) => {
        if (onChange != null) {
            onChange(evt);
        }
    };

    return (
        <div className={classes.container}>
            <Label required={required}>{title}</Label>
            <InputBase className={classes.input} onBlur={handleBlur} onChange={handleChange} placeholder={placeholder} value={value} {...rest} />
            {errorText && <small className={classes.errorText}>* {errorText}</small>}
        </div>
    );
};

// TextField.whyDidYouRender = { customName: 'TextField' }
export default withStyles(styles)(React.memo(TextField));
