import React from 'react';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

const styles = () => ({
    label: {
        backgroundColor: 'transparent',
        color: 'black',
        fontWeight: 700,
        opacity: 0.8,
        '& .required:after': {
            content: '" *"',
            color: '#c00',
        },
    },
});

const Label = ({ classes, children, required }) => {
    return (
        <div className={classes.label}>
            <span className={cn({ required: required === true })}>{children}</span>
        </div>
    );
};

export default React.memo(withStyles(styles)(Label));
