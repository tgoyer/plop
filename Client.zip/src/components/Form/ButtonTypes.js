export default {
    PRIMARY: 'primary',
    SECONDARY: 'secondary',
    SUBHEADER_PRIMARY: 'subheader-primary',
    SUBHEADER_SECONDARY: 'subheader-secondary',
}