import { WebStorageStateStore, User, UserManager } from 'oidc-client-ts';
import { CookieStorage } from 'cookie-storage';

import { contains } from 'Utils/stringHelper';
import { getUserInfo } from 'store/UserModule';
import store from 'store';

const redirectKey = 'redirect_path';
const oidcTokenKey = 'oidc_token_key';
const cookieStorage = new CookieStorage({
    path: '/',
    secure: true,
    sameSite: 'Strict',
});

export function configureOidcSettings(settings) {
    localStorage.setItem(oidcTokenKey, `oidc.user:${settings?.Authority}:${settings?.ClientID}`);
    return {
        authority: settings?.Authority,
        client_id: settings?.ClientID,
        redirect_uri: settings?.RedirectURL,
        response_type: settings?.ResponseType,
        scope: settings?.Scopes,
        stateStore: new WebStorageStateStore({ store: cookieStorage }),
        userStore: new WebStorageStateStore({ store: cookieStorage }),
        automaticSilentRenew: true,
        onSigninCallback: handleOidcSignIn,
    };
}

export function doOidcRedirect(replace, push) {
    const replaceFn = replace ?? window.history.replaceState;
    const pushFn = push ?? window.history.pushState;

    const redirect_path = localStorage.getItem(redirectKey);
    if (redirect_path != null) {
        localStorage.removeItem(redirectKey);
        replaceFn(window.location.pathname);
        pushFn(redirect_path);
    }
}

export function getOidcKey() {
    return localStorage.getItem(oidcTokenKey);
}

export function getOidcUser() {
    const oidcStorage = cookieStorage.getItem(getOidcKey());
    return oidcStorage == null ? null : User.fromStorageString(oidcStorage);
}

export function getTokenTime(time) {
    const ret = time != null ? new Date(time * 1000) : new Date();
    return ret.toLocaleTimeString();
}

export function handleOidcSignIn(token) {
    console.group('OIDC sign-in handled.');
    console.log('Token expires at:', token?.expires_at != null ? getTokenTime(token?.expires_at) : 'Unknown');
    console.groupEnd();
}

export function handleRenewError(auth) {
    return auth.events.addSilentRenewError((error) => {
        try {
            if (contains(error.error_description, 'expired refresh token')) {
                alert('Your session has expired.  You are about be redirected to log back in. Any unsaved changes will be lost.');
                setOidcRedirectPath();
                auth.clearStaleState();
                auth.signinRedirect();
            }
        } catch (error) {
            console.log('auth.signinRedirect failed: ', error);
        }
    });
}

export function handleTokenExpiration(auth) {
    return auth.events.addAccessTokenExpiring(async () => {
        console.group('Refresh Token');
        console.log('Your token has expired.');
        try {
            console.log('Refresh attempted at: ', getTokenTime());
            const user = await auth.signinSilent();
            console.log('Token expires at:', user?.expires_at != null ? getTokenTime(user?.expires_at) : 'Unknown');
        } catch (error) {
            console.log('auth.signinSilent failed: ', error);
        }
        console.groupEnd();
    });
}

export function setOidcRedirectPath(defaultUri) {
    if (localStorage.getItem(redirectKey) == null) {
        let redirectUri = defaultUri;
        if (redirectUri == null) {
            const searchParams = new URLSearchParams(window.location.search);
            searchParams.delete('code');
            const qs = searchParams.size > 0 ? `?${searchParams.toString()}` : ``;
            redirectUri = `${window.location.pathname}${qs}`;
        }
        localStorage.setItem(redirectKey, redirectUri);
    }
}

export async function oidcAxiosResponseErrorHandler(settings, error, axios) {
    console.error('Axios Error:', error);

    const userManager = new UserManager(configureOidcSettings(settings));

    if (error.message === 'canceled') {
        return error;
    } else if (error.response?.status === 401) {
        const user = await userManager.signinSilent();

        console.log('401 URL Error', error);
        console.log('401 URL: ', error.config.url);

        if (String(error.config.url).endsWith('users/me')) {
            console.log('401 URL Start Get User');
            await store.dispatch(getUserInfo());
            console.log('401 URL End Get User');
            return error;
        } else if (user != null && error.config != null) {
            return axios.request(error.config);
        } else {
            return userManager.signinRedirect();
        }
    } else {
        return error;
    }
}

export function oidcAxiosRequestHandler(config) {
    const oidcStorage = cookieStorage.getItem(getOidcKey());
    const user = oidcStorage == null ? null : User.fromStorageString(oidcStorage);
    if (user?.id_token != null) {
        config.headers['Authorization'] = `Bearer ${user?.id_token}`;
    }
    return config;
}
