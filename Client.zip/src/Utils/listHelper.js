import _get from 'lodash/get';

/**
 * @description A custom alpha-numeric sort.
 * @param {string|number} field The key or ordinal location of an object where the compared values resides.
 * @returns -1, 0, or 1 for use in the default javascript sort implementation.
 */
export const alphaNumericSort =
    (field, sortAsFloat = true) =>
    (a, b) => {
        const aa = splitAlphaNumerics(String(a[field]).toLowerCase(), sortAsFloat);
        const bb = splitAlphaNumerics(String(b[field]).toLowerCase(), sortAsFloat);

        for (let x = 0; aa[x] && bb[x]; x++) {
            if (aa[x] !== bb[x]) {
                const c = Number(aa[x]);
                const d = Number(bb[x]);

                if (c === aa[x] && d === bb[x]) {
                    return c - d;
                } else {
                    return aa[x] > bb[x] ? 1 : -1;
                }
            }
        }
        return aa.length - bb.length;
    };

/**
 * @description Returns the index of an object in an array.
 * @param {Array} list The array to search.
 * @param {Function} compare A callback function to use as the value comparison.
 * @return {Number} The index of the first matching value or -1 if not found.
 */
export const findIndex = (list, compare) => {
    return list.reduce((ret, item, index) => {
        if (compare(item) && ret === -1) {
            ret = index;
        }
        return ret;
    }, -1);
};

/**
 * @description Merges two lists, swapping out entries in "source" with entries in "data"
 *              where the comparison delegate function returns true.  Does *NOT* mutate
 *              the source array.  It instead, returns a new array with the result of the merge.
 *              This makes it safe for use in a Redux reducer.
 * @param {Array} source The source list
 * @param {Array} data The data list
 * @param {Function} comparison A comparison delegate to determine if an entry in the
 *                              source array matches an entry in the data array.
 */
export const merge = (source, data, comparison) => {
    let arr = [...source];

    for (let x = 0; x < data.length; x++) {
        const d = data[x];
        const idx = source.findIndex((s) => comparison(s, d));

        if (idx >= 0) {
            arr = [...arr.slice(0, idx), d, ...source.slice(idx + 1)];
        } else {
            arr.push(d);
        }
    }

    return arr;
};

export const partition = (list, comparison) => {
    return list.reduce((acc, item) => {
        if (acc == null) acc = [[], []];
        if (comparison(item)) {
            acc[0].push(item);
        } else {
            acc[1].push(item);
        }
        return acc;
    }, null);
};

/**
 * @description A handy utility to extend javascript's standard sort to handle complex objects.
 * @param {*} accessor The object key to use to do field value comparisons
 * @param {*} useCase Case sensitive sorting.  Defaults to true.
 * @returns -1, 0, or 1 for use in the default javascript sort implementation.
 */
export const sort =
    (accessor, useCase = true) =>
    (a, b) => {
        let aVal = typeof accessor === 'function' ? accessor(a) : _get(a, accessor, '');
        aVal = !useCase && aVal != null ? String(aVal).toLowerCase() : aVal;

        let bVal = typeof accessor === 'function' ? accessor(b) : _get(b, accessor, '');
        bVal = !useCase && bVal != null ? String(bVal).toLowerCase() : bVal;

        const result = aVal < bVal ? -1 : aVal > bVal ? 1 : aVal === null ? 1 : bVal === null ? -1 : 0;

        return result;
    };

export const sortList = (list, field, dir = 'ASC') => {
    if (field == null) return list;

    var newList = list?.sort(sort(field));
    var sortDir = String(dir).toUpperCase();

    return sortDir === 'ASC' ? newList : sortDir === 'DESC' ? newList?.reverse() : list;
};

export const sortDate = (field) => (a, b) => {
    const aVal = a[field].toJSDate != null ? a[field].toJSDate() : a[field];
    const bVal = b[field].toJSDate != null ? b[field].toJSDate() : b[field];

    return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
};

/**
 * @description A custom alphanumeric sort based on user locale.
 * @param {string|number} field The key or ordinal location of an object where the compared values resides.
 */
export const sortLocale = (field) => (a, b) => {
    let aVal = field != null && typeof field === 'string' && field.length > 0 ? a[field] : a;
    aVal = typeof aVal === 'string' ? aVal.toLowerCase() : aVal.toString();

    let bVal = field != null && typeof field === 'string' && field.length > 0 ? b[field] : b;
    bVal = typeof bVal === 'string' ? bVal.toLowerCase() : bVal.toString();

    return aVal.localeCompare(bVal);
};

const splitAlphaNumerics = (value, splitAsFloat = true) => {
    const tz = [];
    let x = 0;
    let y = -1;
    let n = 0;
    let i;
    let j;

    // eslint-disable-next-line
    while ((i = (j = value.charAt(x++)).charCodeAt(0))) {
        const m = splitAsFloat ? i === 46 || (i >= 48 && i <= 57) : i >= 48 && i <= 57;
        if (m !== n) {
            tz[++y] = '';
            n = m;
        }
        tz[y] += j;
    }
    return tz;
};
