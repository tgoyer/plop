import { dateFormat, numericDateTimeFormat, formatDate, toLocalDateTime, getLocale, getMonthsList, timeAgo, toDateTime, toServerDateTime } from './dateHelper';
import { DateTime } from 'luxon';

const serverTimeZone = 'America/New_York';

describe('==> Date Helpers', () => {
    test('formatDate -- default formatting', () => {
        const date = new Date();
        const expected = DateTime.fromJSDate(date).toFormat(dateFormat);
        const actual = formatDate(date);
        expect(actual).toBe(expected);
    });

    test('formatDate -- custom formatting', () => {
        const date = new Date();
        const customFormat = 'MM dd, yyyy';
        const expected = DateTime.fromJSDate(date).toFormat(customFormat);
        const actual = formatDate(date, customFormat);
        expect(actual).toBe(expected);
    });

    test('toLocalDateTime', () => {
        const local = DateTime.local();
        const nyDate = toServerDateTime(local);
        const nyToLocal = toLocalDateTime(nyDate);

        expect(nyToLocal.toFormat(numericDateTimeFormat)).toBe(local.toFormat(numericDateTimeFormat));
    });

    test('getMonthsList creates months list using default locale', () => {
        const actual = getMonthsList('short');
        const expected = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        actual.forEach((month, i) => expect(month).toBe(expected[i]));
    });

    test('getMonthsList creates months list with locale override', () => {
        const actual = getMonthsList('long', 'de-DE');
        const expected = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

        actual.forEach((month, i) => expect(month).toBe(expected[i]));
    });

    test('toServerDateTime', () => {
        const local = DateTime.local();
        const expected = local.setZone(serverTimeZone);
        const actual = toServerDateTime(local);

        expect(actual.toString()).toBe(expected.toString());
    });

    test('toDateTime creates an instance of Luxon DateTime', () => {
        const date = toDateTime(new Date());
        const actual = date.setZone != null;
        expect(actual).toBe(true);
    });

    test('toDateTime returns null from an invalid value', () => {
        const actual = toDateTime('PLOP');
        expect(actual).toBe(null);
    });

    test('timeAgo - default locale', () => {
        const actual = new Date();
        const date = actual.getDate() - 1;
        actual.setDate(date);

        expect(timeAgo(actual)).toBe('yesterday');
    });

    test('timeAgo - de-DE locale', () => {
        const actual = new Date();
        const date = actual.getDate() - 1;
        actual.setDate(date);

        expect(timeAgo(actual, 'de-DE')).toBe('gestern');
    });
});
