/**
 * List of pre defined number formats.
 */
export const Formats = {
    US: {
        decimal: ".",
        groupingSize: 3,
        thousands: ",",
    }
}

export const CurrencyFormats = {
    USD: {
        ...Formats.US,
        moneySign: '$',
        precision: 2, 
    }
}


/**
 * @description Formats a decimal number into a currency string.  Defaults to USD format.
 * @param {Number} size The amount to be formatted.
 * @returns {String} size reformatted with appropriate suffix (KB, MB, GB, etc).
 */
export const formatByteSize = (size) => {
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const neg = size < 0;

    if (neg) {
        size = -size;
    }

    if (size < 1024) {
        return (neg ? '-' : '') + size + ' B';
    }

    const exponent = Math.min(Math.floor(Math.log(size) / Math.log(1024)), units.length - 1);
    const unit = units[exponent];

    size = Number((size / Math.pow(1024, exponent)).toFixed(2));
    return (neg ? '-' : '') + size + ' ' + unit;
}

/**
 * @description Formats a decimal number into a currency string.  Defaults to USD format.
 * @param {Number} amount The amount to be formatted.
 * @param {Object} format The format object that defines the format strategy.  Defaults to CurrencyFormats.USD
 */
export const formatCurrency = (amount, format = CurrencyFormats.USD) => {
    const { moneySign, precision, ...rest } = format;
    return moneySign + formatNumber(amount, precision, rest);
}

export const formatNumber = (number, precision, format = Formats.US) => {
    try {
        const { decimal, thousands, groupingSize } = format;
        const regex = new RegExp(`(\\d{${groupingSize}})(?=\\d)`, "g");
        const negativeSign = number < 0 ? "-" : "";

        let pre = Math.abs(precision);
        pre = isNaN(pre) ? 2 : pre
        
        let amountStr = Math.abs(roundDecimal(number, pre) || 0).toFixed(pre);
        const intPart = parseInt(amountStr, 10).toString();
        const extra = (intPart.length > groupingSize) ? intPart.length % groupingSize : 0;
        
        return negativeSign 
            + (!!extra ? intPart.substr(0, extra) + thousands : '') 
            + intPart.substr(extra).replace(regex, "$1" + thousands) 
            + (!!pre ? decimal + Math.abs(number - parseInt(intPart, 10)).toFixed(pre).slice(2) : '');
    } catch (e) {
        console.log(e)
    }
}

/**
 * @description Converts from a percentage to a decimal value.
 * @param {*} value The value to convert.
 * @param {*} precision Optional.  Precision of any decimal part.  Defaults to 3.
 * @returns {Number} The decimal value.
 */
export const fromPercent = (value, precision = 3) => {
    if (isNaN(value) || value == null) return value;  // value is Not A Number.

    const exp = Math.pow(10, 2);
    return roundDecimal(value / exp, precision+2);
}

/**
 * @description Round decimal to specified precision.
 * @param {*} value The value to round.
 * @param {*} precision The required precision.
 * @returns {Number} The rounded value.
 */
export const roundDecimal = (value, precision) => {
    if (isNaN(value) || value == null) return value;  // value is Not A Number.
    
    const exp = Math.pow(10, precision);
    return Math.round(Number(value)*exp)/exp;
}

/**
 * @description Converts from a decimal value to a percentage.
 * @param {*} value The value to convert.
 * @param {*} precision Optional.  Precision of any decimal part.  Defaults to 3.
 * @returns {Number} The percentage value.
 */
export const toPercent = (value, precision = 3) => {
    if (isNaN(value) || value == null) return value;  // value is Not A Number.

    const exp = Math.pow(10, 2);
    return roundDecimal(value * exp, precision);
}

/**
 * @description Converts from a decimal value to a signed, padded percentage string.
 * @param {*} value The value to convert.
 * @param {*} precision Optional.  Precision of any decimal part.  Defaults to 3.
 * @returns {String} The signed percentage value.
 */
export const toSignedPercent = (value, precision = 3) => {
    if (isNaN(value) || value == null) return value;

    return `${toPercent(value, precision).toFixed(precision)}%`;
}
