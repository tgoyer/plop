export const contains = (value, search) => (isNullOrEmpty(value) ? false : String(value).indexOf(search) >= 0);

export const padEnd = (value, targetLength, padString) => {
    return String(value).padEnd(targetLength, padString);
};

export const padStart = (value, targetLength, padString) => {
    return String(value).padStart(targetLength, padString);
};

export const isNotNullOrEmpty = (value) => !isNullOrEmpty(value);
export const isNullOrEmpty = (value) => value == null || String(value).trim() === '';
