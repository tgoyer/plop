﻿import { baseFontSize, convertRgbToHex, convertHexToRgb, calculateContrastColorRgb, calculateContrastColorHex, generateId, pxToRem } from './layoutHelper';

describe('==> Layout Helpers', () => {
    test('convertRgbToHex converts RGB color values to HEX', () => {
        const expected = '#ff0000';
        const actual = convertRgbToHex(255, 0, 0);

        expect(actual).toBe(expected);
    });

    test('convertHexToRgb converts HEX color values to RGB', () => {
        const expected = { b: 0, g: 0, r: 255 };
        const actual = convertHexToRgb('#ff0000');

        expect(actual.r).toBe(expected.r);
        expect(actual.g).toBe(expected.g);
        expect(actual.b).toBe(expected.b);
    });

    test('calculateContrastColorRgb calculates white color based on dark RGB value', () => {
        const expected = { b: 255, g: 255, r: 255 };
        const actual = calculateContrastColorRgb(255, 20, 20);

        expect(actual.r).toBe(expected.r);
        expect(actual.g).toBe(expected.g);
        expect(actual.b).toBe(expected.b);
    });

    test('calculateContrastColorRgb calculates black color based on light RGB value', () => {
        const expected = { b: 0, g: 0, r: 0 };
        const actual = calculateContrastColorRgb(255, 240, 240);

        expect(actual.r).toBe(expected.r);
        expect(actual.g).toBe(expected.g);
        expect(actual.b).toBe(expected.b);
    });

    test('calculateContrastColorHex calculates white color based on dark HEX value', () => {
        const expected = '#ffffff';
        const actual = calculateContrastColorHex('#336600');

        expect(actual).toBe(expected);
    });

    test('calculateContrastColorHex calculates black color based on light HEX value', () => {
        const expected = '#000000';
        const actual = calculateContrastColorHex('#ffccff');

        expect(actual).toBe(expected);
    });

    test('generateId generates a random 10-character string', () => {
        const expected = 10;
        const actual = generateId();

        expect(typeof actual).toBe('string');
        expect(actual.length).toBe(expected);
    });

    test('pxToRem with default base value', () => {
        const testSize = 7;
        const expected = `${testSize / baseFontSize}rem`; // assumes 13px base.  This value is configured in the library.
        const actual = pxToRem(testSize);

        expect(actual).toBe(expected);
    });
});
