import { contains } from './stringHelper';

const useHttps = true;

const port = useHttps ? '44360' : '8001';
const localApiRoot = `https://localhost:${port}`;

export const baseFontSize = 13; // the base root rem value.  Update this if you change the font-size in the app.js and/or view html, body css declaration.

/**
 * @description Converts supplied RGB values to a HEX color string.
 * @param {Number} r The RED value to calculate against.  Valid values are between 0-255 inclusive.
 * @param {Number} g The GREEN value to calculate against.  Valid values are between 0-255 inclusive.
 * @param {Number} b  The BLUE value to calculate against.  Valid values are between 0-255 inclusive.
 * @returns {string} The converted HEX color string.
 */
export const convertRgbToHex = (r, g, b) => {
    const hex = (c) => {
        const hex = c.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    };
    return '#' + hex(r) + hex(g) + hex(b);
};

/**
 * @description  Converts a supplied HEX value to an object of RGB values.
 * @param {string} hex The HEX value to calculate against.
 * @returns {Object} An object containing the RGB values derived from the supplied HEX color.
 */
export const convertHexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
        ? {
              r: parseInt(result[1], 16),
              g: parseInt(result[2], 16),
              b: parseInt(result[3], 16),
          }
        : null;
};

/**
 * @description  Converts a supplied HEX value to an object of RGBA values.
 * @param {string} hex The HEX value to calculate against.
 * @param {Number} alpha The alpha opacity value.
 * @returns {Object} An object containing the RGBA values derived from the supplied HEX color.
 */
export const convertHexToRgba = (hex, alpha) => {
    return {
        ...convertHexToRgb(hex),
        a: alpha,
    };
};

export const convertRgbaToCss = ({ r, g, b, a }) => {
    return `rgba(${r}, ${g}, ${b}, ${a != null ? a : '1'})`;
};

export const convertCssRgbToRgb = (cssRgb) => {
    if (cssRgb == null) return null;

    const values = cssRgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);

    return values == null
        ? null
        : {
              r: Number(values[1]),
              g: Number(values[2]),
              b: Number(values[3]),
          };
};

export const calculateBrightness = (colorHex, amount) => {
    const usePound = colorHex[0] === '#';

    if (usePound) {
        colorHex = colorHex.slice(1);
    }

    const num = parseInt(colorHex, 16);
    let b = ((num >> 8) & 0x00ff) + amount;
    let g = (num & 0x0000ff) + amount;
    let r = (num >> 16) + amount;

    if (b > 255) b = 255;
    else if (b < 0) b = 0;

    if (g > 255) g = 255;
    else if (g < 0) g = 0;

    if (r > 255) r = 255;
    else if (r < 0) r = 0;

    return (usePound ? '#' : '') + (g | (b << 8) | (r << 16)).toString(16).padStart(6, '0');
};

/**
 * @description Given RGB color values, calculate the correct constrast color based on W3C's AERT accessibility spec.
 * @param {Number} r The RED value to calculate against.  Valid values are between 0-255 inclusive.
 * @param {Number} g The GREEN value to calculate against.  Valid values are between 0-255 inclusive.
 * @param {Number} b  The BLUE value to calculate against.  Valid values are between 0-255 inclusive.
 * @returns {Object} An object containing the RGB values of the calculated contrast color.
 */
export const calculateContrastColorRgb = (r, g, b) => {
    // http://www.w3.org/TR/AERT#color-contrast
    var o = Math.round((parseInt(r, 10) * 299 + parseInt(g, 10) * 587 + parseInt(b, 10) * 114) / 1000);
    return o > 165 ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 };
};

/**
 * @description Given a HEX color value, calculate the correct constrast color based on W3C's AERT accessibility spec.
 * @param {String} hex The HEX value from which to calculate the contrasting value.
 * @returns {String} The HEX color value of the appropriate contrasting color
 */
export const calculateContrastColorHex = (hex) => {
    const rgb = convertHexToRgb(hex);
    const fgRgb = calculateContrastColorRgb(rgb.r, rgb.g, rgb.b);
    return convertRgbToHex(fgRgb.r, fgRgb.g, fgRgb.b);
};

/**
 * @description Generate a 10 character unique string value.
 */
export const generateId = () => [...Array(10)].map(() => Math.random().toString(36)[3]).join('');

export const getClosestParent = (elem, selector) => {
    if (!Element.prototype.matches) {
        Element.prototype.matches =
            Element.prototype.matchesSelector ||
            Element.prototype.mozMatchesSelector ||
            Element.prototype.msMatchesSelector ||
            Element.prototype.oMatchesSelector ||
            Element.prototype.webkitMatchesSelector ||
            function (s) {
                const matches = (this.document || this.ownerDocument).querySelectorAll(s);
                let i = matches.length;
                while (--i >= 0 && matches.item(i) !== this) {}
                return i > -1;
            };
    }

    for (; elem && elem !== document; elem = elem.parentNode) {
        if (elem.matches(selector)) return elem;
    }
    return null;
};

export const getEnvironment = () => {
    const host = String(window.location.host).toLowerCase();

    if (contains(host, 'localhost')) return 'LOCAL';
    if (contains(host, 'esight-vdev')) return 'DEVELOPMENT';
    if (contains(host, 'esight-uat') || contains(host, 'esight-qa')) return 'TEST';
    if (contains(host, 'esight.acml.com')) return 'PRODUCTION';

    return '';
};

export const getExtension = (fileName) => {
    return fileName != null ? String(fileName.match(/\.([0-9a-z]+)(?=[?#])|(\.)(?:[\w]+)$/gim)[0]).replace('.', '') : '';
};

export const getFullyQualifiedUrl = (resourcePath, version = 'v1') => {
    const {
        location: { origin, protocol, port, host },
    } = window;

    const uri = getEnvironment() === 'LOCAL' ? '' : origin == null ? `${protocol}//${host}${port !== '' && ':' + port}` : origin;

    return `${uri}${getResourceUrl(resourcePath, version)}`;
};

export const getResourceUrl = (resourcePath, version = 'v1') => {
    const api = getEnvironment() === 'LOCAL' ? `${localApiRoot}/api/${version}` : `/api/${version}`;

    return resourcePath == null || resourcePath === '' ? api : String(resourcePath).startsWith('/') ? api + resourcePath : api + '/' + resourcePath;
};

/**
 * @description Test if browser is a mobile device
 */
export const isMobileBrowser = () => {
    const agent = navigator.userAgent || navigator.vendor || window.opera;
    return (
        /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|mobileiron|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|playbook|silk/i.test(
            agent
        ) ||
        /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i.test(
            agent.substr(0, 4)
        )
    );
};

/**
 * @description Retrieve values from the URL Query string
 * @param {String} key The query string parameter key used to retieve the value.
 * @returns The value corresponding with the supplied key.
 */
export const getUrlParameter = (key) => {
    key = key.replace(/[[]/, '\\[').replace(/[\]]/, '\\]');
    const regex = new RegExp('[\\?&]' + key + '=([^&#]*)');
    const results = regex.exec(window.location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

export const KeyCodes = Object.freeze({
    ENTER: 'Enter',
    ESCAPE: 'Escape',
});

/**
 * @description Convert pixel values to relative em value based on the root html/body
 *              font-size.  This allows us to stil use "pixel" values in the styling,
 *              but render to rem for responsiveness.
 * @param {Number} pixels The pixel value to convert to rem
 * @param {bool} useImportant Add the !important clause onto the returned setting
 * @param {Number} basePixels An optional override in case you want to base the calculation on a value
 *              different from the root font-size.
 * @returns {String} The appropriate rem value for a CSS/Style rule.
 */
export const pxToRem = (pixels, useImportant = false, basePixels = baseFontSize) => {
    // const dpr = window.devicePixelRatio || 1;
    if (pixels == null) pixels = basePixels;

    return `${pixels / basePixels}rem${useImportant ? ' !important' : ''}`;
};

export const triggerEvent = (target, options) => {
    const event = target.ownerDocument.createEvent('MouseEvents');
    const opts = {
        // These are the default values, set up for un-modified left clicks
        type: 'click', // Defaults to a click event.  Can be overriden in the options.
        canBubble: true,
        cancelable: true,
        view: target.ownerDocument.defaultView,
        detail: 1,
        screenX: 0, //The coordinates within the entire page
        screenY: 0,
        clientX: 0, //The coordinates within the viewport
        clientY: 0,
        ctrlKey: false,
        altKey: false,
        shiftKey: false,
        metaKey: false, //I *think* 'meta' is 'Cmd/Apple' on Mac, and 'Windows key' on Win. Not sure, though!
        button: 0, //0 = left, 1 = middle, 2 = right
        relatedTarget: null,
    };
    options = options || {};

    //Merge the options with the defaults
    for (var key in options) {
        if (options.hasOwnProperty(key)) {
            opts[key] = options[key];
        }
    }

    //Pass in the options
    event.initMouseEvent(
        opts.type,
        opts.canBubble,
        opts.cancelable,
        opts.view,
        opts.detail,
        opts.screenX,
        opts.screenY,
        opts.clientX,
        opts.clientY,
        opts.ctrlKey,
        opts.altKey,
        opts.shiftKey,
        opts.metaKey,
        opts.button,
        opts.relatedTarget
    );

    //Fire the event
    target.dispatchEvent(event);
};
