import { padEnd, padStart } from './stringHelper';

describe('==> String Helpers', () => {
    test('padEnd() pads the string to the right', () => {
        const input = 'A';
        const expected = 'A--';
        const actual = padEnd(input, 3, '-');
        expect(actual).toBe(expected);
    });
    test('padStart() pads the string to the left', () => {
        const input = 'A';
        const expected = '--A';
        const actual = padStart(input, 3, '-');
        expect(actual).toBe(expected);
    });
});