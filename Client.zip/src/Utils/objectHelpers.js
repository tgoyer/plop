export const pluckFields = (obj, fields) => {
    if (!Array.isArray(fields) || obj == null) return null;

    const ret = {};
    const data = { ...obj };

    fields.forEach((field) => {
        ret[field] = data[field];
        delete data[field];
    });

    return [ret, data];
};

export const isNullOrUndefined = (value) => value === null || value === undefined;
