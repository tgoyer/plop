import { DateTime, Info } from 'luxon';

export const serverTimeZone = 'America/New_York';
export const dateFormat = 'MMM dd, yyyy';
export const dateTimeFormat = `${dateFormat} h:mm a`;
export const numericDateFormat = 'MM/dd/yyyy';
export const numericDateTimeFormat = `${numericDateFormat} h:mm a`;
export const debugDateFormat = 'MMM dd, yyyy - t ZZZZ';

/**
 * @description Formats a javascript date object based on the supplied format string.
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @param {String|Boolean} format Optional.  The format string to designate how to format the output.  Defaults to the "defaultFormat" constant at the top of this file.
 *      Uses Luxon formatting options.  See https://moment.github.io/luxon/docs/manual/formatting.html for options.
 * @returns {String} The formatted date string.
 */
export function formatDate(date, format = dateFormat) {
    return formatDateTime(date, format);
}

/**
 * @description Formats a javascript date object based on the supplied format string.
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @param {String|Boolean} format Optional.  The format string to designate how to format the output.  Defaults to the "defaultFormat" constant at the top of this file.
 *      Uses Luxon formatting options.  See https://moment.github.io/luxon/docs/manual/formatting.html for options.
 * @returns {String} The formatted date string.
 */
export function formatDateTime(date, format = dateTimeFormat) {
    const value = date != null ? toDateTime(date) : null;
    return value?.toFormat != null ? value.toFormat(format) : null;
}

/**
 * @description Converts a javascript date from the AB server time zone to local time.  Assumes date is from AB server.  Currently all AB servers sit in Eastern Time Zone.
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @returns {DateTime|null} A an instance of Luxon DateTime representing the server's local date/time. Currently Eastern Time Zone based.
 */
export function toLocalDateTime(date) {
    const value = toServerDateTime(date);
    return value != null ? value.setZone(DateTime.local().tz) : null;
}

/**
 * @description Get the locale string for the browser session.  Used for internationalization.
 * @returns {String} The locale string.
 */
export function getLocale() {
    return (
        (window.navigator.languages && window.navigator.languages[0]) || // Chrome / Firefox
        window.navigator.language || // All browsers
        window.navigator.userLanguage // IE <= 10
    );
}

/**
 * @description Generate and return a string array containing the localized months of the year
 * @param {String} format The format for the returned list.  Defaults to the long name (e.g. "January", "February", etc).
 *      Valid values are "numeric", "2-digit", "long", "short", "narrow". Note two months may have the same "narrow" format
 *      for some locales (e.g. March and May's narrow style are "M").
 * @param {String} locale The locale string used for formatting the returned string array.  Used for internationalization.
 * @returns {string[]}
 */
export function getMonthsList(format = 'long', locale = getLocale()) {
    return Info.months(format, { locale });
}

/**
 * @description Test to see if input is a valid date value
 * @param {String} date The value to be tested.
 * @returns {Boolean}
 */
export function isDate(date) {
    return toDateTime(date) != null;
}

/**
 * @description Generate a relative time output based on the current time and the time passed in.  Example:  "3 days ago" or "in 12 hours".
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @param {String} format Optional.  The format string to designate how to format the output.  Defaults to the "defaultFormat" constant at the top of this file.
 *      Uses Luxon formatting options.  See https://moment.github.io/luxon/docs/manual/formatting.html for options.
 * @returns {String} The "time ago" string.
 */
export function timeAgo(date, locale = getLocale(), format) {
    const units = ['year', 'month', 'week', 'day', 'hour', 'minute', 'second'];

    const dateTime = toDateTime(date);
    const diff = dateTime.diffNow().shiftTo(...units);
    const unit = units.find((unit) => diff.get(unit) !== 0) || 'second';

    const relativeFormatter = new Intl.RelativeTimeFormat(locale, {
        numeric: 'auto',
    });

    return relativeFormatter.format(Math.trunc(diff.as(unit)), unit);
}

/**
 * @description Converts a value to a Luxon DateTime representing the date at midnight or null.
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @returns {DateTime|null} The converted value set to midnight.
 */
export function toDate(date) {
    return toDateTime(date)?.startOf('day');
}

/**
 * @description Converts a value to a Luxon DateTime or null.
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @returns {DateTime|null} The converted value.
 */
export function toDateTime(date) {
    return date == null
        ? null
        : date?.setZone != null // Check to see if it's a Luxon DateTime
        ? date
        : DateTime.fromJSDate(date).isValid // JS Date object
        ? DateTime.fromJSDate(date)
        : DateTime.fromISO(date).isValid // ISO 8601 date string
        ? DateTime.fromISO(date)
        : DateTime.fromFormat(date, dateFormat).isValid // use default string format
        ? DateTime.fromFormat(date, dateFormat)
        : DateTime.fromFormat(date, numericDateFormat).isValid // use common string format
        ? DateTime.fromFormat(date, numericDateFormat)
        : DateTime.fromSQL(date).isValid // SQL date string
        ? DateTime.fromSQL(date)
        : null;
}

/**
 * @description Converts a javascript date and time from local time zone to the AB server time zone.  Currently "America/New_York".
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @returns {DateTime|null} A an instance of Luxon DateTime representing the server's local date/time. Currently "America/New_York".
 */
export function toServerDateTime(date) {
    const value = toDateTime(date);
    const server = value != null ? value.setZone(serverTimeZone) : null;
    return server;
}

/**
 * @description Converts a javascript date from local time zone to the AB server time zone.  Currently "America/New_York".
 * @param {Date|DateTime|string} date A javascript date instance, an instance of Luxon DateTime or an ISO8601 formatted string.
 * @returns {DateTime|null} A an instance of Luxon DateTime representing the server's local date/time. Currently "America/New_York".
 */
export function toServerDate(date) {
    const value = toDateTime(date);
    const server = value != null ? DateTime.fromObject({ year: value.year, month: value.month, day: value.day }, { zone: serverTimeZone }) : null;
    return server;
}
