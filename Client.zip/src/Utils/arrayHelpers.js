export const flattenArray = (arr) => Array.from(new Set(arr));

export const flattenKeys = (obj) =>
    Object.keys(obj).reduce((acc, key) => {
        const val = obj[key];

        if (typeof val === 'object') {
            acc = flattenArray([...acc, ...flattenKeys(val)]);
        } else {
            acc.push(key);
        }

        return acc;
    }, []);

export const flattenValues = (obj) =>
    Object.keys(obj).reduce((acc, key) => {
        const val = obj[key];

        if (typeof val === 'object') {
            acc = flattenArray([...acc, ...flattenValues(val)]);
        } else {
            acc.push(val);
        }

        return acc;
    }, []);

export const hasEntries = (arr) => arr != null && Array.isArray(arr) && arr.length > 0;
