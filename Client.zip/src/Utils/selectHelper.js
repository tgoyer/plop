/**
 * @description Takes a list of objects and returns back a list of label/value pairs.
 * @param {Array} list The source list of objects
 * @param {string} label The field name for the label.
 * @param {string} value The field name for the value.
 * @param {Array} disabledOptions Values that should appear disabled if present
 */
export const toOptionsList = (list, label, value, disabledOptions)=> {
    return list != null && list.length > 0 ? list.map((item) => toSingleOption(item, label, value, getIsDisabled(item[label], disabledOptions ? disabledOptions : []))) : [];
};

/**
 * @description Takes a single object and returns back a label/value pair.
 * @param {Array} item The source object.
 * @param {string} label The field name for the label.
 * @param {string} value The field name for the value.
 * @param {Boolean} isDisabled Should the field appear disabled
 */
export const toSingleOption = (item, label, value, isDisabled) => {
    return item != null ? { label: getValue(item, label), value: getValue(item, value), isDisabled: isDisabled} : null;
};

const getValue = (item, selector) => {
    if (typeof selector === 'function') {
        return selector(item);
    } else {
        return item[selector];
    }
};

const getIsDisabled = (option, disabledOptions) => disabledOptions.includes(option);
