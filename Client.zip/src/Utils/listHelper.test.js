import { merge, alphaNumericSort, findIndex } from './listHelper';

describe('==> List Helpers', () => {
    test('findIndex() finds the first matching index', () => {
        const list = [
            { test: 1, text: 'Plop 1' },
            { test: 2, text: 'Plop 2' },
            { test: 1, text: 'Plop 3' },
            { test: 2, text: 'Plop 4' },
            { test: 1, text: 'Plop 5' },
        ];
        const expected = 1;
        const actual = findIndex(list, (item) => item.test === 2);
        expect(actual).toBe(expected);
    });

    test('findIndex() returns -1 if not found', () => {
        const list = [
            { test: 1, text: 'Plop 1' },
            { test: 2, text: 'Plop 2' },
            { test: 1, text: 'Plop 3' },
            { test: 2, text: 'Plop 4' },
            { test: 1, text: 'Plop 5' },
        ];
        const expected = -1;
        const actual = findIndex(list, (item) => item.test === 12);

        expect(actual).toBe(expected);
    });

    test('merge() mergers two objects', () => {
        const dataPA = [
            { ID: 3119, Name: 'European Equity' },
            { ID: 3212, Name: 'Eurozone Equity' },
            { ID: 3214, Name: 'Australia Value' },
            { ID: 3215, Name: 'Australia Managed Volatility' },
        ];

        const dataMorePA = [
            { ID: 3119, Name: 'European Equity Change' },
            { ID: 3222, Name: 'New Thing 1' },
        ];

        const actual = merge(dataPA, dataMorePA, (source, data) => source.ID === data.ID);

        expect(actual.length).toBe(5);
        expect(actual[0].Name).toBe('European Equity Change');
    });

    test('merge() merges without mutating sources', () => {
        const dataPA = [
            { ID: 3119, Name: 'European Equity' },
            { ID: 3212, Name: 'Eurozone Equity' },
            { ID: 3214, Name: 'Australia Value' },
            { ID: 3215, Name: 'Australia Managed Volatility' },
        ];

        const dataMorePA = [
            { ID: 3119, Name: 'European Equity Change' },
            { ID: 3222, Name: 'New Thing 1' },
        ];

        const actual = merge(dataPA, dataMorePA, (source, data) => source.ID === data.ID);

        expect(dataPA.length).toBe(4);
        expect(dataMorePA.length).toBe(2);
        expect(actual.length).not.toBe(dataPA.length);
        expect(actual.length).not.toBe(dataMorePA.length);
        expect(dataPA[0].Name).not.toBe(dataMorePA[0].Name);
    });

    test('alphaNumericSort sorts numbers', () => {
        const data = [{ ID: 1 }, { ID: 5 }, { ID: 0 }, { ID: 2 }, { ID: 8 }, { ID: 4 }, { ID: 3 }, { ID: 6 }];

        const expected = '0, 1, 2, 3, 4, 5, 6, 8';
        const actual = data
            .sort(alphaNumericSort('ID'))
            .map((obj) => obj.ID)
            .join(', ');

        expect(actual).toBe(expected);
    });

    test('alphaNumericSort sorts strings', () => {
        const data = [{ ID: 'aa' }, { ID: 'av' }, { ID: 'ba' }, { ID: 'bq' }, { ID: 'aav' }, { ID: 'aba' }, { ID: 'qrt' }, { ID: 'qes' }];

        const expected = 'aa, aav, aba, av, ba, bq, qes, qrt';
        const actual = data
            .sort(alphaNumericSort('ID'))
            .map((obj) => obj.ID)
            .join(', ');

        expect(actual).toBe(expected);
    });

    test('alphaNumericSort sorts mixed value lists', () => {
        const expected = '11, 12, 13, 3, 3, 4, 4, 6a, 6b, 6c, 6d, 6e, 6f, 6g, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, A, B, C, D, E, F, G, H, I';
        const actual = mixedData
            .sort(alphaNumericSort('ID'))
            .map((obj) => obj.ID)
            .join(', ');

        expect(actual).toBe(expected);
    });
});

const mixedData = [
    { ID: '3' },
    { ID: '11' },
    { ID: '12' },
    { ID: '6b' },
    { ID: '6c' },
    { ID: '3' },
    { ID: '4' },
    { ID: '13' },
    { ID: '4' },
    { ID: '6.2' },
    { ID: '6.4' },
    { ID: 'E' },
    { ID: '6.3' },
    { ID: '6.6' },
    { ID: '6.1' },
    { ID: '6.5' },
    { ID: 'G' },
    { ID: 'H' },
    { ID: '6.7' },
    { ID: '6a' },
    { ID: '6d' },
    { ID: '6e' },
    { ID: '6g' },
    { ID: 'A' },
    { ID: 'D' },
    { ID: '6f' },
    { ID: 'F' },
    { ID: 'B' },
    { ID: 'C' },
    { ID: 'I' },
];
