import { CurrencyFormats, formatCurrency, fromPercent, roundDecimal, toPercent } from './numberHelper';

describe('==> Number Helpers', () => {
    test('formatCurrency() converts from a number to a formatted currency string', () => {
        const input = 12345678910.3456;
        const expected = "$12,345,678,910.35";
        const actual = formatCurrency(input);
        expect(actual).toBe(expected);
    });
    
    test('formatCurrency() converts from a number to a formatted currency string using a custom format', () => {
        const customFormat = { ...CurrencyFormats.USD, groupingSize: 2 }
        const input = 12345678910.3456;
        const expected = "$1,23,45,67,89,10.35";
        const actual = formatCurrency(input, customFormat);
        expect(actual).toBe(expected);
    });
    
    test('fromPercent() converts from a decimal to a percent value', () => {
        const input = 12.34567;
        const expected = 0.12346;
        const actual = fromPercent(input);
        expect(actual).toBe(expected);
    });
    
    test('roundDecimal() formats number to specified precision', () => {
        const input = 25.1234567;
        const expected = 25.1235;
        const actual = roundDecimal(input, 4);
        expect(actual).toBe(expected);
    });

    test('roundDecimal() ignores non-numeric values', () => {
        expect(roundDecimal(null, 4)).toBe(null);
        expect(roundDecimal('plop', 4)).toBe('plop');
    });

    test('toPercent() converts from a percent to a decimal value', () => {
        const input = 0.1234567;
        const expected = 12.346;
        const actual = toPercent(input);
        expect(actual).toBe(expected);
    });
});