export const getLocalData = (cacheName, key) => {
    const cacheData = JSON.parse(window.localStorage.getItem(cacheName));
    const data = cacheData != null && key != null
        ? cacheData[key]
        : cacheData
    return data;
}

export const setLocalData = (cacheName, key, data) => {
    const cachedData = { ...getLocalData(cacheName) };

    window.localStorage.setItem(
        cacheName, 
        JSON.stringify(key == null 
            ? { ...data }
            : { ...cachedData, [key]: data }
        )
    );

    return data;
}
