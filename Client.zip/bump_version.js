﻿import path from 'path';
import fs from 'fs';
import { cwd } from 'process';
import { readFile } from 'fs/promises';

(() => {
    writePackageVersion();

    /**
     * Updates the package.json with the new version number
     * @method writePackageVersion
     */
    async function writePackageVersion() {
        const packageJson = path.join(cwd(), 'package.json');
        const raw = JSON.parse(await readFile(packageJson, 'utf-8'));

        var buildVersionJson = path.join(cwd(), 'public/version.json');
        var now = new Date();

        var timestamp = now.getTime() / 1000;

        var firstPart = (Math.random() * timestamp) | 0;
        firstPart = firstPart.toString(16).slice(-3);

        var secondPart = (Math.random() * timestamp) | 0;
        secondPart = secondPart.toString(16).slice(-3);

        var buildHash = (firstPart + secondPart).toUpperCase();
        var date = `${now.getFullYear()}-${zeroPad(now.getMonth() + 1)}-${zeroPad(now.getDate())}`;
        var time = `${zeroPad(now.getHours())}:${zeroPad(now.getMinutes())}:${zeroPad(now.getSeconds())}`;

        raw.config.build = {
            version: raw.version,
            hash: buildHash,
            date: `${date} ${time}`,
        };

        fs.writeFileSync(buildVersionJson, JSON.stringify(raw.config.build, null, 2));
    }

    function zeroPad(value) {
        return value < 10 ? `0${value}` : value;
    }
})();
