This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Table of Contents

-   [Run the project](#run-the-project)
-   [Setup a developer certificate](#setup-dev-certificate)

## Run the project

```js
npm start
```

Once running, open a browser to https://localhost:3001

## Setup a developer certificate

To run a Vite project over HTTPS and make it accessible over the local network, you'll need to generate a local SSL certificate.

Generate a local SSL certificate.
You can use mkcert to create a locally-trusted certificate.

## Install mkcert

### MacOS

```js
brew install mkcert
```

### Windows

```js
choco install -y mkcert
```

## Install the local CA

```js
mkcert - install;
```

## Generate the certificate:

```js
mkcert localhost
```

This will generate two files: localhost.pem (the certificate) and localhost-key.pem (the private key).
Move them into the `./certs` folder. Create the folder if it does not exist.

```
mkdir certs
move *.pem ./certs
```

## Start project:

Start application as normal. It should now run in SSL/HTTPS.

```js
npm start
```
